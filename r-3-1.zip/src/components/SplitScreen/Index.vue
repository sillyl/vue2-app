<template>
  <div class="video_split_palyer">
    <div
      v-for="i in videoCheckList"
      :key="i"
      class="player-box"
      :style="liveStyle"
    >
      <WfsVideo
        :id="i"
        curLeft="33%"
        curTop="0px"
        isFull="true"
        @closedVideoId="getClosedVideoId"
      />
    </div>
  </div>
</template>

<script>
import WfsVideo from "@/components/VideoPlay/WfsVideo/Index.vue";
import VideoFullScreen from "../VideoPlay/WfsVideo/VideoFullScreen.vue";
import {
  localStorageGetItem,
  localStorageSetItem,
} from "@/utils/localStorageFun.js";
export default {
  data() {
    return {
      videoCheckList: [],
      videoUrl: [""],
      splitNum: 1,
      playerIdx: 0,
    };
  },
  mounted() {
    this.videoCheckList = localStorageGetItem("videoCheckList");
  },
  computed: {
    newWidth() {
      return `calc(50% - 2px*2)`;
    },
    liveStyle() {
      let style = { width: "100%", height: "100%" };
      switch (this.videoCheckList.length) {
        case 2:
          style = { width: "100%", height: this.newWidth };
          break;
        case 3:
          style = { width: this.newWidth, height: this.newWidth };
          break;
        case 4:
          style = { width: this.newWidth, height: this.newWidth };
          break;
      }
      return style;
    },
  },
  components: {
    WfsVideo,
    // VideoFullScreen,
  },
  methods: {
    getClosedVideoId: function (data) {
      const res = this.videoCheckList.filter((i) => i !== data);
      this.videoCheckList = res;
      localStorageSetItem("videoCheckList", res);
    },
  },
};
</script>
<style lang="scss" scoped>
.video_split_palyer {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-wrap: wrap;
  .player-box {
    // background-color: #000000;
    border: 2px solid #505050;
  }

  .video_player_wfs {
    position: relative;
    top: 0px !important;
    left: 0px !important;
    height: 100%;
    width: 100%;
    border: none;
  }
}
</style>
