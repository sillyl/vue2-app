<template>
  <div class="button_options_group">
    <div
      class="button_options_group_content"
      v-for="(i, idx) in data.group"
      :key="i.id + idx"
    >
      <p v-if="i.name" class="controls_p_name">{{ i.name }}</p>
      <ButtonOptions
        :data="i"
        :arr="i.packages"
        :id="`button_options_${i.id}_${i.pageId}_${i.layout}_${idx}`"
      />
    </div>
  </div>
</template>

<script>
import ButtonOptions from "../ButtonOptions/Index.vue";
export default {
  props: ["data"],
  data() {
    return {};
  },
  components: {
    ButtonOptions,
  },
};
</script>

<style lang="scss" scoped>
.button_options_group {
  position: relative;
  &_content {
    display: flex;
    align-items: center;
    justify-content: space-around;
    margin-bottom: 8px;
  }
}
</style>
