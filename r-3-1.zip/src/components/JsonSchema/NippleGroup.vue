<template>
  <div class="nipple_group" v-if="data">
    <div
      class="nipple_group_content"
      v-for="(i, idx) in data.group"
      :key="(i.groupId || i.id) + idx"
    >
      <p v-if="i.name" class="controls_p_name">{{ i.name }}</p>
      <div class="nipple_group_content_nipple">
        <Nipple
          :joystickId="`joystickGroup_${idx}_${i.id}_${i.layout}`"
          class="nipple_item"
          :group="true"
          :lockX="i?.lockX"
          :lockY="i?.lockY"
          :ctrlMode="true"
          :paramsData="i"
        >
          <div class="joystick_desc">{{ i.desc }}</div>
        </Nipple>
      </div>
    </div>
  </div>
</template>

<script>
import Nipple from "@/components/Nipple/Index.vue";
export default {
  props: ["data"],
  data() {
    return {};
  },
  components: {
    Nipple,
  },
};
</script>

<style lang="scss" scoped>
.nipple_group {
  &_content {
    display: flex;
    // justify-content: space-around;
    align-items: center;

    .nipple_item + .nipple_item {
      margin-left: 40px;
    }

    &_nipple {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
    }
  }
}
</style>
