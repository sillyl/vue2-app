<template>
  <div class="infoBox" id="infoBox">
    <div
      class="circle"
      :style="{ top: top - 5 + 'px', left: left - 5 + 'px' }"
    ></div>
    <div
      class="content"
      id="content"
      :style="{ top: contentTop + 'px', left: contentLeft + 'px' }"
    >
      <el-form
        ref="formRef"
        :model="form.selectPoint"
        label-width="80px"
        size="small"
      >
        <el-form-item label="经度">
          <el-input v-model="form.selectPoint.location.x" disabled></el-input>
        </el-form-item>
        <el-form-item label="纬度">
          <el-input v-model="form.selectPoint.location.y" disabled></el-input>
        </el-form-item>
        <!-- <el-form-item label="航向角">
          <el-input v-model="form.selectPoint.location.omega"></el-input>
        </el-form-item> -->
        <el-form-item label="过程属性" prop="process" v-if="!isMapCorrection">
          <span class="action-add">
            <i
              class="el-icon-circle-plus-outline"
              @click="addProcessItem()"
            />添加
          </span>
          <div
            class="form-items-label"
            v-if="form.selectPoint.process.length > 0"
          >
            <span>目标物</span>
            <span>动作</span>
          </div>
          <div
            class="form-items"
            v-for="(item, index) in form.selectPoint.process"
            :key="index"
          >
            <el-row>
              <el-col :span="9">
                <el-select
                  v-model="form.selectPoint.process[index].target"
                  placeholder="--请选择--"
                >
                  <el-option
                    v-for="item in form.identifierList"
                    :key="item.code"
                    :label="item.name"
                    :value="item.code"
                  ></el-option>
                </el-select>
              </el-col>
              <el-col :span="9">
                <el-select
                  v-model="form.selectPoint.process[index].action"
                  placeholder="--请选择--"
                >
                  <el-option
                    v-for="item in form.metaTaskList"
                    :key="item.method"
                    :label="item.name"
                    :value="item.method"
                  ></el-option>
                </el-select>
              </el-col>
              <el-col :span="2">
                <i class="el-icon-delete" @click="deleteProcessItem(index)" />
              </el-col>
            </el-row>
            <hr />
          </div>
        </el-form-item>
        <!-- <el-form-item label="节点属性" prop="station">
          <span class="action-add">
            <i
              class="el-icon-circle-plus-outline"
              @click="addStationItem()"
            />添加
          </span>
          <div
            class="form-items-label"
            v-if="form.selectPoint.station.length > 0"
          >
            <span>目标物</span>
            <span>动作</span>
          </div>
          <div
            class="form-items"
            v-for="(item, index) in form.selectPoint.station"
            :key="index"
          >
            <el-row>
              <el-col :span="9">
                <el-select
                  v-model="form.selectPoint.station[index].target"
                  placeholder="--请选择--"
                >
                  <el-option
                    v-for="item in form.identifierList"
                    :key="item.code"
                    :label="item.name"
                    :value="item.code"
                  ></el-option>
                </el-select>
              </el-col>
              <el-col :span="9">
                <el-select
                  v-model="form.selectPoint.station[index].action"
                  placeholder="--请选择--"
                >
                  <el-option
                    v-for="item in form.metaTaskList"
                    :key="item.method"
                    :label="item.name"
                    :value="item.method"
                  ></el-option>
                </el-select>
              </el-col>
              <el-col :span="2">
                <i class="el-icon-delete" @click="deleteStationItem(index)" />
              </el-col>
            </el-row>
            <hr />
          </div>
        </el-form-item> -->
        <el-form-item>
          <el-button @click="onDelete">{{
            curMethod === "TASK_NAVIGATION" ? "删除" : "取消"
          }}</el-button>
          <el-button type="primary" @click="onSave">{{
            isMapCorrection ? "确定" : curOpt === "add" ? "添加" : "更新"
          }}</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
import { isEqual } from "lodash";
export default {
  props: [
    "identifierList",
    "metaTaskList",
    "markerData",
    "curTop",
    "curLeft",
    "curCTop",
    "curCLeft",
    "deletePoint",
    "savePoint",
    "curOpt",
    "curMethod",
    "isMapCorrection",
  ],
  data() {
    return {
      left: this.curLeft,
      top: this.curTop,
      contentLeft: this.curCLeft,
      contentTop: this.curCTop,
      form: {
        identifierList: this.identifierList || [], // 目标物
        metaTaskList: this.metaTaskList || [], // 动作
        selectPoint: {
          location: {
            omega: this.markerData.omega || 0,
            x: this.markerData.longitude,
            y: this.markerData.latitude,
          },
          process: this.markerData.process || [],
          station: this.markerData.station || [],
        }, // 选择点
      },
    };
  },
  watch: {
    curTop: function (newVal, oldVal) {
      this.top = newVal;
    },
    curLeft: function (newVal, oldVal) {
      this.left = newVal;
    },
    curCTop: function (newVal, oldVal) {
      this.contentTop = newVal;
    },
    curCLeft: function (newVal, oldVal) {
      this.contentLeft = newVal;
    },
    markerData: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.form.selectPoint.location.x = newVal?.longitude;
        this.form.selectPoint.location.y = newVal?.latitude;
        this.form.selectPoint.location.omega = newVal?.omega;
        this.form.selectPoint.process = newVal?.process;
        this.form.selectPoint.station = newVal?.station;
      }
    },
  },
  methods: {
    // 操作form 函数
    addProcessItem: function () {
      this.form.selectPoint.process.push({ target: "", action: "" });
    },
    deleteProcessItem: function (index) {
      this.form.selectPoint.process.splice(index, 1);
    },
    addStationItem: function () {
      this.form.selectPoint.station.push({ target: "", action: "" });
    },
    deleteStationItem: function (index) {
      this.form.selectPoint.station.splice(index, 1);
    },
    onDelete() {
      // 重置form内容
      this.form.selectPoint = {
        location: { omega: 0, x: null, y: null },
        process: this.markerData.process || [],
        station: [],
      };
      if (this.deletePoint) {
        this.deletePoint();
      }
    },
    onSave() {
      // 传递父组件需要数据
      this.savePoint(this.form?.selectPoint);
    },
  },
};
</script>
<style lang="scss" scoped>
@import "@/assets/css/common.scss";
.infoBox {
  .content {
    z-index: 3;
    border: 1px solid #ccc;
    padding: 10px;
    background: aliceblue;
    position: absolute;
    max-height: 420px;
    overflow: auto;
  }

  .el-form {
    width: 250px;

    .el-form-item {
      margin-bottom: 10px;

      .el-input {
        width: 89%;
      }
    }

    .form-items {
      margin-left: -80px;

      .el-row:nth-child(1) {
        margin-top: 4px;
      }

      .el-col {
        margin-right: 8px;
      }

      .el-col:nth-child(1) {
        margin-right: 13px;
      }

      hr {
        height: 0.1px;
        border: none;
        background-color: #d5e0f1;
      }
    }

    .action-add,
    .el-icon-delete {
      color: $primary-color;
    }

    .form-items-label {
      margin-left: -80px;
      background: #fdf5e6;
      color: #606266;

      span {
        display: inline-block;
        width: 37.5%;
        margin-left: 8px;
      }
    }
  }

  .circle {
    position: absolute;
    z-index: 4;
    width: 10px;
    height: 10px;
    background-color: rgb(255, 0, 136);
    border-radius: 50%;
    border: 2px solid #d5e0f1;
    animation: circlePoint 1s infinite;

    @keyframes circlePoint {
      0% {
        border-color: #d5e0f1;
        box-shadow: 0 0 2px #d5e0f1;
      }
      50% {
        border-color: rgb(255, 0, 136);
        box-shadow: 0 0 5px rgb(255, 0, 136);
      }
      100% {
        border-color: #d5e0f1;
        box-shadow: 0 0 2px #d5e0f1;
      }
    }
  }
}
</style>
