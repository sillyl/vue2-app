<template>
  <el-form
    ref="form"
    :rules="rules"
    :model="form"
    label-width="100px"
    class="map_form"
  >
    <el-row>
      <el-col :span="7">
        <el-form-item label="名称" prop="name" class="map_form_name">
          <el-input v-model="form.name" :disabled="disabledForm"></el-input>
        </el-form-item>
        <el-form-item label="地图类型" prop="type" required>
          <el-select
            v-model="form.type"
            placeholder="请选择地图类型"
            :disabled="optType === 'edit' ? true : disabledForm"
          >
            <el-option
              v-for="val in mapTypeList"
              :key="val.type"
              :label="val.describe"
              :value="val.type"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="文件类型" prop="fileType" required>
          <el-select
            v-model="form.fileType"
            placeholder="请选择文件类型"
            :disabled="disabledForm"
          >
            <el-option
              v-for="item in fileTypeList"
              :key="item"
              :label="item"
              :value="item"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="地图包" prop="file" required>
          <el-upload
            action="upload"
            :limit="1"
            :show-file-list="false"
            :http-request="uploadMap"
            accept=".zip"
          >
            <el-button size="small" type="primary" :disabled="disabledForm"
              >点击上传地图包</el-button
            >
            <!-- <div slot="tip" class="el-upload__tip">
              只能上传jar文件，且不超过10M
            </div> -->
          </el-upload>
        </el-form-item>
      </el-col>
      <el-col :span="14" v-if="this.form.type === 2 && optType !== 'create'">
        <el-form-item
          label="中心经纬度"
          prop="location"
          class="map_form_location map_form_item"
        >
          <el-input
            v-model="form.location.jd"
            placeholder="请输入经度"
            :disabled="disabledForm"
          >
            <span slot="prefix">经 度</span>
          </el-input>
          <el-input
            v-model="form.location.wd"
            placeholder="请输入纬度"
            :disabled="disabledForm"
          >
            <span slot="prefix">纬 度</span>
          </el-input>
          <el-input
            v-model="form.location.gc"
            placeholder="请输入高程"
            :disabled="disabledForm"
          >
            <span slot="prefix">高 程</span>
          </el-input>
        </el-form-item>
        <el-form-item
          label="缩放比例"
          prop="zoom"
          class="map_form_zoom map_form_item"
        >
          <el-input
            v-model="form.zoom.min"
            placeholder="请输入最小缩放值"
            :disabled="disabledForm"
          >
            <span slot="prefix">最小值</span>
          </el-input>
          <el-input
            v-model="form.zoom.max"
            placeholder="请输入最大缩放值"
            :disabled="disabledForm"
          >
            <span slot="prefix">最大值</span>
          </el-input>
        </el-form-item>
        <el-form-item
          label="地图层级"
          prop="level"
          class="map_form_level map_form_item"
        >
          <el-input
            v-model="form.level.min"
            placeholder="输入最低层级"
            :disabled="disabledForm"
          >
            <span slot="prefix">最小值</span>
          </el-input>
          <el-input
            v-model="form.level.max"
            placeholder="输入最高层级"
            :disabled="disabledForm"
          >
            <span slot="prefix">最大值</span>
          </el-input>
        </el-form-item>
        <el-form-item
          label="边界经纬度"
          prop="rectangle"
          class="map_form_rectangle map_form_item"
        >
          <el-input
            v-model="form.rectangle.west"
            placeholder="输入边界西经度"
            :disabled="disabledForm"
          >
            <span slot="prefix">西经度</span>
          </el-input>
          <el-input
            v-model="form.rectangle.east"
            placeholder="输入边界东经度"
            :disabled="disabledForm"
          >
            <span slot="prefix">东经度</span>
          </el-input>
          <el-input
            v-model="form.rectangle.north"
            placeholder="输入边界北纬度"
            :disabled="disabledForm"
          >
            <span slot="prefix">北纬度</span>
          </el-input>
          <el-input
            v-model="form.rectangle.south"
            placeholder="输入边界南纬度"
            :disabled="disabledForm"
          >
            <span slot="prefix">南纬度</span>
          </el-input>
        </el-form-item>
      </el-col>
      <el-col :span="3" class="map_form_col_3">
        <div class="map_form_opts">
          <slot></slot>
        </div>
      </el-col>
    </el-row>
  </el-form>
</template>
<script>
import { getMapTypeList, getMapInfo } from "@/api/map";
import { fileTypeList } from "@/constants/index";
import { isEqual } from "lodash";
import { strToObj } from "@/utils/index";
import dayjs from "dayjs";
export default {
  props: ["optType", "formData"],
  data() {
    return {
      form: this.formData || {
        name: `map${dayjs(new Date().getTime()).format("YYYYMMDDHHmmss")}`,
        type: 2,
        fileType: "png",
        file: null,
        location: {
          jd: "",
          wd: "",
          gc: "",
        },
        zoom: {
          min: 200,
          max: 1000,
        },
        level: {
          min: 1,
          max: 20,
        },
        rectangle: {
          west: "",
          east: "",
          north: "",
          south: "",
        },
      },
      disabledForm: false, //全面禁掉form
      mapTypeList: [],
      fileTypeList: fileTypeList,
      rules: {
        name: [
          {
            required: true,
            validator: this.validateName,
            trigger: ["blur", "change"],
          },
        ],
        location: [
          {
            required: true,
            validator: this.validateLocation,
            trigger: ["blur", "change"],
          },
        ],
        zoom: [
          {
            required: true,
            validator: this.validateZoom,
            trigger: ["blur", "change"],
          },
        ],
        level: [
          {
            required: true,
            validator: this.validateLevel,
            trigger: ["blur", "change"],
          },
        ],
        rectangle: [
          {
            required: true,
            validator: this.validateRectangle,
            trigger: ["blur", "change"],
          },
        ],
      },
    };
  },
  mounted() {
    if (this.optType) {
      //详情
      // this.getMapInfo();
      if (this.optType === "info") {
        this.disabledForm = true;
      } else {
        //编辑
        this.disabledForm = false;
      }
    }
    this.getMapTypeList();
  },
  watch: {
    formData: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.form = this.formData;
      }
    },
    optType: function (newVal, oldVal) {
      if (newVal === "info") {
        this.disabledForm = true;
        this.getMapInfo(); // 编辑之后，前端不存数据，直接冲接口获取最新数据
      } else {
        //编辑
        this.disabledForm = false;
      }
      if (oldVal !== newVal) {
        return true;
      }
    },
    // $route: function (newVal, oldVal) {
    //   if (!isEqual(newVal, oldVal)) {
    //     // this.getMapInfo();
    //   }
    // },
  },
  methods: {
    getMapInfo: async function () {
      const res = await getMapInfo(this.$route.params);
      if (res) {
        this.form = {
          ...res,
          location: strToObj(res.location, ["jd", "wd", "gc"]),
          level: strToObj(res.level, ["min", "max"]),
          zoom: strToObj(res.zoom, ["min", "max"]),
          rectangle: strToObj(res.rectangle, [
            "west",
            "east",
            "north",
            "south",
          ]),
        };
      }
    },
    getMapTypeList: async function () {
      try {
        this.mapTypeList = await getMapTypeList();
      } catch (error) {
        this.mapTypeList = [];
        throw error;
      }
    },
    validateName: function (rule, value, callback) {
      if (value.trim() === "") {
        callback(new Error("请输入名称"));
      } else {
        callback();
      }
    },

    validateLocation: function (rule, value, callback) {
      const { gc, jd, wd } = value;
      if (gc.trim() === "" || gc.trim() === "-") {
        callback(new Error("请输入高程"));
      } else if (jd.trim() === "" || jd.trim() === "-") {
        callback(new Error("请输入经度"));
      } else if (wd.trim() === "" || wd.trim() === "-") {
        callback(new Error("请输入纬度"));
      } else {
        callback();
      }
    },

    validateZoom: function (rule, value, callback) {
      const { min, max } = value;
      if (String(min).trim() === "" || String(min).trim() === "-") {
        callback(new Error("请输入最小值"));
      } else if (String(max).trim() === "" || String(max).trim() === "-") {
        callback(new Error("请输入最大值"));
      } else {
        callback();
      }
    },

    validateLevel: function (rule, value, callback) {
      const { min, max } = value;
      if (String(min).trim() === "" || String(min).trim() === "-") {
        callback(new Error("请输入最小值"));
      } else if (String(max).trim() === "" || String(max).trim() === "-") {
        callback(new Error("请输入最大值"));
      } else {
        callback();
      }
    },

    validateRectangle: function (rule, value, callback) {
      const { west, east, north, south } = value;
      if (west.trim() === "" || west.trim() === "-") {
        callback(new Error("请输入西经度"));
      } else if (east.trim() === "" || east.trim() === "-") {
        callback(new Error("请输入东经度"));
      } else if (north.trim() === "" || north.trim() === "-") {
        callback(new Error("请输入北纬度"));
      } else if (south.trim() === "" || south.trim() === "-") {
        callback(new Error("请输入南纬度"));
      } else {
        callback();
      }
    },

    uploadMap: function (content) {
      this.form.file = content.file;
    },
    resetFormData: function () {
      this.$refs.form.resetFields();
    },
  },
};
</script>
<style lang="scss" scoped>
@import "./Index.scss";
</style>
