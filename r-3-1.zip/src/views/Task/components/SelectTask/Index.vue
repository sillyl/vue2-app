<template>
  <el-menu mode="horizontal" @select="handleSelect">
    <el-submenu index="task">
      <template slot="title">创建任务</template>
      <el-menu-item v-for="i in taskList" :key="i.id" :index="i.id">{{
        i.name
      }}</el-menu-item>
    </el-submenu>
  </el-menu>
</template>

<script>
import { getSceneMetaTaskList } from "@/api/task";
import { isEmpty } from "lodash";
export default {
  name: "SelectTask",
  props: ["optsType", "onClickTaskBtn", "onInitPickup"],
  data() {
    return {
      taskList: [],
    };
  },
  mounted() {
    this.getTaskList();
  },
  methods: {
    getTaskList: async function () {
      this.taskList = await getSceneMetaTaskList({ type: 1 });
    },
    handleSelect(key) {
      const arr = this.taskList?.filter((i) => i.id === key);
      const obj = !isEmpty(arr) ? arr[0] : {};
      this.$store.commit("updateIsTask", {
        isTask: true,
        curTaskInfo: { ...obj, optsType: this.optsType || "add" },
      });
      if (this.onClickTaskBtn) {
        this.onClickTaskBtn(obj);
      }
      if (this.onInitPickup) {
        this.onInitPickup(true);
      }
    },
  },
};
</script>

<style lang="scss" scoped>
@import "@/assets/css/common.scss";
.el-menu {
  display: inline-block;
  background-color: transparent;

  ::v-deep {
    .el-submenu {
      .el-submenu__title {
        height: 34px;
        line-height: 34px;
        padding: 0 16px;
        font-size: 12px;
        background-color: $btn-primary-color;
        color: #fff;
        border-radius: 4px;
        .el-submenu__icon-arrow {
          display: none;
        }
      }
    }
  }
}
.el-menu.el-menu--horizontal {
  border-bottom: 0px;
}
</style>
