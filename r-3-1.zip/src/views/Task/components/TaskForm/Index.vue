<template>
  <el-form
    ref="form"
    :rules="rules"
    :model="form"
    label-width="100px"
    class="task_form"
  >
    <el-row>
      <el-col :span="8">
        <el-form-item label="任务名称" prop="name" required>
          <el-input
            v-model="form.name"
            :disabled="disabledForm"
            placeholder="请输入任务名称"
          ></el-input>
        </el-form-item>
        <el-form-item label="场景选择" prop="scenceId" class="task_form_name">
          <el-select
            v-model="form.scenceId"
            placeholder="请选择"
            @change="onChangeScene"
            @visible-change="visibleChange"
            :disabled="isCurPage === 'sceneDetail' || sceneIdDisabled"
          >
            <el-option
              v-for="item in sceneList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="设备选择" prop="deviceIds" class="task_form_name">
          <el-select
            v-model="form.deviceIds"
            placeholder="请选择"
            multiple
            clearable
            :disabled="deviceDisabled"
          >
            <el-option
              v-for="item in deviceList"
              :key="item.key"
              :label="item.label"
              :value="item.key"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item
          label="生成地图名称"
          prop="mapName"
          required
          v-if="$store.state.curTaskInfo.method === 'TASK_MAPPING'"
        >
          <el-input
            v-model="form.mapName"
            :disabled="disabledForm"
            placeholder="请输入地图名称"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="循环次数"
          prop="circulate"
          v-if="
            $store.state.curTaskInfo.method === 'TASK_NAVIGATION' ||
            $store.state.curTaskInfo.method === 'TASK_INVESTIGATE'
          "
        >
          <el-input-number
            v-model="form.circulate"
            controls-position="right"
            :min="1"
            :max="10"
          ></el-input-number>
        </el-form-item>
      </el-col>
      <el-col :span="8">
        <el-form-item
          label="导航点"
          v-if="$store.state.curTaskInfo.method === 'TASK_NAVIGATION'"
          class="task_form_item_point"
        >
          <el-button
            v-if="optsType !== 'update'"
            type="primary"
            @click="onClickNavPoints"
            :disabled="disabledNav"
            >拾取导航点</el-button
          >
          <el-button type="primary" @click="onClearNavPoint"
            >清空导航点</el-button
          >
          <div class="cur_location" v-if="isCurPage !== 'sceneDetail'">
            <el-button
              type="primary"
              @click="onNavClick"
              :disabled="!disabledNav"
              >当前位置点设置为导航点</el-button
            >
          </div>
        </el-form-item>
        <el-form-item
          label="区域点"
          class="task_form_item_point"
          v-if="$store.state.curTaskInfo.method === 'TASK_INVESTIGATE'"
        >
          <el-button
            type="primary"
            @click="
              onBoundaryPoints(
                optsType !== 'update'
                  ? isShowBoundary
                    ? 'add'
                    : 'save'
                  : 'save'
              )
            "
            >{{
              optsType !== "update"
                ? isShowBoundary
                  ? "拾取边界点"
                  : "保存边界点"
                : "保存边界点"
            }}</el-button
          >
          <el-button type="primary" @click="onClearBoundaryPoints"
            >清空边界点</el-button
          >
          <div class="cur_location" v-if="isCurPage !== 'sceneDetail'">
            <el-button
              type="primary"
              @click="onCurBoundaryPoints"
              :disabled="isShowBoundary || curOpts === 'save'"
              >当前位置点设置为边界点</el-button
            >
          </div>
        </el-form-item>
        <el-form-item
          :label="
            tasksMethods[$store.state.curTaskInfo.method].substr(0, 2) + '目标'
          "
          prop="target"
          v-if="
            $store.state.curTaskInfo.method === 'TASK_GRAB' ||
            $store.state.curTaskInfo.method === 'TASK_RECOGNITION' ||
            $store.state.curTaskInfo.method === 'TASK_TRACKING'
          "
        >
          <el-select v-model="form.target" placeholder="请选择" clearable>
            <el-option
              v-for="item in grabTarget"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item
          label="执行动作"
          prop="action"
          v-if="$store.state.curTaskInfo.method === 'TASK_RECOGNITION'"
        >
          <el-select v-model="form.action" placeholder="请选择" clearable>
            <el-option
              v-for="item in actionList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item
          label="队形"
          prop="formation"
          v-if="$store.state.curTaskInfo.method !== 'TASK_MAPPING'"
        >
          <el-select v-model="form.formation" placeholder="请选择" clearable>
            <el-option
              v-for="item in formationList"
              :key="item"
              :label="item"
              :value="item"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item
          label="地图合并"
          v-if="$store.state.curTaskInfo.method === 'TASK_MAPPING'"
        >
          <el-radio-group v-model="form.mapConflation">
            <el-radio label="process">过程中合并</el-radio>
            <el-radio label="complete">完成时合并</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-col>
      <el-col :span="3" class="task_form_col_3">
        <div class="task_form_opts">
          <slot></slot>
        </div>
      </el-col>
    </el-row>
  </el-form>
</template>
<script>
import { getDeviceAllList } from "@/api/device";
import { isEqual } from "lodash";
import { formationList } from "../../constants";
import { getIdentifierList } from "@/api/identify";
import { getSceneMetaTaskList, getTaskDetail } from "@/api/task";
import { getSenceMenuList } from "@/api/scene.js";
import { getSceneDetail } from "@/api/scene";
import dayjs from "dayjs";
import { tasksMethods } from "../../constants";

export default {
  props: [
    "selectSceneInfo",
    "optsType",
    "getCurTaskInfoPoints",
    "resetMapData",
    "onClickNavPoint",
    "onClearBoundaryPoint",
    "saveBoundaryPoint",
    "updateCurSceneMapObj",
    "deviceCurScenceId",
    "isCurPage",
    "buildMapping",
    "clickCurNavPoint",
    "onClickCurBdyPoints",
  ],
  data() {
    return {
      form: {
        id: "",
        name:
          this.$store.state.curTaskInfo.name +
          dayjs(new Date().getTime()).format("YYYYMMDDHHmmss"),
        scenceId: "",
        deviceIds: [],
        target: "", // 抓取目标
        curTargetName: "", // 目标 label 名称
        formation: "", // 队形
        circulate: 1, // 循环次数
        zonePoint: "", // 区域点
        action: "", // 动作
        mapConflation: "complete", // 地图合并
        mapName: `map${dayjs(new Date().getTime()).format("YYYYMMDDHHmmss")}`,
        mappingType: 0, // 默认手动
      },
      disabledForm: false, //全面禁掉form
      deviceList: [],
      deviceDisabled: false,
      formationList: formationList || [],
      grabTarget: [], // 抓取目标 List
      actionList: [], // 动作 List
      sceneList: [],
      sceneIdDisabled: false,
      rules: {
        name: [
          {
            required: true,
            validator: this.validateName,
            trigger: ["blur", "change"],
          },
        ],
        scenceId: [
          {
            required: true,
            validator: this.validateSceneId,
            trigger: ["blur", "change"],
          },
        ],
        deviceIds: [
          {
            required: true,
            trigger: ["blur", "change"],
          },
        ],
      },
      taskInfo: {},
      disabledNav: false,
      isShowBoundary: true,
      tasksMethods,
      curOpts: "", // 标识边界点是拾取还是保存
    };
  },

  async mounted() {
    // 设备详情不清空 websoket： device-travel
    this.resetMapData();
    if (this.optsType === "update") {
      //详情
      await this.getTaskInfo();
    }
    await this.getSenceMenuList();
    await this.getDeviceList();
    this.deviceIdDisabledFun();
  },
  watch: {
    "$store.state.curTaskInfo": function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        if (this.optsType === "update") {
          this.getTaskInfo();
        } else {
          if (!(this.selectSceneInfo?.name || this.deviceCurScenceId)) {
            const obj = (this.sceneList || [])?.find(
              (i) => i.defaultScence === true
            );
            this.form.scenceId = obj && obj.id;
          }
        }
      }
    },
  },
  methods: {
    getTaskInfo: async function () {
      try {
        // 编辑的时候 参数已store 数据为准
        const params =
          this.$store.state.curTaskInfo.id && this.$store.state.curTaskInfo;
        this.taskInfo = await getTaskDetail(params);
        if (this.taskInfo) {
          const {
            circulate,
            point,
            formation,
            mapConflation,
            mapName,
            mappingType,
          } = this.taskInfo?.params;
          this.form = {
            ...this.taskInfo,
            circulate,
            point,
            formation,
            mapConflation,
            mapName,
            mappingType,
          };

          // 编辑导航任务时，默认开启
          if (this?.getCurTaskInfoPoints) {
            if (this.taskInfo.method === "TASK_INVESTIGATE") {
              this?.getCurTaskInfoPoints(
                [this.taskInfo],
                true,
                this.taskInfo.method,
                this.optsType
              );
            } else {
              this?.getCurTaskInfoPoints(
                [this.taskInfo],
                false,
                this.taskInfo.method,
                this.optsType
              );
            }
          }
        } else {
          this.resetFormData();
        }
      } catch (error) {
        this.taskInfo = null;
        throw error;
      }
    },
    getSenceMenuList: async function () {
      const res = await getSenceMenuList();
      this.sceneList = res?.map((i) => {
        return { ...i, scenceId: i?.id };
      });
      const obj = res.find((i) => i.defaultScence === true);
      // 新建任务时，场景信息中场景名称不存在已默认场景，否则新建任务场景为当前场景
      if (this.optsType !== "update") {
        if (!(this.selectSceneInfo?.name || this.deviceCurScenceId)) {
          this.form.scenceId = obj && obj.id;
          // 拉取默认场景 detail 信息，相当于切换到默认场景的操作
          this.onChangeScene(obj.id);
        } else {
          this.form.scenceId =
            this.selectSceneInfo?.id || this.deviceCurScenceId;
        }
      }
      this.sceneIdDisabledFun();
    },
    getDeviceList: async function () {
      try {
        const res = await getDeviceAllList({ matchScence: false });
        this.deviceList = res;
        // 条件控制不同界面调用相应的接口，避免调取接口冗余
        if (
          this.$store.state.curTaskInfo.method === "TASK_GRAB" ||
          this.$store.state.curTaskInfo.method === "TASK_RECOGNITION" ||
          this.$store.state.curTaskInfo.method === "TASK_TRACKING"
        ) {
          this.grabTarget = await getIdentifierList();
          if (this.$store.state.curTaskInfo.method === "TASK_RECOGNITION") {
            this.actionList = await getSceneMetaTaskList({ type: 2 });
          }
        }
      } catch (error) {
        this.deviceList = [];
        this.grabTarget = [];
        throw error;
      }
    },

    validateName: function (rule, value, callback) {
      if (value && value.trim() === "") {
        callback(new Error("请输入任务名称"));
      } else {
        callback();
      }
    },
    validateSceneId: function (rule, value, callback) {
      if (!this.form.scenceId) {
        callback(new Error("请选择场景"));
      } else {
        callback();
      }
    },
    resetFormData: function (initObj) {
      this.$refs?.form?.resetFields();
      this.form = {
        name: initObj
          ? initObj.name + dayjs(new Date().getTime()).format("YYYYMMDDHHmmss")
          : "",
        deviceIds: [],
        target: "",
        curTargetName: "",
        formation: "",
        circulate: "",
        zonePoint: "",
        action: "",
        mapConflation: "process",
        mapName: `map${dayjs(new Date().getTime()).format("YYYYMMDDHHmmss")}`,
        mappingType: 0, // 默认手动
      };
    },

    onClickNavPoints: function () {
      if (this.onClickNavPoint) {
        this.onClickNavPoint(
          this.optsType,
          this.$store.state.curTaskInfo.method
        );
      }
      this.disabledNav = true;
    },

    onClearNavPoint: function () {
      // this.disabledNav = false;
      if (this.resetMapData) {
        this.resetMapData();
      }
    },

    onBoundaryPoints: function (opts) {
      this.curOpts = opts;
      if (this.optsType === "add") {
        if (this.isShowBoundary === true) {
          // 拾取边界点
          if (this?.getCurTaskInfoPoints) {
            this?.getCurTaskInfoPoints(
              [{}],
              true,
              this.$store.state.curTaskInfo.method,
              this.optsType
            );
          }
        }
        if (this.saveBoundaryPoint && this.isShowBoundary === false) {
          //保存边界点

          const resLen = this.saveBoundaryPoint();
          if (resLen / 2 < 3) {
            this.curOpts = "";
            return;
          }
        }
        this.isShowBoundary = false;
      } else {
        if (this.saveBoundaryPoint) {
          //update 保存导航点
          this.saveBoundaryPoint();
        }
      }
    },

    onClearBoundaryPoints: function () {
      if (this.onClearBoundaryPoint) {
        this.onClearBoundaryPoint();
      }
      if (this.optsType !== "update") {
        // 设备-清空边界点，放开对当前位置点设置为边界点的限制
        this.isShowBoundary = false;
        this.curOpts = "clear";
      }
    },

    resetAreaPointData: function () {
      this.onClearBoundaryPoints();
      if (this?.getCurTaskInfoPoints) {
        this?.getCurTaskInfoPoints([{}], true);
      }
    },

    onChangeScene: async function (e) {
      // 拿到场景id 去获取场景信息 拿到mapObj
      const res = await getSceneDetail({ id: e });
      if (this.updateCurSceneMapObj) {
        this?.updateCurSceneMapObj(res?.map);
      }
      // 重置所有按钮的限制
      this.isShowBoundary = true;
      this.disabledNav = false;
      this.curOpts === "";
      if (this.optsType === "add") {
        if (this?.getCurTaskInfoPoints) {
          this?.getCurTaskInfoPoints([{}], true);
        }
      }
    },

    sceneIdDisabledFun: function () {
      if (this?.buildMapping === true) {
        this.sceneIdDisabled = true;
      }
    },

    visibleChange: function (visible) {
      const { name, params } = this.$route;
      const { id } = params;
      if (visible && name === "deviceId") {
        const curSceneList = this.sceneList;
        if (!this?.buildMapping || this?.buildMapping === false) {
          this.sceneList = curSceneList.filter((i) => !i.name.includes("建图"));
        }
      }
    },

    deviceIdDisabledFun: function () {
      const { name, params } = this.$route;
      const { id } = params;
      if (name === "deviceId") {
        this.deviceDisabled = true;
        this.form.deviceIds = [id];
      }
    },

    onNavClick: function () {
      if (this.clickCurNavPoint) {
        this.clickCurNavPoint();
      }
    },

    onCurBoundaryPoints: function () {
      if (this.onClickCurBdyPoints) {
        this.onClickCurBdyPoints();
      }
    },
  },
};
</script>
<style lang="scss" scoped>
@import "./Index.scss";
</style>
