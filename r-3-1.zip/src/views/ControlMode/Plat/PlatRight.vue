<template>
  <div class="plat_ctrl_mode right">
    <JsonSchema
      :jsonData="$store.state.jsonRightData"
      jsonSchemaId="rigth"
      :videoUrls="$store.state.videoUrls"
      :videoCheckBox="$store.state.videoCheckBox"
      :videoCheckBoxIndex="$store.state.videoCheckBoxIndex"
      :basicInfo="$store.state.basicInfo"
    />
  </div>
</template>

<script>
import JsonSchema from "@/components/JsonSchema/Index.vue";
export default {
  props: [
    "jsonData",
    "videoUrls",
    "basicInfo",
    "videoCheckBox",
    "videoCheckBoxIndex",
  ],
  data() {
    return {};
  },
  components: {
    JsonSchema,
  },
  methods: {},
};
</script>
<style lang="scss" scoped>
@import "./Index.scss";
</style>
