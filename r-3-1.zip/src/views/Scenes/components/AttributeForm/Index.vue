<template>
  <div class="art_form" :style="{ top: top + 'px', left: left + 'px' }">
    <div class="robot_title">区域侦查属性配置</div>
    <el-form
      ref="formRef"
      :model="form.selectPoint"
      label-width="80px"
      size="small"
    >
      <el-form-item label="航向角" v-if="isShow">
        <el-input v-model="form.omega"></el-input>
      </el-form-item>
      <el-form-item label="过程属性" prop="process">
        <span class="action-add">
          <i
            class="el-icon-circle-plus-outline"
            @click="addProcessItem()"
          />添加
        </span>
        <div
          class="form-items-label"
          v-if="form.selectPoint.process.length > 0"
        >
          <span>目标物</span>
          <span>动作</span>
        </div>
        <div
          class="form-items"
          v-for="(item, index) in form.selectPoint.process"
          :key="index"
        >
          <el-row>
            <el-col :span="9">
              <el-select
                v-model="form.selectPoint.process[index].target"
                placeholder="--请选择--"
              >
                <el-option
                  v-for="item in form.identifierList"
                  :key="item.code"
                  :label="item.name"
                  :value="item.code"
                ></el-option>
              </el-select>
            </el-col>
            <el-col :span="9">
              <el-select
                v-model="form.selectPoint.process[index].action"
                placeholder="--请选择--"
              >
                <el-option
                  v-for="item in form.metaTaskList"
                  :key="item.method"
                  :label="item.name"
                  :value="item.method"
                ></el-option>
              </el-select>
            </el-col>
            <el-col :span="2">
              <i class="el-icon-delete" @click="deleteProcessItem(index)" />
            </el-col>
          </el-row>
          <hr />
        </div>
      </el-form-item>
      <el-form-item label="节点属性" prop="station" v-if="isShow">
        <span class="action-add">
          <i
            class="el-icon-circle-plus-outline"
            @click="addStationItem()"
          />添加
        </span>
        <div
          class="form-items-label"
          v-if="form.selectPoint.station.length > 0"
        >
          <span>目标物</span>
          <span>动作</span>
        </div>
        <div
          class="form-items"
          v-for="(item, index) in form.selectPoint.station"
          :key="index"
        >
          <el-row>
            <el-col :span="9">
              <el-select
                v-model="form.selectPoint.station[index].target"
                placeholder="--请选择--"
              >
                <el-option
                  v-for="item in form.identifierList"
                  :key="item.code"
                  :label="item.name"
                  :value="item.code"
                ></el-option>
              </el-select>
            </el-col>
            <el-col :span="9">
              <el-select
                v-model="form.selectPoint.station[index].action"
                placeholder="--请选择--"
              >
                <el-option
                  v-for="item in form.metaTaskList"
                  :key="item.method"
                  :label="item.name"
                  :value="item.method"
                ></el-option>
              </el-select>
            </el-col>
            <el-col :span="2">
              <i class="el-icon-delete" @click="deleteStationItem(index)" />
            </el-col>
          </el-row>
          <hr />
        </div>
      </el-form-item>
    </el-form>
    <div class="art_form_opts">
      <el-button @click="onDelete">取消</el-button>
      <el-button type="primary" @click="onSave">确定</el-button>
    </div>
  </div>
</template>
<script>
import { isEqual } from "lodash";
export default {
  props: [
    "artFormTop",
    "artFormLeft",
    "identifierList",
    "metaTaskList",
    "isShowOthers",
    "onArtFormDelete",
    "onArtFormSave",
    "TaskDetailData",
  ],
  data() {
    return {
      form: {
        omega: 0,
        identifierList: this.identifierList || [], // 目标物
        metaTaskList: this.metaTaskList || [], // 动作
        selectPoint: {
          location: { omega: 0 },
          process: this.TaskDetailData ? [...this.TaskDetailData] : [],
          station: [],
        }, // 选择点
      },
      top: this.artFormTop,
      left: this.artFormLeft,
      isShow: this.isShowOthers || false,
    };
  },
  watch: {
    artFormTop: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.top = newVal;
      }
    },
    artFormLeft: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.left = newVal;
      }
    },
  },
  methods: {
    // 操作form 函数
    addProcessItem: function () {
      this.form.selectPoint.process.push({ target: "", action: "" });
    },
    deleteProcessItem: function (index) {
      this.form.selectPoint.process.splice(index, 1);
    },
    addStationItem: function () {
      this.form.selectPoint.station.push({ target: "", action: "" });
    },
    deleteStationItem: function (index) {
      this.form.selectPoint.station.splice(index, 1);
    },
    onDelete() {
      // 清空form内容
      this.form.selectPoint = {
        location: { omega: 0 },
        process: this.TaskDetailData ? [...this.TaskDetailData] : [],
        station: [],
      };
      if (this.onArtFormDelete) {
        this.onArtFormDelete();
      }
    },
    onSave() {
      // 保存
      if (this.onArtFormSave) {
        this.onArtFormSave(this.form.selectPoint);
      }
    },
  },
};
</script>
<style lang="scss" scoped>
@import "@/assets/css/common.scss";
.art_form {
  position: absolute;
  width: 250px;
  border: 1px solid #ccc;
  padding: 10px;
  background: aliceblue;

  &_opts {
    float: right;
  }

  .el-form {
    max-height: 220px;
    overflow: auto;
    margin-bottom: 8px;
    .el-form-item {
      margin-bottom: 10px;

      .el-input {
        width: 89%;
      }
    }

    .form-items {
      margin-left: -80px;

      .el-row:nth-child(1) {
        margin-top: 4px;
      }

      .el-col {
        margin-right: 8px;
      }

      .el-col:nth-child(1) {
        margin-right: 13px;
      }

      hr {
        height: 0.1px;
        border: none;
        background-color: #d5e0f1;
      }
    }

    .action-add,
    .el-icon-delete {
      color: $primary-color;
    }

    .form-items-label {
      margin-left: -80px;
      background: #fdf5e6;
      color: #606266;

      span {
        display: inline-block;
        width: 37.5%;
        margin-left: 8px;
      }
    }
  }
}
</style>
