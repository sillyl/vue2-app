import { axiosWarpInstance } from "@/utils/axiosInstance.js";

export const login = async (data) => {
  const res = await axiosWarpInstance(
    `/cpix/v1.0/form/login?username=${data.username}&password=${data.password}`,
    data,
    {
      type: "POST",
      skipGlobalHandler: true,
    }
  );
  return res;
};

export const logout = async (data) => {
  const res = await axiosWarpInstance("/cpix/v1.0/account/logout", data, {
    type: "get",
  });
  return res;
};

export const getUserInfo = async (data) => {
  const res = await axiosWarpInstance("/cpix/v1.0/account/common/info", data, {
    type: "get",
  });
  return res;
};
