import { axiosWarpInstance } from "@/utils/axiosInstance.js";

// 开始/结束保存视频
export const saveVideo = (data) => {
  const res = axiosWarpInstance(
    `/cpix/v1.0/configure/device/consumer/video/save/${data.deviceId}`,
    data,
    {
      type: "GET",
    }
  );
  return res;
};

// 下载视频
export const downloadVideo = (data) => {
  const res = axiosWarpInstance(
    `/cpix/v1.0/configure/device/consumer/video/download/${data?.deviceId}/${data?.filename}`,
    data,
    {
      type: "get",
      skipGlobalHandler: true,
      responseType: "blob",
      download: true,
    }
  );
  return res;
};
