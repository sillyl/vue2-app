const { defineConfig } = require("@vue/cli-service");
const LodashModuleReplacementPlugin = require("lodash-webpack-plugin");

module.exports = defineConfig({
  transpileDependencies: true,
  productionSourceMap: false, // 本地开发开启，生产环境关闭
  devServer: {
    client: {
      // https://webpack.docschina.org/configuration/dev-server/
      overlay: {
        errors: true,
        warnings: false,
        runtimeErrors: false, // ResizeObserver loop limit exceeded;element目前的一个bug, http://lihuaxi.xjx100.cn/news/1236383.html?action=onClick
      },
    },
    port: 8083,
    host: "0.0.0.0",
    https: false,
    open: true, //启动服务时自动打开浏览器访问
    proxy: {
      "/dev-api": {
        target: "http://localhost:8090",
        changeOrigin: true, // 开启代理服务器，
        pathRewrite: {
          "^/dev-api": "",
        },
      },
    },
  },
  // 按需加载lodash
  chainWebpack: (config) => {
    config.plugin("loadshReplace").use(new LodashModuleReplacementPlugin());
  },
});
