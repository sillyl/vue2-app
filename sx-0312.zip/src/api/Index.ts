import { axiosWarpInstance } from "@/utils/axiosInstance";

export const getUserDeviceList = async (data: Record<any, any>) => {
  const res = await axiosWarpInstance(
    "",
    data,
    { type: "get" }
  );
  return res;
};


