<template>
  <div>
    <WfsVideo id="video2c951081879df83401879dfd53650002-0" />
  </div>
</template>

<script lang="ts" setup>
import WfsVideo from "@/components/WfsVideo/Index.vue";
</script>
