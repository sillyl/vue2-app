import { createRouter, createWebHistory, RouteRecordRaw } from "vue-router";

type RouterType = RouteRecordRaw & { title?: string };

const routes: Array<RouterType> = [
  {
    path: "/monitor-overview",
    alias: "/",
    name: "MonitorOverview",
    component: () =>
      import(
        /* webpackChunkName: "MonitorOverview" */ "@/views/MonitorOverview/Index.vue"
      ),
    title: "监控总览",
  },
  {
    path: "/job-records",
    name: "JobRecords",
    component: () =>
      import(
        /* webpackChunkName: "JobRecords" */ "@/views/JobRecords/Index.vue"
      ),
    title: "工作记录",
  },
  {
    path: "/system-settings",
    name: "SystemSettings",
    component: () =>
      import(
        /* webpackChunkName: "SystemSettings" */ "@/views/SystemSettings/Index.vue"
      ),
    title: "系统设置",
  },
  {
    path: "/notFound",
    name: "NotFound",
    meta: {
      title: "Page not found",
      isLogin: false,
    },
    component: () =>
      import(
        /* webpackChunkName: "NotFound" */ "@/components/NotFound/Index.vue"
      ),
  },
  // 所有未定义路由，全部重定向到notFound页
  {
    path: "/:pathMatch(.*)*",
    redirect: "/notFound",
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

export { routes };

export default router;
