<template>
  <div class="video_player_wfs" :id="videoId">
    <div class="video_player_wfs_header">
      <!-- <span class="text_overflow_140" :title="videoCheckBox[id]">{{
        videoCheckBox[id]
      }}</span> -->
    </div>
    <VideoFullScreen
      :id="id"
      :isFullScreen="isFullScreen"
      :onIsFullScreen="onIsFullScreen"
    />
  </div>
</template>

<script lang="ts">
import { ref, onMounted, onUnmounted, defineComponent } from "vue";
import VideoFullScreen from "./VideoFullScreen.vue";
import Wfs from "../../../public/static/wfs/wfs.js";

export default defineComponent({
  components: {
    VideoFullScreen,
  },
  props: {
    id: {
      type: String,
      default: "",
    },
  },
  setup(props) {
    const videoId = ref(
      props?.id ? `video_player_wfs_${props?.id}` : "video_player_wfs"
    );
    const wfs = ref<any>(null);
    const isFullScreen = ref(false);

    onMounted(() => {
      startWfs();
    });

    const startWfs = () => {
      if ((Wfs as any).isSupported()) {
        const videoFps = 35;
        const videoDom = document.querySelector(`#${videoId.value}`);
        const channelName = videoId?.value?.slice(5);
        wfs.value = new Wfs();
        wfs.value.attachMedia(
          videoDom,
          channelName,
          "H264Raw",
          //  `ws://10.88.104.116:8090/cpix/v1.0/websocket/device-video/${channelName}`,
          `ws://localhost:8090/cpix/v1.0/websocket/device-video/${channelName}`,
          videoFps
        );
      }
    };

    const onIsFullScreen = () => {
      if (!isFullScreen.value) {
        const dom = document.querySelector(`#${videoId.value}`);
        (dom as Element).requestFullscreen();
      } else {
        if (document.fullscreenElement) {
          document.exitFullscreen();
        }
      }
      isFullScreen.value = !isFullScreen.value;
    };

    onUnmounted(() => {
      wfs?.value?.destroy();
    });

    return { videoId, onIsFullScreen, isFullScreen };
  },
});
</script>
<style lang="scss" scoped>
$prefixCls: "video_player_wfs";
.#{$prefixCls} {
  width: 300px;
  height: 200px;
  border: 1px solid rgb(58, 58, 68);
  position: absolute;
  cursor: pointer;
  z-index: 3; // 目前最上层
  &_header {
    height: 32px;
    line-height: 32px;
    text-align: center;
    background-color: #8ec5fc;
    background-image: linear-gradient(62deg, #8ec5fc 0%, #e0c3fc 100%);

    &-x {
      float: right;
      margin: 0 10px;
      font-size: 20px;
    }
  }
}
</style>
