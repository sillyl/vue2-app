<template>
  <div class="video_player_wfs_content" :id="'video_player_wfs_content_' + id">
    <video :id="id" muted autoplay crossOrigin="anonymous" :controls="false">
      你的浏览器不支持 video 标签
    </video>
    {{ isFullScreen }}
    <i
      :class="[isFullScreen ? 'icon-shrink' : 'icon-enlarge']"
      @click="onIsFullScreen(id)"
    />
  </div>
</template>

<script setup>
import { defineProps } from "vue";
const props = defineProps({
  onIsFullScreen: Function,
  isFullScreen: Boolean,
  id: String,
});
</script>
<style lang="scss" scoped>
.video_player_wfs_content {
  background: rgb(54, 54, 54);
  height: calc(100% - 32px);
  video {
    width: 100%;
    height: 100%;
    object-fit: fill;
  }
  i {
    bottom: 10px;
    position: absolute;
    right: 8px;
    color: #ccc;
    font-size: 20px;
  }
}
</style>
