import { ElLoading, LoadingParentElement } from "element-plus";
import { ComponentPublicInstance, ComponentOptionsBase, Ref } from "vue-demi";

const options = {
  target: document.querySelector(".content") as HTMLElement | string,
  lock: true,
  text: "Loading... ",
  spinner: "el-icon-loading",
  background: "rgba(0, 0, 0, 0.7)",
  fullscreen: false,
};

let loading: { close: any; setText?: (text: string) => void; removeElLoadingChild?: () => void; handleAfterLeave?: () => void; vm?: ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}, {}, string, {}>, {}, {}>; $el?: HTMLElement; originalPosition?: Ref<string>; originalOverflow?: Ref<string>; visible?: Ref<boolean>; parent?: Ref<LoadingParentElement>; background?: Ref<string>; svg?: Ref<string>; svgViewBox?: Ref<string>; spinner?: Ref<string | boolean>; text?: Ref<string>; fullscreen?: Ref<boolean>; lock?: Ref<boolean>; customClass?: Ref<string>; target?: Ref<HTMLElement>; beforeClose?: Ref<(() => boolean) | undefined> | undefined; closed?: Ref<(() => void) | undefined> | undefined; };
const loadingShow = () => {
  loading = ElLoading.service(options);
};

const loadingClose = () => {
  loading && loading.close();
};

const GlobalLoading = {
  loadingShow,
  loadingClose,
};

export default GlobalLoading;
