<template>
  <div class="sx_layout">
    <el-container>
      <el-header>
        <el-menu
          :default-active="$route.path"
          class="el-menu-popper-demo"
          mode="horizontal"
          :popper-offset="16"
          router
        >
          <el-menu-item
            v-for="route in routes"
            :index="route?.alias || route?.path"
            :key="route?.alias || route?.path"
            >{{ route?.title }}</el-menu-item
          >
        </el-menu>
      </el-header>
      <el-main>
        <router-view />
      </el-main>
    </el-container>
  </div>
</template>

<script setup lang="ts">
import { routes } from "@/router";
</script>
<style lang="scss" scoped>
@import "@/assets/css/common.scss";
.sx_layout {
  height: 100%;

  .el-container {
    height: 100%;

    .el-header {
      --el-header-padding: 0px;
    }
  }
}
</style>
