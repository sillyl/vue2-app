module.exports = {
  root: true,
  env: {
    node: true,
  },
  extends: [
    "plugin:vue/vue3-essential",
    "eslint:recommended",
    // "@vue/typescript/recommended",
    "@vue/eslint-config-typescript",
    "plugin:prettier/recommended",
  ],
  parserOptions: {
    ecmaVersion: 2020,
  },
  rules: {
    "no-console": process.env.NODE_ENV === "production" ? "warn" : "off",
    "no-debugger": process.env.NODE_ENV === "production" ? "warn" : "off",
    // 关闭any类型的警告
    "@typescript-eslint/no-explicit-any": "off",
    //关闭组件命名规则
    // "vue/multi-word-component-names": "off",
    "vue/multi-word-component-names": [
      "error",
      {
        ignores: ["index", "Index"], //需要忽略的组件名
      },
    ],
    // 打开规则作为警告（不影响退出代码）
    "no-unused-vars": "warn",
  },
  globals: {
    Wfs: true,
  },
};
