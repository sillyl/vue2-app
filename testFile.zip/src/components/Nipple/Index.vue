<template>
  <div class="joystick" v-if="group ? true : $store.state.isShowNippleVal">
    <div :id="curJoystickId" class="joystick_content"></div>
    <slot></slot>
  </div>
</template>

<script>
import nipplejs from "nipplejs";
import { emergencyStop } from "@/api/cmd";
import { isEqual } from "lodash";
import { getSinglePointDistance } from "@/utils/CoordinatePickupFun";

export default {
  props: [
    "deviceId",
    "lockX",
    "lockY",
    "joystickId",
    "color",
    "oystickType",
    "group",
  ],
  data() {
    return {
      curJoystickId: this.joystickId || "joystick_content",
      // 扩展 标识是什么类型的遥控杆（如仅限上下移动， 左右移动，默认下旋转）,用于处理后端不同接口，不同传参
      type: this.oystickType,
      manager: null,
      moving: false, // move 标识
      notEnd: true, // 未触发end 标识（true: 未结束，false：用户停止操作）
      curDeg: null,
      curLeft: 0,
      curRight: 0,
    };
  },

  mounted() {
    this.initNipple();
  },

  methods: {
    initNipple: function () {
      const zone = document.getElementById(this.curJoystickId);
      const options = {
        zone,
        mode: "static", // semi, dynamic
        position: { left: "50%", top: "50%" }, //在容器内垂直居中显示
        color: this.color || "#09080e",
        threshold: 0.1, // 触发定向事件所需的力量(0, 1)
        lockX: this.lockX || false, // 锁定操纵杆向x（水平）轴移动
        lockY: this.lockY || false, // 锁定操纵杆向y（垂直）轴移动
        shape: "circle", // square
      };

      this.manager = zone && nipplejs.create(options);

      const that = this;

      this.manager?.on("start", function (evt, data) {
        // console.log("start", evt, data);
        that.moving = false;
        that.notEnd = true;
        that.continuePost(); // 开启轮询
      });

      // 滑动摇杆的事件
      this.manager?.on("move", async function (evt, data) {
        // console.log("move", evt, data);
        that.moving = true;
        const {
          angle: { degree },
          vector: { x, y },
        } = data;
        let deg = degree;
        if (degree > 0 && degree <= 180) {
          deg = -degree;
        }

        if (degree > 180 && degree <= 360) {
          deg = 360 - degree;
        }
        const power = getSinglePointDistance(x, y);
        const left = Math.cos((deg / 180) * Math.PI) * (power * 10);
        const right = Math.sin((deg / 180) * Math.PI) * (power * 10);
        // console.log("move", left, right, deg);
        that.curDeg = deg;
        that.curLeft = left;
        that.curRight = right;
        // await that.emergencyStop(left, right, deg);
      });

      //停止滑动摇杆的事件
      this.manager?.on("end", async function (evt, data) {
        that.notEnd = false;
        that.moving = false;
        // console.log("end", evt, data);
        // 结束后给小车发停止指令
        for (let i = 0; i < 5; i++) {
          await that.emergencyStop(0, 0, 0);
        }
        cancelAnimationFrame(that.continuePost);
      });
    },

    emergencyStop: async function (left, top, rotate) {
      let params = {
        deviceId: this.deviceId,
        method: "StickUpdate",
        params: {
          left,
          top,
          rotate,
        },
        cache: "0",
        response: "0",
        expired: 100,
        streamType: 1,
      };
      await emergencyStop(params);
    },

    continuePost: async function () {
      requestAnimationFrame(this.continuePost);
      if (this.moving === true && this.notEnd === true) {
        // 满足移动中，且本次操作未终止
        await this.emergencyStop(this.curDeg, this.curLeft, this.curRight);
      }
    },
  },

  beforeDestroy() {
    this.manager?.destroy();
    this.moving = false;
    this.notEnd = true;
    this.curDeg = null;
    this.curLeft = 0;
    this.curRight = 0;
    cancelAnimationFrame(this.continuePost);
  },
};
</script>

<style lang="scss" scoped>
.joystick {
  position: relative;
  width: 110px;
  height: 115px;
  margin: 2px;
  display: inline-block;

  &_content {
    height: calc(100% - 16px);
    position: relative;

    :first-child {
      z-index: 2 !important;
    }

    ::v-deep {
      .back {
        // opacity: 0.9 !important;
      }
      .front {
        animation: innerFlash 2s infinite;
      }

      @keyframes innerFlash {
        0% {
          border-color: #ffffff;
          box-shadow: 0 0 5px #ffffff;
        }
        50% {
          border-color: #00ff33;
          box-shadow: 0 0 10px #009dff;
        }
        100% {
          border-color: #ffffff;
          box-shadow: 0 0 5px #ffffff;
        }
      }
    }
  }

  &_desc {
    text-align: center;
  }
}
</style>
