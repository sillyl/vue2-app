<template>
  <canvas :width="canvasW" :height="canvasH" :id="ctxId"></canvas>
</template>
<script>
/* 
  当且仅当三个按钮时，即arr 长度为3时，默认设定扇形三个，中心点击不做任何处理
  目前内置支持扇形2-5个，加中心最多六个按钮
*/

import { isEmpty } from "lodash";
import { getFθ } from "@/utils/CoordinatePickupFun";
import { triggerCmd } from "@/components/JsonSchema/triggerCmd";
export default {
  props: [
    "id",
    "num",
    "canvasWidth",
    "canvasHeight",
    "isCore",
    "centerR",
    "arr",
    "bgColor",
    "clickBgColor",
    "fontColor",
    "data",
  ],
  data() {
    return {
      ctxId: this.id || "ctx",
      nums: this.arr?.length - 1 || 5,
      canvasW: this.canvasWidth || 140,
      canvasH: this.canvasHeight || 140,
      roundRadius: this.centerR || 50, // 中心圆半径
      arrs: [],
      clickCurX: 0,
      clickCurY: 0,
      childData: null, // 统一暴露子组件数据 给父组件点击计算使用
      bgCor: this.bgColor || "#E0FFFF",
      clickBgCor: this.clickBgColor || "#409EFF",
      fontCor: this.fontColor || "#000000",
    };
  },
  mounted() {
    this.onDraw();
  },
  methods: {
    onDraw: function () {
      const canvas = document.querySelector(`#${this.ctxId}`);
      const ctx = canvas.getContext("2d");
      const num =
        this.arr?.length === 3 || this.arr?.length === 4
          ? this.nums + 1
          : this.nums; //圆弧的份数
      //一个圆弧对应的弧度
      const rad = (Math.PI * 2) / num;
      const radθ = rad * (180 / Math.PI); // 角度
      const coreX = this.canvasW / 2; // 圆心坐标
      const coreY = this.canvasH / 2;
      const radiusM = this.canvasW / 2.1; // 扇形（大圆）半径
      const roundRadius = coreX / 2.5; // 小圆半径
      const θ = 360 / num / 2; // 需要旋转多少角度
      let radDiff = (Math.PI / 180) * θ;
      let start = radDiff - rad * 2;
      let end = rad + radDiff - rad * 2;
      ctx.translate(coreX, coreY); // 将中心调整到圆心
      let txtPostion = (coreX + roundRadius) / 2;
      const that = this;
      this.updateArrs(txtPostion, roundRadius);
      paintP();
      if (!this.isCore) {
        // 不传默认展示
        paintCircle();
      }

      function paintP() {
        for (let i = 0; i < num; i++) {
          const text = that.arrs?.[i]?.name;
          const x = that.arrs?.[i]?.x;
          const y = that.arrs?.[i]?.y;
          ctx.save();
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.arc(0, 0, radiusM, start, end);
          ctx.closePath();
          ctx.fillStyle = that.bgCor; // 填充整体背景颜色
          ctx.stroke();
          ctx.fill();
          ctx.closePath();
          ctx.beginPath();
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.font = "12px scans-serif";
          ctx.fillStyle = that.fontCor; // 字体颜色
          ctx.fillText(text, x, y);
          ctx.restore();
          start = end;
          end = end + rad;
        }
      }

      function paintCircle() {
        ctx.beginPath();
        ctx.arc(0, 0, roundRadius, 0, Math.PI * 2, true);
        ctx.fillStyle = that.bgCor;
        ctx.stroke();
        ctx.fill();
        ctx.closePath();
        ctx.beginPath();
        ctx.font = "12px scans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillStyle = that.fontCor; // 字体颜色
        if (
          that.arr?.length &&
          !(that.arr?.length === 3 || that?.arr?.length == 4)
        ) {
          ctx.fillText(that.arrs[that.arrs.length - 1]?.name, 0, 0);
        }
        ctx.restore();
      }

      function redrawPaintP(index) {
        for (let i = 0; i < num; i++) {
          const text = that.arrs?.[i]?.name;
          const x = that.arrs?.[i]?.x;
          const y = that.arrs?.[i]?.y;
          ctx.save();
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.arc(0, 0, radiusM, start, end);
          ctx.closePath();
          if (index === i) {
            ctx.fillStyle = that.clickBgCor;
          } else {
            ctx.fillStyle = that.bgCor;
          }
          ctx.stroke();
          ctx.fill();
          ctx.closePath(); // 上一个形成闭合，否则影响下一个开始
          ctx.beginPath();
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.font = "12px scans-serif";
          ctx.fillStyle = that.fontCor; // 字体颜色
          ctx.fillText(text, x, y);
          ctx.restore();
          start = end;
          end = end + rad;
        }
        paintCircle(); // 保证中心圆是是最后一个绘制（重要必须！！！）
      }

      function redrawPaintCircle() {
        ctx.save();
        ctx.beginPath();
        ctx.arc(0, 0, roundRadius, 0, Math.PI * 2, true);
        ctx.stroke();
        ctx.fillStyle = that.clickBgCor;
        ctx.fill();
        ctx.closePath();
        ctx.beginPath();
        ctx.font = "12px scans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillStyle = that.fontCor; // 字体颜色
        if (that?.arr?.length !== 3 || that?.arr?.length !== 4) {
          ctx.fillText(that.arrs[that.arrs.length - 1]?.name, 0, 0);
        }
        ctx.restore();
      }

      canvas.onclick = async function (e) {
        const event = e || event;
        const x = e.layerX - canvas.offsetLeft; //获取点击后x的坐标
        const y = e.layerY - canvas.offsetTop; //获取点击后y的坐标
        that.clickCurX = x;
        that.clickCurY = y;

        const angleA = getFθ({ x: coreX, y: coreY }, { x, y }); // 点击位置在坐标系中的角度
        let angle = θ + radθ * 1;
        const curR =
          Math.pow(x - coreX, 2) + Math.pow(y - coreY, 2) <
          Math.pow(roundRadius, 2);

        const { type, id } = that.data;
        if (curR) {
          const obj = that.arr?.[that.arr?.length - 1];
          if (!(that.arr?.length === 3 || that?.arr?.length == 4)) {
            paintP();
            redrawPaintCircle();
            console.log("在中心圆中", obj);
            await triggerCmd(id, type, obj?.action);
          }
          return;
        }
        const curClickPointR =
          Math.pow(x - coreX, 2) + Math.pow(y - coreY, 2) <
          Math.pow(radiusM, 2); // 确保点击在大圆内触发事件
        if (curClickPointR) {
          const arrData = that.arr;
          const len = that.arr?.length - 1;

          if (that.nums === 1) {
            console.log("在外圆中", arrData[0]);
            if (arrData[0]?.action !== 99) {
              redrawPaintP(0);
              await triggerCmd(id, type, arrData[0]?.action);
            }
          }

          if (that.nums === 2) {
            console.log("在外圆中", arrData[0]);
            if (arrData[0]?.action !== 99) {
              redrawPaintP(0);
              await triggerCmd(id, type, arrData[0]?.action);
            }
          }

          if (that.arr?.length === 3) {
            if (-angle < angleA && angleA <= -angle + radθ) {
              console.log("在扇形0内", arrData[0]);
              if (arrData[0]?.action !== 99) {
                redrawPaintP(0);
                await triggerCmd(id, type, arrData[0]?.action);
              }
              return;
            }
            if (-angle + radθ < angleA && angleA < θ) {
              console.log("在扇形1内", arrData[1]);
              if (arrData[1]?.action !== 99) {
                redrawPaintP(1);
                await triggerCmd(id, type, arrData[1]?.action);
              }
              return;
            }

            if (θ < angleA && angleA < angle) {
              console.log("在扇形2内", arrData[2]);
              if (arrData[2]?.action !== 99) {
                redrawPaintP(2);
                await triggerCmd(id, type, arrData[2]?.action);
              }
              return;
            }
          }

          if (that.arr?.length === 4 || that.nums === 4) {
            if (-angle < angleA && angleA < -θ) {
              console.log("在扇形0内", arrData[0]);
              if (arrData[0]?.action !== 99) {
                redrawPaintP(0);
                await triggerCmd(id, type, arrData[0]?.action);
              }
              return;
            }
            if (-θ < angleA && angleA < θ) {
              console.log("在扇形1内", arrData[1]);
              if (arrData[1]?.action !== 99) {
                redrawPaintP(1);
                await triggerCmd(id, type, arrData[1]?.action);
              }
              return;
            }
            if (θ < angleA && angleA < angle) {
              console.log("在扇形2内4", angleA, arrData[2]);
              if (arrData[2]?.action !== 99) {
                redrawPaintP(2);
                await triggerCmd(id, type, arrData[2]?.action);
              }
              return;
            }
            if (
              (angle < angleA && angleA <= 180) ||
              (-180 < angleA && angleA < -angle)
            ) {
              console.log("在扇形3内", arrData[3]);
              if (arrData[3]?.action !== 99) {
                redrawPaintP(3);
                await triggerCmd(id, type, arrData[3]?.action);
              }
              return;
            }
          }

          if (that.nums === 5) {
            if (-180 + radθ < angleA && angleA < -180 + radθ * 2) {
              console.log("在扇形0内", arrData[0]);
              if (arrData[0]?.action !== 99) {
                redrawPaintP(0);
                await triggerCmd(id, type, arrData[0]?.action);
              }
              return;
            }

            if (-angle + radθ < angleA && angleA < θ) {
              console.log("在扇形1内", arrData[1]);
              if (arrData[1]?.action !== 99) {
                redrawPaintP(1);
                await triggerCmd(id, type, arrData[1]?.action);
              }
              return;
            }

            if (θ < angleA && angleA < angle) {
              console.log("在扇形2内5", arrData[2]);
              if (arrData[2]?.action !== 99) {
                redrawPaintP(2);
                await triggerCmd(id, type, arrData[2]?.action);
              }
              return;
            }

            if (angle < angleA && angleA <= angle + radθ) {
              console.log("在扇形3内5", arrData[3]);
              if (arrData[3]?.action !== 99) {
                redrawPaintP(3);
                await triggerCmd(id, type, arrData[3]?.action);
              }
              return;
            }

            if (-180 < angleA && angleA <= -180 + radθ) {
              console.log("在扇形4内", arrData[4]);
              if (arrData[4]?.action !== 99) {
                redrawPaintP(4);
                await triggerCmd(id, type, arrData[4]?.action);
              }
              return;
            }
          }
        }
      };
    },

    updateArrs: function (txtPostion, roundRadius) {
      let locations = [
        // 默认四个扇形
        { x: 0, y: -txtPostion }, // 0
        { x: txtPostion, y: 0 }, // 1
        { x: 0, y: txtPostion }, // 2
        { x: -txtPostion, y: 0 }, // 3
      ];

      if (this.arr?.length === 3) {
        locations = [
          { x: -txtPostion / 1.6, y: -txtPostion / 1.3 }, // 1
          { x: txtPostion / 1.01, y: 0 }, // 2
          { x: -txtPostion / 1.6, y: txtPostion / 1.3 }, // 0
        ];
      }
      if (this.nums === 5) {
        locations = [
          { x: 8, y: -(txtPostion / 1.2) }, // 3
          { x: txtPostion / 1.1, y: 0 }, // 4
          { x: 8, y: txtPostion / 1.2 }, // 0
          { x: -txtPostion / 1.2, y: txtPostion / 1.8 }, // 1
          { x: -txtPostion / 1.2, y: -(txtPostion / 2) }, // 2
        ];
      }
      this.arrs = (this.arr || [])?.map((i, idx) => {
        return { ...i, ...locations[idx] };
      });
    },
  },
};
</script>
<style lang="scss" scoped></style>
