<template>
  <div class="CesiumViewer">
    <div id="cesiumContainer"></div>
    <CesiumTooltip
      id="CesiumTooltip"
      ref="cesiumTooltip"
      v-if="isShow"
      :identifierList="identifierList"
      :metaTaskList="metaTaskList"
      :curTop="curTop"
      :curLeft="curLeft"
      :curCTop="curCTop"
      :curCLeft="curCLeft"
      :markerData="markerData"
      :deletePoint="deletePoint"
      :savePoint="savePoint"
      :curOpt="curOpt"
      :curMethod="curMethod"
      :isMapCorrection="isMapCorrection"
    />
  </div>
</template>
<script>
import { isEqual } from "lodash";
import CesiumTooltip from "./CesiumTooltip.vue";
import { getIdentifierList } from "@/api/identify";
import { getSceneMetaTaskList } from "@/api/task";
import { isEmpty } from "lodash";
import { hexToRgba } from "@/utils/index.js";
import { stepLineSegment } from "@/utils/geoposition.js";

export default {
  name: "cesiumContainer",
  props: [
    "mapId",
    "mapInfo",
    "pageType",
    "method",
    "taskInfoRow",
    "wsData",
    "isMapCorrection",
    "onSaveMapCorrection",
  ],
  data() {
    return {
      viewer: {},
      isShow: false,
      points: new Map(),
      curTop: 0,
      curLeft: 0,
      longitude: null,
      latitude: null,
      entityPosition: null,
      entity: null,
      curMarkerId: null,
      wpLocation: { x: 0, y: 0 },
      polylineArr: [],
      curOpt: "add",
      curPageType: this.pageType,
      curMethod: this.method,
      identifierList: [],
      metaTaskList: [],
      areaPoints: [],
      isPolygon: false,
      selectMoveEntity: {},
      cesiumTooltipFormData: null,
      mapInfoPointsData: this.taskInfoRow,
      process: [],
      polylinePointArr: [],
    };
  },
  components: {
    CesiumTooltip,
  },
  async mounted() {
    await this.initMapView();
    await this.getApiFormData();
    await this.replaceWsData(this.wsData);
  },
  watch: {
    mapInfo: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.initMapView(newVal);
      }
      return newVal;
    },
    taskInfoRow: function (newVal, oldVal) {
      // if (!isEqual(newVal, oldVal)) {
      this.mapInfoPointsData = newVal;
      this.getExistsPointsData();
      // }
    },
    pageType: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.curPageType = newVal;
      }
    },
    method: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.curMethod = newVal;
        this.getApiFormData();
      }
    },
    wsData: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.replaceWsData(newVal);
      }
    },
  },
  computed: {
    markerData() {
      return {
        longitude: this.longitude,
        latitude: this.latitude,
        omega: this.omega,
        process: this.process,
        station: this.station,
      };
    },
  },
  methods: {
    replaceWsData(arr) {
      // 数组形式为统一 处理场景 多个设备实时数据
      for (let i = 0; i < arr?.length; i++) {
        const data = arr?.[i];
        const travel = data?.travel;
        const color = data?.color || "#ffff00";
        this.polylinePointArr = [];
        if (!isEmpty(travel)) {
          const { location } = travel;
          for (let i = 0; i < location?.length; i++) {
            let lct = location[i];
            let lastJd = 0,
              lastWd = 0;
            if (this.polylinePointArr.length >= 2) {
              lastJd = this.polylinePointArr[this.polylinePointArr.length - 2];
              lastWd = this.polylinePointArr[this.polylinePointArr.length - 1];
            }

            if (stepLineSegment(lastJd, lastWd, lct.x, lct.y)) {
              this.polylinePointArr.push(lct.x);
              this.polylinePointArr.push(lct.y);
            }
          }
          const arr = [...this.polylinePointArr];
          this.addPolylineEntityByName(
            arr,
            {
              color,
            },
            "ws_"
          );
        }
      }
    },
    initMapView: async function (newVal) {
      // 创建 viewer 实例
      // Cesium.Ion.defaultAccessToken =
      //   "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJmNDVhMjQ0Yi05MDg4LTRlNDYtYTIxMi00YmI4ZWYxOWMyNTgiLCJpZCI6MTQ5MzYwLCJpYXQiOjE2ODc3ODQ0OTh9.KlhT_LCnsEtYyawpEmJ_wx44_qTUbgze-SxGMRavbAM";
      this.viewer = new Cesium.Viewer("cesiumContainer", {
        imageryProvider: false, // 使用的影像服务。仅在baseLayerPicker属性被设为false时有效。
        animation: false, // 是否显示左下角仪表盘
        shouldAnimate: false, // 是否初始时刻运动
        homeButton: false, // 是否显示 Home 按钮
        fullscreenButton: true, // 是否显示全屏按钮
        baseLayerPicker: false, // 是否显示图层选择控件 去掉自带的图层选择器
        geocoder: false, // 是否显示地名查找控件，设置为 true，则无法查询
        timeline: false, // 是否显示时间线控件
        sceneModePicker: false, // 是否显示投影方式控件 三维 / 二维
        navigationHelpButton: false, // 是否显示帮助信息控件
        infoBox: false, // 是否显示点击要素之后显示的信息 信息框小部件
        requestRenderMode: false, //true 启用请求渲染模式：更新实体需拖动地图 视图才更新 [true 加载完 entity 后 requestRender 一下]
        scene3DOnly: false, // 每个几何实例将只能以 3D 渲染以节省 GPU 内存 如果设置为 true，则所有几何图形以 3D 模式绘制以节约 GPU 资源
        sceneMode: 2, // 初始场景模式 1 2D 模式 2 2D 循环模式 3 3D 模式  Cesium.SceneMode
        fullscreenElement: document.body, // 全屏时渲染的 HTML 元素
        selectionIndicator: false, // 是否显示选取指示器组件
      });

      this.viewer._cesiumWidget._creditContainer.style.display = "none"; // 隐藏icon

      this.viewer.scene.globe.enableLighting = true;

      this.viewer.scene.screenSpaceCameraController.enableTranslate = false;
      const data = newVal || this.mapInfo;
      const {
        fileType,
        zoom: { min, max },
        location: { jd, wd, gc },
        rectangle: { east, north, south, west },
        level,
      } = data;
      this.viewer.scene.screenSpaceCameraController.maximumZoomDistance = max;
      this.viewer.scene.screenSpaceCameraController.minimumZoomDistance = min;

      this.viewer.camera.setView({
        // 将经纬度和高程转换为世界坐标
        destination: Cesium.Cartesian3.fromDegrees(
          jd || 0.0,
          wd || 0.0,
          gc || 0.0
        ),
        orientation: {
          heading: 6.283185307179586,
          // 视角
          pitch: -1.5686521559334161,
          roll: 0,
        },
      });

      let url = `${
        process.env.VUE_APP_BASE_API
      }/cpix/v1.0/configure/map/consumer/view/${
        this.mapId || data?.id || data?.mapId
      }`;

      const options = {
        url,
        fileExtension: fileType,
        minimumLevel: level?.min,
        maximumLevel: level?.max,
        rectangle: new Cesium.Rectangle(
          Cesium.Math.toRadians(west),
          Cesium.Math.toRadians(east),
          Cesium.Math.toRadians(north),
          Cesium.Math.toRadians(south)
        ),
        tileWidth: 256,
        tileHeight: 256,
      };
      const provider = new Cesium.TileMapServiceImageryProvider(options);
      const layers = this.viewer.imageryLayers;
      layers.addImageryProvider(provider);
      // 监听 Viewer 的 pick 事件
      this.viewer.screenSpaceEventHandler.setInputAction(
        this.onLeftClick,
        Cesium.ScreenSpaceEventType.LEFT_CLICK
      );

      this.viewer.screenSpaceEventHandler.setInputAction(
        this.onMouseWheel,
        Cesium.ScreenSpaceEventType.WHEEL
      );

      this.viewer.screenSpaceEventHandler.setInputAction(
        this.onPinchMove,
        Cesium.ScreenSpaceEventType.PINCH_MOVE
      );

      this.viewer.screenSpaceEventHandler.setInputAction(
        this.onMouseStart,
        Cesium.ScreenSpaceEventType.LEFT_DOWN
      );

      this.viewer.screenSpaceEventHandler.setInputAction(
        this.onMouseMove,
        Cesium.ScreenSpaceEventType.MOUSE_MOVE
      );

      this.viewer.screenSpaceEventHandler.setInputAction(
        this.onMouseUp,
        Cesium.ScreenSpaceEventType.LEFT_UP
      );

      this.getExistsPointsData();
    },

    getExistsPointsData: function () {
      this.areaPoints = [];
      this.viewer?.entities.removeAll();
      for (let i in this.mapInfoPointsData) {
        const paramsPoints = this.mapInfoPointsData?.[i]?.params?.point;
        const areaPoints = this.mapInfoPointsData?.[i]?.params?.area;
        this.process =
          this.mapInfoPointsData?.[i]?.params?.process?.length > 0
            ? [...this.mapInfoPointsData?.[i]?.params?.process]
            : [];
        const color = this.mapInfoPointsData?.[i]?.color;
        let pointArr = [];
        if (paramsPoints?.length > 0) {
          for (let item of paramsPoints) {
            pointArr.push(item?.location?.x, item?.location?.y);
            const id = `marker_${item?.location?.x}_${item?.location?.y}`;
            this.addEntityById(id, item?.location?.x, item?.location?.y, color);
            this.points.set(id, item);
          }
          if (pointArr.length >= 4) {
            this.polylineArr = pointArr;
            this.addPolylineEntityByName(pointArr, { color });
          }
        }
        if (areaPoints?.length > 0) {
          let arr = [];
          for (let i = 0; i < areaPoints?.length; i++) {
            if (i % 2 === 0) {
              arr.push({ x: areaPoints[i], y: areaPoints[i + 1] });
              i++;
            }
          }
          arr.map((i) => {
            const id = `circle_${i?.x}_${i?.y}`;
            this.addEntityCircleById(id, i?.x, i?.y, null, null, {
              color,
            });
          });
          this.addPolygonById({ color, arrs: areaPoints });
        }
      }
    },

    onLeftClick: function (click) {
      const wp = click.position;
      if (!Cesium.defined(wp)) {
        return;
      }
      const ray = this.viewer.scene.camera.getPickRay(wp);
      if (!Cesium.defined(ray)) {
        return;
      }
      const cartesian = this.viewer.scene.globe.pick(ray, this.viewer.scene);
      if (!Cesium.defined(cartesian)) {
        return;
      }
      if (cartesian) {
        const cartographic = Cesium.Cartographic.fromCartesian(cartesian);
        const lon = Cesium.Math.toDegrees(cartographic.longitude);
        const lat = Cesium.Math.toDegrees(cartographic.latitude);
        const elev = this.viewer.scene.globe.getHeight(cartographic);

        this.longitude = lon.toFixed(6);
        this.latitude = lat.toFixed(6);
        const dom = document.getElementById("cesiumContainer");
        const { width, height } = dom.getBoundingClientRect();
        const { x, y } = wp;
        const pick = this.viewer.scene.pick(wp);
        if (this.isMapCorrection) {
          this.setStyle(x, y, width, wp);
        } else {
          if (this.curPageType === "update" || this.curPageType === "add") {
            // 导航任务
            if (this.curMethod === "TASK_NAVIGATION") {
              this.setStyle(x, y, width, wp);

              if (pick && pick.id && pick.id.name === "marker") {
                this.curMarkerId = pick?.id?.id;
                this.curOpt = "edit";
                this.entityPosition = this.wpLocation;
                this.entityPosition = this.entity.position.getValue(
                  this.viewer.clock.currentTime
                );
                // 保证已存在的点的经纬度和原数据返回一致
                const delPointStr = this.curMarkerId?.slice(7);
                const arr = delPointStr.split("_");
                this.longitude = arr?.[0];
                this.latitude = arr?.[1];

                let obj;
                for (let i of this.points.values()) {
                  if (
                    i.location.x === this.longitude &&
                    i.location.y === this.latitude
                  ) {
                    obj = i;
                  } else {
                    obj = null;
                  }
                }
                if (obj) {
                  this.omega = obj?.location?.omega;
                  this.process = obj?.process;
                  this.station = obj?.station;
                } else {
                  this.omega = 0;
                  this.process = [];
                  this.station = [];
                }
              } else {
                this.curMarkerId = null;
                this.curOpt = "add";
                this.omega = 0;
                this.process = [];
                this.station = [];
              }
            }
            // 侦查任务
            if (this.curMethod === "TASK_INVESTIGATE") {
              const id = `circle_${this.longitude}_${this.latitude}`;
              if (pick && pick.id && pick.id.name === "polygon") {
                this.isShow = true;
                if (x > width - 272) {
                  this.curCLeft = x - 272;
                  this.curCTop = y;
                } else {
                  this.curCLeft = x;
                  this.curCTop = y;
                }
                this.curTop = y;
                this.curLeft = x;
                this.wpLocation = wp;
                return;
              }
              if ((pick && pick.id && pick.id.name !== "circle") || !pick) {
                const res = this.entityByNameExists("polygon");
                if (!res) {
                  this.addEntityCircleById(
                    id,
                    this.longitude,
                    this.latitude,
                    pick
                  );
                }
              }
            }
          }
        }

        this.viewer.cesiumWidget.screenSpaceEventHandler.removeInputAction(
          Cesium.ScreenSpaceEventType.LEFT_DOUBLE_CLICK
        ); //去除双击放大地图效果
      }
    },

    setStyle: function (x, y, width, wp) {
      if (x > width - 272) {
        this.curCLeft = x - 272;
        this.curCTop = y;
      } else {
        this.curCLeft = x;
        this.curCTop = y;
      }
      this.curTop = y;
      this.curLeft = x;
      this.wpLocation = wp;
      this.isShow = true;
    },

    onMouseWheel: function (e) {
      this.isShow = false;
      // if (this.isMapCorrection) {
      //   this.isShow = false;
      // } else {
      //   if (this.curPageType === "update" || this.curPageType === "add") {
      //     if (this.curMethod === "TASK_NAVIGATION") {
      //       this.isShow = false;
      //     }
      //   }
      // }
    },

    onPinchMove: function (e) {
      this.isShow = false;
      // if (this.isMapCorrection) {
      //   this.isShow = false;
      // } else {
      //   if (this.curPageType === "update" || this.curPageType === "add") {
      //     if (this.curMethod === "TASK_NAVIGATION") {
      //       this.isShow = false;
      //     }
      //   }
      // }
    },

    onMouseStart: function (e) {
      const pick = this.viewer.scene.pick(e.position);
      if (
        this.curMethod === "TASK_INVESTIGATE" &&
        (this.curPageType === "update" || this.curPageType === "add")
      ) {
        if (pick && pick?.id && pick?.id?.name === "circle") {
          this.selectMoveEntity = pick.id;
        }
      }
    },

    onMouseMove: function (e) {
      const res = this.entityByNameExists("polygon");
      if (
        this.curMethod === "TASK_INVESTIGATE" &&
        res &&
        (this.curPageType === "update" || this.curPageType === "add")
      ) {
        if (!isEmpty(this.selectMoveEntity)) {
          const wp = e.endPosition;
          if (!Cesium.defined(wp)) {
            return;
          }
          const ray = this.viewer.scene.camera.getPickRay(wp);
          if (!Cesium.defined(ray)) {
            return;
          }
          const cartesian = this.viewer.scene.globe.pick(
            ray,
            this.viewer.scene
          );
          if (!Cesium.defined(cartesian)) {
            return;
          }
          if (cartesian) {
            const cartographic = Cesium.Cartographic.fromCartesian(cartesian);
            const lon = Cesium.Math.toDegrees(cartographic.longitude);
            const lat = Cesium.Math.toDegrees(cartographic.latitude);

            this.selectMoveEntity.position = Cesium.Cartesian3.fromDegrees(
              lon,
              lat
            );
          }
        }
      }
    },

    onMouseUp: function (e) {
      const res = this.entityByNameExists("polygon");
      if (
        this.curMethod === "TASK_INVESTIGATE" &&
        res &&
        (this.curPageType === "update" || this.curPageType === "add")
      ) {
        const wp = e?.position;
        if (!Cesium.defined(wp)) {
          return;
        }
        const ray = this.viewer.scene.camera.getPickRay(wp);
        if (!Cesium.defined(ray)) {
          return;
        }
        const cartesian = this.viewer.scene.globe.pick(ray, this.viewer.scene);
        if (!Cesium.defined(cartesian)) {
          return;
        }
        if (cartesian) {
          const cartographic = Cesium.Cartographic.fromCartesian(cartesian);
          const lon = Cesium.Math.toDegrees(cartographic.longitude);
          const lat = Cesium.Math.toDegrees(cartographic.latitude);

          this.selectMoveEntity.position = Cesium.Cartesian3.fromDegrees(
            lon,
            lat
          );

          const circleId = this.selectMoveEntity.id;
          const delPointStr = circleId?.slice(7);
          const arr = delPointStr?.split("_");
          const long = arr?.[0];
          const late = arr?.[1];
          const idx = this.areaPoints.indexOf(long);
          if (idx > -1) {
            this.viewer?.entities.removeById(circleId);
            const L = lon.toFixed(6);
            const La = lat.toFixed(6);
            const id = `circle_${L}_${La}`;
            this.addEntityCircleById(id, L, La, null, true);
            this.areaPoints.splice(idx, 2, L, La);
          }
          this.addPolygonById();
        }
        this.selectMoveEntity = {};
      }
    },

    deletePoint: async function () {
      if (this.curMarkerId) {
        const getByIdBox = this.viewer?.entities.getById(this.curMarkerId);
        this.viewer?.entities.remove(getByIdBox);
        this.points.delete(this.curMarkerId);
        await this.removeEntityByName("polyline");
        const delPointStr = this.curMarkerId?.slice(7);
        const arr = delPointStr.split("_");
        const L = arr?.[0];
        const idx = this.polylineArr.indexOf(L);
        if (idx > -1) {
          if (this.polylineArr?.length >= 4) {
            this.polylineArr.splice(idx, 2);
            this.addPolylineEntityByName(this.polylineArr);
          } else {
            await this.removeEntityByName("polyline");
          }
        } else {
          await this.removeEntityByName("polyline");
        }
      }
      this.process =
        this.mapInfoPointsData?.[0]?.params?.process?.length > 0
          ? [...this.mapInfoPointsData?.[0]?.params?.process]
          : [];
      this.isShow = false;
    },
    savePoint: async function (selectPoint) {
      if (this.isMapCorrection) {
        this.removeEntityByName("marker");
        const id = `marker_${this.longitude}_${this.latitude}`;
        // this.addEntityById(id, this.longitude, this.latitude);
        if (this.onSaveMapCorrection) {
          await this.onSaveMapCorrection({
            x: this.longitude,
            y: this.latitude,
          });
        }
      }
      if (this.curMethod === "TASK_NAVIGATION") {
        if (this.curMarkerId) {
          this.points.set(this.curMarkerId, selectPoint);
        } else {
          const id = `marker_${this.longitude}_${this.latitude}`;
          this.addEntityById(id, this.longitude, this.latitude);
          this.points.set(id, selectPoint);
        }

        let pointArr = [];
        for (let i of this.points.values()) {
          pointArr.push(i.location.x);
          pointArr.push(i.location.y);
        }
        this.polylineArr = pointArr;
        if (pointArr.length >= 4) {
          this.addPolylineEntityByName(pointArr);
        }
      }
      if (this.curMethod === "TASK_INVESTIGATE") {
        if (this.$refs.cesiumTooltip) {
          this.cesiumTooltipFormData =
            this.$refs.cesiumTooltip.form.selectPoint;
        }
      }
      this.curMarkerId = null;
      this.isShow = false;
    },

    saveCurPoint: function (selectPoint, obj) {
      const { x, y } = obj;
      if (this.curMethod === "TASK_NAVIGATION") {
        const id = `marker_${x}_${y}`;
        this.addEntityById(id, x, y);
        this.points.set(id, selectPoint);

        let pointArr = [];
        for (let i of this.points.values()) {
          pointArr.push(i.location.x);
          pointArr.push(i.location.y);
        }
        this.polylineArr = pointArr;
        if (pointArr.length >= 4) {
          this.addPolylineEntityByName(pointArr);
        }
      }
      if (this.curMethod === "TASK_INVESTIGATE") {
        if (this.$refs.cesiumTooltip) {
          this.cesiumTooltipFormData =
            this.$refs.cesiumTooltip.form.selectPoint;
        }
      }
    },

    clearAreaPoints: function () {
      this.viewer?.entities?.removeAll();
      this.areaPoints = [];
    },

    // 根据name删除实体
    removeEntityByName: function (name) {
      const entitys = this.viewer?.entities._entities._array;
      let length = entitys?.length;
      // 遍历防止实体减少之后entitys[f]不存在
      for (let f = length - 1; f >= 0; f--) {
        if (entitys[f]._name && entitys[f]._name === name) {
          this.viewer?.entities.remove(entitys[f]);
        }
      }
    },

    entityByNameExists: function (name) {
      const entitys = this.viewer?.entities._entities._array;
      let length = entitys?.length;
      for (let f = length - 1; f >= 0; f--) {
        if (entitys[f]._name && entitys[f]._name === name) {
          return true;
        }
      }
      return false;
    },

    // add circle 实体
    addEntityCircleById: function (id, x, y, pick, circleMarker, options) {
      if (pick && pick.id && pick.id.name === "polygon") {
        return;
      } else {
        this.entity = this.viewer?.entities.add({
          id: id,
          name: "circle",
          position: Cesium.Cartesian3.fromDegrees(x, y), //实体的定位
          point: {
            color: options?.color
              ? Cesium.Color.fromCssColorString(hexToRgba(options?.color, 0.5))
              : Cesium.Color.fromCssColorString(`rgba(255,0,0,1)`),
            pixelSize: 12,
            outlineWidth: 2,
            outlineColor: options?.color
              ? Cesium.Color.fromCssColorString(hexToRgba(options?.color, 1))
              : Cesium.Color.fromCssColorString(`rgba(255,255,0,1)`),
          },
        });
        if (!circleMarker) {
          this.areaPoints.push(x, y);
        }
      }
    },

    // add polygon 实体
    addPolygonById: function (options) {
      if (!options?.color) {
        this.removeEntityByName("polygon");
      }

      const len = this.areaPoints.length;
      if (!options?.arrs && len < 6) {
        this.$message({
          type: "warning",
          message: "至少三个点形成一个区域才可保存哦！",
        });
        return len;
      }
      const positions = Cesium.Cartesian3.fromDegreesArray(
        options?.arrs || this.areaPoints
      );
      this.entity = this.viewer?.entities.add({
        name: "polygon",
        polygon: {
          hierarchy: {
            positions,
          },
          material: options?.color
            ? Cesium.Color.fromCssColorString(hexToRgba(options?.color, 0.5))
            : new Cesium.ColorMaterialProperty(Cesium.Color.RED.withAlpha(0.5)),
        },
      });
    },

    // add marker 实体
    addEntityById: function (id, x, y, options) {
      this.entity = this.viewer?.entities.add({
        id: id,
        name: "marker",
        position: Cesium.Cartesian3.fromDegrees(x, y), //实体的定位
        billboard: {
          image: require("@/assets/img/marker.png"),
          color: options?.color
            ? Cesium.Color.fromCssColorString(hexToRgba(options?.color, 1))
            : Cesium.Color.WHITE.withAlpha(1),
          height: 20, // 以像素为单位
          width: 20,
          sizeInMeters: false,
          scale: 1.0,
          show: true,
        },
      });
    },

    // 创建 polyline 实体
    addPolylineEntityByName: function (arr, options, ws) {
      if (ws) {
        this.viewer?.entities.add({
          name: "ws_polyline",
          polyline: {
            positions: new Cesium.Cartesian3.fromDegreesArray(arr),
            material: options?.color
              ? Cesium.Color.fromCssColorString(hexToRgba(options?.color, 0.7))
              : new Cesium.ColorMaterialProperty(
                  Cesium.Color.RED.withAlpha(0.7)
                ),
            width: 3,
            show: true,
          },
        });
      } else {
        this.viewer?.entities.add({
          name: "polyline",
          polyline: {
            positions: new Cesium.Cartesian3.fromDegreesArray(arr),
            material: options?.color
              ? Cesium.Color.fromCssColorString(hexToRgba(options?.color, 0.7))
              : new Cesium.ColorMaterialProperty(
                  Cesium.Color.RED.withAlpha(0.7)
                ),
            width: 3,
            show: true,
          },
        });
      }
    },

    getApiFormData: async function () {
      if (this.curMethod === "TASK_INVESTIGATE") {
        this.identifierList = await getIdentifierList();
        this.metaTaskList = await getSceneMetaTaskList({ type: 2 });
      } else {
        this.identifierList = [];
        this.metaTaskList = [];
      }
    },

    resetViewer: function () {
      if (this.viewer) {
        this.viewer.destroy();
        this.viewer = null;
      }
    },

    resetData: function () {
      this.isShow = false;
      this.curMarkerId = null;
      this.wpLocation = { x: 0, y: 0 };
      this.polylineArr = [];
      this.process = [];
      this.station = [];
      this.areaPoints = [];
      this.points.clear();
      this.entityPosition = null;
    },

    resetViewerData: function () {
      this.resetData();
      this.viewer?.entities?.removeAll();
      this.polylinePointArr = [];
    },
  },
  beforeDestroy() {
    this.resetViewer();
  },
};
</script>

<style lang="scss" scoped>
@import "./Index.scss";
</style>
