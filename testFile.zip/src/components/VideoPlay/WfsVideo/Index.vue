<template>
  <div class="video_player_wfs" :id="videoId" :style="{ top, left }">
    <div class="video_player_wfs_header" @mousedown="onCircleMousedown(id)">
      <span class="text_overflow_140">{{ videoCheckBox[id] }}</span>
      <span
        :key="videoId"
        class="video_player_wfs_header_controls"
        v-if="!isShowScreenCapture"
      >
        <el-button
          type="primary"
          size="mini"
          @click="handleScreenshot(id, videoCheckBox[id])"
          >截图</el-button
        >
        <el-button
          type="primary"
          size="mini"
          @click="handleRecording(id, videoCheckBox[id])"
          :icon="recording ? 'el-icon-loading' : ''"
          >{{ recording ? "录制中" : "录制" }}</el-button
        >
      </span>
      <span
        v-if="!isShowFull && !isFullScreen"
        class="video_player_wfs_header-x"
        @click="onClickClosed($event, id)"
        >x</span
      >
    </div>
    <VideoFullScreen
      :id="id"
      :isFullScreen="isFullScreen"
      :onIsFullScreen="onIsFullScreen"
      :getCurBehaviorData="getCurBehaviorData"
    />
  </div>
</template>

<script>
let mediaRecorder; // MediaRecorder对象
import VideoFullScreen from "./VideoFullScreen.vue";
import dayjs from "dayjs";
import { addTask } from "@/api/task";
export default {
  props: [
    "id",
    "curTop",
    "curLeft",
    "isFull",
    "videoCheckBoxIndex",
    "videoCheckBox",
    "parentId",
    "getCurBehaviorData",
    "isShowScreenCapture", // 不传默认false， 默认展示
  ],
  data() {
    return {
      videoId: this.id ? `video_player_wfs_${this.id}` : "video_player_wfs",
      top: this.curTop || "0px",
      left: this.curLeft,
      isFullScreen: false,
      isShowFull: this.isFull || false,
      recording: false,
      imgUrl: "", // 截图地址
      videoData: [], // 存储视频流数据
      wfs: null,
    };
  },
  components: {
    VideoFullScreen,
  },
  mounted() {
    this.startWfs();
  },
  methods: {
    onClickClosed: function (e, id) {
      e.stopPropagation();
      const dom = document.getElementById(`video_player_wfs_${id}`);
      dom.style.display = "none";
      this.$emit("closedVideoId", id);
      this.wfs.destroy();
    },
    onCircleMousedown: function (id) {
      const dom = document.getElementById(`video_player_wfs_${id}`);
      let parentObj;
      if (this.parentId) {
        const parentDom = document.getElementById(`${this.parentId}`);
        parentObj = parentDom?.getBoundingClientRect();
      }

      const { width, height } = dom.getBoundingClientRect();
      let w = width / 2;
      let h = height / 2;
      if (dom) {
        w = dom.offsetWidth / 2;
        h = dom.offsetHeight / 2;
      }
      (document.onmousemove = (el) => {
        const pW = parentObj?.width;
        const pH = parentObj?.height;
        const Lw = el.clientX - w;
        const Rh = el.clientY - h;
        const L = Lw + "px"; // 保持中心位置拖拽
        const R = Rh + "px";
        if (
          Lw < 0 ||
          Rh < 0 ||
          pW - el.clientX < w ||
          pH - el.clientY < h + 5
        ) {
          return; // 限制拖拽范围
        } else {
          this.left = L;
          this.top = R;
        }
      }),
        (document.onmouseup = () => {
          document.onmousemove = null;
        });
    },

    onIsFullScreen: function (id) {
      if (!this.isFullScreen) {
        const dom = document.querySelector(`#${this.videoId}`);
        dom.requestFullscreen();
      } else {
        if (document.fullscreenElement) {
          document.exitFullscreen();
        }
      }
      this.isFullScreen = !this.isFullScreen;
    },
    startWfs: function () {
      const dom = document.getElementById(`video_player_wfs_${this.id}`);
      if (!this.left) {
        dom.style.right = "0px";
      }
      if (Wfs.isSupported()) {
        const videoFps = 35;
        const videoDom = document.querySelector(`#${this.id}`);
        const wfs = new Wfs();
        this.wfs = wfs;
        const channelName = this.id?.slice(5);
        wfs.attachMedia(
          videoDom,
          channelName,
          "H264Raw",
          `ws://localhost:8090/cpix/v1.0/websocket/device-video/${channelName}`,
          videoFps
        );
      }
    },
    // 截图
    handleScreenshot(id, name) {
      const video = document.querySelector(`#${id}`); // 获取video节点
      const canvas = document.createElement("canvas"); // 创建canvas节点
      const w = window?.innerWidth || video?.clientWidth;
      const h = window?.innerHeight || video?.clientHeight;
      canvas.width = w;
      canvas.height = h; // 设置宽高
      const ctx = canvas.getContext("2d");
      ctx.drawImage(video, 0, 0, w, h); // video写入到canvas
      this.imgUrl = canvas.toDataURL("image/png"); // 生成截图地址
      const time = dayjs(new Date().getTime()).format("YYYY_MM_DD_HH_mm_ss");
      const newName = `${name}_${time}`;
      this.downloadFileByBase64(this.imgUrl, newName);
    },

    downloadFileByBase64: function (base64, name) {
      const myBlob = this.dataURLtoBlob(base64);
      const myUrl = URL.createObjectURL(myBlob);
      this.downloadVideoFile(myUrl, name);
    },

    dataURLtoBlob: function (dataurl) {
      let arr = dataurl.split(","),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      return new Blob([u8arr], { type: mime });
    },

    // 录制
    handleRecording(id, name) {
      this.$message({
        type: "warning",
        message: "录制功能还不可用哦，敬请期待！",
      });
      // let chunks = [];
      // this.recording = !this.recording;
      // if (this.recording) {
      //   this.$message.success("开始录制");
      //   // this.wfs.startSaveData();
      //   // const video = document.querySelector(`#${id}`);
      //   // const stream = video?.mozCaptureStream
      //   //   ? video?.mozCaptureStream()
      //   //   : video?.captureStream(); // 火狐:mozCaptureStream， chrome/e：captureStream
      //   // mediaRecorder = new MediaRecorder(stream);
      //   // mediaRecorder.ondataavailable = (e) => chunks.push(e.data);
      //   // mediaRecorder.onstop = () => {
      //   //   const blob = new Blob(chunks, { type: "video/webm" });
      //   //   this.videoUrl = URL.createObjectURL(blob);
      //   //   this.downloadVideoFile(this.videoUrl, name);
      //   // };
      //   // mediaRecorder.start();
      // } else {
      //   this.$message.success("结束录制");
      //   // mediaRecorder?.stop();
      //   // const chunksData = this.wfs.endSaveDate();
      //   // const ArrayBufferData = new Uint8Array(chunksData);
      //   // const blob = new Blob([ArrayBufferData], {
      //   //   type: "video/mp4",
      //   // });
      //   // this.videoUrl = URL.createObjectURL(blob);
      //   // this.downloadVideoFile(this.videoUrl, name);
      // }
    },

    downloadVideoFile: function (videoUrl, name) {
      const time = dayjs(new Date().getTime()).format("YYYY_MM_DD_HH_mm_ss");
      const newName = `${name}_${time}`;
      let a = document.createElement("a");
      a.download = newName;
      a.href = videoUrl;
      a.style.display = "none";
      document.body.appendChild(a);
      a.click();
      a.remove();
    },
  },

  destroyed() {
    this?.wfs?.destroy();
  },
};
</script>
<style lang="scss" scoped>
$prefixCls: "video_player_wfs";
.#{$prefixCls} {
  width: 300px;
  height: 200px;
  border: 1px solid rgb(58, 58, 68);
  position: absolute;
  cursor: pointer;
  z-index: 3; // 目前最上层
  &_header {
    height: 32px;
    line-height: 32px;
    text-align: center;
    background-color: #8ec5fc;
    background-image: linear-gradient(62deg, #8ec5fc 0%, #e0c3fc 100%);

    &-x {
      float: right;
      margin: 0 10px;
      font-size: 20px;
    }

    &_controls {
      line-height: 32px;
      display: inline-block;
      position: relative;
      top: -10px;

      .el-button {
        padding: 6px 8px;
      }
      .el-button:first-child {
        margin-left: 6px;
      }
      .el-button + .el-button {
        margin-left: 8px;
      }
    }
  }
}
</style>
