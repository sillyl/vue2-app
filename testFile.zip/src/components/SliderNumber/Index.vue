<template>
  <div class="custom_slider">
    <p class="controls_p_name" v-if="item?.name">{{ item?.name }}</p>
    <div class="custom_slider_group">
      <i class="el-icon-remove-outline" @click="onClickRemove(data, item)"></i>
      <el-slider
        v-model="sliderNumVal"
        :step="step"
        show-stops
        :min="min"
        :max="max"
        :show-tooltip="true"
        :format-tooltip="formatTooltip"
        @change="onChangeSlider(data, item)"
      >
      </el-slider>
      <i
        class="el-icon-circle-plus-outline icon_add_right"
        @click="onAdd(data, item)"
      ></i>
    </div>
  </div>
</template>

<script>
import { triggerCmd } from "@/components/JsonSchema/triggerCmd";
export default {
  props: ["data", "item"],
  data() {
    return {
      sliderNumVal: this.item?.unit?.[0]?.value || 0,
      step: 1,
      min: this.item?.unit?.[0]?.value || 0,
      max: this.item?.unit?.[this.item?.unit?.length - 1]?.value || 5,
    };
  },

  mounted() {},

  methods: {
    formatTooltip(val) {
      const { unit } = this.item;
      const obj = (unit || [])?.filter((i) => i?.value === val)?.[0];
      const name = obj?.name || val;
      return name;
    },

    onClickRemove: async function (data, item) {
      const { type, id } = data;
      const { action } = item;
      if (this.sliderNumVal !== this.min) {
        this.sliderNumVal = this.sliderNumVal - 1;
      }

      await triggerCmd(id, type, action, this.sliderNumVal * 5);
    },

    onAdd: async function (data, item) {
      const { type, id } = data;
      const { action } = item;
      if (this.sliderNumVal !== this.max) {
        this.sliderNumVal = this.sliderNumVal + 1;
      }
      await triggerCmd(id, type, action, this.sliderNumVal * 5);
    },

    onChangeSlider: async function (data, item) {
      const { type, id } = data;
      const { action } = item;
      await triggerCmd(id, type, action, this.sliderNumVal * 5);
    },
  },
};
</script>

<style lang="scss" scoped>
.custom_slider {
  width: 100%;

  &_group {
    position: relative;
  }
  // margin-top: 35px;
  i {
    color: #fff;
    font-size: 24px;
    position: absolute;
    line-height: 38px;
    left: 1.5%;
  }

  .icon_add_right {
    right: 0px;
    top: 0px;
    left: calc(100% - 74px + 40px);
  }
  .el-slider {
    width: calc(100% - 84px);
    margin: 0 40px 0 44px;
  }
}
</style>
