<template>
  <div class="checkBoxCustum">
    <div v-for="(i, idx) in data.group" :key="i.name + i.groupId + idx">
      <el-checkbox-group
        v-model="checkList"
        @change="onChangeVideoCheckBox"
        :max="3"
      >
        <el-checkbox
          v-for="item in i.videoUrls"
          :key="item.action - 1"
          :title="
            basicInfo.sn + '(' + basicInfo.name + ')' + '-视频' + item.action
          "
          :label="'video' + basicInfo.id + '-' + (item.action - 1)"
          >{{
            basicInfo.sn + "(" + basicInfo.name + ")" + "-视频" + item.action
          }}</el-checkbox
        >
      </el-checkbox-group>
    </div>
    <div class="control_mode_video_list" v-if="checkList?.length > 0">
      <div v-for="(item, idx) in checkList" :key="item + idx">
        <WfsVideo
          :videoCheckBox="videoCheckBox"
          :videoCheckBoxIndex="videoCheckBoxIndex"
          :id="item"
          @closedVideoId="getClosedVideoId"
          :curTop="checkList.indexOf(item) * 202 + 'px'"
          :curLeft="'calc(75% - 300px)'"
          :parentId="parentId || 'control_mode_content_plat'"
        />
      </div>
    </div>
  </div>
</template>

<script>
import WfsVideo from "@/components/VideoPlay/WfsVideo/Index.vue";
import {
  localStorageSetItem,
  localStorageGetItem,
} from "@/utils/localStorgaeFun.js";
import { isEmpty } from "lodash";

export default {
  props: [
    "data",
    "parentId",
    "basicInfo",
    "videoCheckBox",
    "videoCheckBoxIndex",
  ],

  data() {
    return {
      checkList: [],
    };
  },

  components: {
    WfsVideo,
  },

  methods: {
    onChangeVideoCheckBox: function (value) {
      localStorageSetItem("videoCheckList", this.checkList);
    },

    getClosedVideoId: function (data) {
      const res = this.checkList.filter((i) => i !== data);
      this.checkList = res;
      localStorageSetItem("videoCheckList", res);
    },
  },
};
</script>

<style lang="scss" scoped>
.checkBoxCustum {
  max-height: 80px;
  height: 80px;
  overflow: auto;

  .el-checkbox-group {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: flex-start;
    align-items: center;

    .el-checkbox {
      margin-right: 0px;
      color: #000;
      margin-left: 6px;
    }
    .el-checkbox:nth-child(2n) {
      margin-left: 8px;
    }
    ::v-deep {
      .el-checkbox__input {
        top: -12px;
      }
      .el-checkbox {
        width: 47%;
      }
      .el-checkbox__label {
        font-size: 16px;
        line-height: 32px;
        width: calc(100% - 25px);
        display: inline-block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .el-checkbox__inner {
        z-index: inherit;
      }
    }
  }
}
</style>
