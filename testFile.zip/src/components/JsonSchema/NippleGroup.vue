<template>
  <div class="nipple_group">
    <div
      class="nipple_group_content"
      v-for="(i, idx) in data.group"
      :key="(i.groupId || i.id) + idx"
    >
      <p v-if="i.name" class="controls_p_name">{{ i.name }}</p>
      <Nipple
        :joystickId="`joystickGroup_${index}_ ${k.action}`"
        class="nipple_item"
        :data="i"
        v-for="(k, index) in i.packages"
        :key="k.action"
        :item="k"
        :group="true"
      >
        <div class="joystick_desc">{{ k.name }}</div>
      </Nipple>
    </div>
  </div>
</template>

<script>
import Nipple from "@/components/Nipple/Index.vue";
export default {
  props: ["data"],
  data() {
    return {};
  },
  components: {
    Nipple,
  },
};
</script>

<style lang="scss" scoped>
.nipple_group {
  &_content {
    .nipple_item + .nipple_item {
      margin-left: 40px;
    }
  }
}
</style>
