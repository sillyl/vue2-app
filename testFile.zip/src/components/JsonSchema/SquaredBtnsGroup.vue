<template>
  <div class="squared_btn_group">
    <div
      v-for="(i, idx) in data.group"
      :key="(i.groupId || i.id) + idx"
      class="squared_btn_group_content"
    >
      <p v-if="i.name" class="controls_p_name">{{ i.name }}</p>
      <SquaredBtns :data="i" />
    </div>
  </div>
</template>

<script>
import SquaredBtns from "../SquaredBtns/Index.vue";
export default {
  props: ["data"],
  data() {
    return {};
  },
  components: {
    SquaredBtns,
  },
  methods: {},
};
</script>

<style lang="scss" scoped>
.squared_btn_group {
  &_content {
    display: flex;
    align-items: center;
    justify-content: space-around;
    .controls_p_name {
      line-height: 130px;
      width: 60px;
    }
  }
}
</style>
