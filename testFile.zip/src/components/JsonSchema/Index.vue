<template>
  <div class="jsonSchema_content" :id="jsonSchemaId" :key="jsonSchemaId">
    <div v-for="(item, idx) in jsonData" :key="idx">
      <el-alert
        v-if="item.groupName"
        :title="item.groupName"
        type="success"
        center
        :closable="false"
      />
      <SliderNumberGroup
        v-if="isShowSliderNumber(item)"
        :key="(item.id || item.groupId) + idx"
        :data="sliderNumberItem"
      />
      <ButonGroup
        v-if="isShowButonGroup(item)"
        :key="(item.id || item.groupId) + idx"
        :data="butonGroupItem"
      />
      <!-- <NippleGroup
        v-if="item.groupId === 9"
        :key="item.groupId + idx"
        :data="item"
      /> -->
      <ButtonOptionsGroup
        v-if="isShowButtonOptionsGroup(item)"
        :key="(item.id || item.groupId) + idx"
        :data="buttonOptionsGroupItem"
      />
      <CheckBoxCustom
        v-if="isShowCheckBoxCustom(item)"
        :data="checkBoxCustomItem"
        :videoUrls="videoUrls"
        :videoCheckBox="videoCheckBox"
        :videoCheckBoxIndex="videoCheckBoxIndex"
        :basicInfo="basicInfo"
      />
      <SquaredBtnsGroup
        v-if="isShowSquaredBtnsGroup(item)"
        :key="(item.id || item.groupId) + idx"
        :data="squaredBtnsGroupItem"
      />
      <div
        v-if="item.split"
        class="split_H"
        :style="{ height: (item.split || 0) + 'px' }"
      />
    </div>
  </div>
</template>

<script>
import SliderNumberGroup from "./SliderNumberGroup.vue";
import ButonGroup from "./ButtonGroup.vue";
import NippleGroup from "./NippleGroup.vue";
import ButtonOptionsGroup from "./ButtonOptionsGroup.vue";
import CheckBoxCustom from "../CheckBoxCustum/Index.vue";
import SquaredBtnsGroup from "./SquaredBtnsGroup.vue";
import { localStorageGetItem } from "@/utils/localStorgaeFun.js";

export default {
  props: [
    "jsonData",
    "jsonSchemaId",
    "videoUrls",
    "basicInfo",
    "videoCheckBox",
    "videoCheckBoxIndex",
  ],
  data() {
    return {
      sliderNumberItem: {},
      butonGroupItem: {},
      buttonOptionsGroupItem: {},
      checkBoxCustomItem: {},
      squaredBtnsGroupItem: {},
    };
  },
  components: {
    SliderNumberGroup,
    ButonGroup,
    // NippleGroup,
    ButtonOptionsGroup,
    CheckBoxCustom,
    SquaredBtnsGroup,
  },

  methods: {
    isShowSliderNumber: function (item) {
      const data = this.getSliderNumberGroup(item?.group);
      if (data?.length > 0) {
        this.sliderNumberItem = { ...item, group: data };
        return true;
      }
      return false;
    },
    getSliderNumberGroup: function (group) {
      // 得到本组 渲染SliderNumberGroup 的数据
      const data = group?.map((i) => {
        let idStart = String(i?.id).substr(0, 2);
        if (
          idStart === "92" &&
          (i?.type === 1 || i?.type === 2 || i?.type === 3)
        ) {
          return { ...i };
        }
      });
      return data?.filter(Boolean);
    },

    isShowButonGroup: function (item) {
      const data = this.getButonGroup(item?.group);
      if (data?.length > 0) {
        this.butonGroupItem = { ...item, group: data };
        return true;
      }
      return false;
    },

    getButonGroup: function (group) {
      const data = group?.map((i) => {
        let idStart = String(i?.id).substr(0, 2);
        if (
          idStart === "30" &&
          (i?.type === 4 || i?.type === 2 || i?.type === 3)
        ) {
          return { ...i };
        }
        if (idStart === "11" && (i?.type === 2 || i?.type === 3)) {
          return { ...i };
        }
        if (idStart === "10" && i?.type === 4) {
          return { ...i };
        }
        if (
          (idStart === "31" ||
            idStart === "32" ||
            idStart === "33" ||
            idStart === "34" ||
            idStart === "35" ||
            idStart === "36" ||
            idStart === "37" ||
            idStart === "38" ||
            idStart === "39" ||
            idStart === "90" ||
            idStart === "91" ||
            idStart === "93" ||
            idStart === "96" ||
            idStart === "97") &&
          i?.type === 2
        ) {
          return { ...i };
        }
        if (idStart === "95") {
          return { ...i };
        }
      });
      return data?.filter(Boolean);
    },

    isShowButtonOptionsGroup: function (item) {
      const data = this.getButtonOptionsGroup(item?.group);
      if (data?.length > 0) {
        this.buttonOptionsGroupItem = { ...item, group: data };
        return true;
      }
      return false;
    },

    getButtonOptionsGroup: function (group) {
      const data = group?.map((i) => {
        let idStart = String(i?.id).substr(0, 2);
        if (idStart === "10" && i?.type === 1) {
          return { ...i };
        }
      });
      return data?.filter(Boolean);
    },

    isShowCheckBoxCustom: function (item) {
      const data = this.getCheckBoxCustom(item?.group);
      if (data?.length > 0) {
        this.checkBoxCustomItem = { ...item, group: data };
        return true;
      }
      return false;
    },

    getCheckBoxCustom: function (group) {
      const data = group?.map((i) => {
        // 处理展示的视频列表，同时把action 作为ws 参数（重要）
        let videoArr = [];
        for (let k of i.packages) {
          if (k?.action) {
            const url = this.videoUrls[k.action - 1];
            if (url) {
              videoArr.push({ action: k.action, url });
            }
          }
        }
        const newVideoArr = [...videoArr?.filter(Boolean)];
        let idStart = String(i?.id).substr(0, 2);
        const res = localStorageGetItem("curDeviceInfo");
        if (idStart === "94" && i?.type === 5) {
          return { ...i, videoUrls: newVideoArr };
        }
      });
      return data?.filter(Boolean);
    },

    isShowSquaredBtnsGroup: function (item) {
      const data = this.getSquaredBtnsGroup(item?.group);
      if (data?.length > 0) {
        this.squaredBtnsGroupItem = { ...item, group: data };
        return true;
      }
      return false;
    },

    getSquaredBtnsGroup: function (group) {
      const data = group?.map((i) => {
        let idStart = String(i?.id).substr(0, 2);
        if (idStart === "21" && i?.type === 2) {
          return { ...i };
        }
      });
      return data?.filter(Boolean);
    },
  },

  destroyed() {
    this.sliderNumberItem = {};
    this.butonGroupItem = {};
    this.buttonOptionsGroupItem = {};
    this.checkBoxCustomItem = {};
    this.squaredBtnsGroupItem = {};
  },
};
</script>

<style lang="scss" scoped>
.jsonSchema_content {
  ::v-deep {
    .el-alert {
      margin-bottom: 6px;
      border-radius: 0px;
    }
  }
}
</style>
