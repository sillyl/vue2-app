<template>
  <div class="squared_btns" v-if="data.packages?.length > 0">
    <div
      class="icon_direction"
      v-for="(item, idx) in data.packages"
      :key="item.action + idx"
      @click="onBtnClick(item)"
    >
      <i :class="iconClass[idx]">{{ iconClass[idx] ? "" : "ok" }}</i>
    </div>
  </div>
</template>

<script>
import { triggerCmd } from "@/components/JsonSchema/triggerCmd";
export default {
  props: ["data"],
  data() {
    return {
      iconClass: [
        "el-icon-top-left",
        "el-icon-top",
        "el-icon-top-right",
        "el-icon-back",
        "",
        "el-icon-right",
        "el-icon-bottom-left",
        "el-icon-bottom",
        "el-icon-bottom-right",
      ],
    };
  },

  methods: {
    onBtnClick: async function (item) {
      const { id, type } = this.data;
      const { action } = item;
      await triggerCmd(id, type, action);
    },
  },
};
</script>

<style lang="scss" scoped>
.squared_btns {
  width: 130px;
  height: 130px;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
}

.icon_direction {
  width: calc((100% - 8px - 12px) / 3);
  height: calc((100% - 8px - 12px) / 3);
  border: 1px solid #b98716;
  border-radius: 16%;
  display: flex;
  justify-content: center;
  align-items: center;
  background: black;

  i {
    font-size: 25px;
    color: darkturquoise;
    height: 100%;
    width: 100%;
    text-align: center;
    line-height: 38px;
  }
}

.icon_direction:active {
  background: #66b1ff;
  i {
    color: #fff;
  }
}
</style>
