<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style lang="scss" scoped>
#app {
  height: 100%;
  width: 100%;
}
</style>
