<template>
  <div class="robot_history_task" v-if="$store.state.isTaskHistory">
    <div class="robot_title robot_history_task_header">
      历史任务
      <i class="el-icon-close" @click="onClosed"></i>
    </div>
    <div class="robot_history_task_content">
      <el-table
        highlight-current-row
        stripe
        :data="historyTaskList"
        ref="sceneTableRef"
        height="100%"
        v-loading="historyTableLoading"
      >
        >
        <el-table-column
          prop="name"
          label="任务名称"
          :formatter="formatterFun"
          column-key="name"
        >
          <template slot-scope="scope">
            <a
              target="_self"
              rel="noopener noreferrer"
              @click="onClickTaskInfo(scope.row)"
              >{{ scope.row.name }}</a
            >
          </template>
        </el-table-column>
        <el-table-column
          prop="status"
          label="任务状态"
          column-key="status"
          :formatter="formatterFun"
        />
        <el-table-column
          prop="type"
          label="任务类型"
          column-key="type"
          :formatter="formatterFun"
        />
        <el-table-column
          prop="createTime"
          label="创建时间"
          column-key="createTime"
          :formatter="formatterFun"
        />
        <el-table-column label="操作" fixed="right" width="190px">
          <template slot-scope="scope">
            <el-button
              @click="onAction(scope.row, 'update')"
              type="text"
              size="small"
              >编辑</el-button
            >
            <el-button
              @click="onAction(scope.row, 'suspend')"
              type="text"
              size="small"
              v-if="
                scope.row.status === 'Create' ||
                scope.row.status === 'Running' ||
                scope.row.status === 'Pause'
              "
              >{{ scope.row.status === "Running" ? "暂停" : "启动" }}</el-button
            >
            <el-button
              @click="onAction(scope.row, 'end')"
              type="text"
              size="small"
              v-if="
                scope.row.status === 'Running' || scope.row.status === 'Pause'
              "
              >终止</el-button
            >
            <el-button
              @click="onAction(scope.row, 'clone')"
              type="text"
              size="small"
              >克隆</el-button
            >
            <el-button
              @click="onAction(scope.row, 'delete')"
              type="text"
              size="small"
              class="stop_btn"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
import {
  getOnlineTaskList,
  getHistoryTaskList,
  executeTask,
  cloneTask,
  deleteTask,
} from "@/api/task";
import dayjs from "dayjs";
import { Message } from "element-ui";
export default {
  props: [
    "getOnlineTaskList",
    "historyTaskList",
    "historyTableLoading",
    "getHistroyTaskList",
  ],
  data() {
    return {
      isClickOpts: false, // 用来标识用户是在历史记录操作过，在关闭历史记录时做场景在线任务列表数据更新
    };
  },
  components: {},
  mounted() {},
  methods: {
    formatterFun(row, column) {
      const { columnKey } = column;
      switch (columnKey) {
        case "createTime": {
          return row[columnKey]
            ? dayjs(row[columnKey]).format("YYYY-MM-DD HH:mm:ss")
            : "-";
        }
        default:
          return row[columnKey] || "-";
      }
    },
    onAction: async function (row, type) {
      this.isClickOpts = true;
      let params = { id: row.id };
      switch (type) {
        case "suspend":
          {
            params = { ...params, status: "Running" };
            if (row.status === "Running") {
              params = { ...params, status: "Pause" };
            }
            await executeTask(params);
            await this.getHistroyTaskList();
          }
          break;
        case "end":
          this.$confirm("是否确认终止任务：" + row.name + "?", "终止任务", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning",
          }).then(async () => {
            params = { ...params, status: "Cancel" };
            await executeTask(params);
            await this.getHistroyTaskList();
            this.$message({
              type: "success",
              message: "终止任务成功!",
            });
          });
          break;
        case "clone":
          {
            try {
              const res = await cloneTask(params);
              await this.getHistroyTaskList();
              this.$message({
                message: "克隆成功, 请前往场景详情在线任务列表中查看！",
                type: "success",
              });
            } catch (error) {
              console.log("clone error", error);
            }
          }
          break;
        case "delete":
          this.$confirm("是否确认删除任务：" + row.name + "?", "删除任务", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning",
          }).then(async () => {
            await deleteTask(row);
            await this.getHistroyTaskList();
            this.$message({
              message: "删除成功",
              type: "success",
            });
          });

          break;
        default: // 默认走更新update
          this.onClosed("update");
          this.$store.commit("updateIsTask", {
            isTask: true,
            curTaskInfo: {
              ...row,
              optsType: "update",
              customCloseFun: this.customClose,
            },
          });
          break;
      }
    },
    onClickTaskInfo: function (row) {
      this.$router.push(`/task/${row.id}/detail`);
    },
    customClose: function () {
      this.$store.commit("updateIsTaskHistory", true);
    },
    onClosed: function (type) {
      this.$store.commit("updateIsTaskHistory", false);
      if (this.getOnlineTaskList && type !== "update") {
        this.getOnlineTaskList(true);
      }
    },
  },
};
</script>

<style lang="scss" scoped>
@import "@/assets/css/common.scss";
$prefixCls: "robot_history_task";
.#{$prefixCls} {
  position: absolute;
  bottom: 0px;
  height: 40%;
  width: 100%;
  z-index: 1;

  &_header {
    color: #fff;
    border-bottom: 1px solid $grey-color;
    background-color: $header-color;
    .el-icon-close {
      float: right;
      font-size: 20px;
    }
  }
  &_content {
    height: calc(100% - 28px);
    background-color: $header-color;
  }
}
</style>
