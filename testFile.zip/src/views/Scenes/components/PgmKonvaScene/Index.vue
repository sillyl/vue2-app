<template>
  <div
    class="pgm_konva"
    id="pgmContainer"
    :style="{
      height: $store.state.isCollapse ? '100%' : 'calc(100% - 22px)',
    }"
  >
    <v-stage
      class="konva-stage"
      ref="konvaStage"
      :config="konvaConfig.stage"
      @click="onStageClick"
      @wheel="wheelForScale($event)"
      @touchstart="onStageTouchstart"
      @touchmove="onStageTouchmove($event)"
      @touchend="onStageTouchend"
      v-if="pgmData"
    >
      <!--  @dragstart="onDragstart"
      @dragmove="onDragmove"
      @dragend="onDragend" -->
      <v-layer ref="konvaLayer">
        <v-group :config="konvaConfig.group">
          <v-image
            :config="{
              image: konvaConfig.pgmImage,
            }"
          />
        </v-group>
        <!-- websoket 实时路线数据 -->
        <v-group :config="konvaConfig.group">
          <v-line
            v-for="(item, index) in konvaConfig.path"
            :key="index"
            :config="{
              points: sn ? item.groupLine : item,
              stroke: item.color || '#ffff00',
              strokeWidth: 6,
              lineCap: 'round',
              lineJoin: 'round',
            }"
          >
          </v-line>
        </v-group>
        <v-group :config="konvaConfig.group">
          <v-circle
            v-for="(item, index) in konvaConfig.curPoint"
            :key="index + 3000"
            :config="{
              x: item.x,
              y: item.y,
              radius: 8,
              fill: item?.color || '#ffff00',
              stroke: 'black',
              strokeWidth: 3,
            }"
          >
          </v-circle>
          <v-arrow
            v-for="(item, index) in konvaConfig.curPoint"
            :key="index + 2000"
            :config="{
              x: item.x,
              y: item.y,
              points: [
                0,
                0,
                50 * Math.cos((item.omega * Math.PI) / 180),
                50 * Math.sin((item.omega * Math.PI) / 180),
              ],
              pointerLength: 30,
              pointerWidth: 10,
              fill: item?.color || '#ffff00',
              stroke: 'black',
              strokeWidth: 3,
            }"
          >
          </v-arrow>
        </v-group>
        <!-- 点云? -->
        <v-group :config="konvaConfig.group">
          <v-circle
            v-for="(item, index) in konvaConfig.cloudPoints"
            :key="index + 4000"
            :config="{
              x: item.x,
              y: item.y,
              radius: 4,
              fill: '#0000ff',
            }"
          >
          </v-circle>
        </v-group>
        <!-- 导航点交互 -->
        <v-group :config="konvaConfig.group">
          <v-line
            v-for="(item, index) in konvaConfig.polyline"
            :key="index + 1000"
            :config="{
              points: isDetail ? item.groupLine : item,
              stroke: item.color || '#ff0000',
              strokeWidth: 6,
              lineCap: 'round',
              lineJoin: 'round',
            }"
          >
          </v-line>
        </v-group>
        <v-group :config="konvaConfig.group">
          <v-circle
            v-for="(item, index) in konvaConfig.points"
            :key="index"
            :config="{
              id: index,
              x: item.x,
              y: item.y,
              radius: 8,
              fill: item?.color || '#ff0000',
            }"
          >
          </v-circle>
        </v-group>
        <v-group :config="konvaConfig.group">
          <v-arrow
            v-for="(item, index) in konvaConfig.points"
            :key="index + 99"
            :config="{
              id: index,
              x: item.x,
              y: item.y,
              points: [
                0,
                0,
                50 * Math.cos((item.omega * Math.PI) / 180),
                50 * Math.sin((item.omega * Math.PI) / 180),
              ],
              pointerLength: 30,
              pointerWidth: 10,
              fill: item?.color || '#ff0000',
              stroke: 'black',
              strokeWidth: 3,
            }"
          >
          </v-arrow>
        </v-group>
        <!-- 区域点交互 -->
        <v-group :config="konvaConfig.group">
          <v-line
            v-for="(item, index) in konvaConfig.polygon"
            :key="index"
            :config="{
              id: index,
              points: optsType === 'seleted' ? item.groupPolygon : item,
              stroke: item.color || '#ff0000',
              strokeWidth: 6,
              lineCap: 'round',
              lineJoin: 'round',
              fill: item.color || '#ff0000',
              opacity: 0.5,
              closed: true,
            }"
          >
          </v-line>
        </v-group>
        <v-group :config="konvaConfig.group">
          <v-circle
            name="area_circle"
            v-for="(item, index) in konvaConfig.areaPoints"
            :key="index"
            :config="{
              id: item.x + '_' + item.y,
              x: item.x,
              y: item.y,
              radius: 8,
              fill: item.color || '#ff0000',
            }"
            :draggable="
              optsType === 'add' || optsType === 'update' ? true : false
            "
            @dragstart="onDragAreaPointStart"
            @dragend="onDragAreaPointEnd"
          >
          </v-circle>
        </v-group>
      </v-layer>
    </v-stage>
    <NotFound
      v-if="!pgmData"
      desc="暂无地图信息"
      :image="require('@/assets/img/empty.svg')"
    />
    <CoordinatePickup
      :isShow="isShow"
      :visible="visibleCircleTooltip"
      :triggerPosition="triggerPosition"
      :circleNeedData="circleNeedData"
      ref="circleTooltipRef"
      @saveCircleTooltipData="saveCircleTooltipData"
      @deleteCircleTooltipData="deleteCircleTooltipData"
      :isInitPickUp="isInitPickUp"
      :onSaveInitPickup="onSaveInitPickup"
    />
    <AttributeForm
      v-if="isAttributeForm"
      :artFormTop="artFormTop"
      :artFormLeft="artFormLeft"
      :identifierList="identifierList"
      :metaTaskList="metaTaskList"
      :onArtFormDelete="onArtFormDelete"
      :onArtFormSave="onArtFormSave"
      :TaskDetailData="TaskDetailData"
    />
  </div>
</template>
<script>
let timeId;
let lastDist;
let lastCenter;
import CoordinatePickup from "@/components/CoordinatePickup/Index.vue";
import AttributeForm from "../AttributeForm/Index.vue";
import GlobalLoading from "@/components/Loading/Loading.js";
import {
  getMinPoint,
  getKonvaConfigByObj,
  getCenter,
  getDistance,
  getObjXY,
} from "@/utils/CoordinatePickupFun.js";
import { isEqual, isEmpty } from "lodash";
import { viewMap } from "@/api/map";
import { MapImage } from "@/utils/mapImg.js";
import { getIdentifierList } from "@/api/identify";
import { getSceneMetaTaskList } from "@/api/task";
import NotFound from "@/components/NotFound/Index.vue";
import { stepLineSegment, stepPgmLineSegment } from "@/utils/geoposition.js";
export default {
  props: [
    "mapId",
    "wsData",
    "isInitPickUp",
    "onSaveInitPickup",
    "isSceneName",
    "deviceId",
    "buildMapping",
  ],
  data() {
    return {
      pgmData: null,
      konvaConfig: {
        stage: {
          width: 1000,
          height: 1000,
          // draggable: true,
        },
        group: {
          x: 0,
          y: 0,
        },
        pgmImage: null,
        points: [],
        polyline: [],
        polygon: [],
        areaPoints: [],
        path: [],
        curPoint: [],
        cloudPoints: [],
      },
      visibleCircleTooltip: false,
      triggerPosition: {
        layerX: 0,
        layerY: 0,
        clientX: 0,
        clientY: 0,
        pageX: 0,
        pageY: 0,
      },
      threshold: 0.01,
      isTouchStart: false,
      isTouchmoveing: false,
      metaTaskList: [],
      identifierList: [],
      selectPoint: { location: { omega: 0 }, process: [], station: [] },
      stagePointerPosition: {
        x: 0,
        y: 0,
      },
      stageScale: 1,
      // 插入节点的最大数量（包括已删除的），这是个递增值
      historyMaxnodeNum: 0,
      points: new Map(),
      areaPoints: [],
      isDraging: false,
      startDragData: null,
      diffLayerX: 0,
      diffLayerY: 0,
      diffClientX: 0,
      diffClientY: 0,
      diffPageX: 0,
      diffPageY: 0,
      cvsW: null,
      cvsH: null,
      isDetail: false,
      isShow: true,
      method: "",
      optsType: "",
      isAttributeForm: false,
      artFormTop: 0,
      artFormLeft: 0,
      infoAreaPoints: [],
      attributeFormData: [],
      curDragAreaPoint: null,
      sn: false,
      timeId: null,
      mapWs: null,
    };
  },
  computed: {
    circleNeedData() {
      return {
        stage: {
          width: this.cvsW,
          height: this.cvsH,
        },
        points: this.points,
        threshold: this.threshold,
        id: "pgmContainer",
        isTouchStart: this.isTouchStart,
        isTouchmoveing: this.isTouchmoveing,
        form: {
          omega: 0,
          identifierList: this.identifierList, // 目标物
          metaTaskList: this.metaTaskList, // 动作
          selectPoint: this.selectPoint, // 选择点
        },
        stagePointerPosition: this.stagePointerPosition,
        stageScale: this.stageScale,
        isDraging: this.isDraging,
        diffLayerX: this.diffLayerX,
        diffLayerY: this.diffLayerY,
        diffClientX: this.diffClientX,
        diffClientY: this.diffClientY,
        diffPageX: this.diffPageX,
        diffPageY: this.diffPageY,
      };
    },
  },
  components: {
    CoordinatePickup,
    NotFound,
    AttributeForm,
  },
  async mounted() {
    await this.getCircleData();
    this.replaceWsData(this.wsData);
  },
  watch: {
    mapId: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.getCircleData();
      }
    },
    $route: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.getCircleData();
      }
    },
    wsData: function (newVal, oldVal) {
      console.log("wsData", newVal);
      // if (!isEqual(newVal, oldVal)) {
      this.replaceWsData(newVal);
      // }
    },
  },
  methods: {
    replaceWsData(arr) {
      // console.log("arr", arr);
      this.konvaConfig.curPoint = [];
      for (let k = 0; k <= arr?.length; k++) {
        const data = arr[k];
        const travel = data?.travel;
        const cloud = data?.cloud;
        const color = data?.color;
        const sn = data?.sn;
        let pointArr = [];
        let item = {};
        if (!isEmpty(travel) && this.cvsW && this.cvsH) {
          const { location } = travel;
          for (let i = 0; i < location?.length; i++) {
            let lct = location[i];
            const curX = Math.round(this.cvsW * Math.abs(lct.x));
            const curY = Math.round(this.cvsH * Math.abs(lct.y));
            pointArr.push(curX, curY);
            item = { x: curX, y: curY, omega: lct.omega, color };
          }
          if (sn) {
            // 组
            this.sn = true;
            this.konvaConfig.path.push({
              color,
              groupLine: pointArr,
            });
            this.konvaConfig.curPoint.push({
              sn,
              ...item,
            });
          } else {
            // 单个设备数据
            this.sn = false;
            this.konvaConfig.path = [pointArr];
            this.konvaConfig.curPoint.push(item);
          }
        }

        if (!isEmpty(cloud)) {
          for (var i = 0; i < cloud?.location.length; i++) {
            const lct = cloud?.location[i];
            const curX = Math.round(this.cvsW * Math.abs(location.x));
            const curY = Math.round(this.cvsH * Math.abs(location.y));
            const item = { x: curX, y: curY };
            this.konvaConfig.cloudPoints.push(item);
          }
        }
      }
    },
    onDragstart: function (el) {
      this.isDraging = true;
      const { layerX, layerY, clientX, clientY, pageX, pageY } = el.evt;
      this.startDragData = {
        xL: layerX,
        yL: layerY,
        xC: clientX,
        yC: clientY,
        xP: pageX,
        yP: pageY,
      };
    },
    onDragmove: function () {
      this.visibleCircleTooltip = false;
    },
    onDragend: function (e) {
      const { xL, yL, xC, yC, xP, yP } = this.startDragData;
      const { layerX, layerY, clientX, clientY, pageX, pageY } = e.evt;
      this.diffLayerX = layerX + this.diffLayerX - xL;
      this.diffLayerY = layerY + this.diffLayerY - yL;
      this.diffClientX = clientX + this.diffClientX - xC;
      this.diffClientY = clientY + this.diffClientY - yC;
      this.diffPageX = pageX + this.diffPageX - xP;
      this.diffPageY = pageY + this.diffPageX - yP;
    },
    getCircleData: async function () {
      try {
        // GlobalLoading.loadingShow();
        // if (this.timeId) {
        //   await this.clearTimeoutData();
        // }
        if (this.mapWs) {
          this.closeMapWebsoket();
        }
        await this.viewMap();
        await this.getCircleNeedDataList();
      } catch (error) {
        // GlobalLoading.loadingClose();
      } finally {
        // GlobalLoading.loadingClose();
      }
    },
    getCircleNeedDataList: async function () {
      this.identifierList = await getIdentifierList();
      this.metaTaskList = await getSceneMetaTaskList({ type: 2 });
    },
    viewMap: async function () {
      await this.resetData();
      if (
        (this.mapId && !this.isSceneName) ||
        (this.mapId && !this.buildMapping)
      ) {
        try {
          const pgmImageData = await viewMap({
            id: this.mapId,
          });
          this.pgmData = pgmImageData;
          if (pgmImageData) {
            let img = new MapImage(pgmImageData);
            let canvasImg = img.getInitMap("canvas");
            const dom = document.querySelector(".konva-stage");
            // this.konvaConfig.stage.width = dom.clientWidth;
            // this.konvaConfig.stage.height = dom.clientHeight;
            this.konvaConfig.stage.width = canvasImg.width;
            this.konvaConfig.stage.height = canvasImg.height;
            this.cvsW = canvasImg.width;
            this.cvsH = canvasImg.height;
            this.konvaConfig.pgmImage = new Image();
            this.konvaConfig.pgmImage.src = canvasImg.toDataURL();
          }
        } catch (error) {
          console.log("map error----", error);
        }
      }
      if (this.isSceneName || this.buildMapping === true) {
        this.konvaConfig.pgmImage = new Image();
        await this.wsMapWs();
      }
    },

    wsMapWs: function () {
      const mapWsUrl = `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/map/${this.deviceId}`;
      this.pgmData = "";
      this.mapWs = new WebSocket(mapWsUrl);
      this.mapWs.onopen = () => {
        console.log(`${mapWsUrl}----连接成功---`);
        /* mock svg */
        // const base64Str =
        //   "PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIKICAiaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkIj4KPCEtLSBDcmVhdGVkIHdpdGggbWF0cGxvdGxpYiAoaHR0cHM6Ly9tYXRwbG90bGliLm9yZy8pIC0tPgo8c3ZnIGhlaWdodD0iMzQ1LjZwdCIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgNDYwLjggMzQ1LjYiIHdpZHRoPSI0NjAuOHB0IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIj4KIDxtZXRhZGF0YT4KICA8cmRmOlJERiB4bWxuczpjYz0iaHR0cDovL2NyZWF0aXZlY29tbW9ucy5vcmcvbnMjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgIDxjYzpXb3JrPgogICAgPGRjOnR5cGUgcmRmOnJlc291cmNlPSJodHRwOi8vcHVybC5vcmcvZGMvZGNtaXR5cGUvU3RpbGxJbWFnZSIvPgogICAgPGRjOmRhdGU+MjAyMy0xMi0xMVQxNDoyNzoyNy44NjI3NjQ8L2RjOmRhdGU+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzpjcmVhdG9yPgogICAgIDxjYzpBZ2VudD4KICAgICAgPGRjOnRpdGxlPk1hdHBsb3RsaWIgdjMuMy40LCBodHRwczovL21hdHBsb3RsaWIub3JnLzwvZGM6dGl0bGU+CiAgICAgPC9jYzpBZ2VudD4KICAgIDwvZGM6Y3JlYXRvcj4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZGVmcz4KICA8c3R5bGUgdHlwZT0idGV4dC9jc3MiPip7c3Ryb2tlLWxpbmVjYXA6YnV0dDtzdHJva2UtbGluZWpvaW46cm91bmQ7fTwvc3R5bGU+CiA8L2RlZnM+CiA8ZyBpZD0iZmlndXJlXzEiPgogIDxnIGlkPSJwYXRjaF8xIj4KICAgPHBhdGggZD0iTSAwIDM0NS42IApMIDQ2MC44IDM0NS42IApMIDQ2MC44IDAgCkwgMCAwIAp6CiIgc3R5bGU9ImZpbGw6I2ZmZmZmZjsiLz4KICA8L2c+CiAgPGcgaWQ9ImF4ZXNfMSI+CiAgIDxnIGlkPSJsaW5lMmRfMSI+CiAgICA8cGF0aCBjbGlwLXBhdGg9InVybCgjcDY5YjE1ZDc4NjQpIiBkPSJNIDgxLjMwMzg1NyAxNDYuNjgxMDYyIApMIDgxLjY0MzQ1NCAxNDYuMzQxNDY1IApMIDgxLjk4MzA1MSAxNDYuMzQxNDY1IApMIDgyLjMyMjY0NyAxNDYuMzQxNDY1IApMIDgyLjY2MjI0NCAxNDYuMzQxNDY1IApMIDgzLjAwMTg0MSAxNDYuMzQxNDY1IApMIDgzLjM0MTQzOCAxNDYuMzQxNDY1IApMIDgzLjY4MTAzNSAxNDYuMzQxNDY1IApMIDg0LjAyMDYzMSAxNDYuMzQxNDY1IApMIDg0LjM2MDIyOCAxNDYuMzQxNDY1IApMIDg0LjY5OTgyNSAxNDYuMzQxNDY1IApMIDg1LjAzOTQyMiAxNDYuMzQxNDY1IApMIDg1LjM3OTAxOSAxNDYuMzQxNDY1IApMIDg1LjcxODYxNSAxNDYuMzQxNDY1IApMIDg2LjA1ODIxMiAxNDYuMzQxNDY1IApMIDg2LjM5NzgwOSAxNDYuNjgxMDYyIApMIDg2LjM5NzgwOSAxNDcuMDIwNjU5IApMIDg2LjM5NzgwOSAxNDcuMzYwMjU2IApMIDg2LjM5NzgwOSAxNDcuNjk5ODUyIApMIDg2LjM5NzgwOSAxNDguMDM5NDQ5IApMIDg2LjM5NzgwOSAxNDguMzc5MDQ2IApMIDg2LjM5NzgwOSAxNDguNzE4NjQzIApMIDg2LjM5NzgwOSAxNDkuMDU4MjQgCkwgODYuMzk3ODA5IDE0OS4zOTc4MzYgCkwgODYuMzk3ODA5IDE0OS43Mzc0MzMgCkwgODYuMzk3ODA5IDE1MC4wNzcwMyAKTCA4Ni4zOTc4MDkgMTUwLjQxNjYyNyAKTCA4Ni4zOTc4MDkgMTUwLjc1NjIyNCAKTCA4Ni4zOTc4MDkgMTUxLjA5NTgyIApMIDg2LjM5NzgwOSAxNTEuNDM1NDE3IApMIDg2LjM5NzgwOSAxNTEuNzc1MDE0IApMIDg2LjM5NzgwOSAxNTIuMTE0NjExIApMIDg2LjM5NzgwOSAxNTIuNDU0MjA4IApMIDg2LjM5NzgwOSAxNTIuNzkzODA0IApMIDg2LjM5NzgwOSAxNTMuMTMzNDAxIApMIDg2LjM5NzgwOSAxNTMuNDcyOTk4IApMIDg2LjM5NzgwOSAxNTMuODEyNTk1IApMIDg2LjM5NzgwOSAxNTQuMTUyMTkyIApMIDg2LjM5NzgwOSAxNTQuNDkxNzg5IApMIDg2LjM5NzgwOSAxNTQuODMxMzg1IApMIDg2LjM5NzgwOSAxNTUuMTcwOTgyIApMIDg2LjM5NzgwOSAxNTUuNTEwNTc5IApMIDg2LjM5NzgwOSAxNTUuODUwMTc2IApMIDg2LjM5NzgwOSAxNTYuMTg5NzczIApMIDg2LjM5NzgwOSAxNTYuNTI5MzY5IApMIDg2LjM5NzgwOSAxNTYuODY4OTY2IApMIDg2LjM5NzgwOSAxNTcuMjA4NTYzIApMIDg2LjM5NzgwOSAxNTcuNTQ4MTYgCkwgODYuMzk3ODA5IDE1Ny44ODc3NTcgCkwgODYuMzk3ODA5IDE1OC4yMjczNTMgCkwgODYuMzk3ODA5IDE1OC41NjY5NSAKTCA4Ni4zOTc4MDkgMTU4LjkwNjU0NyAKTCA4Ni4zOTc4MDkgMTU5LjI0NjE0NCAKTCA4Ni4zOTc4MDkgMTU5LjU4NTc0MSAKTCA4Ni4zOTc4MDkgMTU5LjkyNTMzNyAKTCA4Ni4wNTgyMTIgMTYwLjI2NDkzNCAKTCA4NS43MTg2MTUgMTYwLjI2NDkzNCAKTCA4NS4zNzkwMTkgMTYwLjI2NDkzNCAKTCA4NS4wMzk0MjIgMTYwLjI2NDkzNCAKTCA4NC42OTk4MjUgMTYwLjI2NDkzNCAKTCA4NC4zNjAyMjggMTYwLjI2NDkzNCAKTCA4NC4wMjA2MzEgMTYwLjI2NDkzNCAKTCA4My42ODEwMzUgMTYwLjI2NDkzNCAKTCA4My4zNDE0MzggMTYwLjI2NDkzNCAKTCA4My4wMDE4NDEgMTYwLjI2NDkzNCAKTCA4Mi42NjIyNDQgMTYwLjI2NDkzNCAKTCA4Mi4zMjI2NDcgMTYwLjI2NDkzNCAKTCA4MS45ODMwNTEgMTYwLjI2NDkzNCAKTCA4MS42NDM0NTQgMTYwLjI2NDkzNCAKTCA4MS4zMDM4NTcgMTU5LjkyNTMzNyAKTCA4MS4zMDM4NTcgMTU5LjU4NTc0MSAKTCA4MS4zMDM4NTcgMTU5LjI0NjE0NCAKTCA4MS4zMDM4NTcgMTU4LjkwNjU0NyAKTCA4MS4zMDM4NTcgMTU4LjU2Njk1IApMIDgxLjMwMzg1NyAxNTguMjI3MzUzIApMIDgxLjMwMzg1NyAxNTcuODg3NzU3IApMIDgxLjMwMzg1NyAxNTcuNTQ4MTYgCkwgODEuMzAzODU3IDE1Ny4yMDg1NjMgCkwgODEuMzAzODU3IDE1Ni44Njg5NjYgCkwgODEuMzAzODU3IDE1Ni41MjkzNjkgCkwgODEuMzAzODU3IDE1Ni4xODk3NzMgCkwgODEuMzAzODU3IDE1NS44NTAxNzYgCkwgODEuMzAzODU3IDE1NS41MTA1NzkgCkwgODEuMzAzODU3IDE1NS4xNzA5ODIgCkwgODEuMzAzODU3IDE1NC44MzEzODUgCkwgODEuMzAzODU3IDE1NC40OTE3ODkgCkwgODEuMzAzODU3IDE1NC4xNTIxOTIgCkwgODEuMzAzODU3IDE1My44MTI1OTUgCkwgODEuMzAzODU3IDE1My40NzI5OTggCkwgODEuMzAzODU3IDE1My4xMzM0MDEgCkwgODEuMzAzODU3IDE1Mi43OTM4MDQgCkwgODEuMzAzODU3IDE1Mi40NTQyMDggCkwgODEuMzAzODU3IDE1Mi4xMTQ2MTEgCkwgODEuMzAzODU3IDE1MS43NzUwMTQgCkwgODEuMzAzODU3IDE1MS40MzU0MTcgCkwgODEuMzAzODU3IDE1MS4wOTU4MiAKTCA4MS4zMDM4NTcgMTUwLjc1NjIyNCAKTCA4MS4zMDM4NTcgMTUwLjQxNjYyNyAKTCA4MS4zMDM4NTcgMTUwLjA3NzAzIApMIDgxLjMwMzg1NyAxNDkuNzM3NDMzIApMIDgxLjMwMzg1NyAxNDkuMzk3ODM2IApMIDgxLjMwMzg1NyAxNDkuMDU4MjQgCkwgODEuMzAzODU3IDE0OC43MTg2NDMgCkwgODEuMzAzODU3IDE0OC4zNzkwNDYgCkwgODEuMzAzODU3IDE0OC4wMzk0NDkgCkwgODEuMzAzODU3IDE0Ny42OTk4NTIgCkwgODEuMzAzODU3IDE0Ny4zNjAyNTYgCkwgODEuMzAzODU3IDE0Ny4wMjA2NTkgCiIgc3R5bGU9ImZpbGw6bm9uZTtzdHJva2U6IzFmNzdiNDtzdHJva2UtbGluZWNhcDpzcXVhcmU7c3Ryb2tlLXdpZHRoOjEuNTsiLz4KICAgPC9nPgogICA8ZyBpZD0ibGluZTJkXzIiPgogICAgPHBhdGggY2xpcC1wYXRoPSJ1cmwoI3A2OWIxNWQ3ODY0KSIgZD0iTSA4MS4zMDM4NTcgMTQ2LjY4MTA2MiAKTCA4MS42NDM0NTQgMTQ2LjM0MTQ2NSAKTCA4MS45ODMwNTEgMTQ2LjM0MTQ2NSAKTCA4Mi4zMjI2NDcgMTQ2LjM0MTQ2NSAKTCA4Mi42NjIyNDQgMTQ2LjM0MTQ2NSAKTCA4My4wMDE4NDEgMTQ2LjM0MTQ2NSAKTCA4My4zNDE0MzggMTQ2LjM0MTQ2NSAKTCA4My42ODEwMzUgMTQ2LjM0MTQ2NSAKTCA4NC4wMjA2MzEgMTQ2LjM0MTQ2NSAKTCA4NC4zNjAyMjggMTQ2LjM0MTQ2NSAKTCA4NC42OTk4MjUgMTQ2LjM0MTQ2NSAKTCA4NS4wMzk0MjIgMTQ2LjM0MTQ2NSAKTCA4NS4zNzkwMTkgMTQ2LjM0MTQ2NSAKTCA4NS43MTg2MTUgMTQ2LjM0MTQ2NSAKTCA4Ni4wNTgyMTIgMTQ2LjM0MTQ2NSAKTCA4Ni4zOTc4MDkgMTQ2LjY4MTA2MiAKTCA4Ni4zOTc4MDkgMTQ3LjAyMDY1OSAKTCA4Ni4zOTc4MDkgMTQ3LjM2MDI1NiAKTCA4Ni4zOTc4MDkgMTQ3LjY5OTg1MiAKTCA4Ni4zOTc4MDkgMTQ4LjAzOTQ0OSAKTCA4Ni4zOTc4MDkgMTQ4LjM3OTA0NiAKTCA4Ni4zOTc4MDkgMTQ4LjcxODY0MyAKTCA4Ni4zOTc4MDkgMTQ5LjA1ODI0IApMIDg2LjM5NzgwOSAxNDkuMzk3ODM2IApMIDg2LjM5NzgwOSAxNDkuNzM3NDMzIApMIDg2LjM5NzgwOSAxNTAuMDc3MDMgCkwgODYuMzk3ODA5IDE1MC40MTY2MjcgCkwgODYuMzk3ODA5IDE1MC43NTYyMjQgCkwgODYuMzk3ODA5IDE1MS4wOTU4MiAKTCA4Ni4zOTc4MDkgMTUxLjQzNTQxNyAKTCA4Ni4zOTc4MDkgMTUxLjc3NTAxNCAKTCA4Ni4zOTc4MDkgMTUyLjExNDYxMSAKTCA4Ni4zOTc4MDkgMTUyLjQ1NDIwOCAKTCA4Ni4zOTc4MDkgMTUyLjc5MzgwNCAKTCA4Ni4zOTc4MDkgMTUzLjEzMzQwMSAKTCA4Ni4zOTc4MDkgMTUzLjQ3Mjk5OCAKTCA4Ni4zOTc4MDkgMTUzLjgxMjU5NSAKTCA4Ni4zOTc4MDkgMTU0LjE1MjE5MiAKTCA4Ni4zOTc4MDkgMTU0LjQ5MTc4OSAKTCA4Ni4zOTc4MDkgMTU0LjgzMTM4NSAKTCA4Ni4zOTc4MDkgMTU1LjE3MDk4MiAKTCA4Ni4zOTc4MDkgMTU1LjUxMDU3OSAKTCA4Ni4zOTc4MDkgMTU1Ljg1MDE3NiAKTCA4Ni4zOTc4MDkgMTU2LjE4OTc3MyAKTCA4Ni4zOTc4MDkgMTU2LjUyOTM2OSAKTCA4Ni4zOTc4MDkgMTU2Ljg2ODk2NiAKTCA4Ni4zOTc4MDkgMTU3LjIwODU2MyAKTCA4Ni4zOTc4MDkgMTU3LjU0ODE2IApMIDg2LjM5NzgwOSAxNTcuODg3NzU3IApMIDg2LjM5NzgwOSAxNTguMjI3MzUzIApMIDg2LjM5NzgwOSAxNTguNTY2OTUgCkwgODYuMzk3ODA5IDE1OC45MDY1NDcgCkwgODYuMzk3ODA5IDE1OS4yNDYxNDQgCkwgODYuMzk3ODA5IDE1OS41ODU3NDEgCkwgODYuMzk3ODA5IDE1OS45MjUzMzcgCkwgODYuMDU4MjEyIDE2MC4yNjQ5MzQgCkwgODUuNzE4NjE1IDE2MC4yNjQ5MzQgCkwgODUuMzc5MDE5IDE2MC4yNjQ5MzQgCkwgODUuMDM5NDIyIDE2MC4yNjQ5MzQgCkwgODQuNjk5ODI1IDE2MC4yNjQ5MzQgCkwgODQuMzYwMjI4IDE2MC4yNjQ5MzQgCkwgODQuMDIwNjMxIDE2MC4yNjQ5MzQgCkwgODMuNjgxMDM1IDE2MC4yNjQ5MzQgCkwgODMuMzQxNDM4IDE2MC4yNjQ5MzQgCkwgODMuMDAxODQxIDE2MC4yNjQ5MzQgCkwgODIuNjYyMjQ0IDE2MC4yNjQ5MzQgCkwgODIuMzIyNjQ3IDE2MC4yNjQ5MzQgCkwgODEuOTgzMDUxIDE2MC4yNjQ5MzQgCkwgODEuNjQzNDU0IDE2MC4yNjQ5MzQgCkwgODEuMzAzODU3IDE1OS45MjUzMzcgCkwgODEuMzAzODU3IDE1OS41ODU3NDEgCkwgODEuMzAzODU3IDE1OS4yNDYxNDQgCkwgODEuMzAzODU3IDE1OC45MDY1NDcgCkwgODEuMzAzODU3IDE1OC41NjY5NSAKTCA4MS4zMDM4NTcgMTU4LjIyNzM1MyAKTCA4MS4zMDM4NTcgMTU3Ljg4Nzc1NyAKTCA4MS4zMDM4NTcgMTU3LjU0ODE2IApMIDgxLjMwMzg1NyAxNTcuMjA4NTYzIApMIDgxLjMwMzg1NyAxNTYuODY4OTY2IApMIDgxLjMwMzg1NyAxNTYuNTI5MzY5IApMIDgxLjMwMzg1NyAxNTYuMTg5NzczIApMIDgxLjMwMzg1NyAxNTUuODUwMTc2IApMIDgxLjMwMzg1NyAxNTUuNTEwNTc5IApMIDgxLjMwMzg1NyAxNTUuMTcwOTgyIApMIDgxLjMwMzg1NyAxNTQuODMxMzg1IApMIDgxLjMwMzg1NyAxNTQuNDkxNzg5IApMIDgxLjMwMzg1NyAxNTQuMTUyMTkyIApMIDgxLjMwMzg1NyAxNTMuODEyNTk1IApMIDgxLjMwMzg1NyAxNTMuNDcyOTk4IApMIDgxLjMwMzg1NyAxNTMuMTMzNDAxIApMIDgxLjMwMzg1NyAxNTIuNzkzODA0IApMIDgxLjMwMzg1NyAxNTIuNDU0MjA4IApMIDgxLjMwMzg1NyAxNTIuMTE0NjExIApMIDgxLjMwMzg1NyAxNTEuNzc1MDE0IApMIDgxLjMwMzg1NyAxNTEuNDM1NDE3IApMIDgxLjMwMzg1NyAxNTEuMDk1ODIgCkwgODEuMzAzODU3IDE1MC43NTYyMjQgCkwgODEuMzAzODU3IDE1MC40MTY2MjcgCkwgODEuMzAzODU3IDE1MC4wNzcwMyAKTCA4MS4zMDM4NTcgMTQ5LjczNzQzMyAKTCA4MS4zMDM4NTcgMTQ5LjM5NzgzNiAKTCA4MS4zMDM4NTcgMTQ5LjA1ODI0IApMIDgxLjMwMzg1NyAxNDguNzE4NjQzIApMIDgxLjMwMzg1NyAxNDguMzc5MDQ2IApMIDgxLjMwMzg1NyAxNDguMDM5NDQ5IApMIDgxLjMwMzg1NyAxNDcuNjk5ODUyIApMIDgxLjMwMzg1NyAxNDcuMzYwMjU2IApMIDgxLjMwMzg1NyAxNDcuMDIwNjU5IAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiNmZjdmMGU7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF8zIj4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMjM0LjQ2MjAxNiAxNDUuNjYyMjcyIApMIDIzNC44MDE2MTMgMTQ1LjMyMjY3NSAKTCAyMzUuMTQxMjEgMTQ1LjMyMjY3NSAKTCAyMzUuNDgwODA2IDE0NS4zMjI2NzUgCkwgMjM1LjgyMDQwMyAxNDUuMzIyNjc1IApMIDIzNi4xNiAxNDUuMzIyNjc1IApMIDIzNi40OTk1OTcgMTQ1LjMyMjY3NSAKTCAyMzYuODM5MTk0IDE0NS4zMjI2NzUgCkwgMjM3LjE3ODc5IDE0NS4zMjI2NzUgCkwgMjM3LjUxODM4NyAxNDUuMzIyNjc1IApMIDIzNy44NTc5ODQgMTQ1LjMyMjY3NSAKTCAyMzguMTk3NTgxIDE0NS4zMjI2NzUgCkwgMjM4LjUzNzE3OCAxNDUuMzIyNjc1IApMIDIzOC44NzY3NzQgMTQ1LjMyMjY3NSAKTCAyMzkuMjE2MzcxIDE0NS4zMjI2NzUgCkwgMjM5LjU1NTk2OCAxNDUuMzIyNjc1IApMIDIzOS44OTU1NjUgMTQ1LjMyMjY3NSAKTCAyNDAuMjM1MTYyIDE0NS42NjIyNzIgCkwgMjQwLjIzNTE2MiAxNDYuMDAxODY4IApMIDI0MC4yMzUxNjIgMTQ2LjM0MTQ2NSAKTCAyNDAuMjM1MTYyIDE0Ni42ODEwNjIgCkwgMjQwLjIzNTE2MiAxNDcuMDIwNjU5IApMIDI0MC4yMzUxNjIgMTQ3LjM2MDI1NiAKTCAyNDAuMjM1MTYyIDE0Ny42OTk4NTIgCkwgMjQwLjIzNTE2MiAxNDguMDM5NDQ5IApMIDI0MC4yMzUxNjIgMTQ4LjM3OTA0NiAKTCAyNDAuMjM1MTYyIDE0OC43MTg2NDMgCkwgMjQwLjIzNTE2MiAxNDkuMDU4MjQgCkwgMjQwLjIzNTE2MiAxNDkuMzk3ODM2IApMIDI0MC4yMzUxNjIgMTQ5LjczNzQzMyAKTCAyNDAuMjM1MTYyIDE1MC4wNzcwMyAKTCAyNDAuMjM1MTYyIDE1MC40MTY2MjcgCkwgMjQwLjIzNTE2MiAxNTAuNzU2MjI0IApMIDI0MC4yMzUxNjIgMTUxLjA5NTgyIApMIDI0MC4yMzUxNjIgMTUxLjQzNTQxNyAKTCAyNDAuMjM1MTYyIDE1MS43NzUwMTQgCkwgMjQwLjIzNTE2MiAxNTIuMTE0NjExIApMIDI0MC4yMzUxNjIgMTUyLjQ1NDIwOCAKTCAyNDAuMjM1MTYyIDE1Mi43OTM4MDQgCkwgMjQwLjIzNTE2MiAxNTMuMTMzNDAxIApMIDI0MC4yMzUxNjIgMTUzLjQ3Mjk5OCAKTCAyNDAuMjM1MTYyIDE1My44MTI1OTUgCkwgMjQwLjIzNTE2MiAxNTQuMTUyMTkyIApMIDI0MC4yMzUxNjIgMTU0LjQ5MTc4OSAKTCAyNDAuMjM1MTYyIDE1NC44MzEzODUgCkwgMjQwLjIzNTE2MiAxNTUuMTcwOTgyIApMIDI0MC4yMzUxNjIgMTU1LjUxMDU3OSAKTCAyNDAuMjM1MTYyIDE1NS44NTAxNzYgCkwgMjM5Ljg5NTU2NSAxNTYuMTg5NzczIApMIDIzOS41NTU5NjggMTU2LjE4OTc3MyAKTCAyMzkuMjE2MzcxIDE1Ni4xODk3NzMgCkwgMjM4Ljg3Njc3NCAxNTYuMTg5NzczIApMIDIzOC41MzcxNzggMTU2LjE4OTc3MyAKTCAyMzguMTk3NTgxIDE1Ni4xODk3NzMgCkwgMjM3Ljg1Nzk4NCAxNTYuMTg5NzczIApMIDIzNy41MTgzODcgMTU2LjE4OTc3MyAKTCAyMzcuMTc4NzkgMTU2LjE4OTc3MyAKTCAyMzYuODM5MTk0IDE1Ni4xODk3NzMgCkwgMjM2LjQ5OTU5NyAxNTYuMTg5NzczIApMIDIzNi4xNiAxNTYuMTg5NzczIApMIDIzNS44MjA0MDMgMTU2LjE4OTc3MyAKTCAyMzUuNDgwODA2IDE1Ni4xODk3NzMgCkwgMjM1LjE0MTIxIDE1Ni4xODk3NzMgCkwgMjM0LjgwMTYxMyAxNTYuMTg5NzczIApMIDIzNC40NjIwMTYgMTU1Ljg1MDE3NiAKTCAyMzQuNDYyMDE2IDE1NS41MTA1NzkgCkwgMjM0LjQ2MjAxNiAxNTUuMTcwOTgyIApMIDIzNC40NjIwMTYgMTU0LjgzMTM4NSAKTCAyMzQuNDYyMDE2IDE1NC40OTE3ODkgCkwgMjM0LjQ2MjAxNiAxNTQuMTUyMTkyIApMIDIzNC40NjIwMTYgMTUzLjgxMjU5NSAKTCAyMzQuNDYyMDE2IDE1My40NzI5OTggCkwgMjM0LjQ2MjAxNiAxNTMuMTMzNDAxIApMIDIzNC40NjIwMTYgMTUyLjc5MzgwNCAKTCAyMzQuNDYyMDE2IDE1Mi40NTQyMDggCkwgMjM0LjQ2MjAxNiAxNTIuMTE0NjExIApMIDIzNC40NjIwMTYgMTUxLjc3NTAxNCAKTCAyMzQuNDYyMDE2IDE1MS40MzU0MTcgCkwgMjM0LjQ2MjAxNiAxNTEuMDk1ODIgCkwgMjM0LjQ2MjAxNiAxNTAuNzU2MjI0IApMIDIzNC40NjIwMTYgMTUwLjQxNjYyNyAKTCAyMzQuNDYyMDE2IDE1MC4wNzcwMyAKTCAyMzQuNDYyMDE2IDE0OS43Mzc0MzMgCkwgMjM0LjQ2MjAxNiAxNDkuMzk3ODM2IApMIDIzNC40NjIwMTYgMTQ5LjA1ODI0IApMIDIzNC40NjIwMTYgMTQ4LjcxODY0MyAKTCAyMzQuNDYyMDE2IDE0OC4zNzkwNDYgCkwgMjM0LjQ2MjAxNiAxNDguMDM5NDQ5IApMIDIzNC40NjIwMTYgMTQ3LjY5OTg1MiAKTCAyMzQuNDYyMDE2IDE0Ny4zNjAyNTYgCkwgMjM0LjQ2MjAxNiAxNDcuMDIwNjU5IApMIDIzNC40NjIwMTYgMTQ2LjY4MTA2MiAKTCAyMzQuNDYyMDE2IDE0Ni4zNDE0NjUgCkwgMjM0LjQ2MjAxNiAxNDYuMDAxODY4IAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiMyY2EwMmM7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF80Ij4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMjM0LjQ2MjAxNiAxNDUuNjYyMjcyIApMIDIzNC44MDE2MTMgMTQ1LjMyMjY3NSAKTCAyMzUuMTQxMjEgMTQ1LjMyMjY3NSAKTCAyMzUuNDgwODA2IDE0NS4zMjI2NzUgCkwgMjM1LjgyMDQwMyAxNDUuMzIyNjc1IApMIDIzNi4xNiAxNDUuMzIyNjc1IApMIDIzNi40OTk1OTcgMTQ1LjMyMjY3NSAKTCAyMzYuODM5MTk0IDE0NS4zMjI2NzUgCkwgMjM3LjE3ODc5IDE0NS4zMjI2NzUgCkwgMjM3LjUxODM4NyAxNDUuMzIyNjc1IApMIDIzNy44NTc5ODQgMTQ1LjMyMjY3NSAKTCAyMzguMTk3NTgxIDE0NS4zMjI2NzUgCkwgMjM4LjUzNzE3OCAxNDUuMzIyNjc1IApMIDIzOC44NzY3NzQgMTQ1LjMyMjY3NSAKTCAyMzkuMjE2MzcxIDE0NS4zMjI2NzUgCkwgMjM5LjU1NTk2OCAxNDUuMzIyNjc1IApMIDIzOS44OTU1NjUgMTQ1LjMyMjY3NSAKTCAyNDAuMjM1MTYyIDE0NS42NjIyNzIgCkwgMjQwLjIzNTE2MiAxNDYuMDAxODY4IApMIDI0MC4yMzUxNjIgMTQ2LjM0MTQ2NSAKTCAyNDAuMjM1MTYyIDE0Ni42ODEwNjIgCkwgMjQwLjIzNTE2MiAxNDcuMDIwNjU5IApMIDI0MC4yMzUxNjIgMTQ3LjM2MDI1NiAKTCAyNDAuMjM1MTYyIDE0Ny42OTk4NTIgCkwgMjQwLjIzNTE2MiAxNDguMDM5NDQ5IApMIDI0MC4yMzUxNjIgMTQ4LjM3OTA0NiAKTCAyNDAuMjM1MTYyIDE0OC43MTg2NDMgCkwgMjQwLjIzNTE2MiAxNDkuMDU4MjQgCkwgMjQwLjIzNTE2MiAxNDkuMzk3ODM2IApMIDI0MC4yMzUxNjIgMTQ5LjczNzQzMyAKTCAyNDAuMjM1MTYyIDE1MC4wNzcwMyAKTCAyNDAuMjM1MTYyIDE1MC40MTY2MjcgCkwgMjQwLjIzNTE2MiAxNTAuNzU2MjI0IApMIDI0MC4yMzUxNjIgMTUxLjA5NTgyIApMIDI0MC4yMzUxNjIgMTUxLjQzNTQxNyAKTCAyNDAuMjM1MTYyIDE1MS43NzUwMTQgCkwgMjQwLjIzNTE2MiAxNTIuMTE0NjExIApMIDI0MC4yMzUxNjIgMTUyLjQ1NDIwOCAKTCAyNDAuMjM1MTYyIDE1Mi43OTM4MDQgCkwgMjQwLjIzNTE2MiAxNTMuMTMzNDAxIApMIDI0MC4yMzUxNjIgMTUzLjQ3Mjk5OCAKTCAyNDAuMjM1MTYyIDE1My44MTI1OTUgCkwgMjQwLjIzNTE2MiAxNTQuMTUyMTkyIApMIDI0MC4yMzUxNjIgMTU0LjQ5MTc4OSAKTCAyNDAuMjM1MTYyIDE1NC44MzEzODUgCkwgMjQwLjIzNTE2MiAxNTUuMTcwOTgyIApMIDI0MC4yMzUxNjIgMTU1LjUxMDU3OSAKTCAyNDAuMjM1MTYyIDE1NS44NTAxNzYgCkwgMjM5Ljg5NTU2NSAxNTYuMTg5NzczIApMIDIzOS41NTU5NjggMTU2LjE4OTc3MyAKTCAyMzkuMjE2MzcxIDE1Ni4xODk3NzMgCkwgMjM4Ljg3Njc3NCAxNTYuMTg5NzczIApMIDIzOC41MzcxNzggMTU2LjE4OTc3MyAKTCAyMzguMTk3NTgxIDE1Ni4xODk3NzMgCkwgMjM3Ljg1Nzk4NCAxNTYuMTg5NzczIApMIDIzNy41MTgzODcgMTU2LjE4OTc3MyAKTCAyMzcuMTc4NzkgMTU2LjE4OTc3MyAKTCAyMzYuODM5MTk0IDE1Ni4xODk3NzMgCkwgMjM2LjQ5OTU5NyAxNTYuMTg5NzczIApMIDIzNi4xNiAxNTYuMTg5NzczIApMIDIzNS44MjA0MDMgMTU2LjE4OTc3MyAKTCAyMzUuNDgwODA2IDE1Ni4xODk3NzMgCkwgMjM1LjE0MTIxIDE1Ni4xODk3NzMgCkwgMjM0LjgwMTYxMyAxNTYuMTg5NzczIApMIDIzNC40NjIwMTYgMTU1Ljg1MDE3NiAKTCAyMzQuNDYyMDE2IDE1NS41MTA1NzkgCkwgMjM0LjQ2MjAxNiAxNTUuMTcwOTgyIApMIDIzNC40NjIwMTYgMTU0LjgzMTM4NSAKTCAyMzQuNDYyMDE2IDE1NC40OTE3ODkgCkwgMjM0LjQ2MjAxNiAxNTQuMTUyMTkyIApMIDIzNC40NjIwMTYgMTUzLjgxMjU5NSAKTCAyMzQuNDYyMDE2IDE1My40NzI5OTggCkwgMjM0LjQ2MjAxNiAxNTMuMTMzNDAxIApMIDIzNC40NjIwMTYgMTUyLjc5MzgwNCAKTCAyMzQuNDYyMDE2IDE1Mi40NTQyMDggCkwgMjM0LjQ2MjAxNiAxNTIuMTE0NjExIApMIDIzNC40NjIwMTYgMTUxLjc3NTAxNCAKTCAyMzQuNDYyMDE2IDE1MS40MzU0MTcgCkwgMjM0LjQ2MjAxNiAxNTEuMDk1ODIgCkwgMjM0LjQ2MjAxNiAxNTAuNzU2MjI0IApMIDIzNC40NjIwMTYgMTUwLjQxNjYyNyAKTCAyMzQuNDYyMDE2IDE1MC4wNzcwMyAKTCAyMzQuNDYyMDE2IDE0OS43Mzc0MzMgCkwgMjM0LjQ2MjAxNiAxNDkuMzk3ODM2IApMIDIzNC40NjIwMTYgMTQ5LjA1ODI0IApMIDIzNC40NjIwMTYgMTQ4LjcxODY0MyAKTCAyMzQuNDYyMDE2IDE0OC4zNzkwNDYgCkwgMjM0LjQ2MjAxNiAxNDguMDM5NDQ5IApMIDIzNC40NjIwMTYgMTQ3LjY5OTg1MiAKTCAyMzQuNDYyMDE2IDE0Ny4zNjAyNTYgCkwgMjM0LjQ2MjAxNiAxNDcuMDIwNjU5IApMIDIzNC40NjIwMTYgMTQ2LjY4MTA2MiAKTCAyMzQuNDYyMDE2IDE0Ni4zNDE0NjUgCkwgMjM0LjQ2MjAxNiAxNDYuMDAxODY4IAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiNkNjI3Mjg7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF81Ij4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMTUxLjI2MDc5OSAxNDUuMzIyNjc1IApMIDE1MS42MDAzOTYgMTQ0Ljk4MzA3OCAKTCAxNjIuMTI3ODk3IDE0NC45ODMwNzggCkwgMTYyLjQ2NzQ5MyAxNDUuMzIyNjc1IApMIDE2Mi40Njc0OTMgMTYxLjI4MzcyNSAKTCAxNjIuMTI3ODk3IDE2MS42MjMzMjEgCkwgMTUxLjYwMDM5NiAxNjEuNjIzMzIxIApMIDE1MS4yNjA3OTkgMTYxLjI4MzcyNSAKTCAxNTEuMjYwNzk5IDE0NS42NjIyNzIgCkwgMTUxLjI2MDc5OSAxNDUuNjYyMjcyIAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiM5NDY3YmQ7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF82Ij4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMTUxLjI2MDc5OSAxNDUuMzIyNjc1IApMIDE1MS42MDAzOTYgMTQ0Ljk4MzA3OCAKTCAxNjIuMTI3ODk3IDE0NC45ODMwNzggCkwgMTYyLjQ2NzQ5MyAxNDUuMzIyNjc1IApMIDE2Mi40Njc0OTMgMTYxLjI4MzcyNSAKTCAxNjIuMTI3ODk3IDE2MS42MjMzMjEgCkwgMTUxLjYwMDM5NiAxNjEuNjIzMzIxIApMIDE1MS4yNjA3OTkgMTYxLjI4MzcyNSAKTCAxNTEuMjYwNzk5IDE0NS42NjIyNzIgCkwgMTUxLjI2MDc5OSAxNDUuNjYyMjcyIAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiM4YzU2NGI7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF83Ij4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMjUwLjQyMzA2NiAxNDQuNjQzNDgxIApMIDI1MC43NjI2NjMgMTQ0LjMwMzg4NCAKTCAyNTguNTczMzg5IDE0NC4zMDM4ODQgCkwgMjU4LjkxMjk4NiAxNDQuNjQzNDgxIApMIDI1OC45MTI5ODYgMTU5LjkyNTMzNyAKTCAyNTguNTczMzg5IDE2MC4yNjQ5MzQgCkwgMjUwLjc2MjY2MyAxNjAuMjY0OTM0IApMIDI1MC40MjMwNjYgMTU5LjkyNTMzNyAKTCAyNTAuNDIzMDY2IDE0NC45ODMwNzggCkwgMjUwLjQyMzA2NiAxNDQuOTgzMDc4IAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiNlMzc3YzI7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF84Ij4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMjUwLjQyMzA2NiAxNDQuNjQzNDgxIApMIDI1MC43NjI2NjMgMTQ0LjMwMzg4NCAKTCAyNTguNTczMzg5IDE0NC4zMDM4ODQgCkwgMjU4LjkxMjk4NiAxNDQuNjQzNDgxIApMIDI1OC45MTI5ODYgMTU5LjkyNTMzNyAKTCAyNTguNTczMzg5IDE2MC4yNjQ5MzQgCkwgMjUwLjc2MjY2MyAxNjAuMjY0OTM0IApMIDI1MC40MjMwNjYgMTU5LjkyNTMzNyAKTCAyNTAuNDIzMDY2IDE0NC45ODMwNzggCkwgMjUwLjQyMzA2NiAxNDQuOTgzMDc4IAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiM3ZjdmN2Y7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF85Ij4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMjYzLjMyNzc0NCAxNDMuNjI0NjkxIApMIDI2My42NjczNDEgMTQzLjI4NTA5NCAKTCAyOTUuMjQ5ODQ0IDE0My4yODUwOTQgCkwgMjk1LjU4OTQ0MSAxNDMuNjI0NjkxIApMIDI5NS41ODk0NDEgMTYwLjYwNDUzMSAKTCAyOTUuMjQ5ODQ0IDE2MC45NDQxMjggCkwgMjYzLjY2NzM0MSAxNjAuOTQ0MTI4IApMIDI2My4zMjc3NDQgMTYwLjYwNDUzMSAKTCAyNjMuMzI3NzQ0IDE0My45NjQyODggCkwgMjYzLjMyNzc0NCAxNDMuOTY0Mjg4IAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiNiY2JkMjI7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF8xMCI+CiAgICA8cGF0aCBjbGlwLXBhdGg9InVybCgjcDY5YjE1ZDc4NjQpIiBkPSJNIDE2NS44NjM0NjEgMTQzLjYyNDY5MSAKTCAxNjYuMjAzMDU4IDE0My4yODUwOTQgCkwgMTg5LjYzNTIzOCAxNDMuMjg1MDk0IApMIDE4OS45NzQ4MzUgMTQzLjYyNDY5MSAKTCAxODkuOTc0ODM1IDE2MC45NDQxMjggCkwgMTg5LjYzNTIzOCAxNjEuMjgzNzI1IApMIDE2Ni4yMDMwNTggMTYxLjI4MzcyNSAKTCAxNjUuODYzNDYxIDE2MC45NDQxMjggCkwgMTY1Ljg2MzQ2MSAxNDMuOTY0Mjg4IApMIDE2NS44NjM0NjEgMTQzLjk2NDI4OCAKIiBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTojMTdiZWNmO3N0cm9rZS1saW5lY2FwOnNxdWFyZTtzdHJva2Utd2lkdGg6MS41OyIvPgogICA8L2c+CiAgIDxnIGlkPSJsaW5lMmRfMTEiPgogICAgPHBhdGggY2xpcC1wYXRoPSJ1cmwoI3A2OWIxNWQ3ODY0KSIgZD0iTSAzNDkuOTI0OTMgMTQzLjI4NTA5NCAKTCAzNTAuMjY0NTI2IDE0Mi45NDU0OTcgCkwgMzU2LjcxNjg2NiAxNDIuOTQ1NDk3IApMIDM1Ny4wNTY0NjMgMTQzLjI4NTA5NCAKTCAzNTcuMDU2NDYzIDE1OC41NjY5NSAKTCAzNTYuNzE2ODY2IDE1OC45MDY1NDcgCkwgMzUwLjI2NDUyNiAxNTguOTA2NTQ3IApMIDM0OS45MjQ5MyAxNTguNTY2OTUgCkwgMzQ5LjkyNDkzIDE0My42MjQ2OTEgCkwgMzQ5LjkyNDkzIDE0My42MjQ2OTEgCiIgc3R5bGU9ImZpbGw6bm9uZTtzdHJva2U6IzFmNzdiNDtzdHJva2UtbGluZWNhcDpzcXVhcmU7c3Ryb2tlLXdpZHRoOjEuNTsiLz4KICAgPC9nPgogICA8ZyBpZD0ibGluZTJkXzEyIj4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMzAwLjM0Mzc5NiAxNDMuMjg1MDk0IApMIDMwMC42ODMzOTMgMTQyLjk0NTQ5NyAKTCAzNDMuODEyMTg3IDE0Mi45NDU0OTcgCkwgMzQ0LjE1MTc4NCAxNDMuMjg1MDk0IApMIDM0NC4xNTE3ODQgMTU5LjI0NjE0NCAKTCAzNDMuODEyMTg3IDE1OS41ODU3NDEgCkwgMzAwLjY4MzM5MyAxNTkuNTg1NzQxIApMIDMwMC4zNDM3OTYgMTU5LjI0NjE0NCAKTCAzMDAuMzQzNzk2IDE0My42MjQ2OTEgCkwgMzAwLjM0Mzc5NiAxNDMuNjI0NjkxIAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiNmZjdmMGU7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF8xMyI+CiAgICA8cGF0aCBjbGlwLXBhdGg9InVybCgjcDY5YjE1ZDc4NjQpIiBkPSJNIDI2My4zMjc3NDQgMTQzLjYyNDY5MSAKTCAyNjMuNjY3MzQxIDE0My4yODUwOTQgCkwgMjk1LjI0OTg0NCAxNDMuMjg1MDk0IApMIDI5NS41ODk0NDEgMTQzLjYyNDY5MSAKTCAyOTUuNTg5NDQxIDE2MC42MDQ1MzEgCkwgMjk1LjI0OTg0NCAxNjAuOTQ0MTI4IApMIDI2My42NjczNDEgMTYwLjk0NDEyOCAKTCAyNjMuMzI3NzQ0IDE2MC42MDQ1MzEgCkwgMjYzLjMyNzc0NCAxNDMuOTY0Mjg4IApMIDI2My4zMjc3NDQgMTQzLjk2NDI4OCAKIiBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTojMmNhMDJjO3N0cm9rZS1saW5lY2FwOnNxdWFyZTtzdHJva2Utd2lkdGg6MS41OyIvPgogICA8L2c+CiAgIDxnIGlkPSJsaW5lMmRfMTQiPgogICAgPHBhdGggY2xpcC1wYXRoPSJ1cmwoI3A2OWIxNWQ3ODY0KSIgZD0iTSAyMDAuNTAyMzM1IDE0My4yODUwOTQgCkwgMjAwLjg0MTkzMiAxNDIuOTQ1NDk3IApMIDIzMi43NjQwMzIgMTQyLjk0NTQ5NyAKTCAyMzMuMTAzNjI5IDE0My4yODUwOTQgCkwgMjMzLjEwMzYyOSAxNjEuMjgzNzI1IApMIDIzMi43NjQwMzIgMTYxLjYyMzMyMSAKTCAyMDAuODQxOTMyIDE2MS42MjMzMjEgCkwgMjAwLjUwMjMzNSAxNjEuMjgzNzI1IApMIDIwMC41MDIzMzUgMTQzLjYyNDY5MSAKTCAyMDAuNTAyMzM1IDE0My42MjQ2OTEgCiIgc3R5bGU9ImZpbGw6bm9uZTtzdHJva2U6I2Q2MjcyODtzdHJva2UtbGluZWNhcDpzcXVhcmU7c3Ryb2tlLXdpZHRoOjEuNTsiLz4KICAgPC9nPgogICA8ZyBpZD0ibGluZTJkXzE1Ij4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMTY1Ljg2MzQ2MSAxNDMuNjI0NjkxIApMIDE2Ni4yMDMwNTggMTQzLjI4NTA5NCAKTCAxODkuNjM1MjM4IDE0My4yODUwOTQgCkwgMTg5Ljk3NDgzNSAxNDMuNjI0NjkxIApMIDE4OS45NzQ4MzUgMTYwLjk0NDEyOCAKTCAxODkuNjM1MjM4IDE2MS4yODM3MjUgCkwgMTY2LjIwMzA1OCAxNjEuMjgzNzI1IApMIDE2NS44NjM0NjEgMTYwLjk0NDEyOCAKTCAxNjUuODYzNDYxIDE0My45NjQyODggCkwgMTY1Ljg2MzQ2MSAxNDMuOTY0Mjg4IAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiM5NDY3YmQ7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF8xNiI+CiAgICA8cGF0aCBjbGlwLXBhdGg9InVybCgjcDY5YjE1ZDc4NjQpIiBkPSJNIDg4LjQzNTM5IDE0My4yODUwOTQgCkwgODguNzc0OTg3IDE0Mi45NDU0OTcgCkwgMTQxLjQxMjQ5MSAxNDIuOTQ1NDk3IApMIDE0MS43NTIwODggMTQzLjI4NTA5NCAKTCAxNDEuNzUyMDg4IDE2Mi4zMDI1MTUgCkwgMTQxLjQxMjQ5MSAxNjIuNjQyMTEyIApMIDg4Ljc3NDk4NyAxNjIuNjQyMTEyIApMIDg4LjQzNTM5IDE2Mi4zMDI1MTUgCkwgODguNDM1MzkgMTQzLjYyNDY5MSAKTCA4OC40MzUzOSAxNDMuNjI0NjkxIAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiM4YzU2NGI7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF8xNyI+CiAgICA8cGF0aCBjbGlwLXBhdGg9InVybCgjcDY5YjE1ZDc4NjQpIiBkPSJNIDM0OS45MjQ5MyAxNDMuMjg1MDk0IApMIDM1MC4yNjQ1MjYgMTQyLjk0NTQ5NyAKTCAzNTYuNzE2ODY2IDE0Mi45NDU0OTcgCkwgMzU3LjA1NjQ2MyAxNDMuMjg1MDk0IApMIDM1Ny4wNTY0NjMgMTU4LjU2Njk1IApMIDM1Ni43MTY4NjYgMTU4LjkwNjU0NyAKTCAzNTAuMjY0NTI2IDE1OC45MDY1NDcgCkwgMzQ5LjkyNDkzIDE1OC41NjY5NSAKTCAzNDkuOTI0OTMgMTQzLjYyNDY5MSAKTCAzNDkuOTI0OTMgMTQzLjYyNDY5MSAKIiBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTojZTM3N2MyO3N0cm9rZS1saW5lY2FwOnNxdWFyZTtzdHJva2Utd2lkdGg6MS41OyIvPgogICA8L2c+CiAgIDxnIGlkPSJsaW5lMmRfMTgiPgogICAgPHBhdGggY2xpcC1wYXRoPSJ1cmwoI3A2OWIxNWQ3ODY0KSIgZD0iTSAzMDAuMzQzNzk2IDE0My4yODUwOTQgCkwgMzAwLjY4MzM5MyAxNDIuOTQ1NDk3IApMIDM0My44MTIxODcgMTQyLjk0NTQ5NyAKTCAzNDQuMTUxNzg0IDE0My4yODUwOTQgCkwgMzQ0LjE1MTc4NCAxNTkuMjQ2MTQ0IApMIDM0My44MTIxODcgMTU5LjU4NTc0MSAKTCAzMDAuNjgzMzkzIDE1OS41ODU3NDEgCkwgMzAwLjM0Mzc5NiAxNTkuMjQ2MTQ0IApMIDMwMC4zNDM3OTYgMTQzLjYyNDY5MSAKTCAzMDAuMzQzNzk2IDE0My42MjQ2OTEgCiIgc3R5bGU9ImZpbGw6bm9uZTtzdHJva2U6IzdmN2Y3ZjtzdHJva2UtbGluZWNhcDpzcXVhcmU7c3Ryb2tlLXdpZHRoOjEuNTsiLz4KICAgPC9nPgogICA8ZyBpZD0ibGluZTJkXzE5Ij4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMjAwLjUwMjMzNSAxNDMuMjg1MDk0IApMIDIwMC44NDE5MzIgMTQyLjk0NTQ5NyAKTCAyMzIuNzY0MDMyIDE0Mi45NDU0OTcgCkwgMjMzLjEwMzYyOSAxNDMuMjg1MDk0IApMIDIzMy4xMDM2MjkgMTYxLjI4MzcyNSAKTCAyMzIuNzY0MDMyIDE2MS42MjMzMjEgCkwgMjAwLjg0MTkzMiAxNjEuNjIzMzIxIApMIDIwMC41MDIzMzUgMTYxLjI4MzcyNSAKTCAyMDAuNTAyMzM1IDE0My42MjQ2OTEgCkwgMjAwLjUwMjMzNSAxNDMuNjI0NjkxIAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiNiY2JkMjI7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF8yMCI+CiAgICA8cGF0aCBjbGlwLXBhdGg9InVybCgjcDY5YjE1ZDc4NjQpIiBkPSJNIDg4LjQzNTM5IDE0My4yODUwOTQgCkwgODguNzc0OTg3IDE0Mi45NDU0OTcgCkwgMTQxLjQxMjQ5MSAxNDIuOTQ1NDk3IApMIDE0MS43NTIwODggMTQzLjI4NTA5NCAKTCAxNDEuNzUyMDg4IDE2Mi4zMDI1MTUgCkwgMTQxLjQxMjQ5MSAxNjIuNjQyMTEyIApMIDg4Ljc3NDk4NyAxNjIuNjQyMTEyIApMIDg4LjQzNTM5IDE2Mi4zMDI1MTUgCkwgODguNDM1MzkgMTQzLjYyNDY5MSAKTCA4OC40MzUzOSAxNDMuNjI0NjkxIAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiMxN2JlY2Y7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF8yMSI+CiAgICA8cGF0aCBjbGlwLXBhdGg9InVybCgjcDY5YjE1ZDc4NjQpIiBkPSJNIDE0My40NTAwNzIgMTI1LjI4NjQ2MyAKTCAxNDMuNzg5NjY5IDEyNC45NDY4NjYgCkwgMTQ0LjEyOTI2NiAxMjQuOTQ2ODY2IApMIDE0NC40Njg4NjMgMTI0Ljk0Njg2NiAKTCAxNDQuODA4NDU5IDEyNC45NDY4NjYgCkwgMTQ1LjE0ODA1NiAxMjQuOTQ2ODY2IApMIDE0NS40ODc2NTMgMTI0Ljk0Njg2NiAKTCAxNDUuODI3MjUgMTI0Ljk0Njg2NiAKTCAxNDYuMTY2ODQ3IDEyNC45NDY4NjYgCkwgMTQ2LjUwNjQ0NCAxMjQuOTQ2ODY2IApMIDE0Ni44NDYwNCAxMjQuOTQ2ODY2IApMIDE0Ny4xODU2MzcgMTI0Ljk0Njg2NiAKTCAxNDcuNTI1MjM0IDEyNC45NDY4NjYgCkwgMTQ3Ljg2NDgzMSAxMjQuOTQ2ODY2IApMIDE0OC4yMDQ0MjggMTI1LjI4NjQ2MyAKTCAxNDguMjA0NDI4IDEyNS42MjYwNiAKTCAxNDguMjA0NDI4IDEyNS45NjU2NTcgCkwgMTQ4LjIwNDQyOCAxMjYuMzA1MjU0IApMIDE0OC4yMDQ0MjggMTI2LjY0NDg1MSAKTCAxNDguMjA0NDI4IDEyNi45ODQ0NDcgCkwgMTQ4LjIwNDQyOCAxMjcuMzI0MDQ0IApMIDE0OC4yMDQ0MjggMTI3LjY2MzY0MSAKTCAxNDguMjA0NDI4IDEyOC4wMDMyMzggCkwgMTQ4LjIwNDQyOCAxMjguMzQyODM1IApMIDE0OC4yMDQ0MjggMTI4LjY4MjQzMSAKTCAxNDguMjA0NDI4IDEyOS4wMjIwMjggCkwgMTQ4LjIwNDQyOCAxMjkuMzYxNjI1IApMIDE0OC4yMDQ0MjggMTI5LjcwMTIyMiAKTCAxNDguMjA0NDI4IDEzMC4wNDA4MTkgCkwgMTQ4LjIwNDQyOCAxMzAuMzgwNDE1IApMIDE0OC4yMDQ0MjggMTMwLjcyMDAxMiAKTCAxNDguMjA0NDI4IDEzMS4wNTk2MDkgCkwgMTQ4LjIwNDQyOCAxMzEuMzk5MjA2IApMIDE0OC4yMDQ0MjggMTMxLjczODgwMyAKTCAxNDguMjA0NDI4IDEzMi4wNzgzOTkgCkwgMTQ4LjIwNDQyOCAxMzIuNDE3OTk2IApMIDE0OC4yMDQ0MjggMTMyLjc1NzU5MyAKTCAxNDguMjA0NDI4IDEzMy4wOTcxOSAKTCAxNDguMjA0NDI4IDEzMy40MzY3ODcgCkwgMTQ4LjIwNDQyOCAxMzMuNzc2MzgzIApMIDE0OC4yMDQ0MjggMTM0LjExNTk4IApMIDE0OC4yMDQ0MjggMTM0LjQ1NTU3NyAKTCAxNDguMjA0NDI4IDEzNC43OTUxNzQgCkwgMTQ4LjIwNDQyOCAxMzUuMTM0NzcxIApMIDE0OC4yMDQ0MjggMTM1LjQ3NDM2NyAKTCAxNDguMjA0NDI4IDEzNS44MTM5NjQgCkwgMTQ4LjIwNDQyOCAxMzYuMTUzNTYxIApMIDE0OC4yMDQ0MjggMTM2LjQ5MzE1OCAKTCAxNDguMjA0NDI4IDEzNi44MzI3NTUgCkwgMTQ4LjIwNDQyOCAxMzcuMTcyMzUxIApMIDE0OC4yMDQ0MjggMTM3LjUxMTk0OCAKTCAxNDguMjA0NDI4IDEzNy44NTE1NDUgCkwgMTQ4LjIwNDQyOCAxMzguMTkxMTQyIApMIDE0Ny44NjQ4MzEgMTM4LjUzMDczOSAKTCAxNDcuNTI1MjM0IDEzOC41MzA3MzkgCkwgMTQ3LjE4NTYzNyAxMzguNTMwNzM5IApMIDE0Ni44NDYwNCAxMzguNTMwNzM5IApMIDE0Ni41MDY0NDQgMTM4LjUzMDczOSAKTCAxNDYuMTY2ODQ3IDEzOC41MzA3MzkgCkwgMTQ1LjgyNzI1IDEzOC41MzA3MzkgCkwgMTQ1LjQ4NzY1MyAxMzguNTMwNzM5IApMIDE0NS4xNDgwNTYgMTM4LjUzMDczOSAKTCAxNDQuODA4NDU5IDEzOC41MzA3MzkgCkwgMTQ0LjQ2ODg2MyAxMzguNTMwNzM5IApMIDE0NC4xMjkyNjYgMTM4LjUzMDczOSAKTCAxNDMuNzg5NjY5IDEzOC41MzA3MzkgCkwgMTQzLjQ1MDA3MiAxMzguMTkxMTQyIApMIDE0My40NTAwNzIgMTM3Ljg1MTU0NSAKTCAxNDMuNDUwMDcyIDEzNy41MTE5NDggCkwgMTQzLjQ1MDA3MiAxMzcuMTcyMzUxIApMIDE0My40NTAwNzIgMTM2LjgzMjc1NSAKTCAxNDMuNDUwMDcyIDEzNi40OTMxNTggCkwgMTQzLjQ1MDA3MiAxMzYuMTUzNTYxIApMIDE0My40NTAwNzIgMTM1LjgxMzk2NCAKTCAxNDMuNDUwMDcyIDEzNS40NzQzNjcgCkwgMTQzLjQ1MDA3MiAxMzUuMTM0NzcxIApMIDE0My40NTAwNzIgMTM0Ljc5NTE3NCAKTCAxNDMuNDUwMDcyIDEzNC40NTU1NzcgCkwgMTQzLjQ1MDA3MiAxMzQuMTE1OTggCkwgMTQzLjQ1MDA3MiAxMzMuNzc2MzgzIApMIDE0My40NTAwNzIgMTMzLjQzNjc4NyAKTCAxNDMuNDUwMDcyIDEzMy4wOTcxOSAKTCAxNDMuNDUwMDcyIDEzMi43NTc1OTMgCkwgMTQzLjQ1MDA3MiAxMzIuNDE3OTk2IApMIDE0My40NTAwNzIgMTMyLjA3ODM5OSAKTCAxNDMuNDUwMDcyIDEzMS43Mzg4MDMgCkwgMTQzLjQ1MDA3MiAxMzEuMzk5MjA2IApMIDE0My40NTAwNzIgMTMxLjA1OTYwOSAKTCAxNDMuNDUwMDcyIDEzMC43MjAwMTIgCkwgMTQzLjQ1MDA3MiAxMzAuMzgwNDE1IApMIDE0My40NTAwNzIgMTMwLjA0MDgxOSAKTCAxNDMuNDUwMDcyIDEyOS43MDEyMjIgCkwgMTQzLjQ1MDA3MiAxMjkuMzYxNjI1IApMIDE0My40NTAwNzIgMTI5LjAyMjAyOCAKTCAxNDMuNDUwMDcyIDEyOC42ODI0MzEgCkwgMTQzLjQ1MDA3MiAxMjguMzQyODM1IApMIDE0My40NTAwNzIgMTI4LjAwMzIzOCAKTCAxNDMuNDUwMDcyIDEyNy42NjM2NDEgCkwgMTQzLjQ1MDA3MiAxMjcuMzI0MDQ0IApMIDE0My40NTAwNzIgMTI2Ljk4NDQ0NyAKTCAxNDMuNDUwMDcyIDEyNi42NDQ4NTEgCkwgMTQzLjQ1MDA3MiAxMjYuMzA1MjU0IApMIDE0My40NTAwNzIgMTI1Ljk2NTY1NyAKTCAxNDMuNDUwMDcyIDEyNS42MjYwNiAKIiBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTojMWY3N2I0O3N0cm9rZS1saW5lY2FwOnNxdWFyZTtzdHJva2Utd2lkdGg6MS41OyIvPgogICA8L2c+CiAgIDxnIGlkPSJsaW5lMmRfMjIiPgogICAgPHBhdGggY2xpcC1wYXRoPSJ1cmwoI3A2OWIxNWQ3ODY0KSIgZD0iTSAxNDMuNDUwMDcyIDEyNS4yODY0NjMgCkwgMTQzLjc4OTY2OSAxMjQuOTQ2ODY2IApMIDE0NC4xMjkyNjYgMTI0Ljk0Njg2NiAKTCAxNDQuNDY4ODYzIDEyNC45NDY4NjYgCkwgMTQ0LjgwODQ1OSAxMjQuOTQ2ODY2IApMIDE0NS4xNDgwNTYgMTI0Ljk0Njg2NiAKTCAxNDUuNDg3NjUzIDEyNC45NDY4NjYgCkwgMTQ1LjgyNzI1IDEyNC45NDY4NjYgCkwgMTQ2LjE2Njg0NyAxMjQuOTQ2ODY2IApMIDE0Ni41MDY0NDQgMTI0Ljk0Njg2NiAKTCAxNDYuODQ2MDQgMTI0Ljk0Njg2NiAKTCAxNDcuMTg1NjM3IDEyNC45NDY4NjYgCkwgMTQ3LjUyNTIzNCAxMjQuOTQ2ODY2IApMIDE0Ny44NjQ4MzEgMTI0Ljk0Njg2NiAKTCAxNDguMjA0NDI4IDEyNS4yODY0NjMgCkwgMTQ4LjIwNDQyOCAxMjUuNjI2MDYgCkwgMTQ4LjIwNDQyOCAxMjUuOTY1NjU3IApMIDE0OC4yMDQ0MjggMTI2LjMwNTI1NCAKTCAxNDguMjA0NDI4IDEyNi42NDQ4NTEgCkwgMTQ4LjIwNDQyOCAxMjYuOTg0NDQ3IApMIDE0OC4yMDQ0MjggMTI3LjMyNDA0NCAKTCAxNDguMjA0NDI4IDEyNy42NjM2NDEgCkwgMTQ4LjIwNDQyOCAxMjguMDAzMjM4IApMIDE0OC4yMDQ0MjggMTI4LjM0MjgzNSAKTCAxNDguMjA0NDI4IDEyOC42ODI0MzEgCkwgMTQ4LjIwNDQyOCAxMjkuMDIyMDI4IApMIDE0OC4yMDQ0MjggMTI5LjM2MTYyNSAKTCAxNDguMjA0NDI4IDEyOS43MDEyMjIgCkwgMTQ4LjIwNDQyOCAxMzAuMDQwODE5IApMIDE0OC4yMDQ0MjggMTMwLjM4MDQxNSAKTCAxNDguMjA0NDI4IDEzMC43MjAwMTIgCkwgMTQ4LjIwNDQyOCAxMzEuMDU5NjA5IApMIDE0OC4yMDQ0MjggMTMxLjM5OTIwNiAKTCAxNDguMjA0NDI4IDEzMS43Mzg4MDMgCkwgMTQ4LjIwNDQyOCAxMzIuMDc4Mzk5IApMIDE0OC4yMDQ0MjggMTMyLjQxNzk5NiAKTCAxNDguMjA0NDI4IDEzMi43NTc1OTMgCkwgMTQ4LjIwNDQyOCAxMzMuMDk3MTkgCkwgMTQ4LjIwNDQyOCAxMzMuNDM2Nzg3IApMIDE0OC4yMDQ0MjggMTMzLjc3NjM4MyAKTCAxNDguMjA0NDI4IDEzNC4xMTU5OCAKTCAxNDguMjA0NDI4IDEzNC40NTU1NzcgCkwgMTQ4LjIwNDQyOCAxMzQuNzk1MTc0IApMIDE0OC4yMDQ0MjggMTM1LjEzNDc3MSAKTCAxNDguMjA0NDI4IDEzNS40NzQzNjcgCkwgMTQ4LjIwNDQyOCAxMzUuODEzOTY0IApMIDE0OC4yMDQ0MjggMTM2LjE1MzU2MSAKTCAxNDguMjA0NDI4IDEzNi40OTMxNTggCkwgMTQ4LjIwNDQyOCAxMzYuODMyNzU1IApMIDE0OC4yMDQ0MjggMTM3LjE3MjM1MSAKTCAxNDguMjA0NDI4IDEzNy41MTE5NDggCkwgMTQ4LjIwNDQyOCAxMzcuODUxNTQ1IApMIDE0OC4yMDQ0MjggMTM4LjE5MTE0MiAKTCAxNDcuODY0ODMxIDEzOC41MzA3MzkgCkwgMTQ3LjUyNTIzNCAxMzguNTMwNzM5IApMIDE0Ny4xODU2MzcgMTM4LjUzMDczOSAKTCAxNDYuODQ2MDQgMTM4LjUzMDczOSAKTCAxNDYuNTA2NDQ0IDEzOC41MzA3MzkgCkwgMTQ2LjE2Njg0NyAxMzguNTMwNzM5IApMIDE0NS44MjcyNSAxMzguNTMwNzM5IApMIDE0NS40ODc2NTMgMTM4LjUzMDczOSAKTCAxNDUuMTQ4MDU2IDEzOC41MzA3MzkgCkwgMTQ0LjgwODQ1OSAxMzguNTMwNzM5IApMIDE0NC40Njg4NjMgMTM4LjUzMDczOSAKTCAxNDQuMTI5MjY2IDEzOC41MzA3MzkgCkwgMTQzLjc4OTY2OSAxMzguNTMwNzM5IApMIDE0My40NTAwNzIgMTM4LjE5MTE0MiAKTCAxNDMuNDUwMDcyIDEzNy44NTE1NDUgCkwgMTQzLjQ1MDA3MiAxMzcuNTExOTQ4IApMIDE0My40NTAwNzIgMTM3LjE3MjM1MSAKTCAxNDMuNDUwMDcyIDEzNi44MzI3NTUgCkwgMTQzLjQ1MDA3MiAxMzYuNDkzMTU4IApMIDE0My40NTAwNzIgMTM2LjE1MzU2MSAKTCAxNDMuNDUwMDcyIDEzNS44MTM5NjQgCkwgMTQzLjQ1MDA3MiAxMzUuNDc0MzY3IApMIDE0My40NTAwNzIgMTM1LjEzNDc3MSAKTCAxNDMuNDUwMDcyIDEzNC43OTUxNzQgCkwgMTQzLjQ1MDA3MiAxMzQuNDU1NTc3IApMIDE0My40NTAwNzIgMTM0LjExNTk4IApMIDE0My40NTAwNzIgMTMzLjc3NjM4MyAKTCAxNDMuNDUwMDcyIDEzMy40MzY3ODcgCkwgMTQzLjQ1MDA3MiAxMzMuMDk3MTkgCkwgMTQzLjQ1MDA3MiAxMzIuNzU3NTkzIApMIDE0My40NTAwNzIgMTMyLjQxNzk5NiAKTCAxNDMuNDUwMDcyIDEzMi4wNzgzOTkgCkwgMTQzLjQ1MDA3MiAxMzEuNzM4ODAzIApMIDE0My40NTAwNzIgMTMxLjM5OTIwNiAKTCAxNDMuNDUwMDcyIDEzMS4wNTk2MDkgCkwgMTQzLjQ1MDA3MiAxMzAuNzIwMDEyIApMIDE0My40NTAwNzIgMTMwLjM4MDQxNSAKTCAxNDMuNDUwMDcyIDEzMC4wNDA4MTkgCkwgMTQzLjQ1MDA3MiAxMjkuNzAxMjIyIApMIDE0My40NTAwNzIgMTI5LjM2MTYyNSAKTCAxNDMuNDUwMDcyIDEyOS4wMjIwMjggCkwgMTQzLjQ1MDA3MiAxMjguNjgyNDMxIApMIDE0My40NTAwNzIgMTI4LjM0MjgzNSAKTCAxNDMuNDUwMDcyIDEyOC4wMDMyMzggCkwgMTQzLjQ1MDA3MiAxMjcuNjYzNjQxIApMIDE0My40NTAwNzIgMTI3LjMyNDA0NCAKTCAxNDMuNDUwMDcyIDEyNi45ODQ0NDcgCkwgMTQzLjQ1MDA3MiAxMjYuNjQ0ODUxIApMIDE0My40NTAwNzIgMTI2LjMwNTI1NCAKTCAxNDMuNDUwMDcyIDEyNS45NjU2NTcgCkwgMTQzLjQ1MDA3MiAxMjUuNjI2MDYgCiIgc3R5bGU9ImZpbGw6bm9uZTtzdHJva2U6I2ZmN2YwZTtzdHJva2UtbGluZWNhcDpzcXVhcmU7c3Ryb2tlLXdpZHRoOjEuNTsiLz4KICAgPC9nPgogICA8ZyBpZD0ibGluZTJkXzIzIj4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMjUxLjEwMjI1OSAxMjMuNTg4NDc5IApMIDI1MS40NDE4NTYgMTIzLjI0ODg4MiAKTCAyNTkuMjUyNTgzIDEyMy4yNDg4ODIgCkwgMjU5LjU5MjE4IDEyMy41ODg0NzkgCkwgMjU5LjU5MjE4IDEzOC44NzAzMzUgCkwgMjU5LjI1MjU4MyAxMzkuMjA5OTMyIApMIDI1MS40NDE4NTYgMTM5LjIwOTkzMiAKTCAyNTEuMTAyMjU5IDEzOC44NzAzMzUgCkwgMjUxLjEwMjI1OSAxMjMuOTI4MDc2IApMIDI1MS4xMDIyNTkgMTIzLjkyODA3NiAKIiBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTojMmNhMDJjO3N0cm9rZS1saW5lY2FwOnNxdWFyZTtzdHJva2Utd2lkdGg6MS41OyIvPgogICA8L2c+CiAgIDxnIGlkPSJsaW5lMmRfMjQiPgogICAgPHBhdGggY2xpcC1wYXRoPSJ1cmwoI3A2OWIxNWQ3ODY0KSIgZD0iTSAyNTEuMTAyMjU5IDEyMy41ODg0NzkgCkwgMjUxLjQ0MTg1NiAxMjMuMjQ4ODgyIApMIDI1OS4yNTI1ODMgMTIzLjI0ODg4MiAKTCAyNTkuNTkyMTggMTIzLjU4ODQ3OSAKTCAyNTkuNTkyMTggMTM4Ljg3MDMzNSAKTCAyNTkuMjUyNTgzIDEzOS4yMDk5MzIgCkwgMjUxLjQ0MTg1NiAxMzkuMjA5OTMyIApMIDI1MS4xMDIyNTkgMTM4Ljg3MDMzNSAKTCAyNTEuMTAyMjU5IDEyMy45MjgwNzYgCkwgMjUxLjEwMjI1OSAxMjMuOTI4MDc2IAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiNkNjI3Mjg7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF8yNSI+CiAgICA8cGF0aCBjbGlwLXBhdGg9InVybCgjcDY5YjE1ZDc4NjQpIiBkPSJNIDE1MC4yNDIwMDggMTIzLjI0ODg4MiAKTCAxNTAuNTgxNjA1IDEyMi45MDkyODYgCkwgMTk2LjA4NzU3NyAxMjIuOTA5Mjg2IApMIDE5Ni40MjcxNzQgMTIzLjI0ODg4MiAKTCAxOTYuNDI3MTc0IDE0MS4yNDc1MTMgCkwgMTk2LjA4NzU3NyAxNDEuNTg3MTEgCkwgMTUwLjU4MTYwNSAxNDEuNTg3MTEgCkwgMTUwLjI0MjAwOCAxNDEuMjQ3NTEzIApMIDE1MC4yNDIwMDggMTIzLjU4ODQ3OSAKTCAxNTAuMjQyMDA4IDEyMy41ODg0NzkgCiIgc3R5bGU9ImZpbGw6bm9uZTtzdHJva2U6Izk0NjdiZDtzdHJva2UtbGluZWNhcDpzcXVhcmU7c3Ryb2tlLXdpZHRoOjEuNTsiLz4KICAgPC9nPgogICA8ZyBpZD0ibGluZTJkXzI2Ij4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMTUwLjI0MjAwOCAxMjMuMjQ4ODgyIApMIDE1MC41ODE2MDUgMTIyLjkwOTI4NiAKTCAxOTYuMDg3NTc3IDEyMi45MDkyODYgCkwgMTk2LjQyNzE3NCAxMjMuMjQ4ODgyIApMIDE5Ni40MjcxNzQgMTQxLjI0NzUxMyAKTCAxOTYuMDg3NTc3IDE0MS41ODcxMSAKTCAxNTAuNTgxNjA1IDE0MS41ODcxMSAKTCAxNTAuMjQyMDA4IDE0MS4yNDc1MTMgCkwgMTUwLjI0MjAwOCAxMjMuNTg4NDc5IApMIDE1MC4yNDIwMDggMTIzLjU4ODQ3OSAKIiBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTojOGM1NjRiO3N0cm9rZS1saW5lY2FwOnNxdWFyZTtzdHJva2Utd2lkdGg6MS41OyIvPgogICA8L2c+CiAgIDxnIGlkPSJsaW5lMmRfMjciPgogICAgPHBhdGggY2xpcC1wYXRoPSJ1cmwoI3A2OWIxNWQ3ODY0KSIgZD0iTSA5My44Njg5MzkgMTIyLjkwOTI4NiAKTCA5NC4yMDg1MzYgMTIyLjU2OTY4OSAKTCAxMzUuNjM5MzQ2IDEyMi41Njk2ODkgCkwgMTM1Ljk3ODk0MyAxMjIuOTA5Mjg2IApMIDEzNS45Nzg5NDMgMTQwLjkwNzkxNiAKTCAxMzUuNjM5MzQ2IDE0MS4yNDc1MTMgCkwgOTQuMjA4NTM2IDE0MS4yNDc1MTMgCkwgOTMuODY4OTM5IDE0MC45MDc5MTYgCkwgOTMuODY4OTM5IDEyMy4yNDg4ODIgCkwgOTMuODY4OTM5IDEyMy4yNDg4ODIgCiIgc3R5bGU9ImZpbGw6bm9uZTtzdHJva2U6I2UzNzdjMjtzdHJva2UtbGluZWNhcDpzcXVhcmU7c3Ryb2tlLXdpZHRoOjEuNTsiLz4KICAgPC9nPgogICA8ZyBpZD0ibGluZTJkXzI4Ij4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMzQ5LjI0NTczNiAxMjIuNTY5Njg5IApMIDM0OS41ODUzMzMgMTIyLjIzMDA5MiAKTCAzNTUuMDE4ODgyIDEyMi4yMzAwOTIgCkwgMzU1LjM1ODQ3OSAxMjIuNTY5Njg5IApMIDM1NS4zNTg0NzkgMTM4LjE5MTE0MiAKTCAzNTUuMDE4ODgyIDEzOC41MzA3MzkgCkwgMzQ5LjU4NTMzMyAxMzguNTMwNzM5IApMIDM0OS4yNDU3MzYgMTM4LjE5MTE0MiAKTCAzNDkuMjQ1NzM2IDEyMi45MDkyODYgCkwgMzQ5LjI0NTczNiAxMjIuOTA5Mjg2IAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiM3ZjdmN2Y7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF8yOSI+CiAgICA8cGF0aCBjbGlwLXBhdGg9InVybCgjcDY5YjE1ZDc4NjQpIiBkPSJNIDkzLjg2ODkzOSAxMjIuOTA5Mjg2IApMIDk0LjIwODUzNiAxMjIuNTY5Njg5IApMIDEzNS42MzkzNDYgMTIyLjU2OTY4OSAKTCAxMzUuOTc4OTQzIDEyMi45MDkyODYgCkwgMTM1Ljk3ODk0MyAxNDAuOTA3OTE2IApMIDEzNS42MzkzNDYgMTQxLjI0NzUxMyAKTCA5NC4yMDg1MzYgMTQxLjI0NzUxMyAKTCA5My44Njg5MzkgMTQwLjkwNzkxNiAKTCA5My44Njg5MzkgMTIzLjI0ODg4MiAKTCA5My44Njg5MzkgMTIzLjI0ODg4MiAKIiBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTojYmNiZDIyO3N0cm9rZS1saW5lY2FwOnNxdWFyZTtzdHJva2Utd2lkdGg6MS41OyIvPgogICA8L2c+CiAgIDxnIGlkPSJsaW5lMmRfMzAiPgogICAgPHBhdGggY2xpcC1wYXRoPSJ1cmwoI3A2OWIxNWQ3ODY0KSIgZD0iTSAzNDkuMjQ1NzM2IDEyMi41Njk2ODkgCkwgMzQ5LjU4NTMzMyAxMjIuMjMwMDkyIApMIDM1NS4wMTg4ODIgMTIyLjIzMDA5MiAKTCAzNTUuMzU4NDc5IDEyMi41Njk2ODkgCkwgMzU1LjM1ODQ3OSAxMzguMTkxMTQyIApMIDM1NS4wMTg4ODIgMTM4LjUzMDczOSAKTCAzNDkuNTg1MzMzIDEzOC41MzA3MzkgCkwgMzQ5LjI0NTczNiAxMzguMTkxMTQyIApMIDM0OS4yNDU3MzYgMTIyLjkwOTI4NiAKTCAzNDkuMjQ1NzM2IDEyMi45MDkyODYgCiIgc3R5bGU9ImZpbGw6bm9uZTtzdHJva2U6IzE3YmVjZjtzdHJva2UtbGluZWNhcDpzcXVhcmU7c3Ryb2tlLXdpZHRoOjEuNTsiLz4KICAgPC9nPgogICA8ZyBpZD0ibGluZTJkXzMxIj4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMjY2LjA0NDUxOSAxMjIuMjMwMDkyIApMIDI2Ni4zODQxMTYgMTIxLjg5MDQ5NSAKTCAyOTUuMjQ5ODQ0IDEyMS44OTA0OTUgCkwgMjk1LjU4OTQ0MSAxMjIuMjMwMDkyIApMIDI5NS41ODk0NDEgMTM5LjIwOTkzMiAKTCAyOTUuMjQ5ODQ0IDEzOS41NDk1MjkgCkwgMjY2LjM4NDExNiAxMzkuNTQ5NTI5IApMIDI2Ni4wNDQ1MTkgMTM5LjIwOTkzMiAKTCAyNjYuMDQ0NTE5IDEyMi41Njk2ODkgCkwgMjY2LjA0NDUxOSAxMjIuNTY5Njg5IAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiMxZjc3YjQ7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF8zMiI+CiAgICA8cGF0aCBjbGlwLXBhdGg9InVybCgjcDY5YjE1ZDc4NjQpIiBkPSJNIDM2MS44MTA4MTggMTIxLjg5MDQ5NSAKTCAzNjIuMTUwNDE1IDEyMS41NTA4OTggCkwgMzkyLjcxNDEyNyAxMjEuNTUwODk4IApMIDM5My4wNTM3MjQgMTIxLjg5MDQ5NSAKTCAzOTMuMDUzNzI0IDE1OC45MDY1NDcgCkwgMzkyLjcxNDEyNyAxNTkuMjQ2MTQ0IApMIDM2Mi4xNTA0MTUgMTU5LjI0NjE0NCAKTCAzNjEuODEwODE4IDE1OC45MDY1NDcgCkwgMzYxLjgxMDgxOCAxMjIuMjMwMDkyIApMIDM2MS44MTA4MTggMTIyLjIzMDA5MiAKIiBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTojZmY3ZjBlO3N0cm9rZS1saW5lY2FwOnNxdWFyZTtzdHJva2Utd2lkdGg6MS41OyIvPgogICA8L2c+CiAgIDxnIGlkPSJsaW5lMmRfMzMiPgogICAgPHBhdGggY2xpcC1wYXRoPSJ1cmwoI3A2OWIxNWQ3ODY0KSIgZD0iTSAzMDAuMzQzNzk2IDEyMS44OTA0OTUgCkwgMzAwLjY4MzM5MyAxMjEuNTUwODk4IApMIDM0Mi4xMTQyMDMgMTIxLjU1MDg5OCAKTCAzNDIuNDUzOCAxMjEuODkwNDk1IApMIDM0Mi40NTM4IDEzOS4yMDk5MzIgCkwgMzQyLjExNDIwMyAxMzkuNTQ5NTI5IApMIDMwMC42ODMzOTMgMTM5LjU0OTUyOSAKTCAzMDAuMzQzNzk2IDEzOS4yMDk5MzIgCkwgMzAwLjM0Mzc5NiAxMjIuMjMwMDkyIApMIDMwMC4zNDM3OTYgMTIyLjIzMDA5MiAKIiBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTojMmNhMDJjO3N0cm9rZS1saW5lY2FwOnNxdWFyZTtzdHJva2Utd2lkdGg6MS41OyIvPgogICA8L2c+CiAgIDxnIGlkPSJsaW5lMmRfMzQiPgogICAgPHBhdGggY2xpcC1wYXRoPSJ1cmwoI3A2OWIxNWQ3ODY0KSIgZD0iTSAyNjYuMDQ0NTE5IDEyMi4yMzAwOTIgCkwgMjY2LjM4NDExNiAxMjEuODkwNDk1IApMIDI5NS4yNDk4NDQgMTIxLjg5MDQ5NSAKTCAyOTUuNTg5NDQxIDEyMi4yMzAwOTIgCkwgMjk1LjU4OTQ0MSAxMzkuMjA5OTMyIApMIDI5NS4yNDk4NDQgMTM5LjU0OTUyOSAKTCAyNjYuMzg0MTE2IDEzOS41NDk1MjkgCkwgMjY2LjA0NDUxOSAxMzkuMjA5OTMyIApMIDI2Ni4wNDQ1MTkgMTIyLjU2OTY4OSAKTCAyNjYuMDQ0NTE5IDEyMi41Njk2ODkgCiIgc3R5bGU9ImZpbGw6bm9uZTtzdHJva2U6I2Q2MjcyODtzdHJva2UtbGluZWNhcDpzcXVhcmU7c3Ryb2tlLXdpZHRoOjEuNTsiLz4KICAgPC9nPgogICA8ZyBpZD0ibGluZTJkXzM1Ij4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMzYxLjgxMDgxOCAxMjEuODkwNDk1IApMIDM2Mi4xNTA0MTUgMTIxLjU1MDg5OCAKTCAzOTIuNzE0MTI3IDEyMS41NTA4OTggCkwgMzkzLjA1MzcyNCAxMjEuODkwNDk1IApMIDM5My4wNTM3MjQgMTU4LjkwNjU0NyAKTCAzOTIuNzE0MTI3IDE1OS4yNDYxNDQgCkwgMzYyLjE1MDQxNSAxNTkuMjQ2MTQ0IApMIDM2MS44MTA4MTggMTU4LjkwNjU0NyAKTCAzNjEuODEwODE4IDEyMi4yMzAwOTIgCkwgMzYxLjgxMDgxOCAxMjIuMjMwMDkyIAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiM5NDY3YmQ7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF8zNiI+CiAgICA8cGF0aCBjbGlwLXBhdGg9InVybCgjcDY5YjE1ZDc4NjQpIiBkPSJNIDMwMC4zNDM3OTYgMTIxLjg5MDQ5NSAKTCAzMDAuNjgzMzkzIDEyMS41NTA4OTggCkwgMzQyLjExNDIwMyAxMjEuNTUwODk4IApMIDM0Mi40NTM4IDEyMS44OTA0OTUgCkwgMzQyLjQ1MzggMTM5LjIwOTkzMiAKTCAzNDIuMTE0MjAzIDEzOS41NDk1MjkgCkwgMzAwLjY4MzM5MyAxMzkuNTQ5NTI5IApMIDMwMC4zNDM3OTYgMTM5LjIwOTkzMiAKTCAzMDAuMzQzNzk2IDEyMi4yMzAwOTIgCkwgMzAwLjM0Mzc5NiAxMjIuMjMwMDkyIAoiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOiM4YzU2NGI7c3Ryb2tlLWxpbmVjYXA6c3F1YXJlO3N0cm9rZS13aWR0aDoxLjU7Ii8+CiAgIDwvZz4KICAgPGcgaWQ9ImxpbmUyZF8zNyI+CiAgICA8cGF0aCBjbGlwLXBhdGg9InVybCgjcDY5YjE1ZDc4NjQpIiBkPSJNIDIwMS4xODE1MjkgMTIxLjU1MDg5OCAKTCAyMDEuNTIxMTI2IDEyMS4yMTEzMDIgCkwgMjM4LjE5NzU4MSAxMjEuMjExMzAyIApMIDIzOC41MzcxNzggMTIxLjU1MDg5OCAKTCAyMzguNTM3MTc4IDE0MC4yMjg3MjMgCkwgMjM4LjE5NzU4MSAxNDAuNTY4MzIgCkwgMjAxLjUyMTEyNiAxNDAuNTY4MzIgCkwgMjAxLjE4MTUyOSAxNDAuMjI4NzIzIApMIDIwMS4xODE1MjkgMTIxLjg5MDQ5NSAKTCAyMDEuMTgxNTI5IDEyMS44OTA0OTUgCiIgc3R5bGU9ImZpbGw6bm9uZTtzdHJva2U6I2UzNzdjMjtzdHJva2UtbGluZWNhcDpzcXVhcmU7c3Ryb2tlLXdpZHRoOjEuNTsiLz4KICAgPC9nPgogICA8ZyBpZD0ibGluZTJkXzM4Ij4KICAgIDxwYXRoIGNsaXAtcGF0aD0idXJsKCNwNjliMTVkNzg2NCkiIGQ9Ik0gMjAxLjE4MTUyOSAxMjEuNTUwODk4IApMIDIwMS41MjExMjYgMTIxLjIxMTMwMiAKTCAyMzguMTk3NTgxIDEyMS4yMTEzMDIgCkwgMjM4LjUzNzE3OCAxMjEuNTUwODk4IApMIDIzOC41MzcxNzggMTQwLjIyODcyMyAKTCAyMzguMTk3NTgxIDE0MC41NjgzMiAKTCAyMDEuNTIxMTI2IDE0MC41NjgzMiAKTCAyMDEuMTgxNTI5IDE0MC4yMjg3MjMgCkwgMjAxLjE4MTUyOSAxMjEuODkwNDk1IApMIDIwMS4xODE1MjkgMTIxLjg5MDQ5NSAKIiBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTojN2Y3ZjdmO3N0cm9rZS1saW5lY2FwOnNxdWFyZTtzdHJva2Utd2lkdGg6MS41OyIvPgogICA8L2c+CiAgIDxnIGlkPSJsaW5lMmRfMzkiPgogICAgPHBhdGggY2xpcC1wYXRoPSJ1cmwoI3A2OWIxNWQ3ODY0KSIgZD0iTSA3My44MzI3MjcgMTAxLjUxNDY4NyAKTCA3NC4xNzIzMjQgMTAxLjE3NTA5IApMIDM5OC4xNDc2NzYgMTAxLjE3NTA5IApMIDM5OC40ODcyNzMgMTAxLjUxNDY4NyAKTCAzOTguNDg3MjczIDI0Ny41NDEzMTMgCkwgMzk4LjE0NzY3NiAyNDcuODgwOTEgCkwgNzQuMTcyMzI0IDI0Ny44ODA5MSAKTCA3My44MzI3MjcgMjQ3LjU0MTMxMyAKTCA3My44MzI3MjcgMTAxLjg1NDI4NCAKTCA3My44MzI3MjcgMTAxLjg1NDI4NCAKIiBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTojYmNiZDIyO3N0cm9rZS1saW5lY2FwOnNxdWFyZTtzdHJva2Utd2lkdGg6MS41OyIvPgogICA8L2c+CiAgIDxnIGlkPSJsaW5lMmRfNDAiPgogICAgPHBhdGggY2xpcC1wYXRoPSJ1cmwoI3A2OWIxNWQ3ODY0KSIgZD0iTSA3My44MzI3MjcgMTAxLjUxNDY4NyAKTCA3NC4xNzIzMjQgMTAxLjE3NTA5IApMIDM5OC4xNDc2NzYgMTAxLjE3NTA5IApMIDM5OC40ODcyNzMgMTAxLjUxNDY4NyAKTCAzOTguNDg3MjczIDI0Ny41NDEzMTMgCkwgMzk4LjE0NzY3NiAyNDcuODgwOTEgCkwgNzQuMTcyMzI0IDI0Ny44ODA5MSAKTCA3My44MzI3MjcgMjQ3LjU0MTMxMyAKTCA3My44MzI3MjcgMTAxLjg1NDI4NCAKTCA3My44MzI3MjcgMTAxLjg1NDI4NCAKIiBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTojMTdiZWNmO3N0cm9rZS1saW5lY2FwOnNxdWFyZTtzdHJva2Utd2lkdGg6MS41OyIvPgogICA8L2c+CiAgPC9nPgogPC9nPgogPGRlZnM+CiAgPGNsaXBQYXRoIGlkPSJwNjliMTVkNzg2NCI+CiAgIDxyZWN0IGhlaWdodD0iMjY2LjExMiIgd2lkdGg9IjM1Ny4xMiIgeD0iNTcuNiIgeT0iNDEuNDcyIi8+CiAgPC9jbGlwUGF0aD4KIDwvZGVmcz4KPC9zdmc+Cg==";
        // this.pgmData = base64Str;
        // this.konvaConfig.pgmImage.src = `data:image/svg+xml;base64,${base64Str}`;
        // this.konvaConfig.stage.width = this.konvaConfig.pgmImage?.width;
        // this.konvaConfig.stage.height = this.konvaConfig.pgmImage?.height;
        // this.cvsW = this.konvaConfig.pgmImage?.width;
        // this.cvsH = this.konvaConfig.pgmImage?.height;
      };
      this.mapWs.onmessage = (msg) => {
        const msgObj = JSON.parse(msg?.data);
        const base64Str = msgObj?.map;
        this.pgmData = base64Str;
        this.konvaConfig.pgmImage.src = `data:image/svg+xml;base64,${base64Str}`;
        this.konvaConfig.stage.width = this.konvaConfig.pgmImage?.width;
        this.konvaConfig.stage.height = this.konvaConfig.pgmImage?.height;
        this.cvsW = this.konvaConfig.pgmImage?.width;
        this.cvsH = this.konvaConfig.pgmImage?.height;
      };
      this.mapWs.onclose = (event) => {
        if (event.wasClean) {
          console.log(
            `[close] Connection closed cleanly, code=${event.code} reason=${event.reason} deviceId=${this.deviceId}`
          );
        } else {
          console.log("[close] Connection died");
        }
      };
      this.ws.onerror = (e) => {
        console.log(`${mapWsUrl}----连接失败---` + e.code);
      };
    },

    closeMapWebsoket() {
      this.mapWs?.close();
      this.mapWs = null;
    },

    clearTimeoutData: function () {
      this.timeId && clearTimeout(this.timeId);
      this.timeId = null;
    },
    initHavedData: function () {
      this.konvaConfig.points = [];
      this.konvaConfig.polyline = [];
      this.$refs.circleTooltipRef.isContent = false;
      this.konvaConfig.polygon = [];
      this.areaPoints = [];
      this.konvaConfig.areaPoints = [];
      this.TaskDetailData = [];
      this.path = [];
      this.curPoint = [];
    },
    onHavedData: function (data, isDetail, method, optsType) {
      this.method = method;
      this.optsType = optsType;
      const w = this.cvsW;
      const h = this.cvsH;
      this.isDetail = isDetail;
      if (!isDetail) {
        this.isShow = false; // false 展示 CoordinatePickup
      }
      this.initHavedData();
      if (data.length > 0) {
        for (let i = 0; i < data.length; i++) {
          const point = data[i]?.params?.point || [];
          const color = data[i]?.color;
          let polylinePoints = [];
          for (let j = 0; j < point.length; j++) {
            const p = point[j];
            const layerX = Math.round(w * Number(p.location.x));
            const layerY = Math.round(h * Number(p.location.y));
            const item = {
              x: layerX,
              y: layerY,
              omega: p.location.omega,
              color,
              key: this.historyMaxnodeNum,
            };
            this.konvaConfig.points.push(item);
            this.points.set(this.historyMaxnodeNum, p);
            this.historyMaxnodeNum += 1;
            polylinePoints.push(layerX, layerY);
            if (polylinePoints.length >= 4) {
              if (isDetail) {
                this.konvaConfig.polyline.push({
                  color,
                  groupLine: polylinePoints,
                });
              } else {
                const newPolyline = [...polylinePoints];
                this.konvaConfig.polyline.push(newPolyline);
              }
            }
          }
          const area = data[i]?.params?.area || [];
          let infoPointArr = [];
          for (let i = 0; i < area.length; i++) {
            let obj = {};
            if (i % 2 === 0) {
              obj.x = area[i];
              obj.y = area[i + 1];
              let Lx = area[i] * this.cvsW;
              const Ly = area[i + 1] * this.cvsH;
              this.konvaConfig.areaPoints.push({ x: Lx, y: Ly, color });
              infoPointArr.push(Lx, Ly);
              if (this.konvaConfig.areaPoints.length >= 3) {
                if (optsType === "seleted") {
                  this.konvaConfig.polygon.push({
                    color,
                    groupPolygon: infoPointArr,
                  });
                } else {
                  const res = [...infoPointArr];
                  this.konvaConfig.polygon = [res];
                  this.areaPoints = area;
                }
              }
            }
          }
          this.infoAreaPoints = [...this.konvaConfig.areaPoints];
          const process = data[i]?.params?.process;
          this.TaskDetailData = process;
        }
      } else {
        this.initHavedData();
      }
    },
    wheelForScale: function (e) {
      e.evt.preventDefault();
      this.isAttributeForm = false;
      const scaleBy = 1.01;
      const stage = this.$refs.konvaStage.getStage();
      const oldScale = stage.scaleX();
      const mousePointTo = {
        x: stage.getPointerPosition().x / oldScale - stage.x() / oldScale,
        y: stage.getPointerPosition().y / oldScale - stage.y() / oldScale,
      };
      const newScale =
        e.evt.deltaY > 0 ? oldScale * scaleBy : oldScale / scaleBy;
      stage.scale({ x: newScale, y: newScale });
      this.$nextTick(() => {
        stage.x(
          (-mousePointTo.x + stage.getPointerPosition().x / newScale) * newScale
        );
        stage.y(
          (-mousePointTo.y + stage.getPointerPosition().y / newScale) * newScale
        );
        stage.batchDraw();
        const scale = e.evt.deltaY > 0 ? scaleBy : 1 / scaleBy;
        this.stageScale = newScale;
        this.stagePointerPosition = {
          x: stage.x(),
          y: stage.y(),
        };
        this.triggerPosition = {
          ...this.triggerPosition,
          layerX:
            stage.getPointerPosition().x +
            (-stage.getPointerPosition().x + this.triggerPosition.layerX) *
              scale,
          layerY:
            stage.getPointerPosition().y +
            (-stage.getPointerPosition().y + this.triggerPosition.layerY) *
              scale,
        };
      });
    },
    onStageTouchstart: function (e) {
      const len = e.evt.touches.length;
      const { pageX, pageY } = e.evt.touches[0];
      if (len >= 2) {
        clearTimeout(timeId);
        this.isAttributeForm = false;
      } else {
        timeId = setTimeout(() => {
          if (this.method === "TASK_INVESTIGATE") {
            const { x, y } = this.stagePointerPosition;
            const dom = document.getElementById("pgmContainer");
            const cxL = pageX - dom.offsetLeft + dom.scrollLeft;
            const cyT = pageY - dom.offsetTop + dom.scrollTop - 62;
            const cx0 = cxL - x;
            const cy0 = cyT - y;
            const cx = cx0 / this.stageScale;
            const cy = cy0 / this.stageScale;
            if (e.target.attrs.id || e.target.attrs.id === 0) {
              this.isAttributeForm = true;
              this.artFormTop = cyT;
              this.artFormLeft = cxL;
            } else {
              // 增加点 编辑存在， 将提示先清空
              if (this.optsType === "update" && !isEmpty(this.infoAreaPoints)) {
                this.$message({
                  type: "info",
                  message: "若想更新边界区域, 请先清空边界点！",
                });
                return;
              }
              this.isAttributeForm = false;
              const obj = { x: cx, y: cy };
              this.konvaConfig.areaPoints.push(obj);
              const uvX = (cx / this.cvsW).toFixed(6);
              const uvY = (cy / this.cvsH).toFixed(6);
              this.areaPoints.push(uvX, uvY);
            }
          } else {
            this.triggerPosition = {
              pageX,
              pageY,
            };
            this.isTouchStart = true;
            this.visibleCircleTooltip = true;
            this.initData();
            if (this.isInitPickUp) {
              this.isShow = false;
            }
          }
        }, 50);
      }
    },
    onStageTouchmove: function (e) {
      e.evt.preventDefault();
      const dom = document.getElementById("pgmContainer");
      const stage = this.$refs.konvaStage.getStage();
      const touch1 = e.evt.touches[0];
      const touch2 = e.evt.touches[1];
      if (touch1 && touch2) {
        this.isTouchmoveing = true;
        this.visibleCircleTooltip = false;
        this.konvaConfig.stage.draggable = false; // 缩放时，禁掉拖拽，两者冲突会导致缩放失效
        const p1 = {
          x: touch1.pageX,
          y: touch1.pageY,
        };
        const p2 = {
          x: touch2.pageX,
          y: touch2.pageY,
        };

        if (!lastCenter) {
          lastCenter = getCenter(p1, p2);
          return;
        }

        if (!lastDist) {
          lastDist = getDistance(p1, p2);
        }
        const newCenter = getCenter(p1, p2); // 缩放中心
        const newDist = getDistance(p1, p2); // 两指距离
        const pointTo = {
          x: (newCenter.x - stage.x()) / stage.scaleX(),
          y: (newCenter.y - stage.y()) / stage.scaleX(),
        };
        let circlePointTo = {
          x: 0,
          y: 0,
        };
        if (this.triggerPosition) {
          circlePointTo = {
            x:
              (newCenter.x -
                (this.triggerPosition.pageX -
                  dom.offsetLeft +
                  dom.scrollLeft)) /
              stage.scaleX(),
            y:
              (newCenter.y -
                (this.triggerPosition.pageY - dom.offsetTop + dom.scrollTop)) /
              stage.scaleX(),
          };
        }
        const scale = stage.scaleX() * (newDist / lastDist);
        // 用于子组件的位置更新
        this.stageScale = scale;
        this.stagePointerPosition = {
          x: stage.x(),
          y: stage.y(),
        };
        stage.scale({ x: scale, y: scale });
        const dx = newCenter.x - lastCenter.x;
        const dy = newCenter.y - lastCenter.y;
        const newPos = {
          x: newCenter.x - pointTo.x * scale + dx,
          y: newCenter.y - pointTo.y * scale + dy,
        };

        this.triggerPosition = {
          pageX:
            newCenter.x -
            circlePointTo.x * scale +
            dx +
            (dom.offsetLeft - dom.scrollLeft),
          pageY:
            newCenter.y -
            circlePointTo.y * scale +
            dy +
            (dom.offsetTop - dom.scrollTop),
        };
        stage.position(newPos);
        lastDist = newDist;
        lastCenter = newCenter;
      }
    },
    onStageTouchend: function () {
      lastDist = 0;
      lastCenter = null;
      // this.konvaConfig.stage.draggable = true;
    },

    onStageClick: function (e) {
      const { layerX, layerY, clientX, clientY } = e.evt;
      this.triggerPosition = {
        layerX,
        layerY,
        clientX,
        clientY,
      };

      if (this.method === "TASK_INVESTIGATE") {
        const { x, y } = this.stagePointerPosition;
        const cx = (layerX - (x || 0)) / this.stageScale;
        const cy = (layerY - (y || 0)) / this.stageScale;
        const obj = { x: cx, y: cy };
        if (
          (e.target.attrs.id || e.target.attrs.id === 0) &&
          e.target.attrs?.name !== "area_circle"
        ) {
          // 点击区域弹窗
          this.artFormTop = layerY;
          this.artFormLeft = layerX;
          this.isAttributeForm = true;
        } else {
          if (e.target?.attrs?.name === "area_circle") {
            //点击点准备拖拽areaPoint
          } else {
            // 增加点 编辑存在， 将提示先清空
            if (this.optsType === "update" && !isEmpty(this.infoAreaPoints)) {
              this.$message({
                type: "info",
                message: "若想更新边界区域, 请先清空边界点！",
              });
              return;
            }

            if (this.optsType === "add" && !isEmpty(this.konvaConfig.polygon)) {
              this.$message({
                type: "info",
                message: "区域点已形成，若想更新, 请先清空边界点！",
              });
              return;
            }

            this.isAttributeForm = false;
            const uvX = (
              (layerX - (x || 0)) /
              (this.cvsW * this.stageScale)
            ).toFixed(6);
            const uvY = (
              (layerY - (y || 0)) /
              (this.cvsH * this.stageScale)
            ).toFixed(6);
            this.konvaConfig.areaPoints.push(obj);
            this.areaPoints.push(uvX, uvY);
          }
        }
      } else {
        this.visibleCircleTooltip = true;
        this.initData();
        if (this.isInitPickUp) {
          this.isShow = false;
        }
      }
    },

    initData: function () {
      this.$refs.circleTooltipRef.form = {
        omega: 0,
        identifierList: this.identifierList, // 目标物
        metaTaskList: this.metaTaskList, // 动作
        selectPoint: this.selectPoint || {
          location: { omega: 0 },
          process: [],
          station: [],
        }, // 选择点
      };
      this.$refs.circleTooltipRef.directions = {
        cx: 60,
        cy: 60,
        omega: 0,
      };
    },

    resetPoint: function () {
      this.konvaConfig.points = [];
      this.konvaConfig.polyline = [];
      this.points = new Map();
      this.historyMaxnodeNum = 0;
      this.resetAreaPointData();
    },

    deleteCircleTooltipData: function (data) {
      const { directions, triggerPoint, visible } = data;
      const {
        location: { x, y },
      } = triggerPoint;
      const { cx, cy } = directions;
      this.visibleCircleTooltip = visible;
      const obj = getMinPoint(
        this.points,
        { x, y },
        this.threshold / this.stageScale
      );

      const obj1 = getKonvaConfigByObj(this.konvaConfig.points, obj);
      if (!isEmpty(obj)) {
        this.points.delete(obj.key);
        let newPolyline = [];
        this.konvaConfig.points = this.konvaConfig.points.map((i) => {
          if (i.key === obj1.key) {
            return;
          } else {
            return { ...i };
          }
        });
        // 更新 polyline
        newPolyline = this.konvaConfig.polyline.map((arrItem) => {
          const result = [];
          for (var i = 0; i < arrItem.length; i = i + 2) {
            if (obj1.x == arrItem[i] && obj1.y == arrItem[i + 1]) {
              continue;
            } else {
              result.push(arrItem[i]);
              result.push(arrItem[i + 1]);
            }
          }
          return result;
        });
        this.konvaConfig.points = [
          ...new Set(this.konvaConfig.points.filter(Boolean)),
        ];
        this.konvaConfig.polyline = newPolyline;
      }
    },
    saveCircleTooltipData: async function (data) {
      const { directions, triggerPoint, visible } = data;
      const {
        location: { x, y, omega },
      } = triggerPoint;
      const { cx, cy } = directions;
      this.visibleCircleTooltip = visible;
      if (this.isInitPickUp) {
        // 设备初始位置设置-拾取逻辑
        // this.konvaConfig.points = [
        //   {
        //     x: cx,
        //     y: cy,
        //     omega,
        //   },
        // ];
        // let map = new Map();
        // map.set(this.historyMaxnodeNum, triggerPoint);
        // this.points = map;
        // 设备-初始位置拾取逻辑
        if (this.onSaveInitPickup && this.isInitPickUp) {
          await this.onSaveInitPickup({ x, y, omega });
          this.isShow = true;
        }
      } else {
        // 导航
        const obj = getMinPoint(
          this.points,
          { x, y },
          this.threshold / this.stageScale
        );
        const obj1 = getKonvaConfigByObj(this.konvaConfig.points, obj);
        let map = new Map();
        if (!isEmpty(obj)) {
          map = this.points.set(this.historyMaxnodeNum, triggerPoint);
          this.konvaConfig.points = this.konvaConfig.points.map((i) => {
            if (i.key === obj1.key) {
              return { ...i, omega };
            } else {
              return { ...i };
            }
          });
        } else {
          map = this.points.set(this.historyMaxnodeNum, triggerPoint);
          this.konvaConfig.points.push({
            x: cx,
            y: cy,
            omega,
            key: this.historyMaxnodeNum,
          });
          this.historyMaxnodeNum += 1;
        }

        this.points = map;
        let pointArr = [];
        const curPoints = [...new Set(this.konvaConfig.points.filter(Boolean))];
        for (let i = 0; i < curPoints.length; i++) {
          pointArr.splice(pointArr.length, 0, curPoints[i].x, curPoints[i].y);
        }
        if (pointArr.length >= 4) {
          this.konvaConfig.polyline.push(pointArr);
        }
        this.konvaConfig.points = curPoints;
      }
    },

    saveCurPoint: function (obj) {
      const { x, y } = obj;
      const triggerPoint = {
        location: { ...obj, stageScale: this.stageScale },
        process: [],
        station: [],
      };
      // 判断当前位置点是都已被添加，若添加则不再更新数据
      let isHaved = false;
      this.points.forEach((val, key) => {
        const location = val?.location;
        if (location.x === obj?.x && location?.y === obj?.y) {
          isHaved = true;
          return;
        }
      });
      if (isHaved === true) {
        // 存在 不在添加
        return;
      } else {
        // 不存在
        let map = new Map();
        map = this.points.set(this.historyMaxnodeNum, triggerPoint);
        const cx = this.cvsW * x;
        const cy = this.cvsH * y;
        const omega = obj?.omega;
        this.konvaConfig.points.push({
          x: cx,
          y: cy,
          omega,
          key: this.historyMaxnodeNum,
        });
        this.historyMaxnodeNum += 1;
        let pointArr = [];
        for (let i = 0; i < this.konvaConfig.points.length; i++) {
          pointArr.splice(
            pointArr.length,
            0,
            this.konvaConfig.points[i].x,
            this.konvaConfig.points[i].y
          );
        }
        if (pointArr.length >= 4) {
          this.konvaConfig.polyline.push(pointArr);
        }
      }
    },

    saveBoundaryPoint: function () {
      const pointArr = [];
      const len = this.konvaConfig.areaPoints.length;
      if (len < 3) {
        this.$message({
          type: "warning",
          message: "至少三个点形成一个区域才可保存哦！",
        });
        return len;
      }
      for (let i = 0; i < len; i++) {
        pointArr.push(
          this.konvaConfig.areaPoints[i].x,
          this.konvaConfig.areaPoints[i].y
        );
      }
      if (pointArr.length >= 6) {
        this.konvaConfig.polygon = [pointArr];
      }
      this.isAttributeForm = false;
    },

    saveCurBoundaryPoint: function (obj) {
      const { x, y } = obj;
      const cx = (this.cvsW * x).toFixed();
      const cy = (this.cvsH * y).toFixed();
      this.konvaConfig.areaPoints.push({ x: cx, y: cy });
      this.areaPoints.push(x, y);
    },

    onArtFormDelete: function () {
      this.isAttributeForm = false;
    },

    onArtFormSave: function (formData) {
      this.isAttributeForm = false;
      this.attributeFormData = formData;
    },

    getAttributeFormData: function () {
      return this.attributeFormData?.process;
    },

    onDragAreaPointStart: function (e) {
      const { id } = e.target?.attrs;
      const arr = id?.split("_");
      const curX = Number(arr[0]);
      const curY = Number(arr[1]);
      // 记录拖拽的点坐标，方便拖拽结束更新点的坐标位
      this.curDragAreaPoint = { curX, curY };
    },

    onDragAreaPointEnd: function (e) {
      const { layerX, layerY, clientX, clientY } = e.evt;
      const { curX, curY } = this.curDragAreaPoint;
      const { x, y } = this.stagePointerPosition;
      const cx = (layerX - (x || 0)) / this.stageScale;
      const cy = (layerY - (y || 0)) / this.stageScale;
      const obj = { x: cx, y: cy };
      const uvX = ((layerX - (x || 0)) / (this.cvsW * this.stageScale)).toFixed(
        6
      );
      const uvY = ((layerY - (y || 0)) / (this.cvsH * this.stageScale)).toFixed(
        6
      );

      let idx = -1;
      for (let i of this.konvaConfig.areaPoints) {
        idx++;
        if (i?.x === curX && i?.y === curY) {
          i.x = cx;
          i.y = cy;
          break;
        }
      }

      // 更新拖拽结束数据
      this.areaPoints?.splice(idx * 2, 2, uvX, uvY);
      const arr = !isEmpty(this.konvaConfig.polygon?.[0])
        ? [...this.konvaConfig.polygon?.[0]]
        : [];
      arr.splice(idx * 2, 2, cx, cy);
      this.konvaConfig.polygon = [arr];
    },

    resetData: function () {
      this.initData();
      this.konvaConfig = {
        stage: {
          width: 1000,
          height: 1000,
          // draggable: true,
        },
        group: {
          x: 0,
          y: 0,
        },
        pgmImage: null,
        points: [],
        polyline: [],
        polygon: [],
        areaPoints: [],
        path: [],
        curPoint: [],
        // { x: 100, y: 100, omega: 45 }
        cloudPoints: [],
      };
      // 切换路由 重绘konva
      lastDist = 0;
      lastCenter = null;
      this.pgmData = null;
      if (this.$refs.konvaStage) {
        const stage = this.$refs.konvaStage.getStage();
        stage.scale({ x: 1, y: 1 });
        stage.position({ x: 0, y: 0 });
        stage.batchDraw();
      }
      this.resetWsData();
    },

    // 只情空点，不清空地图和ws 数据
    clearPgmData: function () {
      this.initData();
      this.resetPoint();
    },

    resetWsData: function () {
      this.konvaConfig.curPoint = [];
      this.konvaConfig.cloudPoints = [];
      this.konvaConfig.path = [];
    },
    resetAreaPointData: function () {
      this.konvaConfig.polygon = [];
      this.konvaConfig.areaPoints = [];
      this.areaPoints = [];
      this.isAttributeForm = false;
      this.infoAreaPoints = [];
      this.curDragAreaPoint = null;
    },
  },

  destroyed() {
    this.pgmData = null;
    this.clearTimeoutData();
  },
};
</script>
<style lang="scss" scoped>
.pgm_konva {
  width: 100%;
}
</style>
