<template>
  <div class="scene" id="scene">
    <NotFound
      v-if="
        (!mapId && !sceneName.includes('建图')) ||
        (sceneName.includes('建图') && !firstDeviceId)
      "
      desc="暂无地图信息"
      :image="require('@/assets/img/empty.svg')"
    />
    <div
      class="scence_CesiumViewer"
      v-if="mapType === 2 && !sceneName.includes('建图')"
      style="height: calc(100% - 22px)"
    >
      <CesiumViewer
        :mapId="mapId"
        :mapInfo="mapInfo"
        ref="cesiumViewerRef"
        :pageType="pageType"
        :method="method"
        :taskInfoRow="mapInfoPointsData"
        :wsData="wsDeviceDataList"
      />
    </div>
    <PgmKonvaScene
      ref="pgmKonvaShowRef"
      v-if="mapType === 0 || (sceneName.includes('建图') && firstDeviceId)"
      :mapId="mapId"
      :wsData="wsDeviceDataList"
      :isSceneName="sceneName.includes('建图')"
      :deviceId="firstDeviceId"
    />
    <CustomCollapse>
      <el-form label-position="top">
        <el-row>
          <el-col :span="5" class="scene_col">
            <el-form-item label="场景信息">
              <p>
                场景名称：
                <span v-if="selectSceneInfo">
                  {{ selectSceneInfo?.name || "-" }}
                </span>
              </p>
              <p>
                地图名称：
                <span v-if="selectSceneInfo">
                  {{ selectSceneInfo?.map?.name || "-" }}
                </span>
              </p>
              <p>
                订阅服务：
                <span v-if="selectSceneInfo">
                  {{ selectSceneInfo?.subscribe?.name || "-" }}
                </span>
              </p>
            </el-form-item>
          </el-col>
          <el-col :span="5" class="scene_col">
            <el-form-item label="已选设备">
              <NotFound
                v-if="selectedDeviceList.length === 0"
                desc="暂无已选设备"
                :image="require('@/assets/img/empty.svg')"
              />
              <ul v-else>
                <li
                  v-for="item in selectedDeviceList"
                  :key="item.id"
                  class="text_mutil_overflow_custum"
                  :style="{ color: item?.color || 'skyblue', fontWeight: 800 }"
                >
                  {{ item.name }}
                </li>
              </ul>
            </el-form-item>
          </el-col>
          <el-col :span="11" class="scene_col list">
            <el-form-item label="在线任务">
              <el-table
                highlight-current-row
                stripe
                :data="onlineTasksList"
                ref="sceneTableRef"
                height="100%"
                v-loading="tableLoading"
                @select="selectChange"
                :header-cell-class-name="headerCellAllClassName"
              >
                <el-table-column
                  prop="name"
                  label="任务名称"
                  :formatter="formatterFun"
                  column-key="name"
                >
                  <template slot-scope="scope">
                    <a
                      :style="ACellStyle(scope.row)"
                      target="_self"
                      rel="noopener noreferrer"
                      @click="onClickTaskInfo(scope.row)"
                      >{{ scope.row.name }}</a
                    >
                  </template>
                </el-table-column>
                <el-table-column
                  prop="status"
                  label="任务状态"
                  column-key="status"
                  :formatter="formatterFun"
                />
                <el-table-column label="操作">
                  <template slot-scope="scope">
                    <el-button
                      @click="onAction(scope.row, 'update')"
                      type="text"
                      size="small"
                      v-if="scope.row.status === 'Create'"
                      >编辑</el-button
                    >
                    <el-button
                      @click="onAction(scope.row, 'Restore')"
                      type="text"
                      size="small"
                      v-if="scope.row.status === 'Pause'"
                      >恢复</el-button
                    >
                    <el-button
                      @click="onAction(scope.row, 'suspend')"
                      type="text"
                      size="small"
                      v-if="
                        scope.row.status === 'Create' ||
                        scope.row.status === 'Running' ||
                        scope.row.status === 'Restore'
                      "
                      >{{
                        scope.row.status === "Running" ||
                        scope.row.status === "Restore"
                          ? "暂停"
                          : "启动"
                      }}</el-button
                    >
                    <el-button
                      @click="onAction(scope.row, 'end')"
                      type="text"
                      size="small"
                      v-if="
                        scope.row.status === 'Running' ||
                        scope.row.status === 'Pause'
                      "
                      >终止</el-button
                    >
                    <el-button
                      @click="onAction(scope.row, 'emergencyStop')"
                      type="text"
                      size="small"
                      class="stop_btn"
                      v-if="
                        scope.row.status === 'Running' ||
                        scope.row.status === 'Action'
                      "
                      >急停</el-button
                    >
                  </template>
                </el-table-column>
                <el-table-column type="selection" width="42" align="center">
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
          <el-col :span="3" class="scene_col btn">
            <div class="scene_opts">
              <SelectTask ref="selectTaskRef" :onClickTaskBtn="resetTask" />
              <el-button
                @click="onClickOpts('history')"
                type="primary"
                size="small"
                >历史任务</el-button
              >
              <el-button
                @click="onClickOpts('edit')"
                type="primary"
                size="small"
                >场景编辑</el-button
              >
            </div>
          </el-col>
        </el-row>
      </el-form>
    </CustomCollapse>
    <AddUpdateTask
      :selectSceneInfo="selectSceneInfo"
      ref="addUpdateTaskRef"
      :getOnlineTaskList="getOnlineTaskList"
      :isShowTaskInfo="isShowTaskInfo"
      :getCurTaskPoints="getCurTaskPoints"
      :resetMapData="resetMapData"
      :getCurTaskInfoPoints="getCurTaskInfoPoints"
      :onClickNavPoint="onClickNavPoint"
      :onClearBoundaryPoint="onClearBoundaryPoint"
      :saveBoundaryPoint="saveBoundaryPoint"
      :getAreaPoints="getAreaPoints"
      :updateCurSceneMapObj="updateCurSceneMapObj"
      isCurPage="sceneDetail"
    />
    <HistoryTask
      ref="historyTaskRef"
      :getOnlineTaskList="getOnlineTaskList"
      :historyTableLoading="historyTableLoading"
      :historyTaskList="historyTaskList"
      :getHistroyTaskList="getHistroyTaskList"
    />
    <UpdateScene
      v-if="isShowUpdateScene"
      :selectSceneInfo="selectSceneInfo"
      :closeUpdateScene="closeUpdateScene"
    />
    <TaskDetail
      v-if="isShowTaskDetail"
      :isShowTaskInfo="isShowTaskInfo"
      :taskCondition="taskCondition"
      :taskInfoRow="taskInfoRow"
      :onTaskEdit="onTaskEdit"
      :onUpdateCancel="onUpdateTaskCancel"
      :onDeleteOnlineTask="onDeleteOnlineTask"
      :getCurTaskInfoPoints="getCurTaskInfoPoints"
      :openDeviceTravelWebsocket="openWebsocket"
      :closeDeviceTravel="closeWebsoket"
    />
  </div>
</template>
<script>
import PgmKonvaScene from "@/views/Scenes/components/PgmKonvaScene/Index.vue";
import CustomCollapse from "@/components/CustomCollapse/Index.vue";
import AddUpdateTask from "@/views/Task/AddUpdateTask/Index.vue";
import NotFound from "@/components/NotFound/Index.vue";
import SelectTask from "@/views/Task/components/SelectTask/Index.vue";
import UpdateScene from "../UpdateScene/Index.vue";
import HistoryTask from "../HistoryTask/Index.vue";
import TaskDetail from "@/views/Task/Detail/Index.vue";
import CesiumViewer from "@/components/CesiumViewer/Index.vue";
import { getOnlineTaskList, executeTask, getHistoryTaskList } from "@/api/task";
import { emergencyStop } from "@/api/cmd";
import { RandomColor } from "@/utils/RandomColor.js";
import { strToObj } from "@/utils/index";
import { isEqual } from "lodash";
import GlobalLoading from "@/components/Loading/Loading.js";
import { getSceneDetail } from "@/api/scene.js";
import { isEmpty } from "lodash";
export default {
  data() {
    return {
      selectedDeviceList: [], // 已选设备
      onlineTasksList: [], // 在线任务
      tableLoading: false,
      isShowSceneDetail: true,
      isShowTaskDetail: this.$route?.query?.taskId || false,
      taskInfoRow: null,
      mapId: "",
      mapType: "",
      historyTableLoading: false,
      historyTaskList: [],
      selectionList: [], // 在线勾选List
      selectSceneInfo: null,
      sceneId: "",
      sceneName: "",
      mapInfo: null,
      loadLoading: true,
      isShowUpdateScene: false,
      pageType: this.$store.state.curTaskInfo?.optsType,
      method: this.$store.state.curTaskInfo?.method,
      ws: {},
      wsDeviceDataList: [],
      mapInfoPointsData: [],
      firstDeviceId: "",
    };
  },
  components: {
    PgmKonvaScene,
    CustomCollapse,
    AddUpdateTask,
    NotFound,
    SelectTask,
    HistoryTask,
    UpdateScene,
    TaskDetail,
    CesiumViewer,
  },
  async mounted() {
    await this.getSceneDetail();
  },
  watch: {
    $route: async function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        // 场景切换 重置
        this.isShowTaskDetail = false;
        this.resetSceneData();
        this.closeWebsoket();
        await this.getSceneDetail();
      }
    },
  },
  methods: {
    getSceneDetail: async function () {
      const { sceneId } = this.$route.params;
      if (sceneId) {
        const res = await getSceneDetail({ id: sceneId });
        this.selectSceneInfo = res;
        this.sceneId = res?.id;
        this.sceneName = res?.name;
        this.mapId = res?.map?.id;
        this.mapType = res?.map?.type;
        this.wsDeviceDataList = [];
        // mock 数据-----------------------------------------------
        //  pgm
        // const obj = {
        //   0: {
        //     travel: {
        //       location: [
        //         {
        //           omega: 0,
        //           x: 0.226816,
        //           y: 0.344086,
        //           insertScale: 1,
        //         },
        //         {
        //           omega: 80.45759988532613,
        //           x: 0.556425,
        //           y: 0.448541,
        //           insertScale: 1,
        //         },
        //         {
        //           omega: 83.10757687751486,
        //           x: 0.219735,
        //           y: 0.58926,
        //           insertScale: 0.6518999194026193,
        //         },
        //         {
        //           omega: 78.69006752597979,
        //           x: 0.65468,
        //           y: 0.625103,
        //           insertScale: 0.9327180547071353,
        //         },
        //       ],
        //     },
        //   },
        //   1: {
        //     travel: {
        //       location: [
        //         { x: 0.568715, insertScale: 1, y: 0.274962, omega: 0 },
        //         {
        //           x: 0.692737,
        //           insertScale: 1,
        //           y: 0.437788,
        //           omega: 0,
        //         },
        //         { x: 0.530726, insertScale: 1, y: 0.723502, omega: 0 },
        //         { x: 0.779888, insertScale: 1, y: 0.576037, omega: 0 },
        //       ],
        //     },
        //   },
        // };

        // tile
        // const obj = {
        //   0: {
        //     travel: {
        //       location: [
        //         {
        //           x: 120.838452,
        //           y: 30.812429,
        //           omega: 0,
        //         },
        //         {
        //           x: 120.837966,
        //           y: 30.811923,
        //           omega: 0,
        //         },
        //         { x: 120.839407, y: 30.81233, omega: 0 },
        //       ],
        //     },
        //   },
        //   1: {
        //     travel: {
        //       location: [
        //         { omega: 0, x: 120.837591, y: 30.81237 },
        //         {
        //           omega: 0,
        //           x: 120.839619,
        //           y: 30.81249,
        //         },
        //         { omega: 0, x: 120.837183, y: 30.811608 },
        //         { omega: 0, x: 120.836621, y: 30.811949 },
        //       ],
        //     },
        //   },
        // };
        // mock 数据--------------------------------------------------
        this.selectedDeviceList = (res?.devices || [])?.map((i, idx) => {
          const color = RandomColor();
          this.openWebsocket(i, color);
          return { ...i, color: color || "skyblue" };
        });

        this.firstDeviceId = this.selectedDeviceList?.[0]?.id || "";
        this.mapInfo = {
          ...res,
          location: strToObj(res?.map?.location, ["jd", "wd", "gc"]),
          level: strToObj(res?.map?.level, ["min", "max"]),
          zoom: strToObj(res?.map?.zoom, ["min", "max"]),
          rectangle: strToObj(res?.map?.rectangle, [
            "west",
            "east",
            "north",
            "south",
          ]),
        };
        await this.getOnlineTaskList();
      }
    },

    closeWebsoket(taskDeviceList) {
      // 关闭任务详情 下 设备的device-tarvel
      if (!isEmpty(taskDeviceList)) {
        for (let i of taskDeviceList) {
          if (this.ws[i?.sn]) {
            this.ws[i?.sn].close();
            this.ws[i?.sn] = null;
          }
        }
        return;
      }
      // 关闭场景 下 设备的device-tarvel
      if (!isEmpty(this.selectedDeviceList)) {
        for (let i of this.selectedDeviceList) {
          if (this.ws[i?.sn]) {
            this.ws[i?.sn].close();
            this.ws[i?.sn] = null;
          }
        }
      }
      this.wsDeviceDataList = [];
    },

    openWebsocket(deviceObj, color, isCurPage) {
      const curPage = isCurPage ? isCurPage : "sceneDetail";
      const deviceId = deviceObj?.id;
      const sn = deviceObj?.sn;
      let socketUrl = `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/device-travel/${deviceId}`;
      this.ws[deviceObj?.sn] = new WebSocket(socketUrl);
      this.ws[deviceObj?.sn].onopen = () => {
        console.log(
          `---WebSocket连接--${curPage}--device-travel----${deviceId}成功---`
        );
        // this.wsDeviceDataList.push({ sn, ...wsData, color });
        // console.log("wsDeviceDataList", this.wsDeviceDataList);
      };

      this.ws[deviceObj?.sn].onmessage = (msg) => {
        const msgObj = JSON.parse(msg?.data);
        this.wsDeviceDataList.push({ sn, ...msgObj, color });
      };

      this.ws[deviceObj?.sn].onclose = (event) => {
        if (event.wasClean) {
          console.log(
            `[close] Connection closed cleanly, --${curPage}--device-travel----, code=${event.code} reason=${event.reason} deviceId=${deviceId}`
          );
        } else {
          console.log(
            `[close] Connection died, --${curPage}--device-travel----`
          );
        }
      };
      this.ws.onerror = (e) => {
        console.log(`WebSocket连接失败: --${curPage}--device-travel----e.code`);
      };
    },

    getOnlineTaskList: async function (notClearSelect) {
      try {
        this.tableLoading = true;
        if (!notClearSelect) {
          this.clearTableSelection();
        }

        const scenceId = this.selectSceneInfo?.id;
        if (scenceId) {
          const content = await getOnlineTaskList({
            scenceId,
          });
          // 单纯排序
          const resSort = content.sort((a, b) => {
            return b?.createTime - a?.createTime;
          });
          const dataColors = (resSort || []).map((i) => {
            return { ...i, color: RandomColor() || "skyblue" };
          });
          this.onlineTasksList = dataColors;
          if (notClearSelect) {
            this.showTableSelect();
          }
        }
      } catch (error) {
        this.onlineTasksList = [];
        this.tableLoading = false;
        console.log("error", error);
      } finally {
        this.tableLoading = false;
      }
    },
    formatterFun(row, column) {
      const { columnKey } = column;
      switch (columnKey) {
        default:
          return row[columnKey] || "-";
      }
    },
    clearTableSelection() {
      this.$refs.sceneTableRef?.clearSelection();
      this.selectionList = [];
      this.mapInfoPointsData = [];
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.onHavedData([], true, "", "seleted");
      }
    },
    // 场景下 勾选在线任务之后，去其他页面不清空勾选(除新建、编辑页，两者会实际更新在线任务列表数据，默认清空)
    showTableSelect() {
      this.$nextTick(() => {
        this.selectionList.forEach((row) => {
          this.$refs.sceneTableRef?.toggleRowSelection(
            this.onlineTasksList.find((item) => {
              return row.name === item.name;
            }),
            true
          );
        });
      });
      this.mapInfoPointsData = this.selectionList;
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.onHavedData(
          this.selectionList,
          true,
          "",
          "seleted"
        );
      }
    },
    onAction: async function (row, type) {
      let params = { id: row.id };
      switch (type) {
        case "Restore":
          {
            params = { ...params, status: "Restore" };
            await executeTask(params);
            await this.getOnlineTaskList(true);
          }
          break;
        case "suspend":
          {
            params = { ...params, status: "Running" };
            if (row.status === "Running" || row.status === "Restore") {
              params = { ...params, status: "Pause" };
            }
            await executeTask(params);
            await this.getOnlineTaskList(true);
          }
          break;
        case "end":
          this.$confirm("是否确认终止任务：" + row.name + "?", "终止任务", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning",
          }).then(async () => {
            params = { ...params, status: "Cancel" };
            await executeTask(params);
            const deleteSelected = this.selectionList.map((i) => {
              if (i?.id === row.id) {
                return;
              }
              return i;
            });
            this.selectionList = deleteSelected.filter(Boolean);
            console.log("nnn", this.selectionList);
            await this.getOnlineTaskList(true);
            this.$message({
              type: "success",
              message: "终止任务成功!",
            });
          });
          break;
        case "emergencyStop": {
          params = {
            deviceId: row.id,
            method: "EmergencyStop",
            params: {
              action: 1,
            },
            cache: "0",
            response: "0",
            expired: 100,
            streamType: 0,
          };
          const len = row.deviceIds?.length;
          if (len > 0) {
            // 急停任务下所有的设备
            for (let i = 0; i < len; i++) {
              params = { ...params, deviceId: row.deviceIds[i] };
              await emergencyStop(params);
            }
          } else {
            await emergencyStop(params);
          }

          await this.getOnlineTaskList(true);
          break;
        }
        default: {
          // 默认走更新update
          this.$store.commit("updateIsTask", {
            isTask: true,
            curTaskInfo: { ...row, optsType: "update" },
          });
          this.clearTableSelection();
          await this.resetTask();
          await this.onTaskEdit(row);
          break;
        }
      }
    },

    onClickOpts: function (type) {
      switch (type) {
        case "history":
          this.$store.commit("updateIsTaskHistory", true);
          this.getHistroyTaskList();
          break;
        default: // 默认走更新edit
          this.isShowUpdateScene = true;
          break;
      }
    },

    closeUpdateScene: function () {
      this.isShowUpdateScene = false;
      this.getSceneDetail();
    },

    getHistroyTaskList: async function () {
      try {
        this.historyTableLoading = true;
        const content = await getHistoryTaskList({
          scenceId: this.selectSceneInfo?.id,
        });

        this.historyTaskList = content;
      } catch (error) {
        this.historyTaskList = [];
        this.historyTableLoading = false;
        console.log("error", error);
      } finally {
        this.historyTableLoading = false;
      }
    },
    selectChange(selection, row) {
      const taskPoints = selection.length > 0 ? selection : [];
      this.selectionList = taskPoints;
      this.mapInfoPointsData = taskPoints;
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.onHavedData(taskPoints, true, "", "seleted");
      }
    },

    // /设置表格背景颜色
    ACellStyle(row) {
      return `color:  ${row.color || "#ccc"}`;
    },

    headerCellAllClassName({ row, column, rowIndex, columnIndex }) {
      // 保证最后一列
      const len = row.length - 1;
      if (columnIndex === len) {
        return "header_cell_allShow";
      }
    },

    // 任务详情
    onClickTaskInfo: function (row) {
      this.isShowSceneDetail = false;
      // 关闭场景的已选设备
      this.closeWebsoket();
      this.isShowTaskDetail = true;
      this.taskInfoRow = row;
      this.clearTableSelection();
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.onHavedData([row], true);
      }
    },

    onDeleteOnlineTask: function () {
      this.isShowTaskDetail = false;
      this.isShowSceneDetail = true;
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.onHavedData([{}], true);
      }
      this.getOnlineTaskList();
    },

    resetTask: function (obj) {
      const addUpdateTaskRefs = this.$refs.addUpdateTaskRef;
      if (addUpdateTaskRefs) {
        addUpdateTaskRefs.isCollapse = true;
        if (addUpdateTaskRefs.$refs && addUpdateTaskRefs.$refs.taskRef) {
          addUpdateTaskRefs.$refs.taskRef.resetFormData(obj);
        }
      }
    },

    // <- goBack
    taskCondition: function () {
      this.isShowSceneDetail = true;
      this.isShowTaskDetail = false;
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.isShow = true;
        this.$refs.pgmKonvaShowRef.resetPoint();
      }
      this.getOnlineTaskList();
      if (this.$refs?.cesiumViewerRef) {
        this.$refs?.cesiumViewerRef?.clearAreaPoints();
      }

      // 退出任务信息，开启场景下 已选设备device-travel
      for (let i = 0; i < this.selectedDeviceList?.length; i++) {
        this.openWebsocket(
          this.selectedDeviceList[i],
          this.selectedDeviceList[i?.color]
        );
      }
    },

    onTaskEdit: function (taskInfo) {
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.resetPoint();
      }

      const curTaskInfoRow = {
        ...taskInfo,
        location: strToObj(taskInfo?.location, ["jd", "wd", "gc"]),
        level: strToObj(taskInfo?.level, ["min", "max"]),
        zoom: strToObj(taskInfo?.zoom, ["min", "max"]),
        rectangle: strToObj(taskInfo?.rectangle, [
          "west",
          "east",
          "north",
          "south",
        ]),
      };

      this.mapInfoPointsData = [curTaskInfoRow];
    },

    isShowTaskInfo: function (isShowTaskDetail) {
      this.isShowTaskDetail = isShowTaskDetail;
    },

    onUpdateTaskCancel: function () {
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.isShow = true;
      }
      this.clearTableSelection();
      this.taskInfoRow = null;
    },

    updateCurSceneMapObj: function (obj) {
      this.$refs?.cesiumViewerRef?.resetViewer();
      this.$refs?.pgmKonvaShowRef?.resetData();
      this.mapId = obj?.id;
      this.mapType = obj?.type;
      this.mapInfo = {
        ...obj,
        location: strToObj(obj?.location, ["jd", "wd", "gc"]),
        level: strToObj(obj?.level, ["min", "max"]),
        zoom: strToObj(obj?.zoom, ["min", "max"]),
        rectangle: strToObj(obj?.rectangle, ["west", "east", "north", "south"]),
      };
    },

    // 拿到taskInfo 的point 给到pgm展示操作
    getCurTaskInfoPoints: function (points, isShow, method, optsType) {
      // method 任务类型
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.onHavedData(
          points,
          isShow,
          method,
          optsType
        );
      }
      this.pageType = optsType;
      this.method = method;
      if (method === "info") {
        const infoObj = points?.[0];
        this.taskInfoRow = infoObj;
      }
    },

    getCurTaskPoints: function () {
      // 处理接口传参
      if (this.$refs.pgmKonvaShowRef) {
        const { points } = this.$refs.pgmKonvaShowRef;
        const paramsPoint = [];
        for (let item of points.values()) {
          paramsPoint.push(item);
        }
        return paramsPoint;
      }

      if (this.$refs?.cesiumViewerRef) {
        const { points } = this.$refs?.cesiumViewerRef;
        const paramsPoint = [];
        for (let item of points.values()) {
          paramsPoint.push(item);
        }
        return paramsPoint;
      }
    },

    getAreaPoints: function () {
      // 处理接口传参
      if (this.$refs.pgmKonvaShowRef) {
        const { areaPoints } = this.$refs.pgmKonvaShowRef;
        const atrFormData = this.$refs.pgmKonvaShowRef?.getAttributeFormData();
        return { areaPoints, process: atrFormData };
      }
      if (this.$refs.cesiumViewerRef) {
        const { areaPoints } = this.$refs.cesiumViewerRef;
        const atrFormData = this.$refs.cesiumViewerRef.cesiumTooltipFormData;
        return { areaPoints, process: atrFormData?.process };
      }
    },

    // 清空point相关数据
    resetMapData: function (cancel) {
      this.clearTableSelection();
      this.taskInfoRow = null;
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.resetPoint();
        if (cancel) {
          // 取消隐藏tooltip
          this.$refs.pgmKonvaShowRef.isShow = true;
        }
      }
      // 清空瓦片图points
      if (this.$refs.cesiumViewerRef) {
        this.$refs.cesiumViewerRef?.resetViewerData();
        this.$refs?.cesiumViewerRef?.clearAreaPoints();
      }
    },

    // 添加任务
    onClickNavPoint: function (optsType, method) {
      this.pageType = optsType;
      this.method = method;
      this.$refs?.pgmKonvaShowRef?.onHavedData([{}], false);
    },

    onClearBoundaryPoint: function () {
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.resetAreaPointData();
      }
      if (this.$refs.cesiumViewerRef) {
        this.$refs.cesiumViewerRef.clearAreaPoints();
      }
    },
    saveBoundaryPoint: function () {
      if (this.$refs.pgmKonvaShowRef) {
        return this.$refs.pgmKonvaShowRef.saveBoundaryPoint();
      }
      if (this.$refs.cesiumViewerRef) {
        this.$refs.cesiumViewerRef.addPolygonById();
      }
    },

    resetSceneData: function () {
      this.$store.commit("updateIsTaskHistory", false);
      this.mapId = null;
      this.firstDeviceId = "";
      this.$refs?.cesiumViewerRef?.resetViewer();
      this.$refs?.pgmKonvaShowRef?.resetData();
      this.selectSceneInfo = null;
      this.sceneId = "";
      this.sceneName = "";
      this.mapId = "";
      this.mapType = "";
      this.wsDeviceDataList = [];
      this.isShowUpdateScene = false;
      this.selectedDeviceList = [];
      this.firstDeviceId = "";
    },
  },
  beforeDestroy() {
    this.closeWebsoket();
    this.resetSceneData();
  },
};
</script>

<style lang="scss" scoped>
@import "./Index.scss";
</style>
