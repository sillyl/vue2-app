<template>
  <div class="robot_update_scene">
    <div class="robot_title robot_update_scene_header">
      场景编辑
      <i class="el-icon-close" @click="onClosed"></i>
    </div>
    <div class="robot_update_scene_content">
      <UpdateForm ref="updateFormRef" :selectSceneInfo="selectSceneInfo">
        <el-button type="primary" @click="onOk">确定</el-button>
        <el-button @click="onClosed">取消</el-button>
      </UpdateForm>
    </div>
  </div>
</template>

<script>
import UpdateForm from "./UpdateForm.vue";
import { updateScene, getSceneDetail } from "@/api/scene";
export default {
  props: ["closeUpdateScene", "selectSceneInfo"],
  data() {
    return {};
  },
  components: {
    UpdateForm,
  },
  methods: {
    onOk: function () {
      if (this.$refs.updateFormRef) {
        const updateFormRef = this.$refs.updateFormRef;
        const videoUrlsAll = updateFormRef.videoUrlsAll;
        updateFormRef.$refs.form.validate(async (valid) => {
          if (valid) {
            try {
              const { name, mapId, subscribeId } = updateFormRef.form;
              const { id } = this.selectSceneInfo;
              const arr = Object.keys(updateFormRef.form);
              const videoPushs = [];
              arr.forEach((i) => {
                if (i.includes("video")) {
                  videoPushs.push(updateFormRef.form[i]);
                }
              });
              const params = {
                ...this.selectSceneInfo,
                id, // 场景id
                name,
                channels: [],
                videoPushs,
                subscribeId,
                mapId,
              };
              await updateScene(params);
              await getSceneDetail({ id });
              this.onClosed();
            } catch (error) {
              console.log("error", error);
            }
          } else {
            return false;
          }
        });
      }
    },

    onClosed: function () {
      this.closeUpdateScene();
      this.$refs.updateFormRef.resetFormData();
    },
  },
};
</script>

<style lang="scss" scoped>
@import "@/assets/css/common.scss";
$prefixCls: "robot_update_scene";
.#{$prefixCls} {
  position: absolute;
  bottom: 0px;
  height: 40%;
  width: 100%;
  z-index: 2;

  &_header {
    color: #fff;
    border-bottom: 1px solid $grey-color;
    background-color: $header-color;
    .el-icon-close {
      float: right;
      font-size: 20px;
    }
  }
  &_content {
    height: calc(100% - 24px);
    background-color: $header-color;
  }
}
</style>
