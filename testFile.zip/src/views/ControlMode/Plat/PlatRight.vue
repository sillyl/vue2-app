<template>
  <div class="plat_ctrl_mode right">
    <JsonSchema
      :jsonData="jsonData"
      jsonSchemaId="rigth"
      :videoUrls="videoUrls"
      :videoCheckBox="videoCheckBox"
      :videoCheckBoxIndex="videoCheckBoxIndex"
      :basicInfo="basicInfo"
    />
  </div>
</template>

<script>
import JsonSchema from "@/components/JsonSchema/Index.vue";
import { getFθ } from "@/utils/CoordinatePickupFun";
export default {
  props: [
    "jsonData",
    "videoUrls",
    "basicInfo",
    "videoCheckBox",
    "videoCheckBoxIndex",
  ],
  data() {
    return {};
  },
  components: {
    JsonSchema,
  },
  methods: {},
};
</script>
<style lang="scss" scoped>
@import "./Index.scss";
</style>
