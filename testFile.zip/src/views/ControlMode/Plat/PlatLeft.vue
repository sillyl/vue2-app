<template>
  <div class="plat_ctrl_mode left">
    <JsonSchema
      :jsonData="jsonData"
      jsonSchemaId="left"
      :videoUrls="videoUrls"
      :videoCheckBox="videoCheckBox"
      :videoCheckBoxIndex="videoCheckBoxIndex"
      :basicInfo="basicInfo"
    />
  </div>
</template>

<script>
import ButtonOptions from "@/components/ButtonOptions/Index.vue";
import JsonSchema from "@/components/JsonSchema/Index.vue";
import { getFθ } from "@/utils/CoordinatePickupFun";
import { localStorageSetItem } from "@/utils/localStorgaeFun.js";

export default {
  props: [
    "curCheckList",
    "jsonData",
    "videoUrls",
    "basicInfo",
    "videoCheckBox",
    "videoCheckBoxIndex",
  ],
  data() {
    return {};
  },
  components: {
    JsonSchema,
  },
  mounted() {},
  methods: {},
};
</script>
<style lang="scss" scoped>
@import "./Index.scss";
</style>
