<template>
  <div
    v-if="$store.state.curSubscribe.isShow"
    class="robot_subscribe"
    style="height: 40%"
  >
    <div class="robot_title robot_subscribe_header">
      {{ subscribeOpts[$store.state.curSubscribe.optType] }}
      <i class="el-icon-close" @click="onClosed"></i>
    </div>
    <div class="robot_subscribe_content">
      <el-form
        ref="formRef"
        :model="form"
        label-width="100px"
        class="subscribe_form"
      >
        <el-row>
          <el-col :span="7">
            <el-form-item
              label="订阅名称"
              prop="name"
              class="subscribe_form_name"
              required
            >
              <el-input v-model="form.name" :disabled="disabledForm"></el-input>
            </el-form-item>
            <el-form-item label="订阅服务" prop="subscribeServer" required>
              <el-select
                v-model="form.subscribeServer"
                placeholder="请选择"
                :disabled="optType === 'edit' ? true : disabledForm"
              >
                <el-option
                  v-for="item in subscribeList"
                  :key="item.id"
                  :label="item.name"
                  :value="item"
                ></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="插件型号" prop="model" required>
              <el-select
                v-model="form.model"
                placeholder="请选择"
                :disabled="disabledForm"
              >
                <el-option
                  v-for="val in codecList"
                  :key="val.model"
                  :label="val.name"
                  :value="val.model"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="14">
            <div class="subscribe_form_encrypt">
              <el-form-item prop="encrypt" label="加密方式">
                <el-select
                  v-model="form.encrypt"
                  placeholder="--请选择--"
                  :disabled="disabledForm"
                >
                  <el-option
                    v-for="val in encrypt"
                    :key="val.value"
                    :label="val.key"
                    :value="val.value"
                  ></el-option>
                </el-select>
              </el-form-item>
              <el-form-item prop="secret" label="加密秘钥">
                <el-input
                  v-model="form.secret"
                  :disabled="disabledForm"
                ></el-input>
              </el-form-item>
            </div>
            <el-form-item label="订阅参数" prop="args" required>
              <el-input
                :disabled="disabledForm"
                type="textarea"
                :rows="2"
                placeholder="请输入内容"
                v-model="form.args"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="3" class="subscribe_form_col_3">
            <div class="subscribe_form_opts">
              <el-button
                type="primary"
                @click="onEdit"
                v-if="$store.state.curSubscribe.optType === 'info'"
                >编辑</el-button
              >
              <el-button
                type="danger"
                @click="onDelete"
                v-if="$store.state.curSubscribe.optType === 'info'"
                >删除</el-button
              >
              <el-button
                type="primary"
                @click="onOk"
                v-if="$store.state.curSubscribe.optType !== 'info'"
                >确定</el-button
              >
              <el-button
                @click="onClosed"
                v-if="$store.state.curSubscribe.optType !== 'info'"
                >取消</el-button
              >
            </div>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>
<script>
import { subscribeOpts } from "@/constants/index";
import {
  getSubscribeServerList,
  addSubscribe,
  updateSubscribe,
  deleteSubscribe,
} from "@/api/subscribe";
import { getPluginList } from "@/api/plugin";
import { isEqual } from "lodash";
export default {
  props: ["optType", "formData"],
  data() {
    return {
      form: {
        id: "",
        name: "",
        type: "",
        args: "",
        model: "",
        encrypt: "",
        secret: "",
        subscribeServer: null,
      },
      subscribeList: [],
      codecList: [],
      encrypt: [{ key: "AES128", value: "AES/ECB/NoPadding" }],
      disabledForm: false,
      subscribeOpts,
      subscribeInfo: null,
    };
  },
  mounted() {
    if (this.$store.state.curSubscribe.optType !== "add") {
      this.getSubscribeInfo(this.$store.state.curSubscribe?.obj);
    }
    if (this.$store.state.curSubscribe.optType === "info") {
      this.disabledForm = true;
    } else {
      this.disabledForm = false;
    }
    this.getFormListData();
  },
  watch: {
    "$store.state.curSubscribe": function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        if (newVal?.optType !== "add") {
          this.getSubscribeInfo(newVal?.obj);
          if (this.$store.state.curSubscribe.optType === "info") {
            this.disabledForm = true;
          } else {
            this.disabledForm = false;
          }
        } else {
          this.disabledForm = false;
          this.resetFormData();
        }
      }
    },
  },
  methods: {
    getFormListData: async function () {
      this.subscribeList = await getSubscribeServerList();
      this.codecList = await getPluginList({ family: 1 });
    },

    getSubscribeInfo: async function (obj) {
      this.subscribeInfo = obj;
      this.form = {
        ...obj,
        subscribeServer: {
          type: obj?.type,
          subscribeServerId: obj?.subscribeServerId,
        },
      };
    },

    onOk: function () {
      if (this.$refs.formRef) {
        const formRef = this.$refs.formRef;
        formRef.validate(async (valid) => {
          if (valid) {
            const params = {
              ...this.form,
              subscribeServerId: this.form.subscribeServer?.id,
              type: this.form.subscribeServer?.type,
            };
            delete params.subscribeServer;
            if (this.$store.state.curSubscribe.optType === "add") {
              await addSubscribe(params);
            } else {
              await updateSubscribe(params);
            }
            this.onClosed();
          } else {
            return false;
          }
        });
      }
    },

    onEdit: function () {
      this.$store.commit("updateCurSubscribe", {
        isShow: true,
        optType: "edit",
        obj: this.subscribeInfo,
      });
    },
    onClosed: function () {
      this.resetFormData();
      this.$store.commit("updateCurSubscribe", {
        isShow: false,
        optType: "",
      });
    },

    onDelete: async function () {
      this.$confirm(
        "是否确认删除订阅：" + this.subscribeInfo?.name + "?",
        "删除订阅",
        {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        }
      ).then(async () => {
        await deleteSubscribe({ id: this.subscribeInfo?.id });
        this.$message({
          type: "success",
          message: "删除成功!",
        });
      });
    },
    resetFormData: function () {
      this.form = {
        id: "",
        name: "",
        type: "",
        args: "",
        model: "",
        encrypt: "",
        secret: "",
        subscribeServer: "",
      };
    },
  },
};
</script>
<style lang="scss" scoped>
@import "@/assets/css/common.scss";
$prefixCls: "robot_subscribe";
.#{$prefixCls} {
  position: absolute;
  bottom: 0px;
  width: 100%;
  z-index: 3;

  &_header {
    color: #fff;
    background-color: $header-color;
    border-bottom: 1px solid $grey-color;
    .el-icon-close {
      float: right;
      font-size: 20px;
    }
  }
  &_content {
    height: calc(100% - 24px);
    background-color: $header-color;
  }

  .subscribe_form {
    overflow: auto;
    height: calc(100% - 8px);
    padding: 8px 8px 0 8px;
    .el-form-item {
      margin-bottom: 20px;
    }

    &_encrypt {
      display: flex;
    }

    &_opts {
      display: flex;
      flex-direction: column;
      align-items: baseline;
      .el-button {
        margin: 0px 8px 8px 10px;
      }
    }
  }
}
</style>
