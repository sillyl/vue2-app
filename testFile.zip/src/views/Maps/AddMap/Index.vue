<template>
  <div v-if="$store.state.isAddMap" class="robot_add_map">
    <div class="robot_title robot_add_map_header">
      添加地图
      <i class="el-icon-close" @click="onClosed"></i>
    </div>
    <div class="robot_add_map_content">
      <MapForm ref="mapRef">
        <el-button type="primary" @click="onOk">确定</el-button>
        <el-button @click="onClosed">取消</el-button>
      </MapForm>
    </div>
  </div>
</template>
<script>
import MapForm from "../components/MapForm/Index.vue";
import { uploadMap } from "@/api/map";
import { updateObjFormat } from "@/utils/index";
import GlobalLoading from "@/components/Loading/Loading.js";
import { Message } from "element-ui";

export default {
  props: ["getNewMenuMapList"],
  components: {
    MapForm,
  },
  methods: {
    onOk: function () {
      if (this.$refs.mapRef) {
        const mapRef = this.$refs.mapRef;
        mapRef.$refs.form.validate(async (valid) => {
          if (valid) {
            try {
              GlobalLoading.loadingShow({ text: "上传中" });
              const params = updateObjFormat(mapRef.form);
              let formData = new FormData();
              for (let key in params) {
                formData.append(key, params[key]);
              }
              const mapId = await uploadMap(formData);
              // 需要重新拉取menu mapList 否则路由无法定位
              if (this.getNewMenuMapList) {
                await this.getNewMenuMapList();
              }
              this.$router.push(`/map/${mapId}?mapType=${mapRef.form?.type}`);
              this.onClosed();
              Message.success("成功上传地图!");
            } catch (error) {
              GlobalLoading.loadingClose();
            }
          } else {
            GlobalLoading.loadingClose();
            return false;
          }
        });
      }
    },
    onClosed: function () {
      this.$refs.mapRef.resetFormData();
      this.$store.commit("addMap", false);
    },
  },
};
</script>
<style lang="scss" scoped>
@import "@/assets/css/common.scss";
$prefixCls: "robot_add_map";
.#{$prefixCls} {
  position: absolute;
  bottom: 0px;
  height: 40%;
  width: 100%;
  z-index: 2;

  &_header {
    color: #fff;
    background-color: $header-color;
    border-bottom: 1px solid $grey-color;
    .el-icon-close {
      float: right;
      font-size: 20px;
    }
  }
  &_content {
    background-color: $header-color;
    height: calc(100% - 24px);
    .map_form {
      height: calc(100% - 8px);
    }
  }
}
</style>
