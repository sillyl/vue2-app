<template>
  <span>
    <i class="el-icon-setting" @click="onClickSettings"></i>
    <el-dialog
      title="系统设置"
      :visible.sync="dialogVisible"
      width="200"
      :modal-append-to-body="false"
      :close-on-click-modal="false"
    >
      <div class="sys_content">
        <el-alert
          title="点击确定保存系统设置！！！"
          type="warning"
          :closable="false"
        >
        </el-alert>
        <p>场景列表过滤条件</p>
        <el-radio-group v-model="isSceneFilter">
          <el-radio label="online">online</el-radio>
          <el-radio label="offline">offline</el-radio>
        </el-radio-group>
        <p>
          摇杆显示 : <el-switch :value="nippleVal" @change="onChangeNipple" />
        </p>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="onCancel">取 消</el-button>
        <el-button type="primary" @click="onSysOk">确 定</el-button>
      </span>
    </el-dialog>
  </span>
</template>
<script>
import {
  localStorageSetItem,
  localStorageGetItem,
} from "@/utils/localStorgaeFun.js";
import { isEmpty } from "lodash";
export default {
  props: ["filterSceneList"],
  data() {
    return {
      dialogVisible: false,
      isSceneFilter: "online",
      nippleVal: false,
    };
  },
  mounted() {
    this.isSceneFilter = localStorageGetItem("isSceneFilter") || "online";
    this.nippleVal = localStorageGetItem("nippleVal") || false;
  },

  methods: {
    onClickSettings: function () {
      this.dialogVisible = true;
    },
    onCancel: function () {
      this.dialogVisible = false;
      this.isSceneFilter = localStorageGetItem("isSceneFilter") || "online";
      this.nippleVal = localStorageGetItem("nippleVal") || false;
    },
    onSysOk() {
      if (this.filterSceneList) {
        this.filterSceneList();
      }
      localStorageSetItem("isSceneFilter", this.isSceneFilter);
      localStorageSetItem("nippleVal", this.nippleVal);
      this.$store.commit("updateisShowNippleVal", this.nippleVal);
      this.dialogVisible = false;
    },
    onChangeNipple: function (e) {
      this.nippleVal = e;
    },
  },
};
</script>
<style lang="scss" scoped>
.el-icon-setting {
  color: aliceblue;
  margin-right: 20px;
  font-size: 16px;
}
.sys_content {
  p {
    margin: 16px 0 12px 0;
  }

  .el-alert {
    margin-bottom: 8px;
  }
}
::v-deep {
  .el-dialog__body {
    padding: 5px 20px;
  }
}
</style>
