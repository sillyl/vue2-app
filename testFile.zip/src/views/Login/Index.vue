<template>
  <div class="login">
    <div class="login-content">
      <h3>登 录</h3>
      <el-form
        :model="loginForm"
        status-icon
        :rules="rules"
        ref="loginForm"
        label-width="100px"
        class="loginForm"
        label-position="top"
      >
        <el-form-item prop="username" label="账号">
          <el-input v-model="loginForm.username"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input
            type="password"
            v-model="loginForm.password"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onClickLogin('loginForm')"
            >登 录</el-button
          >
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
import { login } from "@/api/login.js";
export default {
  data() {
    const validateName = (rule, value, callback) => {
      if (value.trim() === "") {
        callback(new Error("请输入名称"));
      } else {
        callback();
      }
    };
    const validatePsw = (rule, value, callback) => {
      if (value.trim() === "") {
        callback(new Error("请输入密码"));
      } else {
        callback();
      }
    };
    return {
      loginForm: {
        username: "",
        password: "",
      },
      rules: {
        username: [
          {
            required: true,
            validator: validateName,
            trigger: ["blur", "change"],
          },
        ],
        password: [
          {
            required: true,
            validator: validatePsw,
            trigger: ["blur", "change"],
          },
        ],
      },
    };
  },
  methods: {
    onClickLogin: function (formData) {
      this.$refs[formData].validate(async (valid) => {
        if (valid) {
          const params = {
            username: this.loginForm.username.trim(),
            password: this.loginForm.password.trim(),
          };
          const res = await login(params);
          if (res && !res.code) {
            //正常登录
            this.$router.push("/control-mode");
          }
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
  },
};
</script>
<style lang="scss" scoped>
@import "@/assets/css/common.scss";
.login {
  background: $header-color-rgba;
  // color: #000;
  height: 100%;
  // background-image: url("@/assets/img/login-bg.png");
  background-repeat: no-repeat;
  background-size: 100% 100%;
  .login-content {
    width: 320px;
    background: #fff;
    padding: 16px;
    border-radius: 5px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  }
  h3 {
    text-align: center;
  }
  .el-form-item {
    margin-bottom: 16px;
  }
  .el-form-item:nth-child(3) {
    margin-bottom: 8px;
  }
  .el-button {
    width: 100%;
    margin-top: 10px;
  }
}
</style>
