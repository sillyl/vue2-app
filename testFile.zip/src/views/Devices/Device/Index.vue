<template>
  <el-tabs
    type="border-card"
    v-model="activeName"
    @tab-click="handleClick"
    :stretch="true"
    v-loading="basicInfoLoading"
  >
    <el-tab-pane label="基本信息" name="basicInfo">
      <NotFound v-if="!basicInfo" :desc="desc" />
      <div v-else class="basicInfo_tab">
        <div class="basicInfo_delete">
          <el-button
            type="danger"
            v-if="basicInfoLoading === false"
            @click="onClick('delete')"
          >
            删除设备</el-button
          >
          <el-button type="primary" @click="onClick('restart')"
            >重启设备</el-button
          >
        </div>
        <el-row>
          <el-col :span="12">
            <BasicCard basicTitle="设备信息" v-if="basicInfoLoading === false">
              <ul v-if="basicInfo && Object.keys(basicInfo).length > 0">
                <li v-for="(value, key) in basicInfoObj" :key="key">
                  <span v-if="key !== 'videoUrls'">
                    <span>{{ value }}： </span>
                    <span>{{ basicInfo[key] || "-" }}</span>
                  </span>
                  <span v-if="key === 'videoUrls'">
                    <span>{{ value }}： </span>
                    <span v-if="!basicInfo[key] || basicInfo[key].length === 0">
                      -
                    </span>
                    <span v-else class="basicInfo_videoUrls">
                      <br />
                      <span
                        v-for="(item, index) in basicInfo[key]"
                        :key="item"
                        class="basicInfo_videoUrls_span"
                      >
                        <span
                          >地址{{ index + 1 }}
                          <IconCopy :copyData="item" /> ：</span
                        >
                        <span class="text_mutil_overflow_custum_len">{{
                          item
                        }}</span>
                      </span>
                    </span>
                  </span>
                </li>
              </ul>
            </BasicCard></el-col
          >
          <el-col :span="12">
            <BasicCard basicTitle="设备配置" v-if="basicInfoLoading === false">
              <div class="device_config">
                <ul>
                  <li>
                    <span>地图列表： </span>
                    <el-select
                      v-model="mapVal"
                      placeholder="请选择地图"
                      :loading="mapLoading"
                      @visible-change="visibleChange"
                    >
                      <el-option-group
                        v-for="group in mapOptions"
                        :key="group.label"
                        :label="group.label"
                      >
                        <el-option
                          v-for="item in group.options"
                          :key="item.value"
                          :label="item.label"
                          :value="item"
                        />
                      </el-option-group>
                    </el-select>
                    <el-button
                      type="primary"
                      @click="onClick('enable')"
                      :disabled="!mapVal"
                      >启用地图
                    </el-button>
                    <el-button
                      type="primary"
                      @click="onClick('suspend')"
                      :disabled="!mapVal || mapVal?.type === 'tileMapItem'"
                    >
                      关闭地图
                    </el-button>
                  </li>
                  <li>
                    <span>设备升级： </span>
                    <el-select v-model="version" placeholder="请选择">
                      <el-option
                        v-for="item in versionList"
                        :key="item.id"
                        :label="item.name"
                        :value="item.id"
                      >
                      </el-option>
                    </el-select>
                    <el-button type="primary" @click="onClick('onlineUp')">
                      在线升级
                    </el-button>
                  </li>
                  <li>
                    <span>建图操作： </span>
                    <el-button
                      type="primary"
                      :disabled="buildMapping"
                      @click="onClick('buildMap')"
                      >开启建图</el-button
                    >
                    <el-button
                      type="primary"
                      @click="onClick('endBuildMap')"
                      :disabled="!buildMapping"
                      >完成建图</el-button
                    >
                    <el-button
                      type="primary"
                      @click="onClick('cancelBuildMap')"
                      :disabled="!buildMapping"
                      >取消建图</el-button
                    >
                  </li>
                </ul>
              </div>
              <RosNode :deviceId="deviceId" />
            </BasicCard>
          </el-col>
        </el-row>
      </div>
    </el-tab-pane>
    <el-tab-pane name="situational">
      <div slot="label">
        情景控制
        <span @click.stop class="situational_switch">
          <el-switch :value="optsMode" @change="onChangeMode" />
        </span>
      </div>
      <NotFound v-if="!basicInfo && basicInfoLoading === false" :desc="desc" />
      <!-- videoDeviceIds.length > 0 && -->
      <div
        v-if="activeName === 'situational'"
        id="situational_content"
        :class="[
          'situational_content',
          optsMode === false && basicInfo
            ? 'situational_content_manual'
            : 'situational_content_auto',
        ]"
      >
        <NotFound
          v-if="!curMapId && buildMapping !== true"
          desc="暂无地图信息"
          :image="require('@/assets/img/empty.svg')"
        />
        <div
          class="scence_CesiumViewer"
          v-if="curMapType === 2 && !buildMapping"
          :style="{ height: optsMode === true ? 'calc(100% - 22px)' : '100%' }"
        >
          <CesiumViewer
            :mapId="curMapId"
            :mapInfo="mapInfo"
            ref="cesiumViewerRef"
            :pageType="pageType"
            :method="method"
            :wsData="wsData"
            :isMapCorrection="isMapCorrection"
            :onSaveMapCorrection="onSaveMapCorrection"
          />
        </div>
        <PgmKonva
          ref="pgmKonvaShowRef"
          :mapId="curMapId"
          v-if="curMapType === 0 || buildMapping === true"
          :wsData="wsData"
          :isInitPickUp="isInitPickUp"
          :onSaveInitPickup="onSaveInitPickup"
          :buildMapping="buildMapping"
          :deviceId="deviceId"
        />
        <CustomCollapse v-if="optsMode === true">
          <el-row>
            <el-col :span="6" class="device_scene_col">
              <p>当前场景：{{ basicInfo?.scence?.name || "-" }}</p>
              <p>当前任务：{{ basicInfo?.task?.name || "-" }}</p>
              <p>任务状态：{{ basicInfo?.task?.status || "-" }}</p>
            </el-col>
            <el-col :span="4" class="device_scene_col">
              <p>开启视频</p>
              <el-checkbox-group
                v-model="checkList"
                @change="onChangeVideoCheckBox"
                :max="3"
                v-if="videoUrls?.length > 0"
              >
                <el-checkbox
                  v-for="(item, idx) in videoUrls"
                  :key="idx"
                  :label="'video' + basicInfo.id + '-' + idx"
                  :title="
                    basicInfo.sn +
                    '(' +
                    basicInfo.name +
                    ')' +
                    '-视频' +
                    (idx + 1)
                  "
                  >{{
                    basicInfo.sn +
                    "(" +
                    basicInfo.name +
                    ")" +
                    "-视频" +
                    (idx + 1)
                  }}</el-checkbox
                >
              </el-checkbox-group>
            </el-col>
            <el-col :span="10" class="device_scene_col device_scene_col_opts">
              <p v-if="mapInfo?.type === 2">
                <span>
                  <span>地图纠偏</span>
                  <el-button
                    type="primary"
                    @click="onMapCorrection()"
                    :disabled="!curMapId"
                  >
                    拾取
                  </el-button>
                </span>
              </p>
              <p v-if="mapInfo?.type === 0">
                <span class="init_location">
                  <span>初始位置设置</span>
                  <el-button
                    type="primary"
                    @click="onInitPickup()"
                    :disabled="!curMapId"
                  >
                    拾取
                  </el-button>
                </span>
              </p>
              <p>
                <span>
                  <span>任务控制</span>
                  <a
                    target="_self"
                    rel="noopener noreferrer"
                    @click="onClickTaskInfo"
                    :disabled="!basicInfo?.curTaskId"
                    :class="[
                      (!basicInfo?.curTaskId || !basicInfo?.curScenceId) &&
                        'a_disabled',
                    ]"
                  >
                    进入任务
                  </a>
                  <el-button
                    :disabled="
                      !basicInfo?.curTaskId ||
                      !(
                        basicInfo?.task?.status === 'Create' ||
                        basicInfo?.task?.status === 'Running' ||
                        basicInfo?.task?.status === 'Pause'
                      )
                    "
                    type="primary"
                    @click="onTaskClick('startTask')"
                  >
                    {{
                      basicInfo?.task?.status === "Running"
                        ? "暂停任务"
                        : "启用任务"
                    }}
                  </el-button>
                  <el-button
                    :disabled="
                      !basicInfo?.curTaskId ||
                      !(
                        basicInfo?.task?.status === 'Running' ||
                        basicInfo?.task?.status === 'Pause'
                      )
                    "
                    @click="onTaskClick('stopTask')"
                    >终止任务</el-button
                  >
                </span>
              </p>
              <p>
                <span>
                  <span>场景控制</span>
                  <a
                    target="_self"
                    rel="noopener noreferrer"
                    @click="onClickSceneInfo"
                    :class="[!basicInfo?.curScenceId && 'a_disabled']"
                  >
                    进入场景
                  </a>
                  <SelectTask ref="selectTaskRef" />
                  <!-- <el-button type="primary">进入场景</el-button> -->
                </span>
              </p>
              <SelectTaskBehavior ref="selectTaskBehaviorRef" />
            </el-col>
            <el-col :span="3" class="device_scene_col_stopBtn">
              <StopButton
                :data="basicInfo"
                :getDeviceBasicInfo="getDeviceBasicInfo"
                v-if="basicInfo?.deviceStatus || basicInfo?.deviceStatus === 0"
              />
            </el-col>
          </el-row>
        </CustomCollapse>
        <AddUpdateTask
          :selectSceneInfo="selectSceneInfo"
          :getDeviceBasicInfo="getDeviceBasicInfo"
          :deviceCurScenceId="basicInfo?.curScenceId"
          :updateCurSceneMapObj="updateCurSceneMapObj"
          :resetMapData="resetMapData"
          :onClickNavPoint="onClickNavPoint"
          :getCurTaskInfoPoints="getCurTaskInfoPoints"
          :onClearBoundaryPoint="onClearBoundaryPoint"
          :saveBoundaryPoint="saveBoundaryPoint"
          :getCurTaskPoints="getCurTaskPoints"
          :getAreaPoints="getAreaPoints"
          :buildMapping="buildMapping"
          :clickCurNavPoint="clickCurNavPoint"
          :onClickCurBdyPoints="onClickCurBdyPoints"
          isCurPage="deviceDetail"
        />
        <div
          class="control_mode_video_list"
          v-if="checkList?.length > 0 && optsMode === true"
        >
          <div v-for="(item, idx) in checkList" :key="item + idx">
            <WfsVideo
              :videoCheckBox="videoCheckBox"
              :videoCheckBoxIndex="videoCheckBoxIndex"
              :id="item"
              @closedVideoId="getClosedVideoId"
              :curTop="checkList.indexOf(item) * 202 + 'px'"
              parentId="situational_content"
              :getCurBehaviorData="getCurBehaviorData"
            />
          </div>
        </div>
      </div>
      <DragVideo
        v-if="activeName === 'situational' && optsMode === false && basicInfo"
        :checkList="checkList"
        :videoCheckBox="videoCheckBox"
        :videoCheckBoxIndex="videoCheckBoxIndex"
        :dragDataList="dragDataList"
        :deviceId="deviceId"
        :basicInfo="basicInfo"
        :videoUrls="videoUrls"
      />
    </el-tab-pane>
    <el-tab-pane label="在线诊断" name="onlineDiagnosis">
      <NotFound v-if="!basicInfo" :desc="desc" />
      <div
        v-else-if="
          activeName === 'onlineDiagnosis' && basicInfoLoading === false
        "
        class="device_onlineDiagnosis"
      >
        <el-row>
          <el-col :span="12">
            <BasicCard basicTitle="节点诊断" v-if="basicInfoLoading === false">
              <el-table
                :data="onlineDiagnosisList"
                style="width: 100%"
                height="100%"
                :cell-style="cellStyle"
                :header-cell-style="cellHeaderStyle"
                size="small"
              >
                <el-table-column
                  prop="name"
                  label="名称"
                  width="180"
                  column-key="name"
                  :formatter="formatterFun"
                />
                <el-table-column
                  prop="status"
                  label="状态"
                  column-key="status"
                  :formatter="formatterFun"
                />
                <el-table-column fixed="right" label="操作" width="100">
                  <template slot-scope="scope">
                    <el-button
                      @click="onOnlineDiagnosisClick(scope.row)"
                      type="text"
                      size="small"
                      >重启</el-button
                    >
                  </template>
                </el-table-column>
              </el-table>
            </BasicCard>
          </el-col>
          <el-col :span="12">
            <BasicCard basicTitle="载荷诊断" v-if="basicInfoLoading === false">
              <TreeTable :data="loadDiagnosisList">
                <template v-slot:actionNode="configProps">
                  <span v-for="i in configProps.config.action" :key="i.val">
                    <span class="action-i" @click="onAction(configProps, i)">
                      {{ i.val }}
                    </span>
                  </span>
                </template>
              </TreeTable>
            </BasicCard>
          </el-col>
        </el-row>
      </div>
    </el-tab-pane>
    <el-tab-pane label="指令控制" name="command">
      <NotFound v-if="!basicInfo" :desc="desc" />
      <CmdCtrl
        :cmdData="cmdData"
        v-else-if="activeName === 'command' && basicInfoLoading === false"
        ref="cmdCtlRef"
        :onSearch="getCmdListData"
      />
    </el-tab-pane>
    <el-tab-pane label="事件告警" name="alert">
      <NotFound v-if="!basicInfo" :desc="desc" />
      <Alert
        :alertData="alertData"
        v-else-if="activeName === 'alert' && basicInfoLoading === false"
        ref="alertRef"
        :onSearch="getAlertListData"
      />
    </el-tab-pane>
    <el-tab-pane label="控制终端" name="shell">
      <NotFound v-if="!basicInfo" :desc="desc" />
      <Terminal
        v-else-if="activeName === 'shell' && basicInfoLoading === false"
        :socketURI="socketURI"
      />
    </el-tab-pane>
  </el-tabs>
</template>
<script>
import BasicCard from "../components/BasicCard/Index.vue";
import IconCopy from "@/components/IconCopy/Index.vue";
// import PgmKonva from "../components/PgmKonva/Index.vue";
import PgmKonva from "@/views/Scenes/components/PgmKonvaScene/Index.vue";
import NotFound from "@/components/NotFound/Index.vue";
import CustomCollapse from "@/components/CustomCollapse/Index.vue";
import SelectTask from "@/views/Task/components/SelectTask/Index.vue";
import StopButton from "@/components/StopButton/Index.vue";
import TreeTable from "@/components/TreeTable/Index.vue";
import CmdCtrl from "../CmdCtrl/Index.vue";
import Alert from "../Alert/Index.vue";
import Terminal from "@/components/Terminal/Index.vue";
import AddUpdateTask from "@/views/Task/AddUpdateTask/Index.vue";
import SplitScreen from "@/components/SplitScreen/Index.vue";
import WfsVideo from "@/components/VideoPlay/WfsVideo/Index.vue";
import DragVideo from "../components/DragVideo/Index.vue";
import CesiumViewer from "@/components/CesiumViewer/Index.vue";
import RosNode from "../RosNode/Index.vue";
import SelectTaskBehavior from "@/components/SelectTaskBehavior/Index.vue";
import { getDeviceDetail, getAlertList } from "@/api/device";
import { getSceneInfo } from "@/api/scene";
import { getProductInfo } from "@/api/product";
import { getBuiltInMapList, getMapMenuList, mapRectify } from "@/api/map";
import { getCmdList, emergencyStop } from "@/api/cmd";
import { executeTask, addTask } from "@/api/task";
import { restartNode } from "@/api/node";
import {
  localStorageGetItem,
  localStorageSetItem,
} from "@/utils/localStorgaeFun.js";
import {
  deleteDevice,
  enableMap,
  bindMap,
  onlineUpgrade,
  rebootDevice,
} from "@/api/device";
import {
  basicInfoObj,
  deviceStatus,
  onlineNodeStatus,
} from "../constants/index";
import { isEqual, isEmpty } from "lodash";
import dayjs from "dayjs";
import { strToObj } from "@/utils/index";

export default {
  data() {
    return {
      activeName: "situational",
      basicInfo: null,
      basicInfoObj: basicInfoObj,
      basicInfoLoading: true,
      mapLoading: false,
      versionList: [],
      version: "", // 设备升级
      deviceStatus: deviceStatus,
      curStatus: true, // 设备操作当前状态
      desc: "设备不存在或已被删除！！！",
      checkList: [],
      videoCheckBox: {},
      scenceId: "",
      onlineDiagnosisList: [],
      loadDiagnosisList: [],
      configProps: {},
      cmdData: null,
      alertData: null,
      socketURI: "ws://localhost:8090/cpix/v1.0/websocket/device-travel/4",
      optsMode: true, // 默认自动auto
      videoDeviceIds: [],
      curMapId: "",
      curMapType: null,
      videoCheckBoxIndex: {},
      videoUrls: [],
      dragDataList: [],
      mapInfo: null,
      method: "",
      pageType: "",
      selectSceneInfo: null,
      deviceId: "",
      wsDeviceTravelUrl: `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/device-travel/`,
      ws: null,
      wsData: null,
      isInitPickUp: false,
      isMapCorrection: false,
      pickCmdParams: {
        deviceId: "",
        method: "",
        params: {
          id: "",
          x: 0.0,
          y: 0.0,
          omega: 0.0,
        },
        cache: "0",
        response: "0",
        expired: 100,
        streamType: 0,
      },
      addBuildMapTaskId: null, // 开启建图 接口返回id
      onlineDiagnosisWs: null, // 在线诊断websoket 实例
      onlineNodeStatus,
      buildMapping: false, // true：建图中
      taskEventWs: null,
      curPoint: null, // 当前位置点
      mapVal: "",
      mapOptions: [],
    };
  },
  components: {
    BasicCard,
    IconCopy,
    NotFound,
    PgmKonva,
    CustomCollapse,
    SelectTask,
    StopButton,
    TreeTable,
    CmdCtrl,
    Alert,
    Terminal,
    AddUpdateTask,
    // SplitScreen,
    WfsVideo,
    DragVideo,
    CesiumViewer,
    RosNode,
    SelectTaskBehavior,
  },
  watch: {
    $route: async function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.resetDeviceDetailData();
        await this.getDeviceData(this.activeName);
        this.closeDeviceTravelWs();
        await this.closeTaskEventWebsoket();
        await this.openDeviceTravelWs();
        await this.openTaskEventWebsoket();
      }
    },
  },
  async mounted() {
    await this.getDeviceData(this.activeName);
    await this.openDeviceTravelWs();
    await this.openTaskEventWebsoket();
  },
  methods: {
    openDeviceTravelWs() {
      // const { id } = this.$route.params;
      if (this.deviceId) {
        let socketUrl = this.wsDeviceTravelUrl + this.deviceId;
        this.ws = new WebSocket(socketUrl);
        this.ws.onopen = () => {
          console.log(`---WebSocket----device-travel----连接成功---`);
        };

        this.ws.onmessage = (msg) => {
          const obj = JSON.parse(msg?.data);
          // this.wsData = [];
          this.wsData = obj ? [obj] : [];
          console.log("oooooo", obj, this.wsData);
          const location = obj?.travel?.location;
          const len = location?.length;
          this.curPoint = len > 0 ? location?.[len - 1] : null;
        };

        this.ws.onclose = (event) => {
          if (event.wasClean) {
            console.log(
              `[close] Connection closed cleanly,----device-travel----, code=${event.code} reason=${event.reason}`
            );
          } else {
            console.log("[close] Connection died, ----device-travel----");
          }
        };
        this.ws.onerror = (e) => {
          console.log(
            `WebSocket-----device-travel----连接失败: ${e.code ? e.code : ""}`
          );
        };
      }
    },
    closeDeviceTravelWs: function () {
      if (this.ws) {
        this.ws?.close();
        this.ws = null;
        this.wsData = [];
        this.curPoint = null;
      }
    },

    clickCurNavPoint: function () {
      if (isEmpty(this.curPoint)) {
        this.$message({
          type: "warning",
          message: "当前导航点为空！",
        });
        return;
      } else {
        if (this.curMapType === 0) {
          this.$refs?.pgmKonvaShowRef?.saveCurPoint(this.curPoint);
        }
        if (this.curMapType === 2) {
          const selectPoint = {
            location: { ...this.curPoint },
            process: [],
            station: [],
          };
          this.$refs?.cesiumViewerRef?.saveCurPoint(selectPoint, this.curPoint);
        }
      }
    },

    onClickCurBdyPoints: function () {
      if (isEmpty(this.curPoint)) {
        this.$message({
          type: "warning",
          message: "当前位置点为空！",
        });
        return;
      } else {
        // 保存当前边界点
        if (this.curMapType === 0) {
          this.$refs?.pgmKonvaShowRef?.saveCurBoundaryPoint(this.curPoint);
        }
        if (this.curMapType === 2) {
          const { x, y } = this.curPoint;
          const L = x.toFixed(6);
          const La = y.toFixed(6);
          const id = `circle_${L}_${La}`;
          this.$refs?.cesiumViewerRef?.addEntityCircleById(
            id,
            L,
            La,
            null,
            false
          );
        }
      }
    },

    handleClick(tab, event) {
      this.activeName = tab.paneName;
      this.getDeviceData(tab.paneName);
    },

    // 将后端给的数据 处理成渲染所需数据结构
    replaceData: function (data) {
      let arr = [];
      for (let i = 0; i < data?.length; i++) {
        const el = data[i];
        arr.push({
          labels: {
            name: el?.name,
            status: onlineNodeStatus[el?.status],
            action:
              el.value?.length > 0
                ? []
                : [
                    {
                      val: "重启",
                    },
                  ],
          },
          children: this.replaceData(el.value),
        });
      }

      return arr;
    },
    getDeviceData: async function (paneName) {
      await this.getDeviceBasicInfo(); // 用此接口判断设备信息是否存在
      this.closeOnlineWebsocket();
      switch (paneName) {
        case "basicInfo":
          await this.getMapList();
          break;
        case "situational": {
          // 会获取到所有开启的视频 不限于此设备
          const allCheckList = localStorageGetItem("videoCheckList");
          if (allCheckList?.length > 0) {
            this.checkList = allCheckList?.filter((i) => {
              // 获得当前设备下已选择的视频
              const idx = i?.indexOf("-") || 6; // 取得-索引避免设备号是一位以上的值
              return i.slice(5, idx) === this.basicInfo?.id;
            });
            if (this.optsMode === false) {
              const res = [...this.checkList];
              this.dragDataList = (res || []).map((i) => {
                return {
                  id: i,
                  name: this.videoCheckBox[i],
                };
              });
            }
          }
          break;
        }
        case "onlineDiagnosis": {
          this.openOnlineWebsocket();
          // /* --------------mock------------------ */
          // this.onlineDiagnosisList = [
          //   {
          //     //节点信息
          //     name: "name1", //节点名称
          //     type: "0", //节点类型0-软件节点
          //     status: "0", //0-ok 1-不ok
          //   },
          // ];
          // const res = [
          //   {
          //     name: "rrr", //节点名称
          //     type: "1", //节点类型1-硬件节点
          //     value: [
          //       {
          //         //该节点包含的硬件信息
          //         name: "yy1111yy", //硬件名称
          //         status: "0", //硬件状态0-ok 1-不ok
          //       },
          //       {
          //         //该节点包含的硬件信息
          //         name: "yyyy", //硬件名称
          //         status: "1", //硬件状态0-ok 1-不ok
          //       },
          //     ],
          //   },
          //   {
          //     name: "tttttttt", //节点名称
          //     type: "1", //节点类型1-硬件节点
          //     value: [
          //       {
          //         //该节点包含的硬件信息
          //         name: "fffyyyy", //硬件名称
          //         status: "1", //硬件状态0-ok 1-不ok
          //       },
          //     ],
          //   },
          // ];
          // const childRes = this.replaceData(res);
          // this.loadDiagnosisList = [
          //   {
          //     labels: {
          //       name: "名称",
          //       status: "状态",
          //       action: [
          //         {
          //           val: "操作",
          //         },
          //       ],
          //     },
          //     children: childRes,
          //   },
          // ];
          break;
        }
        case "command": {
          this.getCmdListData();
          break;
        }
        case "alert":
          this.getAlertListData();
          break;
        case "shell":
          console.log("shell");
          break;
        default:
          break;
      }
    },

    openOnlineWebsocket() {
      const socketUrl = `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/device-status/${this.deviceId}`;
      this.onlineDiagnosisWs = new WebSocket(socketUrl);
      this.onlineDiagnosisWs.onopen = () => {
        console.log(`---WebSocket连接${socketUrl}成功---`);
      };
      this.onlineDiagnosisWs.onmessage = async (msg) => {
        const msgObj = JSON.parse(msg?.data);
        this.onlineDiagnosisList = msgObj?.event?.swnode;
        const hwnode = msgObj?.event?.hwnode;
        const childRes = await this.replaceData(hwnode);
        this.loadDiagnosisList = [
          {
            labels: {
              name: "名称",
              status: "状态",
              action: [
                {
                  val: "操作",
                },
              ],
            },
            children: childRes,
          },
        ];
      };
      this.onlineDiagnosisWs.onclose = (event) => {
        if (event.wasClean) {
          console.log(
            `[close] Connection closed cleanly, code=${event.code} reason=${event.reason}`
          );
        } else {
          console.log("[close] Connection died");
        }
      };
      this.onlineDiagnosisWs.onerror = (e) => {
        console.log("WebSocket连接失败: " + socketUrl + "code:" + e.code);
      };
    },

    closeOnlineWebsocket: function () {
      if (this.onlineDiagnosisWs) {
        this.onlineDiagnosisWs.close();
        this.onlineDiagnosisWs = null;
      }
    },

    formatterFun(row, column) {
      const { columnKey } = column;
      switch (columnKey) {
        case "status":
          return onlineNodeStatus[row[columnKey]];
        default:
          return row[columnKey] || "-";
      }
    },

    cellStyle: function () {
      return "background-color: #2e4552; color: #000";
    },

    cellHeaderStyle: function () {
      return "background-color: #2e4552; color: #000; padding: 5px 0";
    },

    onAction: async function (configProps, item) {
      const { rowData } = configProps.config;
      const { labels } = rowData;
      await restartNode({
        id: this.basicInfo?.id,
        name: labels.name,
      });
    },

    // 瓦片图 地图纠偏
    onMapCorrection: function () {
      this.isMapCorrection = true;
    },

    onSaveMapCorrection: async function (data) {
      // 确定
      const params = {
        ...data,
        id: this.curMapId || this.basicInfo?.map?.id,
      };
      try {
        await mapRectify(params);
        this.$message({
          message: `纠偏位置 x : ${data?.x}, y : ${data?.y} 已完成`,
          type: "success",
        });
      } catch (error) {
        throw error;
      } finally {
        this.isMapCorrection = false;
      }
    },

    // pgm 初始位置 拾取
    onInitPickup: function () {
      this.isInitPickUp = true;
    },

    onSaveInitPickup: async function (data) {
      const params = {
        ...this.pickCmdParams,
        deviceId: this.basicInfo?.id,
        method: "InitialPose",
        params: {
          id: this.curMapId || this.basicInfo?.map?.id,
          ...data,
        },
      };
      // 确定
      try {
        await emergencyStop(params);
        this.$message({
          message: `初始位置 x : ${data?.x}, y : ${data?.y}, 角度 : ${data?.omega} 已设置`,
          type: "success",
        });
      } catch (error) {
        throw error;
      } finally {
        this.isInitPickUp = false;
      }
    },

    getDeviceBasicInfo: async function (isNotUpdateMapInfo) {
      const curIsControlMode = this.$store.state.isControlMode;
      // 切换设备 视频显示问题
      this.$store.commit("updateIsControlMode", false);
      try {
        if (!isNotUpdateMapInfo) {
          this.basicInfoLoading = true;
        }
        const res = await getDeviceDetail(this.$route.params);
        this.basicInfoLoading = false;
        this.deviceId = res?.id;
        if (!isNotUpdateMapInfo) {
          this.curMapId = res?.map?.id;
          this.curMapType = res?.map?.type;
          this.mapInfo = {
            ...res?.map,
            location: strToObj(res?.map?.location, ["jd", "wd", "gc"]),
            level: strToObj(res?.map?.level, ["min", "max"]),
            zoom: strToObj(res?.map?.zoom, ["min", "max"]),
            rectangle: strToObj(res?.map?.rectangle, [
              "west",
              "east",
              "north",
              "south",
            ]),
          };
        }

        this.selectSceneInfo = res?.scence;
        this.videoUrls = res?.videoUrls || [];
        this.basicInfo = res;
        this.buildMapping = res?.buildMapping;

        for (let i = 0; i < res?.videoUrls?.length; i++) {
          // const key = res?.videoUrls[i];
          this.videoCheckBoxIndex[`video${res.id}-${i}`] = i;
          this.videoCheckBox[`video${res.id}-${i}`] =
            res?.sn + "(" + res?.name + ")" + "-视频" + (i + 1);
        }

        const curDeviceInfo = {
          videoCheckBoxIndex: this.videoCheckBoxIndex,
          videoCheckBox: this.videoCheckBox,
          videoUrls: this.videoUrls,
          basicInfo:
            this.basicInfo || this.$store.state.curDeviceInfo?.basicInfo,
        };

        const curDeviceId = this.basicInfo?.id || this.$route.params?.id;

        // 当前设备信息 存储在本地，存store 为辅助界面监听数据变化
        localStorageSetItem("curDeviceInfo", curDeviceInfo);
        this.$store.commit("saveCurDeviceInfo", curDeviceInfo);
        localStorageSetItem("curDeviceId", curDeviceId);
        this.$store.commit("updateCurDeviceId", curDeviceId);
        res["createTime"] = res.createTime
          ? dayjs(res.createTime).format("YYYY-MM-DD HH:mm:ss")
          : "-";
        this.basicInfo = {
          ...res,
          productName: res?.product?.name,
          curSceneName: res?.scence?.name,
          curTaskName: res?.task?.name,
          curMapName: res?.map?.name,
        };
        // 切换设备用于保证 用户切换设备之前isControlMode的状态
        this.$store.commit("updateIsControlMode", curIsControlMode);
      } catch (error) {
        this.basicInfoLoading = false;
      } finally {
        this.basicInfoLoading = false;
      }
    },

    getMapList: async function () {
      try {
        if (this.basicInfo?.id) {
          const res = await getBuiltInMapList({ id: this.basicInfo?.id });
          const res1 = await getMapMenuList();
          // const versionList = await versionList接口
          const tileMapList = res1?.filter((i) => i?.type === 2);
          // 处理成select 组，并且适合后端传参的结构结构：
          const arr = [];
          if (res?.length > 0) {
            arr.push({
              label: "内置地图",
              options: res.map((i) => {
                return {
                  type: "mapItem",
                  label: i?.name,
                  value: i?.name,
                };
              }),
            });
          }
          if (tileMapList?.length > 0) {
            arr.push({
              label: "瓦片地图",
              options: tileMapList.map((i) => {
                return {
                  ...i,
                  type: "tileMapItem",
                  label: i?.name,
                  value: i?.id,
                };
              }),
            });
          }
          this.mapOptions = arr;
          this.versionList = res.content;
        }
      } catch (error) {
        this.mapOptions = [];
        this.versionList = [];
      }
    },

    onClick: async function (type) {
      const { id } = this.$route.params;
      const deviceId = id || this.basicInfo?.id;
      let params = {};
      switch (type) {
        case "enable": // 启用地图
          params = {
            deviceId: id,
            cache: "0",
            response: "0",
            expired: 100,
            streamType: 0,
            method: "EnableMap",
          };
          if (this.mapVal?.type === "mapItem") {
            params = {
              ...params,
              params: {
                mapName: this.mapVal?.value,
              },
            };
          }
          if (this.mapVal?.type === "tileMapItem") {
            params = {
              ...params,
              params: {
                mapId: this.mapVal?.value,
              },
            };
          }
          await enableMap(params);
          break;
        case "suspend": //  关闭地图
          params = {
            deviceId: id,
            params: {},
            cache: "0",
            response: "0",
            expired: 100,
            streamType: 0,
            method: "EnableMap",
          };
          await enableMap(params);
          break;
        // case "bind": // 绑定地图
        //   await bindMap(params);
        //   break;
        case "onlineUp": // 在线升级
          this.$message({
            type: "warning",
            message: "功能暂不支持，敬请期待！",
          });
          // params = { deviceId };
          // await onlineUpgrade(params);
          break;
        case "buildMap": {
          if (this.basicInfo?.curTaskId) {
            this.$message({
              type: "warning",
              message: `当前设备下存在当前任务: ${this.basicInfo?.task.name}!`,
            });
            return;
          }
          const defaultScenceItem = localStorageGetItem("defaultScenceItem");
          params = {
            name:
              "建图任务" + dayjs(new Date().getTime()).format("YYYYMMDDHHmmss"),
            method: "TASK_MAPPING",
            params: {
              mapConflation: "complete", // 完成时合并
              mapName:
                "map" + dayjs(new Date().getTime()).format("YYYYMMDDHHmmss"),
              mappingType: 0,
            },
            scenceId: "", // 后端不需要该参数
            deviceIds: [this.basicInfo?.id],
          };
          try {
            const taskId = await addTask(params);
            this.addBuildMapTaskId = taskId;

            // 开启建图 跳转到情景控制
            this.activeName = "situational";
            this.optsMode = false;

            // await this.getDeviceBasicInfo(true);
          } catch (error) {
            throw error;
          }

          // if (taskId && this.basicInfo?.curScenceId) {
          //   this.$router.push(
          //     `/scene/${this.basicInfo?.curScenceId}?taskId=${this.basicInfo?.curTaskId}`
          //   );
          // }
          break;
        }
        case "endBuildMap": {
          params = {
            id: this.addBuildMapTaskId || `mapping-${this.deviceId}`,
            status: "Complete",
          };
          try {
            await executeTask(params);
            this.getDeviceBasicInfo(true);
          } catch (error) {
            throw error;
          }
          break;
        }
        case "cancelBuildMap": {
          params = {
            id: this.addBuildMapTaskId || `mapping-${this.deviceId}`,
            status: "Cancel",
          };
          this.$confirm(
            "是否确认取消建图：" +
              (this.addBuildMapTaskId || `mapping-${this.deviceId}`) +
              "?",
            "取消建图",
            {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              type: "warning",
            }
          ).then(async () => {
            try {
              await executeTask(params);
              await this.getDeviceBasicInfo(true);
              this.$message({
                type: "success",
                message: "取消成功!",
              });
            } catch (error) {
              throw error;
            }
          });

          break;
        }
        case "restart": // 重启设备
          this.$message({
            type: "warning",
            message: "功能暂不支持，敬请期待！",
          });
          // await rebootDevice(params);
          break;
        case "delete":
          this.$confirm(
            "是否确认删除设备：" + this.basicInfo.name + "?",
            "删除设备",
            {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              type: "warning",
            }
          ).then(async () => {
            await deleteDevice(this.$route.params);
            this.getDeviceBasicInfo();
            this.$message({
              type: "success",
              message: "删除成功!",
            });
          });
          break;
        default:
          break;
      }
    },

    onTaskClick: async function (type) {
      let params = {
        id: this.basicInfo?.task?.id,
      };
      switch (type) {
        case "startTask":
          if (this.basicInfo?.task?.status === "Running") {
            params = {
              ...params,
              status: "Pause",
            };
          } else {
            params = {
              ...params,
              status: "Running",
            };
          }
          await executeTask(params);
          break;
        case "stopTask": {
          params = {
            ...params,
            status: "Cancel",
          };
          this.$confirm(
            "是否确认终止任务：" + this.basicInfo?.task?.name + "?",
            "终止任务",
            {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              type: "warning",
            }
          ).then(async () => {
            await executeTask(params);
            this.$message({
              type: "success",
              message: "终止任务成功!",
            });
          });
          break;
        }
      }
      await this.getDeviceBasicInfo(true); // 不更新地图信息阻止地图页面刷新
    },

    // 重启
    onOnlineDiagnosisClick: async function (row) {
      await restartNode({
        id: this.basicInfo?.id,
        name: row.name,
      });
    },

    getCmdListData: async function () {
      try {
        const { id } = this.$route.params;
        const { pageInfo } = this.$refs.cmdCtlRef;
        const { pageSize, pageNo } = pageInfo;
        let params = {
          deviceId: id,
          pageNo: pageNo - 1,
          pageSize,
          sort: "createTime",
        };
        if (this.$refs.cmdCtlRef && this.$refs.cmdCtlRef.$refs.optsRef) {
          // 筛选条件存在参数字段
          const { formInline } = this.$refs.cmdCtlRef.$refs.optsRef;
          const { id, method, status, selectTime } = formInline;
          params = {
            ...params,
            id: id ? id.trim() : null,
            method: method || null,
            status: status || null,
            startTime: selectTime && selectTime[0],
            endTime: selectTime && selectTime[1],
          };
        }

        const res = await getCmdList(params);
        this.cmdData = res;
      } catch (error) {
        console.log("api error", error);
      }
    },

    getAlertListData: async function () {
      try {
        const { id } = this.$route.params;
        const { pageInfo } = this.$refs.alertRef;
        const { pageSize, pageNo } = pageInfo;
        let params = {
          deviceId: id,
          pageNo: pageNo - 1,
          pageSize,
          sort: "createTime",
        };
        if (this.$refs.alertRef && this.$refs.alertRef.$refs.optsRef) {
          // 筛选条件存在参数字段
          const { formInline } = this.$refs.alertRef.$refs.optsRef;
          const { id, type, module, selectTime } = formInline;
          params = {
            ...params,
            id: id ? id.trim() : null,
            type: type === "" ? null : type,
            module: module || null,
            startTime: selectTime && selectTime[0],
            endTime: selectTime && selectTime[1],
          };
        }

        const res = await getAlertList(params);
        this.alertData = res;
      } catch (error) {
        console.log("api error", error);
      }
    },

    onClickTaskInfo: function () {
      this.$router.push(
        `/scene/${this.basicInfo?.curScenceId}?taskId=${this.basicInfo?.curTaskId} `
      );
    },

    onClickSceneInfo: function () {
      this.$router.push(`/scene/${this.basicInfo?.curScenceId}`);
    },

    getVideoDeviceIds: function () {
      this.videoDeviceIds = localStorageGetItem("videoCheckList");
    },

    onChangeMode: function (e) {
      // this.getVideoDeviceIds();
      // if (this.videoDeviceIds?.length <= 0 || this.checkList?.length <= 0) {
      //   this.$message({
      //     type: "warning",
      //     message: "哦吼~至少要先选择一个要打开的视频！！!",
      //   });
      //   return;
      // }
      if (e === false) {
        const res = this.checkList;
        this.dragDataList = (res || []).map((i) => {
          return {
            id: i,
            name: this.videoCheckBox[i],
          };
        });
      }
      this.optsMode = e;
    },

    onChangeVideoCheckBox: function () {
      localStorageSetItem("videoCheckList", this.checkList);
    },

    getClosedVideoId: function (data) {
      const res = this.checkList.filter((i) => i !== data);
      this.checkList = res;
      localStorageSetItem("videoCheckList", res);
    },

    // 切换场景跟新地图
    updateCurSceneMapObj: function (obj) {
      // 若切换场景下绑定的地图pgm id 是一样的，不更新地图，但需清空操作数据（除ws）
      if (obj?.id !== this.curMapId && this.curMapType !== obj?.type) {
        this.$refs?.cesiumViewerRef?.resetViewer();
        this.$refs?.pgmKonvaShowRef?.resetData();
        this.curMapId = obj?.id;
        this.curMapType = obj?.type;
      } else {
        this.clearSomeCesiumData();
        if (this.$refs?.pgmKonvaShowRef) {
          this.$refs?.pgmKonvaShowRef?.clearPgmData();
          this.$refs.pgmKonvaShowRef.isShow = true;
        }
      }
      this.mapInfo = {
        ...obj,
        location: strToObj(obj?.location, ["jd", "wd", "gc"]),
        level: strToObj(obj?.level, ["min", "max"]),
        zoom: strToObj(obj?.zoom, ["min", "max"]),
        rectangle: strToObj(obj?.rectangle, ["west", "east", "north", "south"]),
      };
    },

    clearSomeCesiumData: function () {
      this.$refs?.cesiumViewerRef?.resetData();
      this.$refs.cesiumViewerRef?.removeEntityByName("marker");
      this.$refs.cesiumViewerRef?.removeEntityByName("polyline");
      this.$refs.cesiumViewerRef?.removeEntityByName("circle");
      this.$refs.cesiumViewerRef?.removeEntityByName("polygon");
    },

    // 添加任务
    onClickNavPoint: function (optsType, method) {
      this.pageType = optsType;
      this.method = method;
      this.$refs?.pgmKonvaShowRef?.onHavedData([{}], false);
    },

    // 清空point相关数据
    resetMapData: function (cancel) {
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.resetPoint();
        if (cancel) {
          // 取消隐藏tooltip
          this.$refs.pgmKonvaShowRef.isShow = true;
        }
      }
      // 清空瓦片图points
      if (this.$refs.cesiumViewerRef) {
        // 瓦片图不也能删除全部 要保留websocket 展示的 删除除name为ws_开头的所有
        this.clearSomeCesiumData();
        // this.$refs.cesiumViewerRef?.resetViewerData();
        // this.$refs?.cesiumViewerRef?.clearAreaPoints();
      }
    },

    getCurTaskInfoPoints: function (points, isShow, method, optsType) {
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.onHavedData(
          points,
          isShow,
          method,
          optsType
        );
      }
      this.pageType = optsType;
      this.method = method;
    },

    onClearBoundaryPoint: function () {
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.resetAreaPointData();
      }
      if (this.$refs.cesiumViewerRef) {
        this.clearSomeCesiumData();
      }
    },

    saveBoundaryPoint: function () {
      if (this.$refs.pgmKonvaShowRef) {
        return this.$refs.pgmKonvaShowRef.saveBoundaryPoint();
      }
      if (this.$refs.cesiumViewerRef) {
        return this.$refs.cesiumViewerRef.addPolygonById();
      }
    },

    getCurBehaviorData: function () {
      const { action, target } = this.$refs.selectTaskBehaviorRef;
      return {
        action,
        target,
        scenceId: this.basicInfo?.curScenceId,
        deviceIds: this.basicInfo?.task?.deviceIds || [],
      };
    },

    getCurTaskPoints: function () {
      // 处理接口传参
      if (this.$refs.pgmKonvaShowRef) {
        const { points } = this.$refs.pgmKonvaShowRef;
        const paramsPoint = [];
        for (let item of points.values()) {
          paramsPoint.push(item);
        }
        return paramsPoint;
      }

      if (this.$refs?.cesiumViewerRef) {
        const { points } = this.$refs?.cesiumViewerRef;
        const paramsPoint = [];
        for (let item of points.values()) {
          paramsPoint.push(item);
        }
        return paramsPoint;
      }
    },

    getAreaPoints: function () {
      // 处理接口传参
      if (this.$refs.pgmKonvaShowRef) {
        const { areaPoints } = this.$refs.pgmKonvaShowRef;
        const atrFormData = this.$refs.pgmKonvaShowRef?.getAttributeFormData();
        return { areaPoints, process: atrFormData };
      }
      if (this.$refs.cesiumViewerRef) {
        const { areaPoints } = this.$refs.cesiumViewerRef;
        const atrFormData = this.$refs.cesiumViewerRef.cesiumTooltipFormData;
        return { areaPoints, process: atrFormData?.process };
      }
    },

    visibleChange: async function (visible) {
      // 下拉展开列表 重新拉取内置地图，为获取最新地图列表
      if (visible) {
        try {
          this.mapLoading = true;
          await this.getMapList();
        } catch (error) {
          this.mapLoading = false;
          throw error;
        } finally {
          this.mapLoading = false;
        }
      } else {
        this.mapLoading = false;
      }
    },

    openTaskEventWebsoket: async function () {
      const curTaskId = this.basicInfo?.task?.id;
      if (curTaskId) {
        const taskEventUrl = `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/task-event/${curTaskId}`;
        this.taskEventWs = new WebSocket(taskEventUrl);
        this.taskEventWs.onopen = () => {
          console.log(`------task-event 连接成功-----当前任务Id:${curTaskId}`);
        };

        this.taskEventWs.onmessage = (msg) => {
          const eventObj = JSON.parse(msg?.data);
          // 0 通知型事件 1交互性事件，目前和后端敲定的交互逻辑
          if (eventObj?.type === 0) {
            if (eventObj?.eventType === 0) {
              // 任务（中的一个步骤）完成事件
              this.$message({
                type: "success",
                message: "当前任务完成！",
              });
              return;
            }
            if (eventObj?.eventType === 1) {
              // 目标识别事件
              if (eventObj?.value === 0) {
                // 识别到目标
                this.$message({
                  type: "success",
                  message: eventObj?.target
                    ? `成功识别到目标物：${eventObj?.target}`
                    : "成功识别到目标物",
                });
                return;
              }
              if (eventObj?.value === 1) {
                // 未识别到目标
                this.$message({
                  type: "warning",
                  message: "未识别到目标哦！",
                });
                return;
              }
              return;
            }
          }
        };

        this.taskEventWs.onclose = (event) => {
          if (event.wasClean) {
            console.log(
              `[close] Connection closed cleanly,------task-event-----, code=${event.code} reason=${event.reason}`
            );
          } else {
            console.log(`[close] Connection died ------task-event-----`);
          }
        };
      }
    },

    closeTaskEventWebsoket: function () {
      if (this.taskEventWs) {
        this.taskEventWs.close();
        this.taskEventWs = null;
      }
    },

    resetDeviceDetailData: function () {
      this.checkList = [];
      this.optsMode = true;
      this.mapOptions = [];
      this.mapVal = "";
      this.addBuildMapTaskId = "";
    },
  },
};
</script>

<style lang="scss" scoped>
@import "./Index.scss";
</style>
