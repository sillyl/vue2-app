<template>
  <div class="basic_card">
    <el-divider content-position="left">
      <span class="robot_title">{{ basicTitle || "基本信息" }}</span>
    </el-divider>
    <div class="basic_card_slot">
      <slot></slot>
    </div>
  </div>
</template>
<script>
export default {
  name: "BasicInfo",
  props: ["basicTitle"],
};
</script>
<style lang="scss" scoped>
@import "@/assets/css/common.scss";
.basic_card {
  border: 1px solid #dcdfe6;
  border-radius: 6px;
  min-height: 200px;
  height: 100%;
  padding: 0 12px;
  .el-divider--horizontal {
    margin: 0px;
    height: 0px;
    .el-divider__text {
      background-color: $bg-color;
      color: #fff;
      padding: 0px;
    }
  }
  &_slot {
    margin-top: 24px;
    height: calc(100% - 32px);
    overflow: auto;
  }
}
</style>
