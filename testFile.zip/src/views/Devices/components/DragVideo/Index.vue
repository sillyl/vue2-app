<template>
  <div class="drag_video">
    <div class="drag_video_container">
      <NotFound
        v-if="!dataList || dataList.length === 0"
        desc="请勾选想要查看的视频！"
      />
      <draggable class="container" v-model="dataList" @change="dragChange">
        <div
          v-for="(item, index) in dataList"
          :class="['item', 'item_' + index]"
          :key="index"
          :style="getStyle(index)"
        >
          <WfsVideo
            :videoCheckBox="videoCheckBox"
            :videoCheckBoxIndex="videoCheckBoxIndex"
            :id="item.id"
            isFull="true"
            :getCurBehaviorData="getCurBehaviorData"
            isShowScreenCapture="true"
          />
        </div>
      </draggable>
    </div>
    <div class="drag_video_bottom">
      <div class="drag_video_bottom_opts">
        <el-row>
          <el-col :span="6">
            <SelectTaskBehavior ref="selectTaskBehaviorRef" />
            <div class="video_opts">
              <span>视频操作</span>
              <el-button type="primary" size="mini" @click="handleScreenshot()"
                >截图</el-button
              >
              <el-button
                type="primary"
                size="mini"
                @click="handleRecording()"
                :icon="recording ? 'el-icon-loading' : ''"
                >{{ recording ? "录制中" : "录制" }}</el-button
              >
            </div></el-col
          >
          <el-col :span="6">
            <div class="start_video">
              <p>开启视频</p>
              <el-checkbox-group
                v-model="dragCheckList"
                @change="onChangeVideoCheckBox"
                :max="3"
              >
                <el-checkbox
                  v-for="(item, idx) in videoUrls"
                  :key="idx"
                  :label="'video' + basicInfo.id + '-' + idx"
                  :title="
                    basicInfo.sn +
                    '(' +
                    basicInfo.name +
                    ')' +
                    '-视频' +
                    (idx + 1)
                  "
                  >{{
                    basicInfo.sn +
                    "(" +
                    basicInfo.name +
                    ")" +
                    "-视频" +
                    (idx + 1)
                  }}</el-checkbox
                >
              </el-checkbox-group>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="video_opts">
              <span> 视频操作</span>
              <el-button type="primary" size="mini" @click="handleScreenshot()"
                >截图</el-button
              >
              <el-button
                type="primary"
                size="mini"
                @click="handleRecording()"
                :icon="recording ? 'el-icon-loading' : ''"
                >{{ recording ? "录制中" : "录制" }}</el-button
              >
            </div>
          </el-col>
        </el-row>
      </div>

      <Nipple
        :deviceId="deviceId"
        v-if="$store.state.isShowNippleVal"
        class="nipple_left"
        joystickId="joystickCircle1"
      >
        <!-- <div class="joystick_desc">旋转操作</div> -->
      </Nipple>
      <!-- <Nipple
        v-if="$store.state.isShowNippleVal"
        :deviceId="deviceId"
        joystickId="joystickUD"
        color="gray"
        :lockY="true"
      >
        <div class="joystick_desc">上下操作</div>
      </Nipple>
      <Nipple
        :deviceId="deviceId"
        joystickId="joystickLR"
        :lockX="true"
        v-if="$store.state.isShowNippleVal"
      >
        <div class="joystick_desc">左右操作</div>
      </Nipple> -->
      <Nipple
        :deviceId="deviceId"
        v-if="$store.state.isShowNippleVal"
        joystickId="joystickCircle2"
        class="nipple_right"
      >
        <!-- <div class="joystick_desc">旋转操作</div> -->
      </Nipple>
    </div>
  </div>
</template>

<script>
import draggable from "vuedraggable";
import WfsVideo from "@/components/VideoPlay/WfsVideo/Index.vue";
import Nipple from "@/components/Nipple/Index.vue";
import SelectTaskBehavior from "@/components/SelectTaskBehavior/Index.vue";
import NotFound from "@/components/NotFound/Index.vue";
import {
  localStorageGetItem,
  localStorageSetItem,
} from "@/utils/localStorgaeFun.js";
import dayjs from "dayjs";

let mediaRecorder; // MediaRecorder对象
export default {
  name: "DragVideo",
  props: [
    "checkList",
    "dragDataList",
    "videoCheckBox",
    "videoCheckBoxIndex",
    "deviceId",
    "basicInfo",
    "videoUrls",
  ],
  components: {
    draggable,
    WfsVideo,
    Nipple,
    SelectTaskBehavior,
    NotFound,
  },
  data() {
    return {
      dataList: this.dragDataList,
      recording: false,
      curId: "",
      curName: "",
      dragCheckList: this.checkList || [],
    };
  },
  watch: {},
  mounted() {
    this.curId = this.dataList?.[0]?.id;
    this.curName = this.dataList?.[0]?.name;
  },
  created() {
    let userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
    if (userAgent.indexOf("Firefox") > -1) {
      document.body.ondrop = (e) => {
        //拖拽结束事件
        e.preventDefault(); //阻止浏览器默认行为，主要是为了解决火狐浏览器拖拽完打开新的窗口问题
        e.stopPropagation();
      };
    }
  },
  methods: {
    getStyle: function (idx) {
      const dom = document.querySelector(".situational_content_manual");
      const { width, height } = dom?.getBoundingClientRect();
      switch (idx) {
        case 0: {
          return { width: `calc(100% - ${width}px)` };
        }
        case 1: {
          return {
            width: `${width}px`,
            height: `calc(50% - ${height}px)`,
            top: "0px",
            position: "absolute",
            right: "0px",
          };
        }
        case 2: {
          let domItem1 = document.querySelector(".item_1");
          return {
            width: `${width}px`,
            height: `calc(50% - ${height}px)`,
            top: `calc(50% - ${height}px)`,
            position: "absolute",
            right: "0px",
          };
        }

        default:
          break;
      }
      // return { width: "60%", height: "100%" };
    },

    getCurBehaviorData: function () {
      const { action, target } = this.$refs.selectTaskBehaviorRef;
      return {
        action,
        target,
        scenceId: this.basicInfo?.curScenceId,
        deviceIds: this.basicInfo?.task?.deviceIds || [],
      };
    },

    dragChange: function (data) {
      const moved = data?.moved;
      const element = moved?.element;
      this.curId = element?.id;
      this.curName = element?.name;
    },

    onChangeVideoCheckBox: function () {
      const res = [...this.dragCheckList];
      this.dataList = (res || []).map((i) => {
        return {
          id: i,
          name: this.videoCheckBox[i],
        };
      });
      this.curId = this.dataList[0]?.id;
      this.curName = this.dataList[0]?.name;
      localStorageSetItem("videoCheckList", this.dragCheckList);
    },

    // 截图
    handleScreenshot() {
      const id = this.curId;
      if (!id) {
        this.$message({
          type: "warning",
          message: "请先在开启视频列表勾选想要开启的视频！",
        });
        return;
      }
      const name = this.curName;
      const video = document.querySelector(`#${id}`); // 获取video节点
      const canvas = document.createElement("canvas"); // 创建canvas节点
      const w = window?.innerWidth || video?.clientWidth;
      const h = window?.innerHeight || video?.clientHeight;
      canvas.width = w;
      canvas.height = h; // 设置宽高
      const ctx = canvas.getContext("2d");
      ctx.drawImage(video, 0, 0, w, h); // video写入到canvas
      this.imgUrl = canvas.toDataURL("image/png"); // 生成截图地址
      const time = dayjs(new Date().getTime()).format("YYYY_MM_DD_HH_mm_ss");
      const newName = `${name}_${time}`;
      this.downloadFileByBase64(this.imgUrl, newName);
    },
    downloadFileByBase64: function (base64, name) {
      const myBlob = this.dataURLtoBlob(base64);
      const myUrl = URL.createObjectURL(myBlob);
      this.downloadVideoFile(myUrl, name);
    },

    dataURLtoBlob: function (dataurl) {
      let arr = dataurl.split(","),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      return new Blob([u8arr], { type: mime });
    },

    // 录制
    handleRecording() {
      let chunks = [];
      const id = this.curId;
      if (!id) {
        this.$message({
          type: "warning",
          message: "请先在开启视频列表勾选想要开启的视频！",
        });
        return;
      }
      const name = this.curName;
      this.recording = !this.recording;
      if (this.recording) {
        this.$message.success("开始录制");
        const video = document.querySelector(`#${id}`);
        const stream = video?.mozCaptureStream
          ? video?.mozCaptureStream()
          : video?.captureStream(); // 火狐:mozCaptureStream， chrome/e：captureStream
        mediaRecorder = new MediaRecorder(stream);
        mediaRecorder.ondataavailable = (e) => chunks.push(e.data);
        mediaRecorder.onstop = () => {
          const blob = new Blob(chunks, { type: "video/webm" });
          this.videoUrl = URL.createObjectURL(blob);
          this.downloadVideoFile(this.videoUrl, name);
        };
        mediaRecorder.start();
      } else {
        this.$message.success("结束录制");
        mediaRecorder?.stop();
      }
    },

    downloadVideoFile: function (videoUrl, name) {
      const time = dayjs(new Date().getTime()).format("YYYY_MM_DD_HH_mm_ss");
      const newName = `${name}_${time}.webm`;
      let a = document.createElement("a");
      a.download = newName;
      a.href = videoUrl;
      a.style.display = "none";
      document.body.appendChild(a);
      a.click();
      a.remove();
    },
  },
};
</script>

<style lang="scss" scoped>
.drag_video {
  height: 100%;
  &_container {
    height: 70%;
    border: 1px solid red;
    background: black;
    .container {
      height: 100%;
      .item_0 {
        height: 100%;
      }
    }
  }
  &_bottom {
    height: calc(30% - 20px);
    overflow: auto;
    padding: 10px;
    font-size: 16px;

    .nipple_left,
    .nipple_right {
      bottom: 0px;
      margin: 20px 0px 20px 0px;
      position: absolute;
    }
    .nipple_left {
      left: 50px;
    }
    .nipple_right {
      right: 50px;
    }

    &_opts {
      // display: flex;

      ::v-deep {
        .select_task_behavior {
          margin-right: 10px;
          max-width: 348px;
          .select_task_behavior_content {
            .el-select {
              width: 50% !important;
            }
          }
        }
      }

      .video_opts {
        margin-top: 8px;
        span {
          margin-left: 30px;
        }
        .el-button {
          margin-left: 8px;
        }
      }

      .start_video {
        width: 100%;
        margin-top: 8px;
        .el-checkbox-group {
          display: flex;
          flex-direction: column;
          flex-wrap: nowrap;
          .el-checkbox {
            color: inherit;
            width: 100%;
          }
          ::v-deep {
            .el-checkbox__input {
              top: -14px;
            }
            .el-checkbox__label {
              font-size: 16px;
              line-height: 40px;
              width: calc(100% - 25px);
              display: inline-block;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
            }
            .el-checkbox__inner {
              z-index: inherit;
            }
          }
        }
      }
    }
  }

  .video_player_wfs {
    position: relative;
    top: 0px !important;
    left: 0px !important;
    height: 100%;
    width: 100%;
    border: none;

    ::v-deep {
      .video_player_wfs_header {
        .text_overflow_140 {
          width: 100%;
        }
      }
    }
  }
}
</style>
