<template>
  <el-form :inline="true" :model="formInline">
    <el-form-item label="告警类型" prop="type" class="alert_form_item">
      <el-select v-model="formInline.type" placeholder="请选择" clearable>
        <el-option
          v-for="(item, index) in alertTyleList"
          :key="item[index]"
          :label="item[index]"
          :value="index"
        ></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="告警模块" prop="module" class="alert_form_item">
      <el-select v-model="formInline.module" placeholder="请选择" clearable>
        <el-option
          v-for="item in alertModule"
          :key="item"
          :label="item"
          :value="item"
        ></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="时间区间" class="alert_form_item_time">
      <el-date-picker
        v-model="formInline.selectTime"
        type="datetimerange"
        range-separator="至"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        style="width: 100%"
      >
      </el-date-picker>
    </el-form-item>
    <el-form-item label="告警ID" prop="id" class="alert_form_item">
      <el-input
        v-model="formInline.id"
        placeholder="请输入"
        clearable
      ></el-input>
    </el-form-item>
    <el-button type="primary" @click="onSubmit">查询</el-button>
  </el-form>
</template>

<script>
import { alertTyleList, alertModule } from "@/constants";
export default {
  props: ["onSearchFun"],
  data() {
    return {
      formInline: {
        id: "",
        type: "",
        module: "",
        selectTime: [
          new Date() - 7 * 24 * 60 * 60 * 1000,
          new Date().getTime(),
        ], // 默认前一周时间, 统一ms级别时间戳
      },
      alertTyleList,
      alertModule,
    };
  },
  methods: {
    onSubmit() {
      if (this.onSearchFun) {
        this.onSearchFun();
      }
    },
  },
};
</script>

<style lang="scss" scoped>
@import "./Index.scss";
</style>
