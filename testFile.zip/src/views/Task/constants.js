export const taskOptsType = {
  add: "添加",
  update: "编辑",
  info: "任务信息",
};

export const tasksMethods = {
  TASK_TEAM: "编队任务",
  TASK_ROUNDUP: "围捕任务",
  TASK_INVESTIGATE: "侦查任务",
  TASK_GRAB: "抓取任务",
  TASK_NAVIGATION: "导航任务",
  TASK_MAPPING: "建图任务",
  TASK_RECOGNITION: "识别任务",
  TASK_TRACKING: "锁定任务",
  TASK_STRIKE: "打击任务",
  TASK_FOLLOW: "跟随任务",
  TASK_MARK: "标注任务",
};

// 队形
export const formationList = ["方形", "一字型", "三角形"];
