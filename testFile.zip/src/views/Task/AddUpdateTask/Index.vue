<template>
  <div
    v-if="$store.state.isTask"
    class="robot_add_task"
    :style="{ height: isCollapse ? '40%' : '24px' }"
  >
    <div class="robot_add_task_header" @click="onClick">
      <span class="robot_title"
        >{{ taskOptsType[$store.state.curTaskInfo.optsType]
        }}{{ tasksMethods[$store.state.curTaskInfo.method] }}</span
      >
      <i
        class="el-icon-d-arrow-left"
        :style="{
          transform: isCollapse ? 'rotate(-90deg)' : 'rotate(90deg)',
          transition: '0.3s',
        }"
      />
      <i class="el-icon-close" @click="onClosed"></i>
    </div>
    <div class="robot_add_task_content" v-show="isCollapse">
      <TaskForm
        ref="taskRef"
        :optsType="$store.state.curTaskInfo.optsType"
        :getCurTaskInfoPoints="getCurTaskInfoPoints"
        :resetMapData="resetMapData"
        :onClickNavPoint="onClickNavPoint"
        :onClearBoundaryPoint="onClearBoundaryPoint"
        :saveBoundaryPoint="saveBoundaryPoint"
        :updateCurSceneMapObj="updateCurSceneMapObj"
        :deviceCurScenceId="deviceCurScenceId"
        :selectSceneInfo="selectSceneInfo"
        :isCurPage="isCurPage"
        :buildMapping="buildMapping"
        :clickCurNavPoint="clickCurNavPoint"
        :onClickCurBdyPoints="onClickCurBdyPoints"
      >
        <el-button type="primary" @click="onOk">确定</el-button>
        <el-button @click="onClosed">取消</el-button>
      </TaskForm>
    </div>
  </div>
</template>

<script>
import TaskForm from "../components/TaskForm/Index.vue";
import { taskOptsType } from "../constants";
import { addTask, updataTask } from "@/api/task";
import { tasksMethods } from "../constants";
export default {
  props: [
    "selectSceneInfo",
    "onUpdateCancel",
    "getOnlineTaskList",
    "getDeviceBasicInfo",
    "isShowTaskInfo",
    "getCurTaskPoints", // 获取拾取点
    "resetMapData", // 清空数据
    "getCurTaskInfoPoints",
    "onClickNavPoint",
    "onClearBoundaryPoint",
    "saveBoundaryPoint",
    "getAreaPoints",
    "updateCurSceneMapObj",
    "deviceCurScenceId", // 设备情景控制新建任务需要
    "isCurPage", // 控制场景选择的当前页标识
    "buildMapping",
    "clickCurNavPoint",
    "onClickCurBdyPoints",
  ],
  data() {
    return {
      taskOptsType,
      isCollapse: true,
      tasksMethods,
      navPoints: [],
    };
  },
  components: {
    TaskForm,
  },
  methods: {
    onOk: function () {
      if (this.$refs.taskRef) {
        const taskRef = this.$refs.taskRef;
        taskRef.$refs.form.validate(async (valid) => {
          if (valid) {
            if (this.getCurTaskPoints) {
              this.navPoints = this.getCurTaskPoints();
            }
            const res = this?.getAreaPoints && this?.getAreaPoints();
            try {
              const {
                circulate,
                name,
                sceneId,
                scenceId,
                deviceIds,
                formation,
                mapConflation,
                action,
                target,
                mapName,
                mappingType,
              } = taskRef.form;
              let params = {
                name,
                method: this.$store.state.curTaskInfo.method,
                params: {
                  circulate,
                  point: this.navPoints,
                  formation,
                  mapName,
                  mappingType,
                  mapConflation,
                  area: res?.areaPoints,
                  process: res?.process,
                },
                deviceIds,
                scenceId: scenceId || sceneId,
              };
              if (this.$store.state.curTaskInfo.optsType === "update") {
                params = {
                  id: this.$store.state.curTaskInfo.id,
                  ...params,
                };
                const taskId = await updataTask(params);
              } else {
                const taskId = await addTask(params);
              }

              if (this.getOnlineTaskList) {
                // 场景
                await this.getOnlineTaskList(true);
              }

              if (this.getDeviceBasicInfo) {
                // 设备
                await this.getDeviceBasicInfo(true);
              }

              this.onClosed();
            } catch (error) {
              console.log("error", error);
            }
          } else {
            return false;
          }
        });
      }
    },
    onClosed: async function () {
      // 取消 重置更新场景导致的地图
      const mapObj = this.$refs?.taskRef?.updateScenceMapInfo;
      // 1.未切换; 2.切换且切图被修改，重新渲染
      if (
        (mapObj?.id && mapObj?.id !== this.selectSceneInfo?.map?.id) ||
        mapObj?.id
      ) {
        this.updateCurSceneMapObj(this.selectSceneInfo?.map);
      }

      if (
        this.$store.state.curTaskInfo?.page === "taskInfo" &&
        this.isShowTaskInfo
      ) {
        this.isShowTaskInfo(true);
      }
      this.$refs?.taskRef?.resetFormData();
      this.$refs?.taskRef?.resetAreaPointData();
      if (this.$store.state.curTaskInfo["customCloseFun"]) {
        this.$store.state.curTaskInfo.customCloseFun();
      }
      this.$store.commit("updateIsTask", {
        isTask: false,
      });
      if (this.onUpdateCancel) {
        this.onUpdateCancel();
      }
      if (this.onClickNavPoint) {
        this.onClickNavPoint("", "");
      }
      if (this.resetMapData) {
        this.resetMapData(true);
      }
    },
    onClick: function () {
      this.isCollapse = !this.isCollapse;
    },
  },
};
</script>

<style lang="scss" scoped>
@import "@/assets/css/common.scss";
$prefixCls: "robot_add_task";
.#{$prefixCls} {
  position: absolute;
  bottom: 0px;
  width: 100%;
  z-index: 2;

  &_header {
    border-bottom: 1px solid $grey-color;
    height: 22px;
    background-color: $header-color;
    color: #fff;
    .el-icon-close {
      float: right;
      font-size: 20px;
    }
    .el-icon-d-arrow-left {
      margin-left: calc(50% - 94px);
      font-size: 20px;
    }
  }
  &_content {
    height: calc(100% - 22px);
    form {
      background-color: $header-color;
      height: calc(100% - 8px);
    }
  }
}
</style>
