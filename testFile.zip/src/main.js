import Vue from "vue";
import VueRouter from "vue-router";
import VueKonva from "vue-konva";
import ElementUI from "element-ui";
import "element-ui/lib/theme-chalk/index.css";
import store from "./store";
import App from "./App.vue";
import router from "./router";
import "@/assets/css/common.scss";
import { toDark } from "@/utils/dark";

// toDark(true)
Vue.config.productionTip = false;

Vue.use(VueKonva);
Vue.use(ElementUI);

/*  
  fix console 
  vue-router.esm.js:2046 Uncaught (in promise) NavigationDuplicated: Avoided redundant navigation to current location: "xxx"
*/
const orgPush = VueRouter.prototype.push;
VueRouter.prototype.push = function push(location) {
  return orgPush.call(this, location).catch((err) => err);
};

new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount("#app");
