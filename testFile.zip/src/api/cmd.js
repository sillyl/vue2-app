import { axiosWarpInstance } from "@/utils/axiosInstance.js";

// 急停
export const emergencyStop = (data) => {
  const res = axiosWarpInstance(
    "/cpix/v1.0/configure/cmd/consumer/post",
    data,
    {
      type: "post",
    }
  );
  return res;
};

export const getCmdList = (data) => {
  const res = axiosWarpInstance("/cpix/v1.0/configure/cmd/common/list", data, {
    type: "get",
  });
  return res;
};
