import { axiosWarpInstance } from "@/utils/axiosInstance.js";

export const getPluginList = (data) => {
  const res = axiosWarpInstance(
    `/cpix/v1.0/configure/plugin/common/list`,
    data,
    {
      type: "get",
    }
  );
  return res;
};
