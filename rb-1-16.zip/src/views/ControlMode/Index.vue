<template>
  <div
    class="control_mode_content_plat"
    id="control_mode_content_plat"
    v-if="
      $store.state.isControlMode &&
      $store.state.curCtrlMode !== 0 &&
      $store.state.curDeviceId
    "
  >
    <PlatLeft
      :jsonData="jsonLeftData"
      ref="platLeftRef"
      :videoUrls="videoUrls"
      :videoCheckBox="videoCheckBox"
      :videoCheckBoxIndex="videoCheckBoxIndex"
      :basicInfo="basicInfo"
    />
    <div class="center">
      <div
        v-if="$store.state.curDeviceId"
        class="control_mode_content_deviceInfo"
      >
        <el-alert
          v-if="poseFront && poseFront !== 0"
          :title="`前摆臂角度：${poseFront}`"
          type="success"
          center
          :closable="false"
        >
        </el-alert>
        <el-alert
          v-if="poseBack && poseBack !== 0"
          :title="`后摆臂角度：${poseBack}`"
          type="success"
          center
          :closable="false"
        >
        </el-alert>
        <el-alert
          :title="`当前设备：${$store.state.curDeviceInfo?.basicInfo?.name}`"
          type="success"
          center
          :closable="false"
        >
        </el-alert>
      </div>
    </div>
    <PlatRight
      :jsonData="jsonRightData"
      ref="platRightRef"
      :videoUrls="videoUrls"
      :videoCheckBox="videoCheckBox"
      :videoCheckBoxIndex="videoCheckBoxIndex"
      :basicInfo="basicInfo"
    />
  </div>
</template>
<script>
import PlatLeft from "./Plat/PlatLeft.vue";
import PlatRight from "./Plat/PlatRight.vue";
import WfsVideo from "@/components/VideoPlay/WfsVideo/Index.vue";
import { videoCheckBoxIndex } from "@/constants";
import {
  localStorageSetItem,
  localStorageGetItem,
} from "@/utils/localStorageFun.js";
import { getConfigJsonSchema } from "@/api/config.js";
import { isEmpty, isEqual } from "lodash";

export default {
  data() {
    return {
      jsonLeftData: [],
      jsonRightData: [],
      videoUrls: [],
      videoCheckBox: {},
      videoCheckBoxIndex: {},
      basicInfo: null,
      poseWs: null,
      poseBack: null,
      poseFront: null,
      eventWs: null,
    };
  },
  async mounted() {
    await this.getJsonSchemaData();
    await this.openPoseWebsoket();
    await this.openEventWebsoket();
  },

  watch: {
    "$store.state.curCtrlMode": function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.getJsonSchemaData();
      }
    },
    "$store.state.curDeviceId": async function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        await this.getJsonSchemaData();
        await this.openPoseWebsoket();
        await this.openEventWebsoket();
      }
    },
  },
  components: {
    PlatLeft,
    PlatRight,
  },

  methods: {
    getDeviceVideoInfo: function () {
      const res = localStorageGetItem("curDeviceInfo");
      this.videoUrls =
        this.$store.state.curDeviceInfo?.videoUrls || res?.videoUrls;
      this.videoCheckBox =
        this.$store.state.curDeviceInfo?.videoCheckBox || res?.videoCheckBox;
      this.videoCheckBoxIndex =
        this.$store.state.curDeviceInfo?.videoCheckBoxIndex ||
        res?.videoCheckBoxIndex;
      this.basicInfo =
        this.$store.state.curDeviceInfo?.basicInfo || res?.basicInfo;
    },

    getJsonSchemaData: async function () {
      await this.getDeviceVideoInfo();
      const curDeviceId =
        localStorageGetItem("curDeviceId") || this.$store.state.curDeviceId;
      if (curDeviceId) {
        const res = await getConfigJsonSchema({
          id: curDeviceId,
        });

        const pageId = this.$store.state.curCtrlMode;
        if (res?.page) {
          //  0: "无效状态"
          let obj = {};
          res?.page?.map((i) => {
            obj[i.id] = i.name;
          });
          this.$store.commit("updateCurCtrlModes", obj);
        }
        if (res?.function) {
          const modules = res?.function;
          const curPageData = res?.function?.filter(
            (i) => i?.pageId === pageId
          );
          const rightData = curPageData?.filter((i) => i.layout === "right");
          const leftData = curPageData?.filter((i) => i.layout === "left");
          this.jsonRightData = await this.getNewJsonData(rightData || []);
          this.jsonLeftData = await this.getNewJsonData(leftData || []);
        }
      }
    },

    // 1. 处理数据filter出groupId相同的组；2.各个组件所需数据结构; 3.通过小组件反计算 左右展示的组件数量
    getNewJsonData: async function (data) {
      let arr = [];
      // groupId 仅作为分组类型， id 标识，不做分组
      for (let i of data) {
        if (i?.groupId) {
          const filterArr = arr.filter((k) => i?.groupId === k?.groupId);
          if (isEmpty(filterArr)) {
            arr.push({
              groupId: i?.groupId,
              groupName: i?.groupName,
              group: [{ ...i }],
            });
          } else {
            const index = arr.findIndex((k) => i?.groupId === k?.groupId);
            arr[index]?.group.push(i);
          }
        }
        if (!i?.groupId && i?.id) {
          arr.push({
            id: i?.id,
            groupName: i?.groupName,
            group: [{ ...i }],
          });
          // const filterArr = arr.filter((k) => i?.id === k?.id);
          // if (isEmpty(filterArr)) {
          //   arr.push({
          //     id: i?.id,
          //     groupName: i?.groupName,
          //     group: [{ ...i }],
          //   });
          // } else {
          //   const index = arr.findIndex((k) => i?.id === k?.id);
          //   arr[index]?.group.push(i);
          // }
        }
        if (i?.split) {
          arr.push({ ...i });
        }
      }
      return [...arr]; // 适合前端渲染的元数据
    },

    // device-pose
    openPoseWebsoket: async function () {
      await this.closePoseWebsoket();
      const curDeviceId =
        localStorageGetItem("curDeviceId") || this.$store.state.curDeviceId;
      const poseUrl = `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/device-pose/${curDeviceId}`;
      this.poseWs = new WebSocket(poseUrl);
      this.poseWs.onopen = () => {
        console.log("------device-pose 连接成功-----");
      };

      this.poseWs.onmessage = (msg) => {
        const msgObj = JSON.parse(msg?.data);
        const pose = msgObj?.pose;
        const pendulumArm = pose?.pendulumArm;
        this.poseBack = pendulumArm?.back;
        this.poseFront = pendulumArm?.front;
      };

      this.poseWs.onclose = (event) => {
        if (event.wasClean) {
          console.log(
            `[close] Connection closed cleanly, ----device-pose----, code=${event.code} reason=${event.reason}`
          );
        } else {
          console.log("[close] Connection died, ----device-pose----");
        }
      };
    },

    closePoseWebsoket: function () {
      if (this.poseWs) {
        this.poseWs.close();
        this.poseWs = null;
      }
    },

    // device-event
    openEventWebsoket: async function () {
      await this.closeEventWebsoket();
      const curDeviceId =
        localStorageGetItem("curDeviceId") || this.$store.state.curDeviceId;
      const poseUrl = `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/device-event/${curDeviceId}`;
      this.eventWs = new WebSocket(poseUrl);
      this.eventWs.onopen = () => {
        console.log("------device-event 连接成功-----");
      };

      this.eventWs.onmessage = (msg) => {
        const msgObj = JSON.parse(msg?.data);
        const eventObj = msgObj?.event;

        if (!isEmpty(eventObj)) {
          this.$message({
            message: JSON.stringify(eventObj),
            type: "success",
          });
        }
      };

      this.eventWs.onclose = (event) => {
        if (event.wasClean) {
          console.log(
            `[close] Connection closed cleanly, ----device-event----, code=${event.code} reason=${event.reason}`
          );
        } else {
          console.log("[close] Connection died, ----device-event----");
        }
      };
    },

    closeEventWebsoket: function () {
      if (this.eventWs) {
        this.eventWs.close();
        this.eventWs = null;
      }
    },
  },
};
</script>

<style lang="scss" scoped>
@import "./Index.scss";
</style>
