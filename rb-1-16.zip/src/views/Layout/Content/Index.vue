<template>
  <div class="content">
    <router-view></router-view>
    <ControlMode />
    <AddMap :getNewMenuMapList="getNewMenuMapList" />
    <SubscribeForm />
  </div>
</template>
<script>
import ControlMode from "@/views/ControlMode/Index.vue";
import AddMap from "@/views/Maps/AddMap/Index.vue";
import SubscribeForm from "@/views/Subscribes/SubscribeForm.vue";
export default {
  props: ["getNewMenuMapList"],
  components: {
    ControlMode,
    AddMap,
    SubscribeForm,
  },
};
</script>

<style lang="scss" scoped>
.content {
  height: calc(100% - 62px);
  position: relative;
}
</style>
