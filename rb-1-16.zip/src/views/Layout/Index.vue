<template>
  <div class="robot-body">
    <HeaderMenu ref="headerMenuRef" />
    <Content :getNewMenuMapList="getNewMenuMapList" />
  </div>
</template>
<script>
import HeaderMenu from "./HeaderMenu/Index.vue";
import Content from "./Content/Index.vue";
export default {
  components: {
    HeaderMenu,
    Content,
  },

  methods: {
    getNewMenuMapList: function () {
      this.$refs.headerMenuRef?.getMapList();
    },
  },
};
</script>

<style lang="scss" scoped>
.robot-body {
  height: 100%;
}
</style>
