<template>
  <div class="robot_header">
    <el-menu
      :default-active="$route.path"
      class="el-menu-demo"
      mode="horizontal"
      background-color="#23343e"
      text-color="#fff"
      router
      active-text-color="#ffd04b"
    >
      <div class="robot_header_control_mode" v-if="$store.state.curDeviceId">
        <el-button
          type="primary"
          round
          @click="onClickControlMode"
          v-if="
            Object.keys($store.state.curCtrlModes).length > 0 &&
            $store.state.curDeviceId &&
            $store.state.curCtrlMode !== 0
          "
          >{{ $store.state.curCtrlModes[$store.state.curCtrlMode] }}
        </el-button>
      </div>
      <el-submenu index="/scene" popper-class="submenu_popper_item">
        <template slot="title">
          <div @click="onClickScene">
            <i class="el-icon-menu"></i> <span>场景</span>
          </div>
        </template>
        <el-menu-item
          v-for="i in sceneList"
          :key="i.id"
          :index="'/scene/' + i.id"
          :disabled="i.taskNum === 0"
          @click="onClickScenesItem(i)"
          >{{ i.name }}</el-menu-item
        >
      </el-submenu>
      <el-submenu index="/device" popper-class="submenu_popper_item">
        <template slot="title">
          <i class="el-icon-mobile-phone"></i>
          <span>设备</span>
        </template>
        <el-menu-item
          v-for="i in deviceList"
          :key="i.id"
          :index="'/device/' + i.id"
          @click="onClickDeviceItem(i)"
          >{{ i.name }}</el-menu-item
        >
      </el-submenu>
      <el-submenu index="/map" popper-class="submenu_popper_item">
        <template slot="title">
          <i class="el-icon-location-information"></i
          ><span @click="onClickMap"> 地图</span>
        </template>
        <el-menu-item
          v-for="i in mapList"
          :key="i.mapId"
          :index="'/map/' + i.mapId"
          @click="onClickMapItem(i)"
        >
          {{ i.name }}
        </el-menu-item>
      </el-submenu>
      <i class="el-icon-circle-plus add-opt" @click="onAddMap"></i>
      <el-submenu index="subscribe" popper-class="submenu_popper_item">
        <template slot="title">
          <div @click="getSubscribeList">
            <i class="el-icon-document"></i>订阅
          </div>
        </template>
        <el-menu-item
          v-for="i in subscribeList"
          :key="i.id"
          @click="onClickSubscribeItem(i)"
        >
          {{ i.name }}
        </el-menu-item>
      </el-submenu>
      <i class="el-icon-circle-plus add-opt" @click="onAddSubscribe"></i>
    </el-menu>
    <div class="robot_header_userInfo">
      <CustomSettings ref="customSettingsRef" />
      <HeaderUser />
    </div>
  </div>
</template>
<script>
import { getSenceMenuList } from "@/api/scene.js";
import { getDeviceList, getDeviceMenuList } from "@/api/device.js";
import { getMapMenuList } from "@/api/map.js";
import HeaderUser from "@/views/HeaderUser/Index.vue";
import CustomSettings from "../CustomSettings/Index.vue";
import store from "@/store";
import {
  localStorageGetItem,
  localStorageSetItem,
} from "@/utils/localStorageFun.js";
import { getSubscribeList } from "@/api/subscribe.js";

export default {
  data() {
    return {
      sceneList: [],
      deviceList: [],
      mapList: [],
      subscribeList: [],
      wsUrl: `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/terminal/handle`,
      ws: null,
      curIsControlMode: this.$store.state.isControlMode,
    };
  },
  components: {
    HeaderUser,
    CustomSettings,
  },

  async mounted() {
    await this.getDeviceList();
    await this.getSenceMenuListData();
    await this.getMapList();
    await this.getSubscribeList();
    this.openWebsocket();
  },
  methods: {
    openWebsocket() {
      let socketUrl = this.wsUrl;
      this.ws = new WebSocket(socketUrl);
      this.ws.onopen = () => {
        console.log(`---WebSocket连接${socketUrl}成功---`);
      };

      this.ws.onmessage = (msg) => {
        const msgObj = JSON.parse(msg?.data);
        store.commit("updateCurCtrlMode", msgObj?.operateMode);
      };

      this.ws.onclose = (event) => {
        if (event.wasClean) {
          console.log(
            `[close] Connection closed cleanly, ----terminal/handle----, code=${event.code} reason=${event.reason}`
          );
        } else {
          console.log("[close] Connection died, ---terminal/handle----");
        }
      };
      this.ws.onerror = (e) => {
        console.log("WebSocket连接失败: " + socketUrl + "code:" + e.code);
      };
    },

    //获取场景
    getSenceMenuListData: async function () {
      const {
        params: { sceneId },
        path,
      } = this.$route;
      try {
        const menuAllList = await getSenceMenuList();
        const isSceneFilter =
          this.$refs.customSettingsRef.isSceneFilter ||
          localStorageGetItem("isSceneFilter") ||
          "Open";
        const res = menuAllList.filter((i) => i.status === isSceneFilter);
        this.sceneList = res;
        const defaultScenceItem = this.sceneList.filter(
          (i) => i.defaultScence === true
        ); // 本地存储 默认场景信息，为行为动作指令 以新建任务 下发指令，当scenceId 在当前场景下取不到时，使用默认场景信息
        localStorageSetItem("defaultScenceItem", defaultScenceItem?.[0]);
        if (path === "/control-mode") {
          const item = this.sceneList.filter(
            (i) => i.defaultScence === true && i.taskNum !== 0
          );
          if (item.length > 0) {
            const defaultPathId = item[0].id;
            this.$router.push(`/scene/${defaultPathId}`);
          } else {
            const firstDeviceObj = this.deviceList && this.deviceList[0];
            this.$router.push(`/device/${firstDeviceObj?.id}`);
          }
        }
      } catch (error) {
        this.sceneList = [];
      }
    },

    getDeviceList: async function () {
      try {
        const res = await getDeviceMenuList();
        this.deviceList = res;
        // const res = await getDeviceList();
        // this.deviceList = res && res.content;
        store.commit("setDeviceList", this.deviceList);
      } catch (error) {
        this.deviceList = [];
      }
    },
    getMapList: async function () {
      try {
        const res = await getMapMenuList();
        this.mapList = (res || []).map((i) => {
          return {
            ...i,
            mapId: i.id,
          };
        });
      } catch (error) {
        this.mapList = [];
      }
    },
    getSubscribeList: async function () {
      this.subscribeList = await getSubscribeList();
    },
    onClickControlMode: function () {
      this.curIsControlMode = !this.curIsControlMode;
      store.commit("updateIsControlMode", this.curIsControlMode);
    },
    onClickScene: async function () {
      await this.getSenceMenuListData();
    },
    onClickDevice: async function () {
      await this.getDeviceList();
    },
    onClickMap: async function () {
      await this.getMapList();
    },
    onAddMap: function (e) {
      store.commit("addMap", true);
      store.commit("updateCurSubscribe", {
        isShow: false,
        optType: "",
      });
    },
    onClickMapItem: function (i) {
      //查看地图详情，默认放弃添加地图
      this.$router.push(`/map/${i.id}?mapType=${i.type}`);
      store.commit("addMap", false);
      this.closedAddTask();
    },
    onClickDeviceItem: function (item) {
      this.openWebsocket();
      const curDeviceInfo = {
        videoCheckBoxIndex: [],
        videoCheckBox: [],
        videoUrls: [],
        basicInfo: { ...item },
      };

      localStorageSetItem("curDeviceInfo", curDeviceInfo);
      this.$store.commit("saveCurDeviceInfo", curDeviceInfo);
      this.curIsControlMode = this.$store.state.isControlMode;
      this.closedAddTask();
    },

    onClickSubscribeItem: function (i) {
      store.commit("updateCurSubscribe", {
        isShow: true,
        optType: "info",
        obj: i,
      });
      this.closedAddTask();
    },
    onAddSubscribe: function () {
      store.commit("updateCurSubscribe", {
        isShow: true,
        optType: "add",
      });
      store.commit("addMap", false);
      this.closedAddTask();
    },

    onClickScenesItem: function () {
      this.closedAddTask();
    },
    // 更新当前路由 就隐藏任务界面
    closedAddTask: function () {
      store.commit("updateIsTask", {
        isTask: false,
        curTaskInfo: { optsType: "" },
      });
    },
  },
  destroyed() {
    this.sceneList = [];
    this.deviceList = [];
    this.mapList = [];
    this.subscribeList = [];
    store.commit("addMap", false);
    store.commit("updateIsControlMode", false);
    this.curIsControlMode = false;
    store.commit("updateCurSubscribe", {
      isShow: false,
      optType: "",
    });
    if (this.ws) {
      this.ws?.close();
      this.ws = null;
    }
    this.closedAddTask();
  },
};
</script>

<style lang="scss" scoped>
@import "./Index.scss";
</style>
