<template>
  <div class="map_info">
    <NotFound
      v-if="!formData"
      desc="暂无地图信息"
      :image="require('@/assets/img/empty.svg')"
    />
    <div class="map_info_img" v-if="formData">
      <NotFound
        v-if="!pgmImgData && curMapType === '0'"
        desc="暂无地图信息"
        :image="require('@/assets/img/empty.svg')"
      />
      <v-stage
        v-if="curMapType === '0' && pgmImgData"
        class="konva-stage"
        ref="konvaStage"
        :config="konvaConfig.stage"
        @wheel="wheelForScale($event)"
        @touchstart="onStageTouchstart"
        @touchmove="onStageTouchmove($event)"
        @touchend="onStageTouchend"
      >
        <v-layer ref="konvaLayer">
          <v-group :config="konvaConfig.group">
            <v-image
              :config="{
                image: konvaConfig.pgmImage,
                width: konvaConfig.img.width,
                height: konvaConfig.img.height,
              }"
            />
          </v-group>
        </v-layer>
      </v-stage>
      <CesiumViewer
        v-else-if="curMapType === '2'"
        :mapId="curMapId"
        :mapInfo="formData"
        :identifierList="identifierList"
        :metaTaskList="metaTaskList"
        ref="cesiumViewerRef"
      />
    </div>
    <div class="map_info_form" v-if="formData">
      <div class="robot_title map_info_form_header">
        {{ mapTitle }}
        <i
          v-if="mapTitle === '编辑地图'"
          class="el-icon-close"
          @click="onClosed"
        ></i>
      </div>
      <div class="map_info_form_content">
        <MapForm :optType="optType" ref="mapRef" :formData="formData">
          <div v-if="mapTitle === '地图信息'" class="map_form_opts_content">
            <el-button
              type="primary"
              @click="onImport"
              v-if="formData?.type === 0"
              >导入设备</el-button
            >
            <!-- <el-button type="primary" @click="onEdit">编辑</el-button> -->
            <el-button type="danger" @click="onDelete">删除</el-button>
          </div>
          <div v-else class="map_form_opts_content">
            <el-button type="primary" @click="onOk">确定</el-button>
            <el-button @click="onClosed">取消</el-button>
          </div>
        </MapForm>
      </div>
    </div>
    <el-dialog
      title="导入设备"
      :visible.sync="dialogVisible"
      width="200"
      :modal-append-to-body="false"
      :close-on-click-modal="false"
    >
      <div class="import_device_content">
        <el-form ref="form" :rules="rules" :model="form" label-width="100px">
          <el-form-item label="设备选择" prop="deviceIds">
            <el-select
              v-model="form.deviceIds"
              placeholder="请选择"
              multiple
              clearable
            >
              <el-option
                v-for="item in deviceList"
                :key="item.key"
                :label="item.label"
                :value="item.key"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="onCancel">取 消</el-button>
        <el-button type="primary" @click="onImportDevice" :loading="btnLoading"
          >确 定</el-button
        >
      </span>
    </el-dialog>
  </div>
</template>
<script>
import MapForm from "../components/MapForm/Index.vue";
import CesiumViewer from "@/components/CesiumViewer/Index.vue";
import NotFound from "@/components/NotFound/Index.vue";
import { uploadMap, viewMap } from "@/api/map";
import { updateObjFormat } from "@/utils/index";
import GlobalLoading from "@/components/Loading/Loading.js";
import { Message } from "element-ui";
import { isEqual } from "lodash";
import { MapImage } from "@/utils/mapImg.js";
import { getMapInfo } from "@/api/map";
import { getCenter, getDistance } from "@/utils/CoordinatePickupFun.js";
import { strToObj } from "@/utils/index";
import { deleteMap, distributeMap } from "@/api/map";
import { getDeviceAllList } from "@/api/device";
import { getIdentifierList } from "@/api/identify";
import { getSceneMetaTaskList } from "@/api/task";
let timeId;
let lastDist;
let lastCenter;
export default {
  data() {
    return {
      optType: "info",
      mapTitle: "地图信息",
      konvaConfig: {
        stage: {
          width: 1000,
          height: 1000,
          draggable: true,
        },

        group: {
          x: 0,
          y: 0,
        },
        pgmImage: null,
        img: {
          width: 500,
          height: 500,
        },
      },
      pgmImgData: null,
      curMapType: "pgm",
      curMapId: "",
      formData: null,
      dialogVisible: false,
      form: {
        deviceIds: [],
      },
      deviceList: [],
      rules: {
        deviceIds: [
          {
            required: true,
            trigger: ["blur", "change"],
          },
        ],
      },
      identifierList: [],
      metaTaskList: [],
      btnLoading: false,
    };
  },
  components: {
    MapForm,
    CesiumViewer,
    NotFound,
  },
  async mounted() {
    await this.getMapInfo();
    await this.viewMap();
  },
  watch: {
    $route: async function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        await this.getMapInfo();
        await this.viewMap();
      }
    },
  },
  methods: {
    getMapInfo: async function () {
      const res = await getMapInfo(this.$route.params);
      if (res) {
        this.formData = {
          ...res,
          location: strToObj(res?.location, ["jd", "wd", "gc"]),
          level: strToObj(res?.level, ["min", "max"]),
          zoom: strToObj(res?.zoom, ["min", "max"]),
          rectangle: strToObj(res?.rectangle, [
            "west",
            "east",
            "north",
            "south",
          ]),
        };
      } else {
        this.formData = null;
      }
    },
    viewMap: async function () {
      const { mapType } = this.$route.query;
      const { mapId } = this.$route.params;
      this.curMapType = mapType;
      this.curMapId = mapId;
      if (mapType === "0") {
        // pgm
        this.resetData();
        const pgmImageData = await viewMap(this.$route.params);
        this.pgmImgData = pgmImageData;
        if (pgmImageData) {
          this.$nextTick(() => {
            let img = new MapImage(pgmImageData);
            let canvasImg = img.getInitMap("canvas");
            const dom = document.querySelector(".konva-stage");
            this.konvaConfig.stage.width = dom?.clientWidth;
            this.konvaConfig.stage.height = dom?.clientHeight;
            let bili = 1;
            const WC = canvasImg.width > dom?.clientWidth;
            const HC = canvasImg.height > dom?.clientHeight;
            if (HC && !WC) {
              bili = dom?.clientHeight / canvasImg.height;
            }
            if (WC && !HC) {
              bili = dom?.clientWidth / canvasImg.width;
            }
            this.konvaConfig.img.width = canvasImg.width * bili;
            this.konvaConfig.img.height = canvasImg.height * bili;
            this.konvaConfig.pgmImage = new Image();
            this.konvaConfig.pgmImage.src = canvasImg.toDataURL();
          });
        }
      } else {
        // 瓦片图tile
        if (this.$refs?.cesiumViewerRef) {
          this.$refs?.cesiumViewerRef?.resetViewer();
        }
        this.identifierList = await getIdentifierList();
        this.metaTaskList = await getSceneMetaTaskList({ type: 2 });
      }
    },
    wheelForScale: function (e) {
      e.evt.preventDefault();
      const scaleBy = 1.01;
      const stage = this.$refs.konvaStage.getStage();
      const oldScale = stage.scaleX();
      const mousePointTo = {
        x: stage.getPointerPosition().x / oldScale - stage.x() / oldScale,
        y: stage.getPointerPosition().y / oldScale - stage.y() / oldScale,
      };
      const newScale =
        e.evt.deltaY > 0 ? oldScale * scaleBy : oldScale / scaleBy;
      stage.scale({ x: newScale, y: newScale });
      this.$nextTick(() => {
        stage.x(
          (-mousePointTo.x + stage.getPointerPosition().x / newScale) * newScale
        );
        stage.y(
          (-mousePointTo.y + stage.getPointerPosition().y / newScale) * newScale
        );
        stage.batchDraw();
      });
    },
    onStageTouchstart: function (e) {
      const len = e.evt.touches.length;
      if (len >= 2) {
        clearTimeout(timeId);
      } else {
        timeId = setTimeout(() => {}, 50);
      }
    },
    onStageTouchmove: function (e) {
      e.evt.preventDefault();
      const stage = this.$refs.konvaStage.getStage();
      const touch1 = e.evt.touches[0];
      const touch2 = e.evt.touches[1];
      if (touch1 && touch2) {
        this.konvaConfig.stage.draggable = false; // 缩放时，禁掉拖拽，两者冲突会导致缩放失效
        const p1 = {
          x: touch1.pageX,
          y: touch1.pageY,
        };
        const p2 = {
          x: touch2.pageX,
          y: touch2.pageY,
        };

        if (!lastCenter) {
          lastCenter = getCenter(p1, p2);
          return;
        }

        if (!lastDist) {
          lastDist = getDistance(p1, p2);
        }
        const newCenter = getCenter(p1, p2); // 缩放中心
        const newDist = getDistance(p1, p2); // 两指距离
        const pointTo = {
          x: (newCenter.x - stage.x()) / stage.scaleX(),
          y: (newCenter.y - stage.y()) / stage.scaleX(),
        };
        const scale = stage.scaleX() * (newDist / lastDist);
        // 用于子组件的位置更新
        stage.scale({ x: scale, y: scale });
        const dx = newCenter.x - lastCenter.x;
        const dy = newCenter.y - lastCenter.y;
        const newPos = {
          x: newCenter.x - pointTo.x * scale + dx,
          y: newCenter.y - pointTo.y * scale + dy,
        };
        stage.position(newPos);
        // stage.batchDraw();
        lastDist = newDist;
        lastCenter = newCenter;
      }
    },
    onStageTouchend: function () {
      lastDist = 0;
      lastCenter = null;
      this.konvaConfig.stage.draggable = true;
    },
    onImport: async function () {
      this.dialogVisible = true;
      const res = await getDeviceAllList({ matchScence: false });
      this.deviceList = res;
    },
    onEdit: function () {
      this.optType = "edit";
      this.mapTitle = "编辑地图";
    },
    onDelete: function () {
      this.$confirm(
        "是否确认删除地图：" + this.$refs.mapRef.form.name + " ?",
        "删除地图",
        {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        }
      ).then(async () => {
        // 删除接口
        await deleteMap({ id: this.formData?.id });
        this.getMapInfo();
        this.$message({
          type: "success",
          message: "删除成功!",
        });
      });
    },
    onOk: function () {
      if (this.$refs.mapRef) {
        const mapRef = this.$refs.mapRef;
        mapRef.$refs.form.validate(async (valid) => {
          if (valid) {
            try {
              GlobalLoading.loadingShow({ text: "上传中" });
              const params = updateObjFormat(mapRef.form);
              let formData = new FormData();
              for (let key in params) {
                formData.append(key, params[key]);
              }
              await uploadMap(formData);
              this.onClosed();
              Message.success("成功上传地图!");
            } catch (error) {
              GlobalLoading.loadingClose();
            }
          } else {
            GlobalLoading.loadingClose();
            return false;
          }
        });
      }
    },
    onClosed: function () {
      this.$refs.mapRef.resetFormData();
      this.optType = "info";
      this.mapTitle = "地图信息";
    },
    resetData: function () {
      this.optType = "info";
      this.mapTitle = "地图信息";
      this.konvaConfig = {
        stage: {
          width: 1000,
          height: 1000,
          draggable: true,
        },
        group: {
          x: 0,
          y: 0,
        },
        pgmImage: null,
        img: {
          width: 500,
          height: 500,
        },
      };
      // 切换路由 重绘konva
      lastDist = 0;
      lastCenter = null;
      if (this.$refs.konvaStage) {
        const stage = this.$refs.konvaStage.getStage();
        stage.scale({ x: 1, y: 1 });
        stage.position({ x: 0, y: 0 });
        stage.batchDraw();
      }
    },
    onCancel: function () {
      this.dialogVisible = false;
      this.form = {
        deviceIds: [],
      };
    },
    onImportDevice: async function () {
      try {
        this.btnLoading = true;
        await distributeMap({
          mapId: this.formData?.id,
          deviceIds: this.form.deviceIds,
        });
        this.$message({
          type: "success",
          message: `成功导入所选设备!`,
        });
        this.onCancel();
      } catch (error) {
        console.log("导入设备失败");
      } finally {
        this.btnLoading = false;
      }
    },
  },
};
</script>

<style lang="scss" scoped>
@import "./Index.scss";
</style>
