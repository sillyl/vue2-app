<template>
  <div class="drag_video">
    <div class="drag_video_container">
      <NotFound
        v-if="!dataList || dataList.length === 0"
        desc="请勾选想要查看的视频！"
      />
      <draggable class="container" v-model="dataList" @change="dragChange">
        <div
          v-for="(item, index) in dataList"
          :class="['item', 'item_' + index]"
          :key="item.id"
          :style="getStyle(index)"
        >
          <WfsVideo
            :videoCheckBox="videoCheckBox"
            :videoCheckBoxIndex="videoCheckBoxIndex"
            :id="item.id"
            isFull="true"
            :getCurBehaviorData="getCurBehaviorData"
            isShowScreenCapture="true"
          />
        </div>
      </draggable>
    </div>
    <div class="drag_video_bottom">
      <div class="drag_video_bottom_opts">
        <el-row>
          <el-col
            :span="4"
            class="col_nipple col_nipple_left"
            v-if="$store.state.isShowNippleVal"
          >
            <Nipple
              :deviceId="deviceId"
              joystickId="joystickCircle1"
              class="nipple_left"
            >
            </Nipple>
          </el-col>
          <el-col :span="6">
            <div class="start_video">
              <p>开启视频</p>
              <el-checkbox-group
                v-model="dragCheckList"
                @change="onChangeVideoCheckBox"
                :max="3"
              >
                <el-checkbox
                  v-for="(item, idx) in videoUrls"
                  :key="idx"
                  :label="'video' + basicInfo.id + '-' + idx"
                  :title="
                    basicInfo.sn +
                    '(' +
                    basicInfo.name +
                    ')' +
                    '-视频' +
                    (idx + 1)
                  "
                  >{{
                    basicInfo.sn +
                    "(" +
                    basicInfo.name +
                    ")" +
                    "-视频" +
                    (idx + 1)
                  }}</el-checkbox
                >
              </el-checkbox-group>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="video_opts">
              <span> 视频操作</span>
              <el-button type="primary" size="mini" @click="handleScreenshot()"
                >截图</el-button
              >
              <el-button
                type="primary"
                size="mini"
                @click="handleRecording()"
                :icon="recording ? 'el-icon-loading' : ''"
                >{{ recording ? "录制中" : "录制" }}</el-button
              >
            </div>
            <SelectTaskBehavior ref="selectTaskBehaviorRef" />
          </el-col>
          <el-col
            :span="4"
            class="col_nipple col_nipple_right"
            v-if="$store.state.isShowNippleVal"
          >
            <Nipple
              :deviceId="deviceId"
              joystickId="joystickCircle2"
              class="nipple_right"
            >
            </Nipple>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
</template>

<script>
import draggable from "vuedraggable";
import WfsVideo from "@/components/VideoPlay/WfsVideo/Index.vue";
import Nipple from "@/components/Nipple/Index.vue";
import SelectTaskBehavior from "@/components/SelectTaskBehavior/Index.vue";
import NotFound from "@/components/NotFound/Index.vue";
import {
  localStorageGetItem,
  localStorageSetItem,
} from "@/utils/localStorageFun.js";
import dayjs from "dayjs";
import { saveVideo, downloadVideo } from "@/api/video";
import { donwloadFile } from "@/utils/downloadFile";

let mediaRecorder; // MediaRecorder对象
export default {
  name: "DragVideo",
  props: [
    "checkList",
    "dragDataList",
    "videoCheckBox",
    "videoCheckBoxIndex",
    "deviceId",
    "basicInfo",
    "videoUrls",
  ],
  components: {
    draggable,
    WfsVideo,
    Nipple,
    SelectTaskBehavior,
    NotFound,
  },
  data() {
    return {
      dataList: this.dragDataList,
      recording: false,
      curId: "",
      curName: "",
      dragCheckList: this.checkList || [],
      filename: "",
    };
  },
  watch: {},
  mounted() {
    this.curId = this.dataList?.[0]?.id;
    this.curName = this.dataList?.[0]?.name;
  },
  created() {
    let userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
    if (userAgent.indexOf("Firefox") > -1) {
      document.body.ondrop = (e) => {
        //拖拽结束事件
        e.preventDefault(); //阻止浏览器默认行为，主要是为了解决火狐浏览器拖拽完打开新的窗口问题
        e.stopPropagation();
      };
    }
  },
  methods: {
    getStyle: function (idx) {
      const dom = document.querySelector(".situational_content_manual");
      const { width, height } = dom?.getBoundingClientRect();
      switch (idx) {
        case 0: {
          return { width: `calc(100% - ${width}px)` };
        }
        case 1: {
          return {
            width: `${width}px`,
            height: `calc(50% - ${height}px)`,
            top: "0px",
            position: "absolute",
            right: "0px",
          };
        }
        case 2: {
          let domItem1 = document.querySelector(".item_1");
          return {
            width: `${width}px`,
            height: `calc(50% - ${height}px)`,
            top: `calc(50% - ${height}px)`,
            position: "absolute",
            right: "0px",
          };
        }

        default:
          break;
      }
      // return { width: "60%", height: "100%" };
    },

    getCurBehaviorData: function () {
      const { action, target } = this.$refs.selectTaskBehaviorRef;
      return {
        action,
        target,
        scenceId: this.basicInfo?.curScenceId,
        deviceIds: this.basicInfo?.task?.deviceIds || [],
      };
    },

    dragChange: function (data) {
      const moved = data?.moved;
      const element = moved?.element;
      this.curId = element?.id;
      this.curName = element?.name;
    },

    onChangeVideoCheckBox: function () {
      const res = [...this.dragCheckList];
      this.dataList = (res || []).map((i) => {
        return {
          id: i,
          name: this.videoCheckBox[i],
        };
      });
      this.curId = this.dataList[0]?.id;
      this.curName = this.dataList[0]?.name;
      localStorageSetItem("videoCheckList", this.dragCheckList);
    },

    // 截图
    handleScreenshot() {
      const id = this.curId;
      if (!id) {
        this.$message({
          type: "warning",
          message: "请先在开启视频列表勾选想要开启的视频！",
        });
        return;
      }
      const name = this.curName;
      const video = document.querySelector(`#${id}`); // 获取video节点
      const canvas = document.createElement("canvas"); // 创建canvas节点
      const w = window?.innerWidth || video?.clientWidth;
      const h = window?.innerHeight || video?.clientHeight;
      canvas.width = w;
      canvas.height = h; // 设置宽高
      const ctx = canvas.getContext("2d");
      ctx.drawImage(video, 0, 0, w, h); // video写入到canvas
      this.imgUrl = canvas.toDataURL("image/png"); // 生成截图地址
      const time = dayjs(new Date().getTime()).format("YYYY_MM_DD_HH_mm_ss");
      const newName = `${name}_${time}`;
      this.downloadFileByBase64(this.imgUrl, newName);
    },
    downloadFileByBase64: function (base64, name) {
      const myBlob = this.dataURLtoBlob(base64);
      const myUrl = URL.createObjectURL(myBlob);
      this.downloadVideoPng(myUrl, name);
    },

    dataURLtoBlob: function (dataurl) {
      let arr = dataurl.split(","),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      return new Blob([u8arr], { type: mime });
    },

    // 录制
    async handleRecording() {
      let chunks = [];
      const id = this.curId;
      if (!id) {
        this.$message({
          type: "warning",
          message: "请先在开启视频列表勾选想要开启的视频！",
        });
        return;
      }

      const video = id?.slice(5);
      const idx = video.indexOf("-") || 2;
      const deviceId = video.slice(0, idx);
      if (!this.recording) {
        try {
          this.filename = await saveVideo({
            video,
            deviceId,
            flag: 1, // 开始
          });
          this.$message.success("开始录制");
          this.recording = !this.recording;
        } catch (error) {
          throw error;
        }
      } else {
        await this.downloadVideoFile(video, deviceId);
      }
    },

    downloadVideoFile: async function (video, deviceId) {
      try {
        // 结束录制
        await saveVideo({ video, deviceId, flag: 0 });
        this.$message.success("结束录制");
        this.recording = !this.recording;
        try {
          const response = await downloadVideo({
            deviceId,
            filename: this.filename,
          });
          const time = dayjs(new Date().getTime()).format(
            "YYYY_MM_DD_HH_mm_ss"
          );
          const newName = `${name}_${time}.h264`;
          await donwloadFile(response, newName);
          this.$message.success("完成下载");
        } catch (error) {
          throw error;
        }
      } catch (error) {
        throw error;
      }
    },

    downloadVideoPng: function (videoUrl, name) {
      let a = document.createElement("a");
      a.download = name;
      a.href = videoUrl;
      a.style.display = "none";
      document.body.appendChild(a);
      a.click();
      a.remove();
    },
  },
  destroyed() {
    this?.wfs?.destroy();
  },
};
</script>

<style lang="scss" scoped>
.drag_video {
  height: 100%;
  &_container {
    height: 70%;
    border: 1px solid red;
    background: black;
    .container {
      height: 100%;
      .item_0 {
        height: 100%;
      }
    }
  }
  &_bottom {
    height: calc(30% - 20px);
    overflow: auto;
    padding: 10px;
    font-size: 16px;

    &_opts {
      height: 100%;
      .el-row {
        height: 100%;
        .col_nipple {
          height: 100%;
          display: flex;
          justify-content: center;
          align-items: center;

          &_left {
            float: left;
          }
          &_right {
            float: right;
            flex-direction: row-reverse;
          }
        }
      }

      ::v-deep {
        .select_task_behavior {
          margin-right: 10px;
          max-width: 348px;
          .select_task_behavior_content {
            .el-select {
              width: 50% !important;
            }
          }
        }
      }

      .video_opts {
        margin-top: 8px;
        span {
          margin-left: 30px;
        }
        .el-button {
          margin-left: 8px;
        }
      }

      .start_video {
        width: 100%;
        margin-top: 8px;
        .el-checkbox-group {
          display: flex;
          flex-direction: column;
          flex-wrap: nowrap;
          .el-checkbox {
            color: inherit;
            width: 100%;
          }
          ::v-deep {
            .el-checkbox__input {
              top: -14px;
            }
            .el-checkbox__label {
              font-size: 16px;
              line-height: 40px;
              width: calc(100% - 25px);
              display: inline-block;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
            }
            .el-checkbox__inner {
              z-index: inherit;
            }
          }
        }
      }
    }
  }

  .video_player_wfs {
    position: relative;
    top: 0px !important;
    left: 0px !important;
    height: 100%;
    width: 100%;
    border: none;

    ::v-deep {
      .video_player_wfs_header {
        .text_overflow_140 {
          width: 100%;
        }
      }
    }
  }
}
</style>
