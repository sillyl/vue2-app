<template>
  <div class="cmd_content">
    <Operations ref="optsRef" :onSearchFun="onSearch" />
    <div class="cmd_content_table">
      <el-table
        highlight-current-row
        stripe
        :data="cmdData && cmdData.content"
        ref="cmdTableRef"
        height="calc(100% - 37px)"
      >
        <el-table-column
          prop="id"
          label="指令ID"
          :formatter="formatterFun"
          column-key="id"
        >
          <template slot-scope="scope" v-if="scope.row.id">
            <span>{{ scope.row.id }}</span>
            <IconCopy style="margin-left: 10px" :copyData="scope.row.id" />
          </template>
        </el-table-column>
        <el-table-column
          prop="method"
          label="指令方法"
          column-key="method"
          :formatter="formatterFun"
        />
        <el-table-column
          prop="params"
          label="指令参数"
          :formatter="formatterFun"
          column-key="params"
        />
        <el-table-column
          prop="result"
          label="指令结果"
          column-key="result"
          :formatter="formatterFun"
        />
        <el-table-column
          prop="status"
          label="指令状态"
          column-key="status"
          :formatter="formatterFun"
        />
        <el-table-column
          prop="createTime"
          label="创建时间"
          :formatter="formatterFun"
          column-key="createTime"
        />
      </el-table>
      <el-pagination
        style="text-align: right; margin-top: 5px"
        @size-change="onSizeChange"
        @current-change="onCurrentChange"
        :current-page="pageInfo.pageNo"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="pageInfo.pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="pageInfo.totalNum"
      >
      </el-pagination>
    </div>
  </div>
</template>

<script>
import Operations from "./Operations.vue";
import IconCopy from "@/components/IconCopy/Index.vue";
import dayjs from "dayjs";
export default {
  props: ["cmdData", "onSearch"],
  data() {
    return {
      pageInfo: {
        pageNo: 1,
        pageSize: 50,
        totalNum: 0,
        totalPage: 0,
      },
    };
  },

  watch: {
    cmdData: function (newVal, oldVal) {
      if (newVal) {
        this.pageInfo.pageNo = newVal.pageable.pageNumber + 1;
        this.pageInfo.pageSize = newVal.pageable.pageSize;
        this.pageInfo.totalNum = newVal.totalElements;
        this.pageInfo.totalPage = newVal.totalPages;
      }
    },
  },
  components: {
    Operations,
    IconCopy,
  },
  methods: {
    formatterFun(row, column) {
      const { columnKey } = column;
      switch (columnKey) {
        case "params": {
          return JSON.stringify(row[columnKey]) || "-";
        }
        case "createTime": {
          return row[columnKey]
            ? dayjs(row[columnKey]).format("YYYY-MM-DD HH:mm:ss")
            : "-";
        }
        default:
          return row[columnKey] || "-";
      }
    },
    onCurrentChange: function (page) {
      this.pageInfo.pageNo = page;
      this.onSearch();
    },
    onSizeChange: function (size) {
      this.pageInfo.pageSize = size;
      this.onSearch();
    },
  },
};
</script>

<style lang="scss" scoped>
@import "./Index.scss";
</style>
