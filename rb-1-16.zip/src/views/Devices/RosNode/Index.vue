<template>
  <div class="ros_node_table" v-if="rosNodeData.length > 0">
    <el-button type="primary" @click="onSaveBtnClick">启用节点</el-button>
    <el-table
      highlight-current-row
      stripe
      :data="rosNodeData"
      ref="rosNodeTableRef"
      height="100%"
      v-loading="tableLoading"
      :cell-style="cellStyle"
      :header-cell-style="cellHeaderStyle"
      @selection-change="selectChange"
      size="small"
    >
      <el-table-column
        prop="name"
        label="节点名称"
        :formatter="formatterFun"
        column-key="name"
      />
      <el-table-column
        prop="type"
        label="节点类型"
        column-key="type"
        :formatter="formatterFun"
      />
      <el-table-column type="selection" width="42" align="center">
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import { getRosNode, enableNode } from "@/api/node";
import { rosNodeStatus } from "../constants/index.js";
export default {
  props: ["deviceId"],
  data() {
    return {
      rosNodeData: [],
      tableLoading: false,
      selectionList: [],
    };
  },

  mounted() {
    this.getTableData();
  },

  methods: {
    getTableData: async function () {
      try {
        this.tableLoading = true;
        this.rosNodeData = await getRosNode();
      } finally {
        this.tableLoading = false;
      }
    },

    formatterFun(row, column) {
      const { columnKey } = column;
      switch (columnKey) {
        case "type":
          return rosNodeStatus[row[columnKey]] || "-";
        default:
          return row[columnKey] || "-";
      }
    },

    selectChange(selection, row) {
      this.selectionList = selection;
    },

    cellStyle: function () {
      return "background-color: #2e4552; color: #000";
    },

    cellHeaderStyle: function () {
      return "background-color: rgb(100 169 209); color: #000";
    },

    onSaveBtnClick: async function () {
      if (this.selectionList?.length === 0) {
        this.$message({
          type: "warning",
          message: "请先勾选需要启用的节点!",
        });
        return;
      }
      const names = this.selectionList.map((i) => i.name);
      await enableNode({
        id: this.deviceId,
        nodeNames: names,
      });
    },
  },
};
</script>

<style lang="scss" scoped>
@import "@/assets/css/common.scss";
.ros_node_table {
  height: calc(100% - 216px);

  .el-button {
    float: right;
    margin-bottom: 8px;
    padding: 9px 18px;
  }

  .el-table {
    height: 100%;
    background-color: $bg-color;
    border-top: 1px solid #fff;
  }
}
</style>
