<template>
  <div
    class="pgm_konva"
    id="pgmContainer"
    :style="{
      height: $store.state.isCollapse ? '100%' : 'calc(100% - 22px)',
    }"
  >
    <v-stage
      class="konva-stage"
      ref="konvaStage"
      :config="konvaConfig.stage"
      @click="onStageClick"
      @wheel="wheelForScale($event)"
      @touchstart="onStageTouchstart"
      @touchmove="onStageTouchmove($event)"
      @touchend="onStageTouchend"
      v-if="pgmData"
    >
      <!--  @dragstart="onDragstart"
      @dragmove="onDragmove"
      @dragend="onDragend" -->
      <v-layer ref="konvaLayer">
        <v-group :config="konvaConfig.group">
          <v-image
            :config="{
              image: konvaConfig.pgmImage,
            }"
          />
        </v-group>
        <!-- websoket 实时路线数据 -->
        <v-group :config="konvaConfig.group">
          <v-line
            v-for="(item, index) in konvaConfig.path"
            :key="index"
            :config="{
              points: sn ? item.groupLine : item,
              stroke: item?.color || '#ffff00',
              strokeWidth: 6,
              lineCap: 'round',
              lineJoin: 'round',
            }"
          >
          </v-line>
        </v-group>
        <v-group :config="konvaConfig.group">
          <v-circle
            v-for="(item, index) in konvaConfig.curPoint"
            :key="index + 3000"
            :config="{
              x: item.x,
              y: item.y,
              radius: 8,
              fill: item?.color || '#ffff00',
              stroke: 'black',
              strokeWidth: 3,
            }"
          >
          </v-circle>
          <v-arrow
            v-for="(item, index) in konvaConfig.curPoint"
            :key="index + 2000"
            :config="{
              x: item.x,
              y: item.y,
              points: [
                0,
                0,
                50 * Math.cos((item.omega * Math.PI) / 180),
                50 * Math.sin((item.omega * Math.PI) / 180),
              ],
              pointerLength: 30,
              pointerWidth: 10,
              fill: item?.color || '#ffff00',
              stroke: 'black',
              strokeWidth: 3,
            }"
          >
          </v-arrow>
        </v-group>
        <!-- 点云? -->
        <v-group :config="konvaConfig.group">
          <v-circle
            v-for="(item, index) in konvaConfig.cloudPoints"
            :key="index + 4000"
            :config="{
              x: item.x,
              y: item.y,
              radius: 4,
              fill: '#0000ff',
            }"
          >
          </v-circle>
        </v-group>
        <!-- 导航点交互 -->
        <v-group :config="konvaConfig.group">
          <v-line
            v-for="(item, index) in konvaConfig.polyline"
            :key="index + 1000"
            :config="{
              points: isDetail ? item.groupLine : item,
              stroke: item.color || '#ff0000',
              strokeWidth: 6,
              lineCap: 'round',
              lineJoin: 'round',
            }"
          >
          </v-line>
        </v-group>
        <v-group :config="konvaConfig.group">
          <v-circle
            v-for="(item, index) in konvaConfig.points"
            :key="index"
            :config="{
              id: index,
              x: item.x,
              y: item.y,
              radius: 8,
              fill: item?.color || '#ff0000',
            }"
          >
          </v-circle>
        </v-group>
        <v-group :config="konvaConfig.group">
          <v-arrow
            v-for="(item, index) in konvaConfig.points"
            :key="index + 99"
            :config="{
              id: index,
              x: item.x,
              y: item.y,
              points: [
                0,
                0,
                50 * Math.cos((item.omega * Math.PI) / 180),
                50 * Math.sin((item.omega * Math.PI) / 180),
              ],
              pointerLength: 30,
              pointerWidth: 10,
              fill: item?.color || '#ff0000',
              stroke: 'black',
              strokeWidth: 3,
            }"
          >
          </v-arrow>
        </v-group>
        <!-- 区域点交互 -->
        <v-group :config="konvaConfig.group">
          <v-line
            v-for="(item, index) in konvaConfig.polygon"
            :key="index"
            :config="{
              id: index,
              points: optsType === 'seleted' ? item.groupPolygon : item,
              stroke: item.color || '#ff0000',
              strokeWidth: 6,
              lineCap: 'round',
              lineJoin: 'round',
              fill: item.color || '#ff0000',
              opacity: 0.5,
              closed: true,
            }"
          >
          </v-line>
        </v-group>
        <v-group :config="konvaConfig.group">
          <v-circle
            name="area_circle"
            v-for="(item, index) in konvaConfig.areaPoints"
            :key="index"
            :config="{
              id: item.x + '_' + item.y,
              x: item.x,
              y: item.y,
              radius: 8,
              fill: item.color || '#ff0000',
            }"
            :draggable="
              optsType === 'add' || optsType === 'update' ? true : false
            "
            @dragstart="onDragAreaPointStart"
            @dragend="onDragAreaPointEnd"
          >
          </v-circle>
        </v-group>
      </v-layer>
    </v-stage>
    <NotFound
      v-if="!pgmData"
      desc="暂无地图信息"
      :image="require('@/assets/img/empty.svg')"
    />
    <CoordinatePickup
      :isShow="isShow"
      :visible="visibleCircleTooltip"
      :triggerPosition="triggerPosition"
      :circleNeedData="circleNeedData"
      ref="circleTooltipRef"
      @saveCircleTooltipData="saveCircleTooltipData"
      @deleteCircleTooltipData="deleteCircleTooltipData"
      :isInitPickUp="isInitPickUp"
      :onSaveInitPickup="onSaveInitPickup"
    />
    <AttributeForm
      v-if="isAttributeForm"
      :artFormTop="artFormTop"
      :artFormLeft="artFormLeft"
      :identifierList="identifierList"
      :metaTaskList="metaTaskList"
      :onArtFormDelete="onArtFormDelete"
      :onArtFormSave="onArtFormSave"
      :TaskDetailData="TaskDetailData"
    />
  </div>
</template>
<script>
let timeId;
let lastDist;
let lastCenter;
import CoordinatePickup from "@/components/CoordinatePickup/Index.vue";
import AttributeForm from "../AttributeForm/Index.vue";
import GlobalLoading from "@/components/Loading/Loading.js";
import {
  getMinPoint,
  getKonvaConfigByObj,
  getCenter,
  getDistance,
  getObjXY,
} from "@/utils/CoordinatePickupFun.js";
import { isEqual, isEmpty, cloneDeep } from "lodash";
import { viewMap } from "@/api/map";
import { MapImage } from "@/utils/mapImg.js";
import { getIdentifierList } from "@/api/identify";
import { getSceneMetaTaskList } from "@/api/task";
import NotFound from "@/components/NotFound/Index.vue";
import { stepPgmLineSegment } from "@/utils/geoposition.js";
import { UvToWorld, worldToUv } from "@/utils/mapWorldUvConversion";

export default {
  props: [
    "mapId",
    "wsData",
    "isInitPickUp",
    "onSaveInitPickup",
    "isSceneName",
    "deviceId",
    "buildMapping",
    "taskInfoRow",
    "curMethod",
    "selectionList",
  ],
  data() {
    return {
      pgmData: null,
      konvaConfig: {
        stage: {
          width: 1000,
          height: 1000,
          // draggable: true,
        },
        group: {
          x: 0,
          y: 0,
        },
        pgmImage: null,
        points: [],
        polyline: [],
        polygon: [],
        areaPoints: [],
        path: [],
        curPoint: [],
        cloudPoints: [],
      },
      visibleCircleTooltip: false,
      triggerPosition: {
        layerX: 0,
        layerY: 0,
        clientX: 0,
        clientY: 0,
        pageX: 0,
        pageY: 0,
      },
      threshold: 0.01,
      isTouchStart: false,
      isTouchmoveing: false,
      metaTaskList: [],
      identifierList: [],
      selectPoint: { location: { omega: 0 }, process: [], station: [] },
      stagePointerPosition: {
        x: 0,
        y: 0,
      },
      stageScale: 1,
      // 插入节点的最大数量（包括已删除的），这是个递增值
      historyMaxnodeNum: 0,
      points: new Map(),
      areaPoints: [],
      isDraging: false,
      startDragData: null,
      diffLayerX: 0,
      diffLayerY: 0,
      diffClientX: 0,
      diffClientY: 0,
      diffPageX: 0,
      diffPageY: 0,
      cvsW: null,
      cvsH: null,
      isDetail: false,
      isShow: true,
      method: "",
      optsType: "",
      isAttributeForm: false,
      artFormTop: 0,
      artFormLeft: 0,
      infoAreaPoints: [],
      attributeFormData: [],
      curDragAreaPoint: null,
      sn: false,
      timeId: null,
      mapWs: null,
      curPath: [], //用于存储device 详情页 device-pose path数据
      pixelX: null, // x方向像素大小
      pixelY: null, // y方向像素大小
      originX: null, // 原点坐标x
      originY: null, // 原点左边y
      resolution: null, // 分辨率
      curMethoded: this.curMethod,
    };
  },
  computed: {
    circleNeedData() {
      return {
        stage: {
          width: this.cvsW,
          height: this.cvsH,
        },
        points: this.points,
        threshold: this.threshold,
        id: "pgmContainer",
        isTouchStart: this.isTouchStart,
        isTouchmoveing: this.isTouchmoveing,
        form: {
          omega: 0,
          identifierList: this.identifierList, // 目标物
          metaTaskList: this.metaTaskList, // 动作
          selectPoint: this.selectPoint, // 选择点
        },
        stagePointerPosition: this.stagePointerPosition,
        stageScale: this.stageScale,
        isDraging: this.isDraging,
        diffLayerX: this.diffLayerX,
        diffLayerY: this.diffLayerY,
        diffClientX: this.diffClientX,
        diffClientY: this.diffClientY,
        diffPageX: this.diffPageX,
        diffPageY: this.diffPageY,
      };
    },
  },
  components: {
    CoordinatePickup,
    NotFound,
    AttributeForm,
  },
  async mounted() {
    await this.getCircleData();
    this.replaceWsData(this.wsData);
  },
  watch: {
    mapId: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.getCircleData();
      }
    },
    $route: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.getCircleData();
      }
    },
    wsData: function (newVal, oldVal) {
      this.replaceWsData(newVal);
    },
  },
  methods: {
    replaceWsData(arr) {
      // console.log("arr", arr);
      this.konvaConfig.curPoint = [];
      this.konvaConfig.path = [];
      this.konvaConfig.cloudPoints = [];
      for (let k = 0; k <= arr?.length; k++) {
        const data = arr[k];
        const travel = data?.travel;
        const cloud = data?.cloud;
        const color = data?.color;
        const sn = data?.sn;
        let pointArr = [];
        let item = {};
        if (!isEmpty(travel) && this.cvsW && this.cvsH) {
          const { location } = travel;
          for (let i = 0; i < location?.length; i++) {
            let lct = location[i];
            const curX = Math.round(this.cvsW * Math.abs(lct.x));
            const curY = Math.round(this.cvsH * Math.abs(lct.y));
            const len = this.konvaConfig.path?.length;
            let lastX = 0;
            let lastY = 0;
            if (len > 2) {
              if (sn) {
                const lastGroupLine =
                  this.konvaConfig.path?.[len - 1]?.groupLine;
                lastX = lastGroupLine?.[0];
                lastY = lastGroupLine?.[1];
              } else {
                lastX = this.konvaConfig.path?.[len - 2];
                lastY = this.konvaConfig.path?.[len - 1];
              }
            }

            if (stepPgmLineSegment(lastX, lastY, curX, curY)) {
              pointArr.push(curX, curY);
            }

            item = { x: curX, y: curY, omega: lct.omega, color };
          }
          if (sn) {
            // 组
            const idx = this.konvaConfig.path.findIndex((j) => j.sn === sn);
            if (idx === -1) {
              this.konvaConfig.path.push({
                sn,
                color,
                groupLine: pointArr,
              });
            } else {
              this.konvaConfig.path[idx] = {
                sn,
                color,
                groupLine:
                  this.konvaConfig.path[idx]?.groupLine.concat(pointArr),
              };
              this.sn = true;
            }
            const index = this.konvaConfig.curPoint.findIndex(
              (i) => i.sn === sn
            );
            if (index === -1) {
              this.konvaConfig.curPoint.push({
                sn,
                ...item,
              });
            } else {
              this.konvaConfig.curPoint[index] = {
                sn,
                ...item,
              };
            }
          } else {
            // 单个设备数据
            this.sn = false;
            if (pointArr?.length > 0) {
              this.curPath = this.curPath.concat(pointArr);
              this.konvaConfig.path = [this.curPath];
            }
            this.konvaConfig.curPoint = [item];
          }
        }

        if (!isEmpty(cloud)) {
          for (var i = 0; i < cloud?.location.length; i++) {
            const lct = cloud?.location[i];
            const curX = Math.round(this.cvsW * Math.abs(location.x));
            const curY = Math.round(this.cvsH * Math.abs(location.y));
            const item = { x: curX, y: curY };
            this.konvaConfig.cloudPoints.push(item);
          }
        }
      }
    },
    onDragstart: function (el) {
      this.isDraging = true;
      const { layerX, layerY, clientX, clientY, pageX, pageY } = el.evt;
      this.startDragData = {
        xL: layerX,
        yL: layerY,
        xC: clientX,
        yC: clientY,
        xP: pageX,
        yP: pageY,
      };
    },
    onDragmove: function () {
      this.visibleCircleTooltip = false;
    },
    onDragend: function (e) {
      const { xL, yL, xC, yC, xP, yP } = this.startDragData;
      const { layerX, layerY, clientX, clientY, pageX, pageY } = e.evt;
      this.diffLayerX = layerX + this.diffLayerX - xL;
      this.diffLayerY = layerY + this.diffLayerY - yL;
      this.diffClientX = clientX + this.diffClientX - xC;
      this.diffClientY = clientY + this.diffClientY - yC;
      this.diffPageX = pageX + this.diffPageX - xP;
      this.diffPageY = pageY + this.diffPageX - yP;
    },
    getCircleData: async function () {
      try {
        // GlobalLoading.loadingShow();
        // if (this.timeId) {
        //   await this.clearTimeoutData();
        // }
        if (this.mapWs && !this.$store.state.isTask) {
          this.closeMapWebsoket();
        }
        await this.viewMap();
        await this.getCircleNeedDataList();
      } catch (error) {
        // GlobalLoading.loadingClose();
      } finally {
        // GlobalLoading.loadingClose();
      }
    },
    getCircleNeedDataList: async function () {
      this.identifierList = await getIdentifierList();
      this.metaTaskList = await getSceneMetaTaskList({ type: 2 });
    },
    viewMap: async function () {
      if (this.isSceneName || this.buildMapping === true) {
        await this.wsMapWs();
      } else {
        if (this.mapId) {
          await this.resetData();
          try {
            const pgmImageData = await viewMap({
              id: this.mapId,
            });
            this.pgmData = pgmImageData;
            if (pgmImageData) {
              let img = new MapImage(pgmImageData);
              let canvasImg = img.getInitMap("canvas");
              const dom = document.querySelector(".konva-stage");
              // this.konvaConfig.stage.width = dom.clientWidth;
              // this.konvaConfig.stage.height = dom.clientHeight;
              this.konvaConfig.stage.width = canvasImg.width;
              this.konvaConfig.stage.height = canvasImg.height;
              this.cvsW = canvasImg.width;
              this.cvsH = canvasImg.height;
              this.konvaConfig.pgmImage = new Image();
              this.konvaConfig.pgmImage.src = canvasImg.toDataURL();
            }
          } catch (error) {
            console.log("map error----", error);
          }
        }
      }
    },

    wsMapWs: function () {
      const mapWsUrl = `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/map/${this.deviceId}`;
      this.mapWs = new WebSocket(mapWsUrl);
      this.mapWs.onopen = () => {
        console.log(`${mapWsUrl}----连接成功---`);
        /* mock png base64 */
        // const base64Str_0 =
        //   "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAfQAAAH0CAAAAADuvYBWAAAEiElEQVR4nO3RQQ3AMBDAsLZYx2pgNxbXR2wEkbLfZxGzv9sFjDu3A5hnepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5kepDpQaYHmR5ketAPe20F5ThHtFsAAAAASUVORK5CYII=";

        // const base64Str_1 =
        //   "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAfgAAAJoCAAAAACvzax9AAAFrElEQVR4nO3asQ0DIRAAQfO1fln0ikt4O7Cw2Jn4gpNWR8RYLw4x7y+Gh/BN1+4F2EP4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4KOGjhI8SPkr4E83nkbF+vwZ/yMVHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcKfZ37wAccPnCPN+3FE+ChPfZTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfJTwUcJHCR8lfNQ1d2/AFi4+aqzdG7DFG9WhDzXUsKxNAAAAAElFTkSuQmCC";
        // const base64Str_2 =
        //   "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABUoAAAqeCAAAAABlMzCYAAAvYElEQVR4nO3dW3LbRrtAUdjloWJW6bkqD7raAkmAmyBFcq1TlTiy/YdHira/RjfAXy8TwBMb8wX+R35JKUD1+9YvAOD+SSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCvsZt34BXIu7nQAyUykcYKRkPVMpQGYqBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcik9EY8wA0eiYfsAWSmUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBTu0bj1C+Bvv15u/QoA7p6pFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFO6TZ0P9KFIKd2yppxp7Cx6yBw9nzLd+Bc9HSgEyC3yATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQU4NU4/7dKKcCUOjpN06+XC70MgOdlKgWYpmkaZTA1lQJkplKATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgGmKb+7kKfoAmakUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBTgwzjz90kpwIf5zJj+ernwCwF4PqZSgC/Om0qlFODTmM/6bRb4AJmpFCCTUoBMSgEyKQXIpBQgk1KATEoB3p17C75zpQCdqRTgw7ljqakUIDOVAmRSCpBJKcAH10oBbsZUCpBJKUAmpQCZlAK8c+MowO2YSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFODTmXfhuwcfIDOVAmRSCpBJKcAn10oBbsVUCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQBfnfXEUikFyDz6GSAzlQJkUgrwxXlv7mSBD5CZSgEyKQXIpBQgk1KAr8Y5G0+2nQAyUylAJqUAmZQCfOVaKcBtmEoBMikFyKQU4C+ulQLchKkUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATErhjp31aE124B58gMxUCnfNWPozSClAZoEPkJlKATIphTvnaulPIKVw38Z861fA5FopwAWYSgEyKQXIpBQgk1KAr846EmHbCSAzlQJkUgqQSSnAV66VAtyGqRQgk1KATErhznky1E8gpXDnlp8MNST2qqQU7t5yNOdpGFmvRkrh7n2fS8c0L36cvTgMBQ9g8fnPQ0uvR0oBMgt8gExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFWDA2/epfLzu9DIDnYSoFyKQUIJNSgExKARaMTftOUgqwZN7yi6UUIJNSgAWzBT5ANSzwAaptU6m7nQAyUylAJqUAmZQCLLGDD5Bt2neSUoAFY9PtTlIKsMARfYArc64UIDOVAizbsMT/s9+rALhjm/adLPABMgt8gExKARY5og9wVa6VAmSmUoAlY8sK31QKsGjLW5JIKUBmgQ+QSSlAJqUAmZQCZFIKkEkpQCalAJmUAizyOBOAasvNTlIKsGjTW45KKUD2e9NbPQM8jU0L/C2/GOB5bBk0PRkKIHOtFCCTUoAlmzaSLPABMlMpQCalAJmUAizzjqMA12QqBcikFCCTUoBMSgGW2XYCuCZTKUAmpQCZlAJkUgqQ/d72ICkAvrODD5B5mzyAzFQKkJlKATJTKUDmMBRAJqUAmZQCZFIKkEkpwAHrTzjZwQfITKUAmZQCZL83vX0JAAtcKwXILPABMikFyDxFHyBzrRQgs8AHyKQUIJNSgGUbdpJcKwXITKUAmZQCZFIKkHmcCUBm2wkgs8AHyKT0MblqA1clpQCZbSeAzLYTQGaB/6CsNeCaTKUA2Z9bvwB2MuYxzR8/fv/BNE3TNH/9EHABFviPah7T/LbKf8vmmKa3jI7PygKXIKUPa57/uV46T2P+MpcCl+Na6VMZk5jCHqT0+Vjdw8X9erEDARC5VgqQ/TaUAlSulQJkHmcCsGxDHH87FgNwwOqYWuADHLB+J8kOPsAhq6dSKQU4YP3lz9+TfSeAResX+K6VAmQW+ACHuFYKUFngA1yRqRTgkC0LfBv4AIss8AGuxwIfIJNSgEM8zgTgekylAJkdfIDMAh8gs8AHyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBTgEG+TB9Ctbal78H+89e95CNyKqfTHm6e3PxnH+989ywuuxAL/Tv37hXv75/n1L18GVDmFK1i9JpTS78Zff/vnhyd/29KvPvL7v/6uj3FzjDHGNE1jzO8fHtN4+7KO+eOHwA/xe5pMON+Nv2M1v6bsLWnj49d8pG+apjG/r8Ln8e8SfJ6+RPLLp3tM03sr3377WyznaX7913/MofPb6xmvLbXIh2vYssAfzzbhjOnr5PllFHz/2xhffu5LLue3z9V4vWw5f/ym92nx7YPz/O0zOn9ZqX/+5Hsu5zHN00c+p/k93q8fmOcvX9CPK6f+AISf5OXl5b+XZ/Hf2/+z//338YHPH31+4L+///Hjp19/2+tH/lv6rG39TP738vVf9v11Hv6Nz/M1g7vw6+V+T9v8+7rHNI/5bVicP37N29g43n/u9SPz11/y+Rvefjzmw5+TMX/+9eJW/s8+3UICfrr7O1f6dRf7/fLhaymnMY9pfrv+uNCaxUB+6/G88MGfR0zhKtbG4C6m0tfBcrxdMvyYH8frxcvxeQ3zraM//f8f4E6szsmvlxuV9PPf+h7FtzX3mL78w/uvGNP7zs08ps/h8stqftd1N/CcVidlpwX+t3//93X0+FiVf35w+hg+/77g+f0PhvfDldoJ/AAXTOnJfE7vw+ZfFy3H/PnhA9O0XgI/2x5T6VsWlxM4Jitx4E6sLtWmu50O/LovZ9zH+77QPP6dMN/PqL9+UEmBn29eW8cNO/j//LJD+zzmTeBhrA3ahseZzEv/+P1fM7ujEXg266+Vfh7pBOAvv6eVjxJWUuD5rF1k/55WFnJWUoAD/qz+lUIKPJ0b3+0E8Ey8IQlAJqUAB23ZdgIgWX0YCoBDVh+GAng+Wx5n4q55gOT3tOHZJwAsse0EkDmiD5BtevQzAEtMpQCZa6UA2WtKrfABgtdrpQ6WAgS/p8nBUoDGthNA5jAUQGYqBcgchgLIpBTgsJXXP6UU4KC1R0VtOwEctPaoqLudALI/0+QdSQCWbXrHUe+TB1B4byeAg+YN206zFT7AkrFyiW/bCeCgtTv4bhwFyBzRBzjM3U4A12KBD5DZdgLIXlPqHUkAlrhWCpBteTKU+50AClMpwBFb7nYCYMnKNbuUAhy26VopAMHbYagbvwqAn8lhKIBr+fUyTdMwlwIE7sEHyNyDD5C9vk3erV8FwM+07Sn67hwFOJ9rpQCZa6UAh40t9+Bb3gMEFvgAmbudADLXSgEyC3yA7G2BbywFOJ8FPkD2NpU6DQVwPjv4ANnbEX0rfIDz2cEHyOzgA2SulQJkUgqQSSlAJqUAmR18gOx9B98WPsDZ3hf47hwFOJtrpQDHrFqzu1YKkL1Ppa6VApzNVAqQuQcfIHt/9LOWApzNVApwzKo8OlcKcMRYVUfnSgGOWDdnSinAMZsW+AAsWTWWOlcKcNhYl1JTKcAR266VOg0F8N3K003v50odhgI4m2ulAJmn6ANktp0AMikFyN6fDHXbVwFw1zwZCiCzgw+QOaIPcMS6802mUoDMDj7AEeuW7I7oA2QW+ACZBT5AZgcfIPOOowDHbHpvJ/tOAAvGvKaOf97+bioFWLQmj3bwAY5Z9UZ5dvABjlj3lqPvU+nKNygF4DsLfIBjVr2LqJQCZI7oA2Qf205aCnCuj5TadQI4l2ulAJkbRwEyR/QBMgt8gMwCHyAzlQJkjugDZKZSgMzdTgCZw1AAmQU+QGaBD5BZ4ANkFvgAmakUIHOtFCD7fPSzlgKcybVSgMy1UoDMtVKAzFQKkLlWCpCZSgGyz5S6WApwJgt8gMwCHyCTUoBMSgEyKQXIPu92soMPcCY7+ACZqRQgc60UIPtM6XzDVwFw10ylAJmUAmR28AEyUylAJqUAmZQCZN4mDyAzlQJkdvABMvfgA2QfKXXfKMC5bDsBHLWmjn/ef2AqBTjXx7bTEFOAM9nBB8g+z5W6WAqwYM35Jkf0AY5ac/FTSgGOW9FSh6EAjlqzwLftBJBZ4AMct2nbyQofYMGmu50AWLJtB9/NTgBLbDsBXINtJ4BMSgEyO/gAmWulAJkFPkAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQObGUYDMjaMAx43Tz3O2wAc44fST8U2lAJmpFCCTUoBMSgEyKQXIpBQgk1KA7EtK3e4EsGBFHJ0rBThhuNsJYH+mUoDsy5OhXCsFOM9nSk/frw/AItdKATLXSgEyUylAJqUAmZQCZG4chYfje/n6vk6lPv/wAFa8pxsX9zWlPv/wAGa321zc6U+pa6XwYE4/eoOt5pOfU+dK4dFY4d+AbSd4ML6TL+/05/RLSv1BBo/Ad/ItWODDg3Gt9BZsO8GDUdId2MEH2J+UwqNxrvTivLcTwBXYdgLITKUAmZQCZFL68GxBwP5cK31wY3LOEPbneaUPbhZSuALPK314biN8Pqai63OtFB6OPz2vzwL/8fm6Ph1f8uuzwH98vq5PZ9bSq/v66GeffoCzePQzPBxbjdfnXClAZgf/0bluA1dgKgXITKUAp5xc3JlKATJTKUDmbieAzN1OD8+fkLA/10oBMgt8gJNO5dFUCpDZwX901hrQOVcKsL+/plIDDMCCk8+y+CulTkMBLDgZR9dKH92Yxlj4E3VMw1OjYLVTLXUY6uGN+a//CMZ47eiYxRRWcxiK714zOk2Tizqwyjj1rSKlz2tMs7eugMuQUoDMthNAJqUAJ9l2AtidqRTgpE13OwFwDikFyKQUIJNSgExKATIpBTjFU/QB9mcqBTjJ3U4AuzOVApzkbieA3UkpwGknxlIpBTjNG5IA7M1UCnCSw1AAuzOVAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKcNqJO0fdOAqQmUoBMikFyKQUIJNSgNNsOwHszVQKcJq3yQPYm5QCnOS9nQB2ZyoFOM21UoC9WeADZKZSgExKATIpBTjNjaMAezOVAmRSCpBJKUAmpQArHN93su0EkJlKATIpBThtWOAD7MxUCnCau50A9mYqBVjBtVKAnZlKAU7zhiQA2WyBD7AzUynACsenUikFOG3MR3/aAh8gM5UCnGYHHyA7sYMvpQCZa6UAmakUIJNSgBXc7QSwM1MpQCalAJmUAmRSCpBJKUAmpQCnjeOnoRyGAljh+FP2pBQgs8AHWMHdTgA7M5UCrDCOjqVSCrCGbSeAfZlKATIpBcikFCCTUoBMSgEyKQXIpBRgBTeOAuzMVAqQSSnACscX+FIKkEkpwAqzNyQB2JepFGANUynAvkylAGt4ij5A5c2bAXZmKgVYw7YTwL5MpQBr2HYC2JcFPkBmKgXIpBRgBU/RB9iZqRRgDTv4APuSUoBMSgEyKQXI7OADZKZSgExKAdbwkD2AfZlKATIpBVjD3U4A+5JSgExKAdaYj63wpRQgk1KANcZ85CedKwXITKUAmZQCZFIKsIYj+gD7su0EkJlKAVZxRB9gV1IKkEkpQGbbCSAzlQJkUgqQSSlAJqUAmZQCZFIKsIq7nQB2JaUAmSP6AJmpFGCVY9dKTaUAmakUYJ0jY6mUAqwy5sM/J6UAq8xHplLXSgEyUylAJqUAmZQCZFIKkEkpQCalAJmUAqzjXCnAnkylAJmUAmRSCrCOa6UAezKVAqwyTKUAezKVAmRSCpBJKUAmpQCZlAJkUgqwypGzUA5DAXSmUoBMSgHWObLCl1KAzLVSgMxUCpBJKUAmpQDreMgewJ5MpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalACuNgz8jpQDZr5dbvwKAu2cqBcikFGCtgxdLpRQgk1KAlcZ86GekFCCzgw+QmUoB1rLtBFC52wkgO7jr5FopQGcqBVjr4ArfVAqQmUoBMikFyKQUIJNSgExKATIpBVjLjaMA+5FSgMwRfYDMVAqQSSlAJqUAmZQCZFIKkEkpQCalAKsdut3JuVKAzFQKkEkpwGqHFvhSCpC5VgqQmUoBMikFyKQUIJNSgExKATIpBcikFB7YGIffI5NzHPp0/rnqqwCuap6m+dav4TmYSuFxmUkv7tCfTO52goc15jEZS69DSuFxDR29uLH8KbXAh4dldX95B0oqpfDA5llNL8y1UoDdmErhYdnAvx4phYdleX953iYPno4N/OuRUoDMAh8elvX99UgpPCzXSq9HSgEyKWWaJkvBB2XX6Wqk9EmNt7+OaYzXp1qK6SPyVb0WO/jPY3wZUsY8pvn9uUHv325GmEdz6H5xLk9Kn8eYpo9cjtn32TMY/oC8Fgv8J/Llierz5HvsCSjp9Ujp85jH7Pvq2TgOdS0W+M/Dgv75uHP0akyl8NCMpZd16KiLlMJDM5ZemKfoPz3fU09nTKbSSzv0bSSl8Lj88Xk1tp0AMlMpQCalAJmUAmRS+jxs5cJubDsBZKZSgExKn4eHO8NuLPABMlMpQCalz8P6HnYjpU9ES2EvUvokhpDCjqT0OSgp7MoO/rPw1hSwIyl9Gt59EvYjpc9jTGIKO3Gt9Hl462bYjakUIDOVAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUA2YGUeowQwHrudgLILPABMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBNhhj6aNSCrDBvPhRKQXYYCy29NfLtV8HwMMxlQJkUgqQSSnABosb+K6VAnSmUoBMSgEyKQXYYvFiqWulAJmpFCCTUoANlg9DSSnABrNrpQD7MJUCbLI0lppKATJTKUAmpQBbeEMSgMphKIBs+b2dbDsBZKZSgA1WLfCXfxEAr5bvdvonpctXAQA4xrVSgMy1UoDMtVKAzAIfILPAB9hg3d1OVvgAR7jbCWAnFvgAm3j0M8AuTKUAmZQCZFIKsMnStVIpBcikFGCLsXSy1A4+QGYqBdhirLlW6sZRgM0s8AEyC3yATSzwAbKlHfx/U+p98gCOckQfoHKuFGAfplKATSzwAXZhgQ+QOQwFkDkMBbCJa6UAlcNQAPswlQJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJu42wlgF1IKsM3CWOrJUADbLNyE78lQAJkFPkAmpQCZlAJsMi/sKXleKUBmKgXIpBQg+5ZSB0sBtjKVAmRSCrDJ0trdDj5A5lopQGaBD5B9S6nnmQAc41opwC4s8AEyKQXI7OADZK6VAmSmUoDMVAqQ2XYC2MS5UoBdmEoBtvHeTgB7MJUCbDO+j6WmUoDMVAqQSSnAJg5DAXTj+4OdpRQgs8AHyKQUYJuFi6VSCrDN7FwpwA5MpQCZlAJkUgqQSSnANh6yB7AHUylAJqUAG31f4UspQCalAJmUAmR28AEyUynARh5nArADUynARqZSgB2YSgE2ckQfYAcW+ACZqRRgq28rfFMpQGYqBdhozbbTwvOhAfg0f/vI95QuvMMzAMe4VgqQuVYKkC2k1AIfYJuFbafvF1QBOMa1UoDMAh8gs+0EsJUbRwEuz1QKkC3s4LtWCrDN0lSqpQBHrHpvJwdLAbZxrRQgk1KATEoBMikFyDzOBCDzFH2AzAIfIHMPPkBmKgXIPK8UIDOVAmRSCpA5VwqQ2cEHyDyvFCCzgw+QWeADZHbwAbKlBb4VPsAmplKAbCmlDpYCbGLbCSBzrhQgW9p2ssAH2MRUCpC5VgqQmUoBMvfgA2QLKbXrBLCNa6UAmRtHATLbTgCZBT5AZoEPkEkpQCalAJltJ4DMVAqQLT5F31gKsMXiAt+towBbWOADZFIKkLnbCSBzGAog8+hngMwCHyCz7QSQuVYKkJlKATLXSgEyO/gA2dJUOrx/M8AWFvgAmW0ngExKATIpBcikFCBztxNAZgcfILPAB8gWF/hW+ABbmEoBsqWUum0UYJPFBb6WAmxhBx8gs+0EkC1uO1ngA2yxuO1kKgXYwmEogMy2E0BmKgXIpBQgk1KAbDGldvABtrDtBJBZ4ANkyym1wgfYwFQKkEkpQLa8g+95JgAb2MEHyGw7AWSmUoDMthNAJqUAmZQCZFIKkEkpQCal8BwccdyVw1AAmakUnoCRdG/udoIn4LEaezOVAmRSCpDZdgLITKUAmZQCZHbwAbLllDo58cz8QQqbWeDzt+EPUthu+W3yrv0quK3x+YMxjzH8B/B4fE13tnwYyluOPrQxzePzKs6Yp2lM0zzm9+82X33YygL/+YxpGtM8j2kaH/83T2Oe5uk1owaYB2SpsTNT6RMa0zQvXBId85hf/wJstJjSYY33yGwswcUtLvBn32uPbLbYe0K+5Ds7cK7U5/2BWcE/Jd/T+3K30/NZuk7Kw/M135cnQwFkDkM9I6uO5+P6+M5MpQCZqRQgO5BSiwGA9Q6k1Gmoh+arCxd2aIGvpQCr/Vn64JgmB7kfl68sXJxtp+djxQEXd+Ae/Gl6PYjmmw7gtGNT6TyGAQbgtONH9N2s/ZB8WeHSFredPviOe0RWGnBxx1NqfHk8Qgo7cA/+8xmT9QZc2PGplMckpHBhzpU+neENSeDiLPCfj7ud4OJOTaXGl8cz+7LCpZlKATJTKUB2PKVCCrDC8ZS6BR9ghZOHocQU4BTnSgGyEyl1AhHgNFMpQHYipa6UApx2coFviQ9wyqmpVEnvhhUE3I5tp3s1vv2jlsLN2Ha6U99LqqVwOx5ncpfGNP2zZPBofLglU+l9WqqmksLNSOl9WljLKyncjgX+fRoL63sxhZsxld6p+d/BdJ6VFG7GO47epTH/M4PKKNyUBf7dcvsE/BwW+HdqGEThB5HSOyWkcHNfNiyk9F65tQlu7ctE41opQGYqvU/j+1RqTIXbkdJ79c/FUttQcEsW+ACZqfReWc/DDyKl9+rf9fzC1VPgWqT0UcxKCrfjWilAZip9GKZSuB1TKUBmKgXIpBQgk9J75dIo/CBSeqeGw0/wg9h2AshMpXfKTAo/iZTeKet7+Eks8AEyUylAJqUAmZQCZFIKkEkpQCalAJmUAmSHUuoAOMBqjugDZKZSgOxASse/bw0MwEEW+ADZwQW+FT7AWocW+JMVPsBah6ZSj8MEWM21UoDM3U4AmZQCZAe3nQBYy7VSgMwCHyBzRB8gOziVOqIPsJYj+gCZa6UAmR18gMxUCpBJKUAmpQDZwZTawQdYy7YTQGaBD5BJKUAmpQDZ4ZTadwJYybYTQOYwFEBmKgXIXCsFyP4c+Pjw7GeAtSzwATLnSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATJPhgLI3DgKkFngA2RSCpBJKUAmpQCZlAJk3pAEIHMYCiAzlQJkplKAzLYTQOYefIDMAh8gs8AHyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyDxkDyDzkD2AzAIfIPM2eQCZBT5AZoEPkEkpQCalAJmUAmRSCpAdSanTUADrOAwFkFngA2TudgLILPABMgt8gExKATIpBcikFCCTUoBMSgEyKQXI3IMPkDmiD5C5cRQgM5UCZLadADIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIDuWUg80AVjF40wAMgt8gExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgOxwSj1iD2AlD9kDyCzwATIpBcikFCCTUoBMSgEyKQXInCsFyJwrBcgs8AEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQUoxjRN06+XW78MgLtnKgXIpBQgk1KA843Xv7lWCpCZSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBaZp+rgDkrNIKTytv+I55lu9jIfgHnyAzFQKT2tM0zTe/mJ535hK4dm8LuXH/PajMc3TNOYxWeEHUgrPa0zTR1ZJpBSei2zuQkoBMttOAJmUAmRSCpBJKUAmpQCZlMKTcV/THhyGAshMpQCZlMKTscDfg5Tyt/fvs+FhQY/KjaN7+HPrF8APMeZpTNM8pukjp27Wfki+rLuw7fT0xjS/PXRtev/R6wODfMs9KF/YPUjpc3t7VOWXD/g2e3DDCn8XUgqQ2XYCyKT0sdhz54Thv5FdSOljcRWMU/w3sgsphacym0p3IaX3benbwrcKx5hKdyGld23h6JK34IUbcBgKIDOV3rlvq3l3zsMNmEoBMlMpQHYypVaLAKecnkrdHAFwwumUzmIKcNzJRz/PjvQCnLBi2+n9scAALHMYCiBzGAogk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFqMavl1u/BIC7ZyoFyKQUIJNSgMq1UoDOVAqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZFIKkEkpQCalAJmUAmRSynfj4y/AKlLKh/He0HmMaZpv/XLgjvx6ufUr4EcYygmBqZRpmqYxW89DYCoFyEylAJmUAmRSCpBJKUAmpQCZlAJkUgqQSSlAJqUAmZQCZJtS6jZtgCWbUjqLKcACjzMByFwrBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMikFyKQUIJNSgExKATIpBcikFCCTUoBMSgEyKQXIpBQgk1KATEoBMimFmxu3fgFkv15u/QoA7p6pFCCTUoBMSgEyKQXIpBQgk1J+LEeEuB8OQwFkplIuyBzJs5JSLmVM03zr1wA3YoEPkJ0zlVrFPR5fU0hMpQCZa6U/mVkR7oSU/jzj4292ceBOWOADZKbSHViXw7MxlQJkN55KxzSmcSdD3J28TOAGbj+Vjh+3t/LzXhHww90+pQB37163ncbSD+/lUgHwaEylANn/P23RLuAO4+UAAAAASUVORK5CYII=";

        // const base64Str_3 =
        //   "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABVsAAAqnCAAAAACOKowrAAA+Y0lEQVR4nO3daXbbONuuUSQrQ8WsCnN1/VBjyabYgLdEidz7fCeVSlde8avLj0AQ/PNVAD5XK3Xur6y/v/c0f7QV+Fw/K/momi+o6b2/L/7vAQT9TOarE/qQtgIHcGpuG/iZoR8L0FbgMF441WorcGj1OaOrtgLP1p71xjvkGeOsfQIAeeZWgDxtBcjTVoA8bQXI01aAPG0FyNNWeK333ulJirZCWnvw/ZMqroegrbBK+/Wdu7t86u+6vs1JTTyTtsKQ22S2+x9q7fJNKadSttN32t1v5Njc88rh/D4ludW7H7x+/8ePz/zT5v8sO6atHMLjxl1+5sGvEEf6aCtH0WqRSl5GWwHyXMsCyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI09bNOOcTdsxZLQB55laAPG0FyNNWgLw9tbUVF4iA9+BaFkDenuZWgHehrcCxPWcl0ZoAQJ65FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1uBw2v5P/LPV/7PBDg6cytAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStA/iAs52AB5JlbAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVOLb2lD/1z9dT/liAQzO3Akf3jMnV3AqQZ24FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQUoLf0H/vlK/4kAmFsB8oOruRUgz9wKkKetAHnaCpCnrcDBxfdfleJaFsAzmFsB8rQVIE9bgcN7woqr9VaAPHMrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQP4kLOdgAeSZWwHytBUgT1sB8rQVoMSvZrmWBZBnbgXI01aA/AZXbQUOr5VSw3+k9VaAPHMrQJ62AsSPE9BWgFbtbwX4AOZWgDxtBcjTVoA8bQXI01aAPG0FyNNWgGJ/K8AHMLcC5GkrQJ62AuRpK0CetgLkaStwePnjW+3BAngCcytAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0AppZSW/MP+fCX/NABKMbcCPIO2AuRpK0CetgLkaStAnrYC5GkrQHZvayn2twKctFKDf5q2AuRZEwDI01aAEl9x1VaAUkrNxtV6K0CeuRUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVPlPb+gNg1J+vrT8CgP0xtwLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrfKbmpte35p5XgDxzK3yqNvhd3oO2wmdqt9+pwz/FdrQVPlO9BLXep7TdfMt2tBU+VTt/U+9KWkuppdUHv4dXcS0LPlcrGvqutBU+mgn1TWkrQJ71VoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FOAs+ZszZ2AB55laAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDPntwK8NXMrQJ62AuRpK0CetgLkaSvARW6jgH0CAHnmVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQU4C54xqK0AJ63m/ixtBTipwcFVWwFOWqmxuDpPAKCUkl0SMLcCnFTnYAG8N3MrwEkztwLkBVdcza0AJ/a3Arw3bQXIs94KkGduBcjTVoA8bQXI01aAPG0FyNNWgDPPHQDIyx3fan8rwBOYWwHytBUgT1sBToKXsqy3AjyBuRXgxNwK8N7MrQAnLTi4mlsB8sytAHnaCpCnrQB52gqQp60AedoKkKetAHnaCnDm3gGAt2ZuBbjwTBeAd2ZuBTiz3grw1sytAHnaCpCnrQBXsRVXbQU4a6Wm/ijXsgDyzK0AedoKkKetAHnaCpCnrQDfUpuw7BMAyDO3AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgKceRYhwFsztwLkaSvARW5RwJoAQJ65FSBPWwHytBUgT1sB8rQVIE9bAW6EtmHZgwWQZ24FyNNWgDxtBbhwzyvAOzO3AuRpK8BVbFHAmgBAnrkVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBXgW+pAAecJAOSZWwHytBXgyhmDAG/M3AqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAFexe161FSDPeQIAeeZWgDxtBbhqqRVXawIAeeZWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FuIo9Q9szXQDyzK0AedoKkKetAHnaCnAjdDXLtSyAPHMrQJ62AuRpK0CetgLkaSvArcxGAfsEAPLMrQB52gpwq0UWBf4l/hCAvWg18seYWwFu1MzFLNeyAPLMrQB52gpwJ7ImoK0AtzIXs7QVIM+1LIA8cyvAHXuwAN6UuRUgT1sB8rQVIE9bAW6EnqGtrQB52gpwyzNdAN6VuRUgT1sBbriWBfC2tBXgRnUtC+BdmVsB8rQVIE9bAb6FtglYbwV4AnMrQJ62AtwILQpYEwDIM7cC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrwI3m/FaAd2VuBcjTVoBbmTUBbQW40Wrkj7HeCpBnbgW41SKrAuZWgDxzK8CdyA5XcytAnrkVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FeBe4sYs92UB5JlbAe4l5lZtBfghcDy2NQGAPHMrQJ62AtyJPIzQmgBAnrkVIE9bAX6wBwsgq5XS7MECyAvE1dwKcMc+AYA3ZW4FyNNWgHvOagF4AvsEAN6SuRUgT1sBfrDeChCX2OBqvRUgz9wKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCh8tckY+edoKn6zVxFmj5LnnFT5eS5w3Sta/rT8AYB1lfUvWBODTSes70lb4dFZc35G2wqerVVzfj2tZ8OmaRYE3ZG6FT2dsfUfaCh9PXN+QPVjw6WzCekfmVvhwllvfkmtZAPcSX67MrfDxLLeGJd4JaCt8PIsCWZGvVdYEAPLMrQB52gpwL7EoYE0AIM/cCpCnrfDpmk1Yb0hb4cO1oeME2s23bEFb4cPVUuuP0bWVWkorpTYz7Va0FfaiXf9ZmyfArpH4i9NW2IF6/ebmn6W2Uh1A2CFxo5s9WLA/jsbanrkV9ucurebWTWgr7JwZdrnA1yNrAgB55laAe/YJAMRFLgVqK8CdyLY1bQXIcy0LIM/cCpCnrQB52rpXg2fMuUMHZvBMF5Zxlzm8irl1f1op7XS63I9v3PwIL2Nu3atWv6dU8yq8mrbuWKun8+e//xV4EW3dJRmFjWkrQJ5rWQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkPe3bf0RAOzPn6+tPwKA/flbiskVIMzcCpDnWhZAnjUBgDxrAgB51gQA8rQVIE9bAfK0FSBPWwHytBUgT1sBhq3Z/G9/K0CeuRUgT1sB8rQVIE9bAQY117IA3ou5FWDQqvNXtRVgmDUBgPdibgUY5FoWwJsxtwLkaStAnrYCDFuz3qqtAHnaCjCsrhhctRVgWKv9v1dbAfK0FSBPWwGG1RU7BbQVYFgr/Quu2gowbM0+AecJAOSZWwEesd4KELdig6u2AuT9+VpzJQyAIa5lAQxrpX/01FaAPOutAHnaCpCnrQB52gqQp60AeX/XPW4LgAH2YAHk/W3mVoA0cyvAA6vOajG2AqT9dVILQJx9AgAPrBg9/6763QA75nlZAG/FmgBAnjUBgGFrBk97sACGrRk8rbcC5P0tFlwB0sytAHn2CQA80p/Hv8oK8MCKs1qquAKkWW8FyLPeCpDnviyAR/pHT2sCAHmeoQ3wyIo9WMXDCAGGrXleVl3xtC2APVszt9ooADBszdwKQJo9WLAb3oLGrdqD1dQVIMv+VtgLY9I7+fNVmmUBgKy/pUgrwKDWveD656uUYocrQNRpbnV5ESDpdO+AuRUg6a+yAjzU+67+z5flVoA097wC5Ll3ACDPOVgAeX9LEVeAMOutAHnaCpB32t9qUQAg6W+p7h7YJV8vj8hn/X24dwAg729xVMsueTQ6bOp0LcvLcIe8G4ENne/LsiwA8Et/Gt3zulMuUMKmTve8WhPYHWWFTZ3WW70QAZLO17IMrrtj9wds6V8p1ub2yOcUNvW3WBHYpWpuhS25L2unWvFFEzZ0mluNOABJ9gnsl88qrNZ9od9zB3ZKWCGh9r6U/pbidfhxZn4p9TUTNuO5A59o1hdDXzFhve4JxXkCh9RKbdX+EHgebd2x8z6sVmq5lPT2i7C0wvO4lvWRZnzGrmuyrZ6+39rNoTxVWuGpnI39keZ38RLUVu+C6jMOz+Va1m7VUku9fFPLNa318tPA8/z5Ks71OB4XsuDJzK1H1KqvpvBc7h34UKsWTJ2RBc92WhMQ10/jUwbvzZoAQJ62fqTmXT28xLpzsPg0LvPDm/tXimtZAMO66+ie18/kyyG8xro1AXEFSPpblBXgge5LG56hDfDQuvVWAAatW281uQIM6F4T8NyBz+ToMniN3rjaJ/CZuh/sC7yE/a0Aj63ZJwBAlmtZAHnWWz9T8zmDl+h9pXleFkCe9VaAx9w7cDCWBOCtmVs/lAcPwEus24Pldfp5vNeAd+ae1w/loS7w1k73ZZlbAZLOc6spCCDIeuun8jmDd3Y+q8XY+mmkFV5i1f5WZQUYtGoPlpvTP4+vh/DWvu8dkNdPYhkH3tv3moDX6ifx2YLXWLXeagh6b95SwGZ6by8/za3S+tZqaaVd7/BoRW3hZdadg+XGrI2182fwVzfP/1JLKbW0VlprtTS3esCr9I6e52tZXquDXvIlp5VS6nlZprbrl7lWWimtltbKqailltpKqac51hdEeGvOahkyMBfe/tDP9elWTz99+mcrtZ1aef49rd7+lvbrK1m7LujU65jaLv+o199z/uZm9cdXRHhbp7Ye/GLWpZvf/WzlXK527mQ7te08Y5Zy/efpp+rp15XLZNkuP1m+a1hP36ut1Jv/UC3XP7jc/KbTf/RS1Ntql8ufXp0CAc/XW8fD7RO4LGte7pe4u2/i9JPt+6pRK620Wsv5HXir56JdlmAuw+l5nfSSwlJLqfW0QFrL6fv13M52+v7Nf7heKtlqLfUU2FZLabW200LAeQ4+rwqcG3ykzxpspne9dRdz69379Z/jXLsuZrZyebd+mRKvI2m9rK3WVm+vH7WfI2a9/ucGFgZ+fizfP3VeFhhea7hOq6V8T731+7838Kfe/BbgHX1YW2/aVm6/d/NWuZTL/HidKO/XM2ur7Vquc1HL92+4DKL17j8w/JHM+Whn/+rbXzfx6y+LAsDTda69ndv6ri/Tm9a062RXzhlslxXMa0BP0bzMp+Xyoz8uJ12yernkdP+fGvq3Rx/WZjb/AOAw1rT1LcbW05X1y7v38/cv49nNm/hy/m65fO988fw8jl5+uEQCpGFwcKuuZc39ras2VP78za1dNsyX1ko7XcSp5bo9/nzt6GYfZ6uXt8K1lfPVoeviaP2+2n5ZfA50UVrh4NZdy3qGRxd1TgU9j5vn3UuXlc96vfB0N4rWgZXLm7XRif8owOt9fX19ff3331fCfz//5ecf+9/Xf1+n//vvv/9u/u3r+8e//5zbbwf+GID3ddknMPPd7+T16/J9meh7k/z3qPrzDzFnAm+td7110R6s9uhmoGs1r/tDb9MK8LE6M3Z57sDMy1T1dsBt12/r90+XUs5Xmc73HwEcz5K5dfbKAcDBnebWuSsCzmQGmOPv9C+5ZW4FjmXNM13m/XbrpwAzne8dcEEfIGjhPgEAZri01dwKMKBz8PS8LIC8f6UUO1cBHui86fVyLUtbAXJO663SCpBkvRVgxLqzWmzBAhjS+ab+siYgrgA59rcC5F3OwTK3AuSYWwHyLvsE7MICyLnuE5BWgJiFZ2MDMIP1VoA8cytA3t9SSmluzAJI+luKBQGAR5yNDfA2zucJWBIAGNSXR/e8AoxYdcagsgIMquvmVgAGdI6e5/2t4goQdL2WZVkA4LdVzx2oBleAIa1vwdWaAMCIVdeySuvcZgCwc6ue82qDK8Cgvsnzeg6WuRUg5np+q7kVYEBfHa/PyzK3AsRcrmWZWwEGrdmDBcCgddeyjK0AQ1buwbLeCjBg3b0DwQ8EYEdW3fPq0QMAg/rWW697sCwKAMRYEwAY05dHz3kFGNW1KPC93hr8SAB2o2+99d/5Nyc/EoD9WLW/FYBhK+95NboC/Lbqnlf3ZQEMWrkm4JBBgCGrzm8FIOd6DpblVoABfXX0vCyAMX1xPK8JNHEFyLnuE7AHCyDGvQMAed9ttSYAkGJuBcjTVoC8S1utCADkXO8dEFeAGGdjA+RdnpdlbAXIudw7YGwFyHEtCyDPcwcARq18povJFeC3Vc90AWDQ2ue8WhMASDG3AuRZbwUY1/Ou3poAwKiVz3l1axZAijUBgFEr51YAUpyDBTBq5X1Z4gowwH1ZAE+wag+WS1kAQ7o2UV2vZdmCBRBjvRVgnDUBgLh1+wSsCQAM6qnj99xqTQAgxR4sgFFdk6f7sgDGrVsTCH4gAAdnbgXIM7cC5JlbAcate6YLAAO6dv/frAmYXAFCbtYErLgCDHCeAEDcyrOxxRUg5fv8VnEFSHEtC2DUyjMGcx8IwI6sO6vFigDAoFX7WwEY5L4sgLyeufXfut8OsHetJ4/2twLk3awJ2CkAMKRj9Pw3/UsAjmzlPa8ADOp4V//dVksCAEN6DnC9mVtdzAIY4N4BgPdgnwBAnjUBgDxzK0Ce9VaAPG0FyNNWgDxtBcizTwAgzz4BgDxrAgB5nvMKkOc5rwB5nukCkOf8VoC8P19bfwQA+2OfAECe/a0AebfrreIKkHG7JmCnAECGPVgAea5lAeRpK0CetgLkaStA3m1b7cECyPDcAYC82/uyxBUgw5oAQJ77sgDy7BMAyLMmAJBnnwBAnvNbAfKstwLkaStAnj1YAHmeoQ2Q57kDAHm3e7BMrgAZ9mAB5NknAJCnrQB52gqQZ38rQJ5zsADynIMFkGcPFsCEjjq6lgWQZ00AYEJHHa0JAOT9+dr6IwDYn3/f321WBQAGtOXLAjdtlVaAIevWW50xCDBk7R4scQUYsDyOrmUB5DlPAGBCW15H92UBTFh3LQuAQcvj6vxWgCnrrmW5eQAgwz4BgLy7fQI2CgBE3F3LsiQAEGGfAECetgLk3e3Bst4KEOGeV4A817IA8uxvBchzfitAnn0CAJMWT57aCpBnnwDAlLb4Sr+5FWDK8t3/2gowxbMIAd6BPVgAea5lAeR5XhZAnvVWgDzrrQB59mAB5GkrwJS2+G29tgJMqYtvetVWgDzPHQCYtmpNwD4BgEHr1gTEFWDAyjMGLQoADHDGIEDeqrl1+cnaAAxxngBAnjUBgEnr1lttE4BdaF7LaYsfmGUPFuxPde1kc9YEYHeMrXn2YAFVXeMWvxP4t+p3AxzDqntefamDnTAobe3+HCxxhR1oBqW4lXuwfK2DHfBCfgP2YMEeyevWnI0NO+S1nLbu3gFrArAP3oLGORsb8FqOW3cty9gKO+HFHLewrndnDFoTgF1o4rq5+/NbxRVgyNI6Ok8A9sdq6/b+Tf8SPlsr3h8eTm0+52nr9gn4dOyQT+oxGV03Zg/WEcjr0biWtT1zK+xPLdWktDHXsmB/LLLnrbvn1Ve6XXJ25OF48ECcZ7rwm1fZEfmKmrX48Y7397z6dOyTd4fHU0v1VTWprbrnlV2y1fGAWim+pm7LHizYoVpKtVVgU/ZgHYBP6xHV5g3LppzVApBnbt0/bwxhvaWvI9eyAPJ+XMsy4gAEuHcAIO/HeqsF113ydgTWst7KT7biQMDCbVT3zx3wKtwjn1N4vR/rrV6GO+QKJQSsehahtO6STyust3BGsQdr/6QVXs+1LIBpS08EsL/12LxRgXmWnm59v0/AYS17dPqfxPdnttVSWm3l9L8We0NgllVzq7TuU707yrOWdv5UN4MrzLXquQNmmENp9edIC4T8m/4l7FX1tRTmWvpqsb/1yJwfAXOtes4rABHueQXI+9FWV40BAtyXBZBnbgWYYdX+VgASnIMFMMOqMwZtEwBIsL8VIM/+VoA817IA8qwJAMyw6lqW/a0Aw5bl0dwKMMeaMwYBSLBPAGCOZWsC9gkA5FkTAJjBPgGAvFXP0LbeCjDIGYMAm/u5JmBRAGA9cytAnn0CAHOsu+fVmgDAkFX3vEorwKBVc6s9WACDnNUCELfuviwAAuzBApijLVoUsE8AYI5l663mVoA8660Ac3heFkCcc7AAnmHRxSxtBcizJgAwh/VWgCdYFFdtBZjFvQMAcevOanEQFsAQ660AW7MHCyDP3AqQp60Ac1hvBXiCRXG13gqQZ24FmMV9WQBx1lsB8jzTBWBr5laAPG0FyNNWgDmafQIAeavOb3WAK8B69gkAzOI5rwAbs94KkGe9FWCOZfsE/j3rwwDYlXXPIvQwQoBBzm8F2JhrWQBzOGMQYGvaCjBHtd4KsDH7WwFmWXcOlj1YAKtZbwXI01aAPNeyAPLMrQB52gqQp60AedoKMIvnvAI8wZK4aitAnrYCzLPktlVtBZhl0UFY2gowSzO3AuSZWwHyzK0A23JWC0CeuRUgT1sB5llyLcuaAECeuRUgT1sB5rG/FSDOGYMAT7Dk3gHXsgDyzK0A81hvBYhzDhZAnvNbATamrQB52gqQp60As7h3AGBj2gowy5ItWNoK8ATaCpCnrQB52gqQp60Aec4YBMgztwLM4zmvANsytwLM44xBgG1pK8BMCwZXbQWYacGJAtoKkKetADMtWBOwBwsgz9wKkKetAPO4LwtgW+ZWgHnclwXwBPYJAGzK3AowT3PPK0DckodoayvAPK5lAWzLtSyAPHMrQJ62AsxjvRUgr9qDBRDXPHcAIM7cCrAtbQXI01aAPG0FyNNWgDz3vALkmVsBZvLcAYBNmVsBZnLvAMATzI+rtgLkaStAnmtZAHnmVoCZFjxEW1sB8qwJAOSZWwFmsiYAkOeZLgB5Cx6Ypa0Ac81fE3AtCyDP3Aow04JrWeZWgDxzK8Bc9mABxDm/FSBvwf5W660AeeZWgJnc8wqQ555XgE1pK0CetgLMNnvBVVsBZpu94qqtAHnaCpCnrQB52gqQ555XgDxzK0CetgLMNf9AAW0FyNNWgNncOwCQN3tNwD4BgDxzK0CetgLM5bkDAE9gvRVgQ+ZWgDxtBZjLeivAE7jnFSBu/kO0tRUgzz4BgDxzK0CetgLkaStAnrYC5GkrQJ62AuRpK0Dev60/AICP0WbfmuXeAYA8awIAszmrBWBD2gqQp60Aea5lAeSZWwHytBVgNs/QBtiQuRVgNvtbAfLq3LhqK0Ce9VaAPHMrwGzWWwHyrLcC5JlbATakrQB52gow28wnumgrwALWWwGeYO7gqq0As9mDBbAh97wC5JlbAWZr1gQAtqOtAPPN3SdgvRUgz9wKMN/cBVdtBZjNfVkAeXXugqu2AuRpK0CefQIAeeZWgDxtBZjPPa8ATzAzrtZbAfLMrQDzuS8LYDvaCrCA+7IANuNaFkCeuRVgAdeyAOLcOwCwHW0FWGDmPgHXsgDyzK0AeQ/aOvuZMABHsvKe17mP4AZggDUBgDxtBVhi3qKAfQIAeeZWgPnmXssytwLkmVsB8rQVIE9bAfK0FSBPW2HX2tzr2szkbGyglFJrc0LIBrQV9qzV0qoTQoI8dwAopbb2XYNmfl1v7pcp9w7AjrVSajO0RrV5eTW3wr5J6za0FXatWgdIm/fFypoAwBLz3gmYW2HXTK1pM/9G/z33owC2pKxPMG9NwNwKO+Y61ma0FXbM3LoZbYUdq/KaN+9v1Hor7NjMfe4sYb0VIG7mVyttBVjCM7SZ4bwNupXaXFTeJasCGzG3Hsr1mORWWmmtnL5tzQGfOyatYTMPG9fWI2nn/3/9Tqul1FbOr7+qr/vjWMG4mV+srAkcyullZpA5EEsCcTNXz+zBOhJLqkfkjMFtaOuxeJkdjC+nT+CMQeC6mk6MMwb5ydOUD0las5wxCJDnvizguu2OGPtb+cWbw8Oppfq0h5lbAVuw8ma+D9BW2LMqrXmz6moPFkCeuRVgkVlzqz1YR+Leclht5svI3AqwQJ13YJy2AixibuUHKwLwKtoKkKetR+LmR3gVbQXIswfrOEyt8DoP51YvxJ1pzaEd8DrueT2MVoqdAvAq5tbDqFVa4WXMrQdicoWXeTS3Glt3yOQKL/OorV6CO+WLJryENQGAPPcOAORpK0CetgLkaStAnnsHAPIe7m+1CQugmzUBgLyH9w5YEwDo5p5XgDz3vALkmVsB8sytAHkP2trEFaCfc7AA8uxvBcjTVoA8bQXI01aAPG0FyPvZVvcMAKxnbgXI+9VWgyvAau4dAMgztwLk/bqW5RwBgNVcywJYZNa7+59tNbYCrGduBcizTwAgz9wKkKetAIu0ORezfq0J2IQFsNqvuVVaAUbNmVvdlwWwSNf+VnMrwHrObwXIc18WQN6vudXgCjBqzgxqbgVYpmufgLgCjOqZW13MAhg1awJ1VgtAnrkVIM9ZLQDLuJYFENd3z6s1AYDVzK0AeeZWgEVmTaDmVoCFZsygv/cJGFwBRsyK5L9nfxQA+9K3JuB5WQCjuva3ArCatgLkaSvAQjMWBVzLAlim5/zWZg8WwKiea1nVzQMAY2aNoNZbARbp298KwJhZC6ee6QKwzJxbrJyDBbBM13Neq7gCjOm759U+AYC1fq8JmFsBxsx5e//rvixjK8CoORPor30CzhgEWM0eLIBl2ow3+NZbARbq2d9qwRVgVN/+1id8IAB74jmvAHGelwWQV2fU1XkCAMt07ROw3gqwmjUBgDxrAgB5zhMAyLMHC2CZrnsHpBVgVNf+VmsCAONmdNI5WAB51lsBFuo6TwCAUc4YBMhzDhZAnrkVIM/cCrAJ17IAlnE2NkBe1z2vAIzrupZlwRVgLfe8AuTZJwCwUNcerCquAKM6nvNqbgVYbWC9tbkzC2AdcyvAQm26k7+eRehAAYBx9rcC5PXNrQCM6ZtbARgzY251fivAUtOdHJhbxRVgVM/c6loWwKi+9VZzK8BKzsECyLMmALCQZxEC5HmGNsAm3DsAsFTXHiwAxlhvBdiE9VaAhdw7AJDXtSYAwChnDALEta5zsGYcTAhwYLVrTaDaKQAwZkZch9YEXMwCWMd6K0CetgIsNrkooK0AC7W+52W5lgUwxlktAHF99w4YWwFWcp4AQJ79rQB5Q2sCFgUARk2OoP86fg8A48ytAIu5dwAgruveAQBWsgcLIM8eLIClpq9K/fka+F3iCrCKuRVgqb65FYBRk48jtE8AYLmp9/dDbXXzAMA6g2cMWnAFGDF9xd/+VoClph/PYr0VYLmpuNqDBZA3eC3r5R8FwGfp2CcgrQAruXcAYLmpnQIDzx1oVlwB1hncgyWtAGP69mBZcQUY1XPPq7kVYB1zK0CefQIAS01f8nfvAMBSteesFnEFmNB1LQuAUVMj6MC9A7YJAIzr2t/quQMAo7rWW82tAKMmHzxgvRUgzx4sgOV6njsAwKi+/a0mV4BVBu95nX48LAAjrAkALGe9FeD1tBUgT1sBFuu6d6DZJwCwyvA9r/YJAIyZOndleA+WuAKsMbzeKq0AY6bmVuutAB06npdlvRVgQsfcCsCEjrnVWS0A4/rOxrYmALDGYFuruRVgTNdZLc4YBBg1NYK6lgWw3NTc+u8lHwXAvvSd1QLAqI41gaquAKOsCQDkTa0JDJ6DBcAq7ssCWM7+VoDXsyYAkDc8t1oTAFjDfVkAHbruebXeCjCq5/xWaQUY1zW3Wm8FWMN6K0De8D6BV38UAB+m63lZAIwbH0LdOwCQ51oWQJ71VoAe46G0vxWgx3goXcsCyLMmAJBnbgXIe7DeanIFWMGaAECefQIAeQ/WW9UVYAVrAgB59gkA5D1oq8kVYIUH17KstwKM6XqmCwCj+s7GtiYAsMKDfQLWBABGdZwxaG4FWMW9AwAdJibQ4edlNW0FWGF4bq3WBABGjWfy3/LfAsAEawIAecN7sKQVYMLoO/zhuVVdAUZN3AcwuN5qwRVgXN89r8ZWgBXclwWQ5xwsgDxrAgB57ssCyBtuq7QCrPFovVVdAfo9WBOw4AqwgjUBgDxrAgB5j9pqTQCgn7kVIM/cCpD3aJ8AAKPa2Pt7ZwwCdBkdQp3VApDnWhZA3qNzsKy4AowZn0AfPC8LgBU8dwAgz7UsgDzXsgDyPNMFIM+9AwB57nkFyHM2NkCe/a0AefYJAOTZ3wqQZ58AQJ59AgB59gnAofx8cXuxP4m5FQ6nXb85/evos0no455XOJRaSqmllVZLOQW2VS/4Jxi+liWusDOt1PM3J7XVdv12yw9srx7dO9D8bcOOtFJPdb2Mq7W0enmZe7k/wYO2Nl/JYF8udT3/W739B3nmVjiC21f0j3HVi/0pzK1wCF7TL/ZwbvWJAOj28DwBaYU9sYX1xTznFY7AS/rV3DsAR1Crur7Ww7nVJwL2pInrazm/FQ7Bja0v9uieV2BPWrHU91rayk/ft0KyHz6lr/agrT4Rx3O9Sccnf5ccyfJij65lWfbet++Lle1ymGc9nTdXWms+/ztkvfXFHt7z6hOxZ7/S+esask//3rjV8sXsbz2iobTWy2e9Xr9hR9rvr5881YP1Vp+FXTu/ym4DWi/n0Vdh3aXaXKF8LWsCh+Tzezit2P7xWtYEjsiL7HiqN6Mv5qyWQ/L5hSdzz+sRWVM9oOpi1mtZEzgkbxCPyOf8pTxD+5C8yo7H9csXe7Qm4MacPfMyOySf85ey3npEXmRH5LP+Wo/a6vMAu+Il/WKPn0VoUWC/fG4hYPSFNHLPqw3mAI+NJnJsD5bpZq981YRnG70vq+nrTokrPNmDs1pum+p1uD82YcGTjewTqA4q3zGfWniqR3PrhcPKd8mnFZ7MvQPH06yiw9NNza0mnB1qpVgUgOeanFu9BPfH5xQSRt8ATrbV20eAIT33DrBvtoDAk2nrITXHRcBzTbXVS3CPPNMFnm1yn4AjWwAWm7EmYHQFWMiaAECfsT7OuHfA0hzAQvYJAOS5Lwug08iiwINnugAwrud5WQCMW3fPq40CAItNr7dacAVYanqfgPuyPob3GPBaI6+56XteeVc/v+rZigzvw3kCH6uVu5aevoD6ZMF7mF4T8Gp9S+3nmxGfJ3i1Xy/DG+7L+lS1/O6pC4/wSmMvOG39VC5cwcbWPS+L9/TrC2YregsvNfr4DvdlfaxfdbUgAK81Fld7sD7Uj10CwMuNbnvU1g9mexxsa+Q1qK0fq5lbYWuP46qtH8zcCm9LWwHy7MEC6DO2B0tbP1X7/Xm1vRVeqo7c9Kqtn6r+PgbL8iu80ugeLG39WD+3LSsrvNa6Z7rwOcYO5QHyRuqqrZ/LoArbci3rKNQWXsq1LIAncM8rwCuZWwH6WG8FeC1t/Vx2XMG2PC9rl5yCBW9MWz9WNbjCtjxDe5ecHwBvzB4sgF6Pl+bMrZ/LkgBsa+w1aG4FyBuZW41FAJ3MrQB5/x79xOiJ2gCMebgmUJUVYFzXGYPiCtDJHiyAPmM38Dxuq20CAON61gR+PkYUgFt952BJK8Co9ngGfbi/1Ql2AN3clwXQ63EmH9+XZXAF6OVaFkDew7YqK0A39w4A9Hr8VJfH5wkYXAFGdT0vy6UsgFEjmRy5d0BcAcYtf16WJQGAcSMjqD1YAJ3q42tZD587YHAFGNc1twIwqj4eQrUVoNfjwfXx/tbnfCQA+9F1LesZHwjAIVgTAMjTVoA8z3QB6NXzLEIAxnVcy2omV4Bej5/p4rAWgF7WBADynDEI0O3h0unImoC6AnQaWROQVoBO9rcCdGp952CpK8CIkUcIjO3BclwLQB9rAgB5zhgEyDO3AuSZWwHyxu4dAKCP8wQAutnfChD3+PZVawIA3R7G1dwK0O3h3Prv4W9xWxZAL3MrQC/PIgTI63gWYakGV4BOo890seAK0MUeLIA817IA8jwvCyDP3AqQZ70VIO/xfVmlOcMVoM/ImoA9WACd3JcFkDe2T+B1HwXAvphbAfLG2lpNrgBdzK0AeaP7BADoMr6/FYAe5laAPOutAHmj+wRe9lEA7MvoOVjiCtBl9L4sV7MAuriWBZDn/FaAvNF9AtYEALqM3jtgVQCgizUBgLzxZxFaFADoMb7ealEAoId7XgHyPNMFIG98bpVXgB4je7BswQLoNHrPq7EVoItrWQB5zhgEyDO3AuQ5qwUgb/yZLuIK0GP8PAELrgA9RtcEpBWgy/h6qzUBgB7OxgbIGz0b2wZXgC7j663WBAB6eKYLQJ77sgDyxve3AtBj/FqWnQIAPdyXBZDnmS4Aea5lAeSNPS/LkgBAH+cJAOQ5Bwsgb/xsbAB6uOcVIG98f6v1VoAe5laAPPcOAOSN7W9VVoA+9mAB5I2vCYgrQA/3ZQHkOU8AIG9in4DBFaDD+JqAyRWgh3sHAPKcjQ2QN3qegNVWgC4TawLNgivAcqN7sMytAF0m7nk1tgJ0mNiDBUAHZ7UA5E3swTK5AnQYv5ZlcAXoMbEmYG4F6OC+LIA8z3kFyBu9L8s5WABdPNMFIM96K0Ce5w4A5FkTAMgb399qbAXoMX5Wi7kVoMfEtSxxBehgnwBAnvMEAPKcjQ2QZ00AIM9zBwDyrAkA5I2eg1VscQXoMf5MF8sCAD1G26qsAF0mzsF60UcBsC8T52CJK0CHqf2t4gqw3NT+ViuuAMtN7G+VVoAOU9eyrAkALDe6B8vUCtDFHiyAPM8iBMibOk8AgOUm9rdaFADoYG4FyHMtCyDP3AqQ5zwBgDxzK0Cee14B8tw7AJA3tb9VXQGWm2irBw8AdJhabzW3AixnnwBA3tT+VgCW01aAPG0FyHPGIECea1kAeVNzq8EVYLnR57y6LQugi7kVIG/qnlc3vQIs51oWQJ41AYC8qTWB13wUAPviviyAPGcMAuS5lgWQ5xnaAHmelwWQZ00AIG9yn4BFAYDFzK0Aea5lAeSZWwHy3JcFkOdaFkDe5LMIbXAFWGzqHCxjK8ByU2sC4gqw3OR6qzUBgHEDM6g9WAB59mAB5GkrwDpDl6WsCQDkuXcAYJ2hTNonALDG8ABqTQBgpYEntFgTAFijDT78ytwKkGcPFkDe5DlYACxmTQAgz5oAQN50Wy0LACxlbgXIs94KkGduBcibamuz3Aqw2OTzspzVAjCiOb8VuHd3I3xz7F2Q9VagldJKqbZcBmkrHNE5orVcqnoaWw2uMdoKR9PONW2nhcLa2rm1zbXrHOutcECt1FZbvS4F1FJatd6aNNnWoUNfgY/WSr2+sk/f8UJPm55b/Z3DrpzGUy/sJ7PeCgdTayueMvp02gqQN91WX95gT4afnEea9VaAPHPrx7MjEd6Q/a1wNPaxvoK2AuTZJwCHYx3pBTyLEA7HksALmFspxVfQQxk+ypmwyWe6+BJ3BOeNdqcXXTv/X2tehPtkX+UrTD7T5SUfBds5BfTc0Xb+f5fT51oVV+hin8DBtVJO/aznNynndyrtdGiyr6171AxNL6CtR9dqqz/eJHrLuG++ZL6Eth6bCQaewz6BY/OAJHgObd2bhRefpPV4PBTrJbR1b8SSKf438gra+ukGZhBjCaP8D+QVXMv6eANX9V3oh63NmFt9kXtnQ/tpfMZgc+bWT2cXFUt5X5M29DeqrR+u1d+fVnvDYXPaemwmGHiOOee3Wr7bL2mF55gxt1rQA1hoqq3XmVVeAWabM7fWVqrpFWDY0HWLf3N+Y7UwAPDIUBxn3DtQSymlKivAkDZ0w8788wQ83WOffFphpToU19n7W+1H3yX7W+E53DsAsNLAkOKMwWOzIgABzhMAeAlzK0CetgLkzW6rhTmA2Wa3tcorwFyuZQHkWW8FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgLVaaT9+5M/XJh8IwK6ZWwHWM7cCPJ+5FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwECftw8oK0A67V6/+/aCrBe/TG3uucVIM/cCrCes1oAns/cCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKsNrPxw547gDAE5hbAfK0FSBPWwHyZrT11xotAONcywLIsyYAkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKetAHnaCpCnrQB52gqwWvv5A3++tvgwAPbN3AqQp60AedoKkKetAHnaCpCnrQBr/dqCZQ8WwBOYWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIKHd/dufr40+DIAdM7cC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0BAu//XP1/bfBgAe2ZuBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQVIuL8xS1sB8tzzCpBnbgXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoCE+3OwnNUCkGduBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAvJltbdO/BIAL5wkA5FkTAMjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcib21aHDALM54xBgDxrAgB52gqQp60AedoKkKetAHnaCpCnrQB5C9rq9gGAmdw7AJBnTQAgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSBPWwHytBUgT1sB8rQVIE9bAfK0FSiltK0/gL3587X1RwCwP+ZW4JvxNcXcCpBnbgXI01aAPG2F47K6+jzWWwHyzK0AedoKkKetAHnaCpCnrQB52gqQp60AedoKkKet/PD7Vh0378Bi2soPtZTSSmmttPM3W39E8IG0lYtWWmunrl57WkstVV1hMecJcNJqq6WVc0lrq98/seFHBZ/q39YfAO+k3n9T7r8HzGZuBciz3gqQp60AedoKkKetAHnaCpCnrQB52gqQp60AeYva6rZygFnclwWQt2BuvRySBMCEhXNrq05FApi08FpWNbkCTFu+T8DcCjDFtSyAvK79rZYFAEaZWwHy3JcFkNfXVosCAGOsCQDkWRMAyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXIaaW0Ukr587X1RwKwP+ZWgDxtBcjTVoA8bQXI01aAPG0FyGnnf2orQE61vxXgacytAHnaChBzWW61JgDwBOZWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgKDzSVjOwQLIM7cC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0BSa6WU8udr648DYH/MrQB52gqQp60AedoKkKetAHnaCpCnrQBJrZRifyvAM5hbAaLclwXwJOZWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQVIa9oKkNZq+fO19QcBsD/mVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgKRWSinOEwB4AnMrQJ62AuRpK0CetgJEtVJcywJ4BnMrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0CetgLkaStAnrYC5GkrQJ62AuRpK0BUK6WUP19bfxgA+2NuBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgDxtBcjTVoA8bQXI01aAPG0FyNNWgLSmrcBPbesP4CPd/a1VbQXOfidVZBeo9//652ubDwNgz8ytAAE/hnxtBQi4WRNoxZoAwDOYWwHCmrkVoFf7uTnghrYC76E9DtUHsiYAbOt8gX1faTW3AjyBuRXolrlxa5e3f2krsEC7/rOVX/d5Dv/SSftaDDizJgAscHNpfGcLpGHaCswmp7NpK0Ce9VYeOK2ntdLa94/wVP6C90RbGdZqK6WV0mo9N3afVxxe72FBn5RWxd6GtvJDO31TW6mllvP/6eqwnm7d/1W273/U5/wl+9Rtw3orv5hQn+LBZSBXh3bq39YfAO/Hi/2V/G3vlDUB7lmdSxj6WxTRY7EmAJBnbmX3jOJswNzKx3GtjQ9gbqXLa2bBNrxwKa28P3MrQJ65lcWsX8IkbWXAeD1ruxwz8OPXDfwQHJQ1AUopp7uDWqnL7hJySxE8oq3HdFvFVk9hPV99F0wI6FoTaO3BBVzeUTufvvL9lr21Wm7evbfSzgezTD6lA5jH3LoHd1Noqed3+LXV0n6/yzeXwgusuZZlcn2Cdj3kr5wGynZ6n9Duf025mUXbdy0vb+xPpwJ+nxB4S1rhBcyt76DVy5B5eld+Wf9sp++ex9DOPzr6kQLzaOtzXJJ4vk50DWS5XjE6HT4N7JO2Zlzred7JVEr5fvdtdoTD2bytrV4vvryn6+TZbt6fn9+rAwzb+r6sVkqt7eXvjtvt965PLDo/2fT7ylG7XkI6VfXylr5Wb+eBMZvPreWJM+vdwPk9a3438vtXvffsDHyazdr6I2Q9XWs/8ljqbTZbqacdSZIJvNw7zK2lDAfw96rm/Z2a18vu13m03H8fYCMvbuv1NqHTfs6BVcvzHUWlni8dXS4hff8swNtb29bHsbt/x377vcuOz7FQiijwydbuE6i/z/E8X2+vrdzfqVku148uWR3Lp7QCn+xd1lsB9uR/WLqisFU7uIAAAAAASUVORK5CYII=";
        // const base64Str_4 =
        //   "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABbkAAA0RCAAAAAC0CZ+BAADJsUlEQVR4nOzda5qjupIoUJ369lA1q6u59v1hHsLGGGweIXKtPl3pysrKYicmEKFQ6H//lwBoSfmfyA3QmH9XHwAAG4ncAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA3QGpEboDUiN0BrRG6A1ojcAK0RuQFaI3IDtEbkBmiNyA0wUa4+gM9EbuDvKC+/La+fzalED94iN3ArZfpiiMwlpZRyefy+lO63Kc8MsUs+/jB/M0Tu6LcYgHdKH6VLP2IufUzLpaScUim5pJRKzo9ol/u/VlIu3SC7j4Ilpzw7GI/jv/5FbuA2A/x5JZecUkk5ldy9zn0grgJZH84eg+rc/f4Rvsdfur/VBelcUsolp3GQnqOGxf/939VHADD1iJdd1Cx9WB6jc/dnwxekLn53obukXFKeRukuUA/xunqV3n7q8YmIwfsRuYsRN3C5Pgz1UXoYKOc6jJc+l5HL+P8p9Z/dXcTY2I+5BW7gakPk7kbUj5HzIylyXco5YnCULQHiqEJ0n7uYSWucL1r0VhUIHGpF4O1qQUpJVSV1efp4pWiBW+QGjlDmIm5JKQ0F1ZOyu/L4CxGi9KxoB/bf5y8BWDDMkpU8LQfpP9mVg3RziLmknFPq0yDjL3HlcINuY26gjpxrgmgZVyGmarCch5Fz7lfE9LV4j68u5fFHZcyLnBmz88xvcn7E5dz/mvLjD3P19fFuLGYo4a/6VFFWDaFTV5j3GDE/Ppf78XSZTiaGmFEcdAUq/UqbrrxwKDvs6g376pWcxtepniyNNuYWueHPqePQpBAvPeLWuIKlinf9epf5Th9nm1tHk1IVavv/jQsrSxfG6/xNfRN6Wf9TlyJGi90iN/wl0wBV+qicx9UtaRyGpnTBCLoev3eD/JTqONyN/4eDHRfljMc8PCBUa3mqj2maiu++ZuZgwg66RW5o0DeBZJwo7Aec45rwAKPolFJ/IP3QuBodjxF4+p/+vP57+K97F5fnnjfe6O8KAYsCRW6IrEyi0PC7MeSU1cPBYVR9pWoAPdwtctdopB9h58nYOKUv7lNl9ttsNwy5f/ouRxC5IZAqJD8PLeuPpWveMRk4p+UIc3zQ7lrtlVzN/w33mSHLnMbEcvUf0j8RPP7ejweyY2qjv7vs9g13InLDRV6j9KT3XfeJSWCeaXn3ZCHE7Bq6h4FyneEYjzs9/7dNsxpzN6jdM8k7fMOSo2ZL1HPDCep66W4N4SN50RU1jzu1DJ8Yap5L/V3Ky/d7+ofe/8mnY8zDL9PPPpah5Pz4tSt87r+6+2zOk7+b6+MsXSSv7jZ55tXu4oXbHekVCPuqs9L9SHPoFv1wbOu7N9dy9Q+O5RvPhRzdJ3OfIq6GylWn1TwOqvvqlO7zwz92j4CyKg11CdkSWLQQg4byuf6xuqqlGz51/pzgu2m5/oD6pqlDE9VqQcpQmFH6aJ7q/8anqo2bxOcFUdPcIjfU3oWlPhzXSzPSzMvzzf3j7wJNX2tXRfcyV0N3/4i81lyCJ4QhcjtXtG31ULCeExvTAt0IutSJhGsi8psttdKwZKbaKjFPPgx/4c13DrsgMLDx7XDtcTz77+oDgO+NMXcSrqbVZUNlb7eyo16Nkksa25HWr/uuo2cYst79bSRPEjFpGor7DPn4l1L/E/jwaF/qv8sqF929P5MtIbzXODOusOjn/7rXVfVwtT/htfoq50lOeVipnfvpy3qvxZcPzwnmzmTysH5cmD2QsE/+UTWxhtJdmLDqVkHD8rs8XFRXjouGPhn9jF694CSNhc3jLN/k7lLfhJ48r/eu/vb4NWn6u9QfzPTO1r0o1dG63NeJGrhFbuKp+muklKrB8xURul+Y3aeY+/HtcKx5iMB95mLShm52AcrYAKkqsRuD/EszpFVTiJOyw7EmsYy3lf4/KGIkCkptCfc3H13qUV//ofQ931L/67squsOD9dDTdOxiOgbVulK5Hian55Acw+Rn1R13mZm/DHfgUY0JqHA/M5GbXw1RrR99Vuuhn9dqXzdqHttNpyH6plRlkXszA94m1It7hjU1469Tbf4nnm38kcb7eYncf93bscTzWLkfhfZBcNro6HNDjWPk6ubQD57HZPKYVR5zErlOS8S7Ir+2vorxRv/RR4tbRyly38JPb6syDpGH/09j0Lu8RGMcsI+Pr9USwDqpMWQzXpf7vfzudsrK8/T8kMFbw6A73qSuyH0DY7CtF8d9vDwjVMyNxkXjdV3GzD5Ti6mNYJfX2dac0r/9E9oqbCWlyN2il6FkGRIW0zHp+3fbRWE7l+E4x3ZMaRKBX8LzNFQHu4BimctoP00xzBWu8Fa1PVosIncYK94bwxZPryXMbx6U3yaxNx7calX6e9hwO6VUD5qrF6LIvupZyjS9QQ4FNH7iW4z3vWA/N/25d/YuJNZtk8vMh3qrqfL4+pK69dilpPL4kPqXL//OtlC8R+DO3a85pUfX5jwGhdwnOUpOebK8vPvYfWWuSp13Pry/qORUhlORc8ndWvouYOe+nTbt0597Xy9L1x6/G6Y4xp2bhmZB/XzatIJup4nB2dM6HZlVX9x38yjV2Hmy80k/9VeqeFD/1/SJjnGZoPfVFWYmBJyIr4yz48F+grIlXxjPYbUwI6U0pnHzUJaRhiKHaln02iqA380+5FVlqmOsrpds9P9Bw9KZKh3d/5cNi1ae1gNypfmRA1+rZgli/UhF7jmT6FSvMOlrH4ZKjmHoWQ9TZ13UMXT2Iq5zoeN/bF9JN955uq+tkqR9wH5eHwl3VO1DGey9fv/I/eaZsQ9L9YZT6WnA0i/Grsqdq/Lm61ppVP/usD6wO648CcvvhgrPs1j94LqaTIy4uJsNnL3f1Wsoo/08m4/cL4O/Sch5rW0egvRYndEvAHxum5GnmecrovTkaKqjGkb643/W0EqvSk+/f8Qb/8OCvSEhjlKNhIJdKIEj90z8XfjalwLgsf/a2B70Ybmg7tKOoc8LmJ9+P6Rp8iRFk1LqU9D140Ia09wvE6bDNww3loBAGpihjHRgz8cy5F3rnpovI840HRp3rZzPO+rt+uxymYzr83Cnr3px9Dn1PstcR+nnM7cwqzJUuAzpO+CNei4/2LUy1nNvO7AdAmJJaSxzLqWkMhY9l+GT3bH1K+9yKXksdn78jcdX1ftQpeET1wTu/PQxDUXPj0rn3P3m8QWPN0XOOaWuDDelkh/J5lxSyl1s70pzU06Pn8Lzv/Z6DI+09fgzGNL1afIpYE4eI1C0K2V1tmTNCr/qybyvXR4+N27/V6+pG3IaYyFa90se40xMLzmWMWkxSU+nUv9HlcmXj92T60F0lfEYwuzGO/70KPrymJJfji7aSAJCmZRhRTKMucvwy+uLfgT8eNV/6uVvPCLCY0zcjTG7NG15rKd7RKFcyrAqMKVUSv1h/O7dby8LLbn+0K0+qz9U69FyPZXRx/D8GFin0r3K6TFU7gbbuTxSF4/vkYd/qxogD98mzdzzl29oefK80f+oh1WZT/8GMK+/xMOtPX23m1mpcvKlHxamamA5fFlV4jv+bjrQTPXs4OIo+qi09Lbv269P6QsC+//AIdHcD4af8g796LhPsPd9I4YM9fCFZRx1HxE9+/LFFf+d0d6QEEddgBZMnS0pY7u5aqVcF3eq5+yXmPCcHHj99K8hefzry9/oXdlItbp8nO1Lk5m+asHwUJsyrMWpTtxCoO2XqDyvKqyq8+qeUR/+m3+I6Mu3x4HIDYuqlTjBHlC7yN23qR8+P46fh88cnaNfXTX9WiiX0tN9pR/n55moOSov8bhaOvgmVq+oUJxGw+eHmdWn/6c3yqrA/cP3h79hHPvFitz/UurTzdME6OPXui6hHBu4J/90l/wd88hjKUbubyp5uJvklHLpSzNKzkMeIz+KNR5VKFWbtGHCeChHqbLafZpkMDlhn89eFfJn/sL6s//TY8pCXi4Pefiok78QTrDA/Rhzvyz/2OM7f/ou1frE6aq/1A+V61dDkjn1ufIxI/Fc1/wyXP562Purd//SliP47l7/ki8Zl+0EewdCYKHz3HMh9mnd92bv/uJQBtd/zSO0DpN5ua9SGZqfDuF3mmt6G3+mKea5P2vHGLW3H/m4aCf1ibDhtpgCvhMhnMmYNtYl8xhzb/s7zzOPc3XDVZK5TMfQaQjJQ01z3/JpLsn80FrI3dHTBOm2vzmOvfPCTxd4Y8ysxrpsJmPutyPsPB5+v6CkGwePf9pH4aHTUamHzel17Pg0nJx+yfyY+a/69icx/XvTMhrgk7h9Iv73f3Mj7jFJOmZNqqLmegavTsM+R4R3j/qzKQ/h5K3vfzRVtgn4QtBM9yRbMhYj99no6ezYcxWykHAKP2a4ypBuCOa/VKe5hxRF7j/9fMAC9/n8mIGpKlvykln+vq4B4AaqScBYYfDRcarrHPq03CZ3DaZiHTHAGcoY/HLZWoJ3sGltyZVHAhBM0PnJeoZSagTgSdApyn9pWJ9R0qOPNgAppWg5ktH//q/ufipsAwxCr34fl0BGOzqAC4XNc/9LXfvTkkrJSefP6JwfOM9Tz+Y4/qXUFb+UR+FLuHsLE84PnCdsBvlf32e1b70a7M7ylzkVcLG+2V64i3Hc+z3qveXvckbgWnGn/v4Nd5NwNxWAS+UxcAeL4P+6nRp7cesXSeNd1mmCcwS90v6lVPK0WUnUQ2W472d3WDjFsMl4sCvuX79rQieXHO2xgE7pOoCVNG4qCZwhWlT8l9IkCJRcDLqDyv02co8iIKGbbao3TCnJdb5C/SOLFbv/Tc9fztMhOMHUN1lXHpvkp5eu8/XCjZMmXV5fN1cgnFJtEnrpgdAy1/k6YVtg/0upjKUlxWqcyGb3l4MveButk3PQn1Q95s4iQwvqBLeTBYeKup3Zv8lzk7qSwB47zZWqGW/U4QDcRD1IinW1/Usl90O30pcvEFHOqUttBd2lA+6mitclVmD8L72ktQWEqIYFOOp/uFys5MFBynM9Thj/Uh6LFcJVvvAk52gPbfxFJUULZH/OuA9l/2QgesfVV/4UN1mu9AejdrRHjHHv9/TpfJQc7uj/opJLcia42l95B0ZdPPFvUmu+OJDL0ikRdBthOBNc6q+UMvQRO9p/7b8qHC9Oe5WuKo3L5ZziDQH4c7oqp1tHhTrmxfoP/Zeq1qFLx5b7u2ys4/+TyrQxL1zk9mOIcclEtP/M/8aXH/u7PuJ2tP+CP+ivPKjC5UrQnSgf+1AOK3EWjq7oLwa8Fyy27SFuFdf//i+llfOnj3b+IncAcfc1hXvpx9zRLrh/Ka28Vwa99fxJtpyDU5TAtSVjm9el20r3X2BqLAi5bjjeEPBCjrnXBIHcrd/Tny4GU8VwgqiXWVUV+CGA374AqB2ee+Bk0TYPnOS5P0yj6nYURM4S3XCG4dk2Wo3Jv/S0D+V7ojbwp4yNVKNV1f3v/+rtekTnNmiyCWeJWxU4LvCM9kTAnFL9Chwq6IX2v/+rG89Fu6/wRrRHN7iroMFxuoOwooVGZKcKzhQtH/G//5fXzlASiEE3nKDe6zHUNfdvErgN5BqhzSucIVS0rv2bJuDDHifPnCo43LgAJ9hQqc6WBHscYIECTjhJyM4l/1WHI3A3xLmCEwQtLel3EI7aypB5xfJ3OMHHncKu0q3EsbijNcUTEhwulzE4hoqP/+rf5HBFi8wzJQHnGFuphrrm/vd/k0xOrIMDuNbY1+nKo3jxv/8r9Tg71sEBXC1k7P6XombgWSStBScYCrpzrO3Apv25ARhFnVL69/lLiCjm2wnups8mBxvgTnsFCgcAlfLyIoR6T5yUxG6AWsjF7+lfSrneFSfYjYV3nCc4QV0zfemBPPnf/6W66iVoNh7gAiUH7Vzyr247F+22AnClHHV14r/psdlDGOBVsND4L9U7CBd9jFoR620EdzXurx7qmnt0eX2E61yi5XL+hq/eEE4UHK+UIZscKnB32ZKqyWusw7uPhZ9rnnzB2hNQ4jWehN0EeWfnHHSK8mUNZaijO93s22WMqWO0fIqzk9+W6ttUZTvp+c+m8vTjuENw9U9M/m4p9jTjrsKkbesN1i88jBePnRXGXiolNbep+Oxgtby+fomF1es+JA/xtf6C/qabSx6q34fPTb9PfvySh+eX8Wzn7sHr8bGMzzmlPD7xeDLr/y/n1P2u+wu5PCqUhu+8+gcEjQk0JMmzL6/3v/9LaXJfCXS3W+HlWB+fKH0CYtylLfefLo//xJLr36UqmZVTyY9fHy9Kyv0XP75LSuNvHtO7fTll9+WPLyndJ4Y/6v44pTzprJtymXxx/2e5DP90dyh9vf3joB/fdqcfJDCv9Bft1Qcy8b//C1xsnlIVm6sf3OzPsJ5I6ONbHxLH8pkhsJZ+QrbkMQqOcbofZT9+7cPu+HMq04/fepm3Hv6t4bPdEb355+KdMNhFmHH3GDyuPY6pyRrKx+DvsuN7Dcj92DmP/z/5dQi//TC0DrUv3oXZISDnYcD75jus/pZbffo+45FNP73Pvw68FfPxdjrmfjygX3tEc6rQXY2O64ibZqLfzAi1jJ9+86f7ef521e+r7Pfng174zgFPFdzN05RWDM957rRT6P46KfTIbgyvu+zBXK44pTeBbymQv7bUevq6XN7+0Qezkfnpm8xV9Q/j6TqN8/Kvzw65g6Xe4IYms4BhPKoCh9qSnMvGPXv6io2xaK2kaopw+rWvf7eU/m+Wvtwi93/y+IPS/SN5+M5l/F6vYTgPqe2XI539G0vH+Doqz6kvLemONI+7wZXxx1jyoxA0T/7u4y92n8/5UdJT/cRL6v/7cvf9hn9kOJY8/MuP/9znIwT+gtdegWvHcXNfN9Rt9POEQ3HEOFAeBs39kHqsxhgeS0pVY7EhOr1M7A3/RX0WqDz/aepmKUs/4H36dsP/9+n17r8qPf+k+kT7yw9mLA55+tEN3/V5EravfOmD+BjJh89Y7gqnqIq9rj2QJ122ZDy4dcmSMhZs9BG4qlUbo3WefGlK03KNudxAH+Ff5gjncsNjGUgeg+pQ7TeExCGqVjOeQ+1JVeGXUv3HVdbm8c2q7zn59tNvPnznl+84fpNF/deUofJl+G9I9SEHeyfBPcWcVZquocxpZbIk90vmc36sLknlMWodxoddbuIRh7vgOgTJXMbwWGVbUhq+QZ4uNnyKg48cRe4Ccs79Z8excf9NUv8x92mH1KdS8pCJ6HMQpTqAVP8g+qF5/42rf2M8wDz5zXT0Xr1ceoSofk7DI0sX6vsfWa5ySsCxqss11hrFpzH32lmvbgTYV+WVcZSc+2F3993mxtdpdqD9OrM4DKknB1UlGJ6qBidf8rPhmw8D5Q25pLnvtO3vpOd/fvz47fcENguZLOny3HW0/PQ3+tRBP5StPvFkGKWWOganKmCnIbfS3wq6YfmQna4S568p5M/W/4UDI+Gbb70mb/LuE9cW3sMfEjNb8rL6fV0mdlKlV/3dcY5xGEKnNEbuLhOeh5HkUD++JnDGHWaedWTV2D/aGwnuqVrAHOmSe0Tuoapj5cGVamZxrBsZEhvjTNqQGU7L4S1uUK5cfpB1eUqodxHcWFXyFsfMmHvdX+wKSib1G1VACfUfeSt9AknohjPU83OXHsjETJ57S+JCgL6GZAmcJWDcfq0tCZbM4R3nCU4RMnD39dxVYUis42NOPX0AHCjuPpTTavNgx8ezMixmAo42FMwFGyt1Hae63+Voh8eLaikqcJ5Qg6V/qR5nF3OOwT0tQgUOFfVKm3Z5zTnYjYUXzg+caViQEura+5ce7aO635bsKTywMvMKONAQEmNFxmlV4NBCiphemnwDBws8QzlptRrrAKlNno6A4w3LDkM96U77lgjbzVBcAucYW2BfeRRP/j39PtJdhTdKveclcKQ+WTKzt+2F/qXU7+LbibXzA8+KRAmcZ0yWhBpzd9mSSdsSD+KB6fUF59qw78x5+myJzs+NiLowAG5qTHNHioyv+1AazQF0SsTu3M9VgTml0m0FabIyqPLyAjhQqIjdm/YKLOMTgaRJUMNpkTfhz7ngPT/2Cgx1wfUzlPVRZXE7vjU7PQM/i5kueaotSd327JEOkVnOEpwg6K4z/6YPIPlRtRjpCJkVrLoUznJy0qK6zCKlS56qAkvu5icjHSOvSqgKJTjP2e/8cSQb6Zr7l1IuVSbnsYJS3I4u1mwJ3FnXSTVUYHzJc5ufbINzBKcI2XDqZQ1lziXYWiFmZQ1m4BQhw+Ejclc7UZbHb0SF6MwjwwmGEq4caqzU7/1eRYFcDOfiK2oC4Qzj/uqRLrn//V96lJrnSUl3sKPkhcDNH3ZqfIq4EKeL3ClPsvCiQnxurXCOkF1eu16BQ+jOJXXrKC88KIBFJ0aokMUlfW3Jcy4n0jECTF0RoSJN/z16BU7KALNVHm1wmuBw1cYKkcaz/x7D7HpjBVULDVD9A6fI1UaUga661xlKU1+NcIOFUwyTgIEuuX8pPaWMcqzl+czzZASnipVF7vqWBK18YYGHIzhelY6IdMH9l9K031Soo+OtYvU7nGDIQYQacg/Zki4K5BLrkYB33GLhDGWoBggVG5/quSMdGsDlhmLAUNHx3/MnQh0d75TkVMEJxoxEqPxkP0MZcoEn70mWwEkiVgX+l1KaLMaxM20TSha74RQhH26HPHe/1VqsJZ68kWO+neB+xogY6KJ7yZYYcjehpORMwQmqTqrXHshEN+auVnWEKn1hQaT3EdzWOEEZKDZ2e+KYomyOTDecIWZo7FbijMXmFx4Lm1j9Dp0jB8Mxp/7+pX5q8sEayjYUcRsGx14MXYwM1Vr5X8oplTI+eHsCb0I2HwGnKE8fY/iXumAd67D4oDhhcIocMtH9Lz2Wd1bHJCS0INKbCO6sj46hrrlHVWCuZiilSxohXQKninTFzeysEOzewgwlgXCaiJV3//UvIi4T4p1QvW/g1iIG7mEN5TDkDlX5wjuh3kRwb+Pu72H0HaeGIbeQ0ISi8B7OMhQGxrnoumxJrmsWLfKIT9yGc5S+X0mowNhF7lKluaVQG+AkwVkiJrqH2pKQR8dboe7/cG+PrsqRLrpHnrtUOytceTSs5jzBKUqKmC0ZZigfB1WyZdUAg1BtuQf/Ukqp5FKG20qk+wrvlFglSnBjYVe/VzmSmPcXnuWifhNOEbJZ4PNuZiXLlzQhaxcIp8gvLwKYqS0JlYcHuFTYLq8pTRcH5UhLhZjlBMHpAl12fVXgqKRY9xbm5OL2CufoZygjrX/79/qpXCyujk9SC05SZZLD6HZWmH5SaWB8akvgHMMevZFC99C3ZNzgWNQG6I3hOlC6pMuWjJOSas2aoMkrnKMM610iXXNDbUn/iZxzrCNkRsnFaYIz5H6YFGfAnfp67jKsncxKSxrhRMFJAm712M1Q5jFZkiOl4Xkrx3ojwd2FCoyve7/nVMxSAgzipUteV78rL2mDkwSnqELjhUfx5HUNZcrJJGV4JaVsESWcIFC8HvVj7jFZUrqEScjDpWe1FJwm3mKXYfV71ckwF7uahZetoYRTlJcXAXRrKMdA3a3wNOQOLtDdH25tSEBEuuReV+I8gnakY2RepBEA3FdfDlgCTS11K3Gmm5gJ2/F5KIJzDK0mIl1zQ6/AIW2qsKQJNp2DcwyL3iJdcV1tybQsUA4VoBdwP7O+V2B9RCXFurswwwmCkww7KwS67Ma93+uywEj3FmaF6qEAd1ZtrXDpcdSGeu5SFy1anhdeiXT/hxsbA3acwP26hjLYPpkAV+vXUMYJjf2Yezwij+FN8FQEZwkUsXuve7+LCE3IyamCk8Qr6H7tFWhnhTY4S3CO8vQxgmElTqqW5ge6s/BGKbqCwSmqrk5hgvfYK3DYzizU8fGGVoFwjqFmOlK59FBbMjx820O4Cc4SnCbeIspHl9e6wtymCo1wluAc4yLKMPo891hklouKswZkSS04xzCyDRQZu50Vpv0BA91ZeKMkGxfBSeINusfV7+OLOEcHcLExfRwoNL7siaNQuA3ZaYJTjDN/ga651zWUoW4sABeLWLQxF7kj5eF5Q1ILTjIE7kDXXF/PXRV0p1AHyBtCN5wk4E6UL2soaUWcNxHc2jisjVOJO+yJMx7Qo+VUlAPkHWcITjHWlsSpxO33oawO7pGPj3KAzBK24SwRM5NDnrsqNo94nADXiDgFONZzW4rTFqNuOEu8kNjnuSfpEkEBoBdwEWW1g3A3f5oNutvgNMFJ+qLAOEtyxjx3xFwO7wnccI5q94JLj6M2rsQZPpVLpAMEuFq40P065s62W2mDQTecI1zcHmcoyxgHSrfpmnnK0JweOEu8nRXe1HNLmMQXZ7IE7m2MjWEuutkZypTFhfDktOAcdWuQKKour3lsZRjnmYAFcd5GcGPjapc4kfF//5dSKs+x2gL4FpRAz25wX0OADHS9VXnuurok0BHyjrME5wjXnnvsW1I3LhESGlBenpSAI0S8zuZnKEPdXJhVTCPDWcJVdM/sQ5lTSjlS5SJz9JeBkwQMhv91H0seWk49BnKCQnhOEZwhclVgTuPxlUjbrfGWxyI4wxiv41xzM2soIy0U4j1nCU4St7akVlLIxA4THovgJH03kECX3BC5p6kc47n46gQXcJzcX2pxLrihnrtK5QjczXCe4HhDQMxhQnc9QzkSEBoQ5j0Et9e3eb32KCr1njjjlj0qhRvgwQhOMpZvXHkUtXqGclz+HubweCvO3R9uL08+BDBXW5IiHSDvOEdwki4fESfNPUbuKg4ICS1wluAsZfIhgrEqsCouERQAApsZc9s/uAlOEJykDBuGhbnsZle/222lBQqA4CTxek7N7olj5/cGuLfCSYaa6TgX3WzfkmwT4fi0UIeT5LGqJMpFN7cnjs1WACrhmgXWY+4qCR/nAHmjxLn9w82VwDOUxtxtcX+F0wTeh3I4pFxs/t4C5wjOEnn1+/A8kHOgRZ684RzBWUq4ZoF1r8BRli4B6IVrFji3hjJb5NGAMDd/uLuAF9vcDGVKKc6tBeBqXa/AOMmIuZU40fbKZJ5TBOfoAnag2o3Zeu6csjF3eAI3nCQ/fbzeOEPZL3jXtQRuLM6wsSXh6rn7yF2eisw0CwxPQ0feKtUlXHK3bqvk8TL31tkm3M+ti9xl2mJKdUl8xe2VeZPn53e8dbaJFrq7PHeeHlERuMPLOc67iEjKJMzkVK+PTq+v+CxgW85JbUkefs1ZS6P4Ar6fuN6wf0s/5M4lpfy40+ecxz9nrSElEedn9zpDmVJKuaRs2B2fbAnzPjQldXFvFjRbklIeSxVzSikXzUvCc4KYUz52k44zdGxGtJZT497v9a4PJdRqIeZIlTDvc+D25tku2k9spsvr208QSTZyYtaafco9UG8T71ZXdZwaEzndrmvhDpZajvh+4nofl9IVgXuzcIOkMVtS7ddT8rSWiJDUbvJG3x9p6Y8F76bNdHlNj5PqxAZXkklkZgxNh969O3IuOhNt1A1sc4kSGOsur1UccFahUcMi9+Uxt4t8g75tQJyfWb2b2VBsnqPcV4DN+sDtKt7NsLwlzM90HHPXTaeUBP4Zj3ZEzvaNjI2llgfdTvp6YyuYiw9kMFfPnQLdWThYTqWoLryV/CEdEiwENSLaT60ac49lgda+/xXh9kVlBx8XahtybxVvCrDKc49DL13o7mfugcqT1T3lTw9R9ivc6uOP9HT1DGV/Lkuo/dZ4Z0OBUhlW7ZTyeD19+HO276T053r+T425vxHtRlf1CqyTJWYob2WoEhumrsqYDU22aLidT41LHufbWV8tXlqx6hXYv+rHZ9FuMjxZf4JyScNGR8M1Ww28nvey4xYWZijL5zXyVOI9nL5ZiRPoCHln9SxyV9I0W/8Xbcqc302m0+qBdUm5jA9ezvoGnxY3na6K3JNy7kCHyKy9HnWDvSHZwRCZq2ZE+XGJ153l2CDaKsq6y+twTKVYRRle3iOf5SzfUt+3pHT9JEt5NJIbJ6rTXz33a/+rX7+uvP2TS9T7UNZZeCvgG/D77V9++47GJ+a+kujxWSc7LdfEPqeLZ9cmBhl016vfq08rNvgbuskNC6/uZW2IdtJnk45vgl+svGK9hrJaRBnm+DhWrNwd+xC5v/Ah6EWbHpjLluySQaUJXVWg830rK5tvRwlCJ1ra4G35b0b7Yf1Xve5T2/YP/jv6KgSn+2aGEv7+l5Smydq/ebP++W0e5joZx9xlGHllec8/Y+jH8Dcv5LvK/Zkd9iV8LL/JOafcnXM7Km1SJh+uN+0VWJd08ydYlPEHeKL6WbQ095sZyiuOhAtEW17AXgTrXZVqz7Brj6Q3yZYML0sJ9FjAcfr8tilKWJDDPZ1Ox9x1v8Awh8hxjLlhnWBXSlVbUo+zPWv9FY/Q7XxDU+qdFfL4woX8N4y5O2uj4bMwV8m/mc/ZEOdmFrqtj73k3K3hozBXydwOwikFOkD2MGyJk54af6ongjWiXShzY+6cU/bwfA/P+5+UlLvKoZJSKaWekgY+iXKhvBlz26auCSvPUNcOcJFzDUsiVwVqFnhLa0YJzjcsCLe6vMqWjKsx5ErasO4krbkLS5bAosdVFKfZS10VWO/XE+YA+dmqU+l8w0dxWvHVY+6+oDtPig5o3LpWzVHekBBRVT4bwxC5q1YlJZVcXMrxrTlFZdKSJFdd93O332ic1B2w0rt6blfzfTyKuUsuj77rdd57UuANvBeruGSI3CWXXE+gup5vrz/FTjV8FCtwj9mSKrWdLYC/lzL+OibExvegUw0fBds8alrPbVvCpjhLcJquhUQQ0y6vnVxkSxrgFMFpogy2O9WYu8pzG3M3QYM/OEfkNZR5rB+zhrIFRR91OEe4a20cc49D7pw8iQMMxp0eg4TwccxdLX63+r0JnozgJHnsXHLxkXTm+nNLoLbB3RXOUxXXBjBG7lKncqIcHkui3P7hrwhzyb1d/R7oGHnDZASco+RgBd3/1b+pHr+jHB+LxG44Q46Wh5jPlmT5khYou4eTlMir3+u6lzgtxHnHOYKzRO049VxQEmfbHoCrBR5z1z1e49xbAC4WbgpwUs897NhTFJw1wVocOEUe5wBjXHN15J6UlggK8TlHcI4SbdBd57lLVVqSLNFrgBogOEXOj1F3jLCdpr0Ch1Ct2KwRwjacI9oD7qQ/d7BuWHzkHgvn6ONjkEvuzer3rFY4vpLCvI3g9mIVdE/ruXu5pBxlDpV3sqJ7OEe0ZMkkz121CszFoDu+ahcj4EBDMIwyWHrT5ZU2OGFwqihTS/N9S1ISFOIrOk7BSYJNUD6tocyvrwgrlyhPbnB3/TApyiU33c2s2vxd6I5P4IaTRancmN+H8rE2L8YRsshJghMMyxSDDGonkbsacqcc5Qh5q2SZbjhHnny43GQlTt1ySkgAGPTRMUZkrPehrPdV8BDeAF3U4SyxllBOewVWHboVlzRAq0A4SbQkxJt67hzuQJlh0A0niZUseVNbUvXqJjRpLThFsDRElee2grI5Ho3gFCVKHXdvki2ZHJuQEJ7CTThLsOXv03ruYTszzacaEWscADcWavn7m50VBO4mFAum4CSxygKn2ZLx4ASEBgjccJ5Qoftdl9cYR8cyVYFwmlB1gXWee1qnECSdAxBGDlIdWEfuelqyhKuC4Q2nCU5Qql+v96Y/d8opyEMByyS64QT9hRZl7dtT35KReADQyd268ihr36o1lPlRq0BLgryN4O669HGU/tfzVYEiQhvUlsBJQlWWPNWWvHkN8MflsHnu8ZiiFL6wQpA3Etxdl+eOccXN1pYUBQuNULoJZwm1hvLdShwBoQlusXCuIKHRDGXbgkx0wx/wKC65+igepl1ex+nTIDcWFjlLcJpQl9v8bmYewhsR6r0Ed1ZC9ed+33EKgEGQmP3w1HFq2BQn2GHyTnGe4O/5r/7NGARKlDWefOI8wQmCDZEmee6qzWuJdqC84TzBGWKNkZ5mKKs2r7GOkznOEZykH9cGKbyb9i0RCZrjlMEZhjREjETyfFVgSql4Dm+CvYvgVCEC99MayucthGPcXXhPn1c4R9drKsj1Nl1D+XxQQQ6SdwRuOEewoo1pbcmQ6VbP3YacsoJuOEFfsxHkenvKc/e9Z4v8aQtEbThLrIvtfa9AOe4GlCRdAmcosTaifFdbUqJs/cCSEO8h+EtiXHRvqwJluhsR430Et1eqXy/3NnKnYhVlfEWuG84xZElCXHFPHaeqaclsSSXAw9hHNURcfLsSx2N4C0qU+RK4u37qL8YFN+1bEu2+wrLyeIQL8fQGNxcpcBtzt80aSjjJuEtvBO/quYMcHotCDQLg1qrFLgFMsyVVzlTJQgNykHcR3F4ZU8kRTPehrH8T4/hYpEUBnKNfmhhkieJTtkS6pC1Wv8NZ+tB97VF0ltZQAtDJ1a+Xm0bu6jmgSHS3QE0gnKPEXf1edZnKKrpbkEsymQynCBURpzsrjMcmGDQjm0yG44VqW/Kc537eiJLQSgoz1Q1/RIzI+DxDWR2Vh/DwcnmsgL/6OOAPCNUiaJrnLpNOhpGOk7fMSMDhSorVoHua587js7eihVY4TXC4aIvenqoCx6Sp7twtyEbccIZoaxQXegUGOUKWSGrBWSJ1eJuOuaedS2I9HTDPaYITlFjpkqfakklpcIx7C8tCvZ3groLtPvVcFVhlc4SEVjhTcLhQgXthJY5w0IxYbyngcM+1JeNra6pb4CTBWSJdbS/9uXO06heWlHD5N7inuLuZpef5UwmT8EK8ieAPiXHNve3PbY/DFhSNS+AskQLi+93MQh0m79jPDM4ReDezUqVMYxwfywRuOEl3ocV4wn1aQ5mludujHS8cbmg0EWOk9Ny3ZNyaXslCE0pKOVbjYLilyLUluQrcFxwMX9HWEf6aN2so1Ss0oigBglP0axNjXG/PfUtGWeOSVjhRcIJH7I5xub2p585d/vT042EzmS04QymBtjN7u/rdtFcbHtu/O1VwuEgF3U+1JfUwO8Txsayk5EzBCfrKuxiX2/surzGOj2U5OVNwhhxqJc7C6ncRoQGBBgFwa1UmOYDnGcqxK7fakibkFGUQAHcWex9KY+7G5NL/AhwoD0snQlxuT9kS85PNsYISzhE3W1IlS8rkAzGVVHScglOEKr597vLaB4Fs8qsFOSUzEnCKUOsmnjpODa9KLpZQNkK+BE4UIi4+VwWmcdAd6QbDW8WDEZxg6IEd4np723GqCNztCDEIgFvLoSb/3taWpCC3FpY9ZiPcZuF4gcfcQ3FJjnF8fPBY/m6OEg5WQo2532dLUpAjZFF3ntxm4VjDSpwQF9vbviVmKBth93c4R+CVOMNBZTOUDfFwBH/LywxlrtfiCN7hGXLDaeIsT3xe/T55IAhxhCwpegXCOfopyhDX2/udFWIcH8sevQKdKzhBoBnKd7UlyhUa8RhzO1dwsCF5HGKcNMlzl2r0Jha0QqYbzhGouGQy5q4PqOgd2o4I7yS4uVCj2oU9cazLa4KzBKcIEbF7T11eJ3WAoQ6UeSo34Ryh0hAvVYGvr4gsa1MA58iPtk4hLrfFviU0ICe3WTherI0D30buJHgDDEINkP57+r1oDfAqVsnGu45TegU2QmcwOEfOga61l6rAcZ1QNgJvgI3f4SyB98SZCnGIANfr5ydDjJXeZktSCnKEAEy93UE4a2PUCH1L4CSB+3Nbi9MYgRtOEaqX09tsSRm3Ogb48/rSkhBx8e0OwimpDGxDnAc4uLWS41xsL7Ul/X0lp5yDHCNL4ryX4N66jnwhx9zTJrSG3A2Q6IaTxNla4X09d6h0PMC1SqDA/bqGsgzZkkmhCcAfFyggvtaW9OuEbCjeiMcewsDRAl1nr7uZ1WNuGlDGaWXgSHEutJcZynoVZTZDGZ/aEjhJ4Dz3INtrpSGBnuLgpkI1BHlbz20FZSsCvZvgvmKFxNcxdxk+6vzcBPXccIqu2i7E1faa5+7itRx3KwJ1e4d7i5PoXpihjHB4rGDQDScYYmOEq+3tbmYpK+huR4S3EtxbqKvMmLt9xtxwgmF1YoSr7XUlziDC4fGZCQk4Q6jViS+r36tDkyxpg/ME5yjVr9d6qQocRnBZVWAbLJmCc8QpLVnozx3i8PgsTuoN7i1Q5H5diTMelSF3OyK8l+DeyrDA/Hqv2ZL+RS4xjpAPNAqEU0SaBFzYE8fOCo24/E0Ef0K10+PlofG141T1Skhogq0V4Az9WDbC1fYUuasMSS4KhdtgawU4Q6RugU+RuyoEFLcBBlXF9PVeqwKVBTbH8nc4Q+iqwFGcJwM+ifBegpsLdJktRG6504YUt1k4WHn6eKWXjlPVXmsRjo9PAj3Awa1F2m5mpuOUgN2ULM0NZxhGtRGC5H8vnykvLwD+vBypemOmV+C4K865h8KXrMSBU0TuW9LPdWWzXgCjSIsT365+tzCvGW6wcJKcUgqxc8FrbckQryMcHiu4wcIp8piRuNpCbUkRuttQcozZbri3SN1TX2coi3ru1pSqYAk4RumjY4TIOLMnzlj5YtDdgpIjtAuGu8tjdLy+emNhH0rhoBGPtJaTBYcLs2R5oVdg1um1ESXCOwnuL0zgnqvnrl4EOEA+U3sPh4t1ib1UBV5yFPzESYMzBGoW+FIVmCaL3wMcIat4PIJDxbrE3vfnziXUYk/eKdWvwGFK7tYpBoiLi3viBDg+PnKW4BQ50AhpJnJX/bAEBYCHSEUbM5G7qgqkCc4UnCAHyk2+rwrMWk61RPSGw/X13NdX4c7srNC/kOduyeXvJLi9qjPIlYeR0kJ/7kd/lVOPhR94QIKjVbsXXG2ptiRST0MWlKQQCM4QuCqw7jgV4NbCSs4VHG3oFXjtYaTZjlORNjhmlTAbdcCtxSm8W6gKDHB0rGE6As5QQmdLxqMSEJoS4N0EN1ZyiRMUl7Il2axXE+I8wcHdRenQvVRbQhu6BzjzyXCsYZB0eeCezXPXJd00IttDGA6WI69+r2sBxYIm5JxSoAwc3FOkdeX/vXxGAGhOScm2oXC0YW1igIvtdcxdp3BE8Sb0fXkFbjhDgHavr7UldbS++uhYqR91AwcqOW5tSZ59SXjOFhytW658/cU2VxXYH5Uys1aUFKJlMNzaUL8V4FJbqC1ZaBVYhl+IogQYB8C9laeP11kYcy+M4XIqj33hr/8PIPVnzMmAI+VAna8XZyi7gDB7rDYYDsQEJZwiTFvOuRnK/PyJF+UxHpdZDaGUHOK9BHdXwjzeLnScyunNeLuMqXAlxCEYc8MpwkS+mcg9tgpM78JBnKpGksAN5yg5RYl8C70CFzLZ6gVDufxdBH9C7rMQ119yM/tQDtVl+U2ELtXXCOHAn5Gj1AXOzVC+VJc8f8XwzBCnRuYvC7OpKdzcGLevjnxLOyuUt0kRQSKSx2zJ5VMmcHtxtnqcjdxDKuRN6H5sv2LNXhSmHeAU/Vj7+uBnH8pbCNB1Ev6CwLUlw/SjbVZa4TzBKcJcasu7mdGGywcA8DfkyYcLzfQtiVNszlq6yMA5gnQued2HMlcLPItcdwM8I8E5hjnAy4u55vLcQ9NQnYya4BTBGcpQVHJ9ScDMGkqDuCaJ33CsPF2neKmllTjZEsk25JTcbuEEfd+Syy+3mdXvk2VClx8gK7nJwuHy08fLLO0gnC7PwrOeeywcLc4al8VsyfVtVVglpwCDALi9OD1S52YoizWUjZHXgnMMwfFis/tQjkd1+fEBRHN9x6m5bMkYrq8/PoAwwjTDn12J08lZvqQJ9qGEk0SJiLMrccZUjtqSFqjnhjOUlOPmudO4VVnJ1xec85mTBGfIqUS52GZnKB8vipXwjcg5RVjVBXdXQq/EGXYHtvy9EaoC4QxxIuJMnrsMrQJTKYZy4ZXhVgscLEo8XOpbklLS5jW+rHgTzhFnWflcVeDkrhLlFsNbJcysCdxekAXwr3viPOVHotxieCtOz2C4tyo4httZIVV3FWG7EU4UnCJXv15pNnIPxSWnHgrfM+iGE5Ru0H19gnJhzK2YG6ASZzA7u7NCv/m70N0Q5ZtwgiDpkv/93/NnSi5DELj88FhDPTecJcjVttSfW81CIy5/F8FfESUmLtWWFKG7CU4SnGZcYn6p12xJqjt0n3gk/ECHbjhB6Sf/8tUl00s7K6R8fe0LKxSBG84wVm1cfbnN9ecOs0yIdZwmOMtQM32txTF3ufqJgFVK9StwvMuLcGfrucdXVx8en5UoFabwd1x9uc3OUCb13G2R54ZzRImNs3viDAdnyN0E2RI4R8lBnnBn1lAOr7Juga0oAd5K8Af0K8yvvt7m1lD2Li82Z6WSInQvoz3F+2aToQ3f5asU56oCq7vJ1TcWPouSeCOqulqsG449PpaSvG82qbZ3vPjnZg3lHcR4fiOibvZ62Be8+9h3uLh+MWBrgoyUZnYzu/oxgO+4AHnSdx4ao/MYv0tXgeBq3ybIEso3Y+6hW6D7cRs89fLGisjsnbNJ2L4l1czk1UfHOsZNvLEmcHv7rFbCDLpn11DWB+WsQqtert7ZeHN1EGpL3L4l04puZxVaVTWyyCnlnEvO+XFZ52GH8MuDUEPi7PC4uPo9F4G7DfLczPtUCaFxwkZRVuIs1pYUsbsJQUYBhLVwEbvEt8mTD9eZ3c1sVPLlR8hnOSXxmxnl5cWbP2eby39wiytxRO1GeORl1ljf+/5LvHE2KV0tztU/tbmdFS6/nQB76GchlwL39cPHxpTJh6vM9i3pz7OWU20osiXM+zQM86bZaoiOAVfijKzEaUKMxzdaJXyvNvRWvPxqW47clx8eqzhPzCrj4/O8IMtKmjEser88pzwbucfzffXhcZLy6ADKrYzPzO9WuJdUp0f5aAjdV//MPoy5rz489vQ+MndN5UxX3cvHTvt9r25WixISZ1e/Dzdop7Qdn99Rj1b6j/912+j0bT5z6RqghXljsouynA7Jwy+s9eFHepbZjlPl9RXRrWoKl1PJeXiUGh6Th377l78f2denpdo5qUP4ztXbmS3vieN23Ih1fUumb7Xqtlzfq53yW/kQuVUlbRVlmeJsnruqWDQGa8bHU1Xe/rbaqPDqNyR7WlfN7SJfL8zPanGGsriQG/LpVL05l87wH/AmDRakTKIpUX5YHzpOcSNzbfbzIz0yPGVFeV+yi+kGlJOnrGF2mi3Ggu5rj2O2y+vkoIy672JsPjTZBzx3vz4KxOS5b6Uaa5c+6pQcpTyiSbnEWLL8aYbShdyCdQtyH+V/b74qyO567KlMisPeV4o561vEuFTmZyidybbkOuPxTskpL9T9Oee3VJ1WQ+x9fGq/eI7F3cxSLtcfISusfX57ez6j1Dqxr1XROsuJbhBjyD3bn7t6raVBE9Yn3t59kfN8T6tOq5WzG0S5yc315+4PTjl3K/JT5cA7S1/STVppYvEHOemrDZXSV//MZmtLuivc6WzG6qzW2xHDcLd21u8o9yUlfWVJycPGXEEGkY0IsrHCm9qSvtuBNHcjVl6AS0V/QdJ37M1FvLcQeyssrn4vxmBNWH2KFt5sURYYsD+Be09BNsWZX0M5NiByJTdg/bqKt0WBRVvIuzL5vKsoQ5yZbEmpZiad9CasrC1Z+rIgK8MgurBj7mlJydW3FlZYufd7XniIyv2stBMOC4K0DpjdE2d4le1v1Y41g4D8qc3Q1SMJiK3EHXNPF8zmyw+RVdYF7vzuhA7b4jjd8FbpFydePaD9tIby+iNknbJibUBJpdtxst8wOJXH/5Wc+2aBhx4lNC2/vLjIcn/uUgy527GqiKCaex4nJUsea52cb1gQZCOhmTWU9aWry2sTVr2LSjUNmcuQ8i6Tb6CFBSzpI+LV18nymDsX6ZIGrBwF9HUlpfrfzBcBb1XLFC81G7mnA23XcnT58cuHE7XyPF79jgQ++7AnThK4G7Cy5ci6Xs3aXMCSvqnTtZfJYt+Sx2uDsHtYeR7NUcJ7fQXX1YnkD1WBj/ISYlu1vdL785irv52NuGFJX8J18cPp/Or3qr5Mv5oGrFn9Xj3ddbtWVic5TK0TxJZXjpSONj9D2b9YudUK1yqrmkXlYSazPH5Tcs65eyfmlPrfAQuu3g3nYb5vSalGYK7l2yg55fzYjqn01d055ZJK7tZQOtmwKETYTm/3fh/WQNsWOr71DVrLWDlS8uP/Dj0yuKEQ20e9idz9i2xNXRPWjpcfWxBWXyp0wybDsDZgVeB4ORdFgS0oayckHimRqnmvwA0blGGT3osP5M3q93GD46sPkBXWN/jrgrbiP/hGztXOCsHquVPSgagxWzYiE7ThB0/ltVf5sIZSqiS+8vQROE6QTXE+7v1OdM4RnGfYFOfaodJyl1cbygLUYoTEmZ0VUtVmyniuHc4VHG4ot4uYLRlH2qXEWOrJAi1H4CzDBOXF19vHLq9X31r4KEiBKfwJJW7HqZF67hY4R3CaGKV3H1a/X7/1A6vYyQbOEWMOcH7MPd0U5+qMDsu63o7OEpwhxBjpw+r3lItllNE5PXCebl4p4gxlvYXZ+pYYXKbbMsGpgsPFyJZ8znOfdSR8T3EJnCZE6P6Q5xYM4jPShvOMm85c6s1KnDp0iwyxDR15nSg4XtXm9ULvurwO64TMT8bXzZg4UXC4HOM6e7eG0vitITHeSvAXlBjtJuazJeJ2W/LwC3Cs/uE24AzluG1KVmvWAqcIThOilOtdbUn/QGD43QDnCM7SR+yYM5QVYSG8EHPd8EeEaPP6Zg2lnCnAjNzGSpwgNTC8F+KNBH9FiCvtY7bEM3h4IR7e4K8IkZJY3vs9d9UlggLAQ4Rmge92EH7wHN6IbGcFOFfEPHelFI/h0T1OkdMExwsySPrQtyTlrJVReGaR4Sy5hAiI78bcpfoYIiHPJyHeT3B7IZoFrqgtERDCC7EcF/6C0q0wD7knTqpuKOJBfCI3nCbE3grv9qGsA7dBd3RiNpykxJhXerOGstpA2NYK8UWoL4U/Ich8kv7c9+EOC8cb+pZcGibf7f0eo6sKqzhXcKII80pvakvyWBVoAB6ekA2niREQP9WWCArhjQsDnCw4Q4CywDeRe4gFQZZ6sqh7I1kyBUcLMlL6OOZWWtIAD0hwnsB57mIhTnts9gwnaGT1u9Ad3tgf7NLDAM7yrrakfxGjLxaLBGz4Y96NuQWDljxmKN1j4Twh89wypi15ZEvkteAEffvUa1e6fB5ziwfhOUVwmtxdcNc2nnrXK7B6bfzdCicKDtfP/V17ub2r51YV2JII9aXwN8SIjR+zJdqWtMOpgsPFGCF9qufOWeyOr8u4xXhLAYf70LckCQfxBdkYD/6ICNnJTytxPILHZ9U7/DXv+paM25mJ3eGp5IbzdAHx2jTyx9oSz+AtkC2B00Tozfmx45RH8RYI2nCWEPtQvq0K7GJBLiUrLokuwsoA+CsiDJQ+7ayQUpZFDS/EJh3wR0S43v77+BUCdzOcKThc7DWU49FpHhrdsFeoMwWHizFA+jhDSQsiLA2AvyHEdfa5KjDIgbKoJOcJThKgLPBTbcnQjJbAHtU/kiXwV7xbQ1m9EhDCc3uFEwW43N7UluSq8EXkboCTBCcJcbF93ofS7u/RDTdZJwr+iE/ZklxCPBqwoH8sUnkPZ4hwob3r8pqHEmEjOYBBDlBaspAtGdqqRLjBAEQRYOXbx5U4JQXJyLOgu7s6UXC8oR3fhcewYg1lMeoOr+vP7UTB8SJ0nHobuceVOCkXo7nYAjy8wV/RD2UvbX/9dg1l/6I8hnJGc3GJ2HCm0GPuGK0MWSF3gwBnCk6QI1xpn/Pclr9H11duOk9wigCX2ud9KLPQHVy2BgfOE2J7x48zlEXJQgM0eYWzDJv0XnkQK7IlxtzBlcdbyFmCU5TJh2t8nqFMRnPBaecIJwpxuX2u5w4xkcoipwjOF7Geuz4ocQHgWcR67lItxSE89dxwlhBpiHc7CMdYJ8Q6EbpOwp/xuOAuvd7eRO7pRjgiQnDusnCqy2P3uzF3qfqHFxEhusvfR/CHBLjeFjpOVYFbrhvgYWgWeOExvB1zZ8Ul7ZDnhtOE6Ma3oiowG3K3womC4/WLXCKOuSehW0ej0Eo2RQlnuj7RvWI3M/sqBDcE7hB1pnB3EZ5t3+/9Xm2TGeFAWSBkw3ki5I8/15aUHOJAWSKdBacL3rfEmLsBpfoVOFKEgdJ/bz4/iQEBjpMl/RylEwXHi5CEeJstGVKnORnLRZeLjSjhLBFWlX/OlhRFgdGF2BcP/oocoCpw1RrKAHcYFj06FDhNcI7LQ/dCbcmb3xCSYTecpTx9vMCKlThJWIhN8Q+caViyHHDMXee2szx3aDbEgTPlAFW473czG/rPRSiBYVF+vJWcKDhBhKHs+45Tk5ZTxHb5fAn8KZdfcZ/z3Dlng7norm86CX9GGRIS13nfcWqYPlVu1gyhG47Xx8OIee46VosH4TlFcJoI1VzrqgJpg8lkOEGAQffbbEl9TOJBcKVuMgOcI+AM5VONudgdmrE2nOqxiCLgmLuO1dlSnNCEbThRyd1ylyvj4podhD2ER9e9kZwmOMflF9ya1e9E150rg284Q3mEx4hVgXUKJ4sJAJ0Ie1C9X4mjzyvAqwgVAetW4th0BeChTyVfGRff7SA8qS2R9AboRB5zj4Pu3KfjiS/AOwr+gFz9eokVXV4NuVtw+YwJ/B2XN3ldsxLHkDu4MnTAMeSG4/X1G1fmuRc6To35EgEhtHHbIrdYONywYVjMbEk9RVmsfw/u+qc3+DuuD93r1lBmMSE0D0VwogAD2ffZkioaKOcOTj4LzhdyhnI65Daqi+36IQD8IddXBLxf/T4lNETmvgon6tLH+cKw+H71+5jbFrWjC7C5EvwlZfjlIktVgWX6kfDcY+EUXUH3dQewsBKnvLwirJxSyk4UnKAEKMNdsfo9JdXc4V3+RoI/5eorblVVoLrABojacJbrFy2/j9y5mqDM6gLDK8kNFk4RIIO8MOYe89wpFasoY8uTD8CRrt/5dcWY28xXeNd3UYC/pFzen3vFmPvxu8OPhO+5t8KJ8vWLKNeMuUsymovusaRL/IYzXB8P3+5DWSsBDpTPBG44QYQL7f1KHNmSllxdXQp/R4R6jYWVOGO0vv4w+cQ+lHCebl+ciCtxDLPbUbq5bqcMznB9Qfe6nRVOOBB+EOHpDf6MADN/a2pLrj9KgDiuX/m2IluiWLgB/XyyUwVHKwHqb1dkS4o64fBK1WQGONSYnbwuMq7q8ioehHd97zL4M4ZBd8jaklHWgy40ZwdOdf2OBUu7mQ0vrj9MlmSDbThTvnxeaWE3s/o3Mt0Aneu7c76N3PUhZfXCwbmxwnny9fFwzUqcIjJE55kILhAwW1Ir16/1ZNn1YwD4M8r12ZL3XV6rYZywABDIUq/AJHY34/LyUvhL+qKNy664dbuZKeiOLsCUCfwdlzcuWciWTHLbAkNkRW8ZOM/YGiTgmLsqWcy6TsXmvgonyvnyMfeKNZTFFsLxlaePwIHirqGcUBUYnV6BcJ7r4+G61e+adIeXh1+AQ0WIheuqAkWE8Gz+Due5vAx3KVsyHpz17+GJ2XC6kHnucdIrp6JbYGjFFCWcJsD6lnV74iRjuvCkS+Asly+hXLWzwstviOf6QQD8GdenINZUBeaUs8LA2GxbBOcZkpOX5U1W9OfOKZVUbK4QmpMD5+nDYb6sYdCKMXcpKcLTAYtKSuI3nKS71GLWluRxYV6AuVQ+c5bgVJddcksrcRSXtMSgG85y/SLFNVWBj4MzBxZcSSmX7DTBCa5eRPk+cpdpbltIiO3q8lL4Wx4PuZeFxfd57vz0O3OUoXUPRk4SHC5AO5ClqsDJNpTFeK4FThIcLvfJ44h74kyXUMqVBHf1EAD+lKu3Vliq566DtVxJG5wmOMHl25mtWEP5+J2tFSIrw5Kuiw8E/pKcrhotreoVKBw0QHEJnGbcX/0i/635Ios8AAbXJyAWu7zm+vX1xwoQQb68ccninjiCdUOufifBH3L5SHZxB+FxhaeiwPCktOA0lzcuWbEPZYgVQ6ziNMEZhiqueDsrpMlBGcxFJ1sCZxmH3FdFxoXakjwZdBNc1wDn6sOAP+D6C23d3u9G3A2Q6IbTXF3QvW71uxZ00V3dLRj+lBJ39fuEiBBc15zAHRbOcPUE5brIndV2x5e7ZrzA4a5OliyvoewVMaEJxcMRnCNyl9eJnFV1xyZow1n65e8B96FMJV/+RMAGJinhLIHXUFap7ZJKKRqZNEHghuMF3lkhTxLdKdvSLDb9ueF0IfPck02Dy5W7ZfJZth8OnKSUq6PhYq/Aaleckosxd3AWUcJZrk50r+oVmHJJZZI+ISinCM4Ub4YyVQf1GGybn4xLySac6PL8w7psSZcnufxoWfCo4nSK4BTXZieXIrfN39sicMNZrt4vbCnPPRyR5ZMteLSccp7geONil4sGSytrS+xF2QC1JXCWqxeYr6stEbibYcwNJ7g6HC6vxOnlVFL2IB6bRZRwuoA7CNcLKHMqxRq92JweOEu5+npb3eXVNGV4iu7hJPnlxckW9n6v5JJLyYZ1sZmhhJNcPkJat4NwGjY6JKixvNR5gsNdnTxenKEcV78ng7ngutNjOgJO0Bfb5YAzlPVGCtkWh60w5IbDlS5ml6tC97rV7ynZV6EB6gLhJFd3eV1cQ6lzSVNK0kQdznLtQGm5KjAPH0sp5r5CK8l8BJzl6k1xlvZ+n/426/Ia3NWdFODPGPLbAcfc0yKFy+ZQ2UjghqNdfpWtXUNpBWULcnKLhROEXv0+ffrOJQsKcZX+FyktONwQC6+KiUt57jFQ58vvMHx0cd4N/phLi0uW8tz15u85pUd9yeFHxHeMteFM11YFrt8TR2QIrn9Gcp7gDFHH3PVGlDkVLaeCE7HhPOXagdJCl9dqkF0eqW7Z7gY4RXB/K/Pc1lW3Qv0PnKFb7xKxV2AdBEpOReiObSgMBI41NAOJ2CvwZft3YjNDCWfpRrYBV79XS3H6jcwM6CJzduA03WA7YLZkVErqN1cQHYIatr4w5IYTXBwK11UFppS6e4y4ENRwU3VvhRPE7VsyCdy2MwsvJ6cI/oilqsB6+FaSjRUa0G+vABzr4kq71V1er9+mnjWy0A2HK1c3m1gbuS1+b4SsFhzv8nHsyr4l12+7xkfavMJ5hjWUl4xp1425S8oCQnRXt3qHP6TugX3Fv78UufPb3xCQmyuc5uoy3JV57lxUloSnPzecpk8fB+zPXd1NhO0GOElwnmtn/tbWlqSUFXTHVi5uOwl/ycUbqi9G7ly9ytfvU8+i/PQRuK3lMXcVDEpJ2aA7uK6ho9MEN7ewm9k0z52vzuvwmYpuOEkfDi8Ki8s7KzyN3kSE2Ip2jnCSki7dWmE5WzIE7pxT1hEjvEcfdWcJDndxP5CVtSXd2nfDuci6PTqcJLi9lfXcKRdNp8J7lAUK3XB7K6sC332CQNxZ4XQhV7+PzQJLLlm5WXBOD/wRa/Pcj2dwY26AlIYW3aFrS3LqS7qN6+Iql3d7hz+kVL+ebv1uZt3uCoJDWP2pcXOFw9XD2gusy3OXVFKxK05s/bIAI2843sWX2dIaylI1wxrzJeJCXFa/wzmG6BhwzJ2r4VtJ3WBOVIhLmoR3ytsdE8ub1yzKFz/cLnacqpe/6/Ean4JulpTHI3Pp+7gPC7ceibYi0faNi7IQa2coS9YPoxUuP54MLZpzedSHPYrEHi9KefRxvvgYm1Mu3T1wfa/AnCS5o7uydxmBrexc4a2zxZiQuOJfX9kr8PEbgTuy0u+sYPDEk5UXrnfOetfG7Q9j7pfu3EJ3cAbdzFs15HZ9b3NlumT1Spyci5gQW39xFqNunqx6R3jbbHJtVeC6PHcubscNuLrElLCeJ6xSrnfj6t843jfbRB1z19tQvqkFJSC1XTwb3hNd3B7fIo8N8LxlWrO8EmccaOeUstAdnilK3uga240947pru+54542zSeSqwOpcype0wBbCvLEYZ2w+/Y2o2ZI0uQmXp98TkJPEkvyuT7OY/YVLx9wra0seHUuKjElsJWktw6xHCq3kxbeHq3uTvovAJVauocxKudugoJt5i2VHapK2e2zwmIJmSwYlFeUl8XW7dDhPTH14R+RshnKri1u9fIjcbsJN6YdOK05bGb58+LXUf8atTNo1z7l0Z65GXRodl7Ml9YmUMGlB1xDu05mafzoeW4A61fezPJ/W/6kzv9q125mt283MFodt6NIkn66+biKz6x/XLZYv5dFQ7rFvnRX0N7V8Wu1YuEXcMXd5KiVxVkMr3dYKKyrv6/HX0GNwOlXuZN/KMJv29s2x8nGN3rVXytr+3I9CfRvjhDZUbX66/ur9Ravbc35Kj3EnH+pHdC7ZLuxKnLE74HSlLDHl6dl6Y7IWo9S/KwL37b2tiMjDL6zyZk3TWRYj99jkoJR+w0zpz/g+PBqtO4VO9K08NQt89wXO+moX3+U+zFDWHcZSSooOQls1CnAG/6T6rL/OPj/eOR6pt7n0x/UhW1KeXzm3ga1Z+v5u1jk/t/p0pm9l6LRfuh6vfYub8nhGyymlYh6rHR/quYfLPBfzky1YMWcyXMOzX1ad8h0Pi+tNJ6LfdCFy0lcbd2W+5If238qvK1oZNWBFJqR8WLWbh9AtrXIrZfqqJEnt31SbU1xxpXxaQ1kPulV7xreqeLMs7ymqPuyW1sVpp32LCztOra/nFrXDW7sP5acm+o8/d77vZOX42jnf5MJBztrI7ZQ2oXtIWtO25O3XVPlQbmRV7HbOtwi7Eqd2cd05q+T1Z+lzYxIn/KYWFmw55xtc+sNanKF8eV72AB3bUDby4Tzl9D7RPU5sONm3kock2ON/9ZNXN4mlemyTS3cIW10V+GlhHiGse35bnKJUuX9TpQrUr2fXRNZW16YVV3Z5fTxby5hEVyYf3n/V+y8YLm+n+m7yuCS6X4pTlQpm9+qt4q6hnHJPbkCufl3+srdDbrtE/w3TFRqu7c1WVnIdZOXq99T3EnNVR7byoeixg8L8FOVrqxpgwTUxcXGGsorTuRS57vj6bW4+nKeF0kG3ZmjAh3ruSRZetiS4ySYJH75uIfd14cIwaMmFBd0f8tx1swOBO7o8JDvW9C9J8wPsfi/L/Q4L7qjPNwbMc08Oqriaoytr1tekPgs239PT/RnWyVdWYX3KllgL3ZJ+fcXnk9WnS/ptg/Pw+Z7zDUsC13NPhtnl7fM1YawsLunPZSm5pFJKyuWxI2UZa37f1J4AKaWrtxBau4Yydc1DPUzHtr5Z4GdONby1tjPnQdauoex/62oObkWeZO1g2pgb3hqqs665TpYjd31Mj43qXM2BrVyGs/Lumy27ggWXjrlX13MPzWqMugNbsYfk6tXtuh3AoitD94a+Jd0u0QZicZV+0mTh2Wgh5fWaHAPmXdx/b0NVoCFYC8rHTXFKX9Dd7wGepw1AO842LAs85q7GbsbaTch9wd/7r8hDd+5qG/hcyuOZqt8wxfmGNa65VD7t/V6xY0Z8fRL789YK1XihPHZD6cN599EjFixqYoYyl65ToAs6trXvpmoLFKcUvnJhc7bVY+5cpLqb8NhS8PNaHHuMwk+aGHPLlTRhbbbk8bXHHgvcXOAZylGpp7MIKncLbVZ1DDz6YODWytqWykf4MOZ+mqKULonvU1EgsI8mxtwblk1zpUeXgquPAu7vyoC4uA/lsK/h4+W4RI+gRGw4y6VX24aVOI8uzgcfDz8Zn4ucKDjYlc0C1+9mNiyWPvR4+M2wnsvTERzr0mvsU5fXyUaUkiXxOUVwksAzlPVUV558IKZ+Y8mLDwNuL3CeO9cvBIMWdCWm7q9wkoh57l63pFq1WXjlMRnhRMHB8tPHU62u585d32chIbR+ZsKYG4525VX2KXIPj92P7s1CQnjF3RVOcO2D7eZ9KIlt6DmlUQEc68oS3A9rKEfVJlliQmTrmwUCv7jy8Xb9PpTDRikCd1wekeAsl+7Zuj5b4vm7DcbccJILl+Ksry0x1m6JSUo42KWdJj6tfq9e6jcVX1HIDScZmgRdcdGtXEM59JsSvEPLfRVndp7gYFcuxflYz92/KN1rKZPAivljOE2ZfDjXlj1xSkoSJrGVfhWlAA5Hu7IJ39rInftMiRV6geVc+oSWswTHKleOuTfsIFxVBRrRxdQvn1TCCWe4rgZ3Q7bkcZjyJWGVknPuHooEbjjaWMl1flDcsBJnWPsuKsQ06TXlHMHRWliJ0xealZyyouF4use2XG0iDByoXHmpfcpz13XBOaWxOpAQqrmH4fyklJwkONqlfUvW7/3eV8DYKOtaZfI6dzMPffv0NCS1zj8y+FMC7/0+7TiVioDwrTLz6rvvkavfDZXbJT2mJqs8tzMFx8rVE+/ZVq+hfKRJbLiSPp6l2SCdX1/1cXbh25X6S0sufWOScUq7lFRK31Sm7ixjGhkOdmVBwOp67j+6qcLwHzz9Ly958stj0Nt/Sckl13+xW9WYchkXyuTuu5Rxy4pq64r0uEuWlEvXMKb0rx5/eTbaPw2z1QDBsS6cVdqwm9mlM6n7mI1lTwuMhs0jnssfH6G3/0H0qYvSffLxFan/7LAcpvTNuoZVMi+v+t+u9u5rnz/f/PmCwELvrDA5usZKuUsef33/FX2U7sa3XUDtQvIQq4cwnPIkDEfW0rmC9lRDtdMvtsXIPV3aUXJpYNw9k9V4vOpHubnvVjskLsY/es5CzIfmXN7+UTDRTxa07MoS3I/ZkjyJ3QcfzTfqkfU4hq6Gz2kcI/cZj3Wxd/kLcnlJTnz4+nVfvectIeL5gtuIm+eeJmIvDgTVDGCfV+4Hz2lIZUwC3/ibTfFwQwHNm3+uTnNPvmE91fj0z+Ty9D2+OYTJH2z9TsAWF0bu1buZpaEs4gIlpUfxWxkGy3153GNJfvcn04rmL6qo+3vD/J/lp9+n7r6Rh1vK46ty7j4//L26WC/nUrrOUP1a9eqvlPHfycMf1f9Ien6flG7Je376E4EbDtWPJa+olf6wm9lkwWQuy0e4z9GX6cuu5nmshyv9p4dyjpc2KnVt3dr49Qi6dT7oZdFo96e5i5R9nE6pitfdgfftzEvKXZ+XnLtvVVLJqZQuIpfH2e9LA3PKj0/lx4NEziWX0m1q0UXyPkznXB1J7oO7tiVwsivSEVt6BX5IdO86f9lFsmkNx7cp4DcTjeMyxD7LMk5a1qXZwzF1VddVyeCj/KRP1Dy+01CFU8aiwf7vpKFMMI+p+b6su3pIeFSEl+onkFNf193n8l/LZoajTsmQG443jChPt36GMn+uCayXpnzwEnT6cJbGIrwhiD6nj4eX8zE5lzR+pzxMWw4lfnUF9hgi03OM3vTfM/Pft/wXp1XkZUjYD7eG1N9A+htAGpaxvn6P6XcWueEEfXSMWFuyeinOUPacqkHh9Cte6vXGkW01xZiG4Wr95bkecI6xaVgaM/4Eh7q//m7Q33HGPzjbS0O/N1/09PP4/t8TtuEEgWtLprUTCwFlfJyfflE1bu1flr7EYhxJDoV6uc8p1CvIJwF3GIdWhzjUaI/FJi8H9/zqAjv842u+hcANxxuzARHH3NNsyfwhTqtO+kUt0z9PqUsn94/8Y/L3zbeskjOvgbekYfjdf/m9wtUvy1VL0Mp7uJvrBt0f1lA+ZZjffln9hcNnhz8cvrDPcCxlXSZfvzB6BrjSEPcuGCptqC15f3TTjMpTwnb6a/15gHZdOUO5vj/3bOAuKb1sBt9XSKQq9zx8p+v+SwF2VSYfTvVxB+EqdL9ZWjj9bEmpW4jy/PfnfgvQqjz5cKr1u5mVaevAh/wy4k7PM5YAdzTM6V3wb3/MlkwS3a83l5wmC6779hvG1sDNXVjO/XnM/XZecQjpefJfYGt44I8YqpRPH3Zv2c3stbx6+JoL51gBLnHhSpyP2ZKZ1YfP2Z18YZ4e4FoR89zl6fXTYvjuM1WDJoC/4cIpyo974uS1WXhxG/hTxuB4evjb0CtQOgSgUrXPP9nHyD3dHgyA3mWlGR/XUNbFf1cUvwDEVJ4+nmhLtsSYG2A07o97dnT8OOYefbsLJMAdXViWsaHjlMANUJkkk0+1ZcydSirCN0BK6dJegZ/z3FVB9812DAP4yWXr3z93nBpG2cVaG4BBGWcoz/6n19dz5+kW7AB/2pVrXZYjd8mKAgHmBd37PSWr3wHmXVdaspznni6ZzLNblwH8TRc2uF6M3M87KGSjboBev/n7+UPaD7Ul9RaTxWIcgN6YLAmY565TOcoCAUaX9Qr878OfT0bZAjfAi/MXKX7ch3J8WYoZSoDe0OX1/EHtpzF3JduxDGB0Xej+vIPwuPm7dAnAq2D13E+kSgAGF9SU9D5H7ukyIdEbIKV0SR13b8uYO8uXAPQuDIdbakuMuAFGgbMl09ANwOWWqwJLvrQFLUB80TpOpZyqgyo2oQQYdXXcF6xR/JAtKdXeCjlloRug0y/AuaCL6sdegZNEt4QJQO+6PMTnXoFX7vsAEFjYvd/Hm8qFy4UA4ikvL06zviqwmKEEqA2J7rOD45ZsiXQJQCVytmTcz8xaHIBRFx3Pj4wr+nNfmMsBiGuYBTz9X96y+t3W7wARrMhzX5fKAYjssuD4IVtSNy7R4xVgVCWQz16muGkljjWUAKPLEt2f+pZMfiNwA8yIV8993ewpQGyP+BiwtmQYaBeb4gBUrltXvqEqULIEoHZZUNyyg3CSMgEYXLdlwabILVcC0LswIq7v8pqy0A0wGIbc529ntr62RKoEoHbdtjNbsiX6cwMMqqqNs4Pj58hdt5wSugE6+bqMxOfIXR2bwA0wyE8fz7NtzC3TDTAIW89drrytAARWnj6eZ01tSda6BGDGVQ2619SWSG8DLDi98G5DVaCVOAC1ywq6N8xQ2hMHoBZ2htIaSoB5wxTg6SXTK8bcY22JZAnA6LJsyZa+JQbdAJUW8tzWUAJUymWrXVbs/X5lQyyAuC5b6/Lf5y8xRQkw47pFittqS6RLAHp9/cb5kXFNnttQG+BVmXl1jm07CJujBOiNE5TxaktKFa6L4TfAwxAaS+S+JanImwD0qpLpeGNuGRKAeVeNZrftrCCIAwwuC4krVuIMiW65EoDaVRXd2/LcAFxvy544xtwAlcuC45Y1lMbcABFs6RUIQKUPjxHrucdKRYNugFcRsyV6BQLMy5MPp9m0s8L5jwQAcZWrMhEf67lLGpZRGnID1K5a7LJmJc74UuwG6F23XdiK1e8jgRtgkMPWluRUBWxZboBXAXsFjgy5AUZD5+vTR7Wb9sQRugEG1+3Nu2YlTn9skiUAtaGc++TwuG0fSrEbYFSq/QvOZAdhgK89YmK42pInMt0AnbGeO2JtyVizeOSRALTluqHsx8hdqucAI26AV/GqAnMVr425ASpXJSRWZEuKeUmAJRHz3GO2RAgHuN6KPHdF6AZ4FS5bIs8N8Maw+Xu8NZQl19viAPBw2V6PW/qWiNsAlcv2V1+1EmdoOSVdAjCIPOauGHQDDPp5wNND439n/4MAdzG2wD45dq+I3FIkAHPyVZu/r4jcWfAGmBN3T5xSlSyK4QCvzi7f+N//rfiiKnIDMHqEx4B9S0oRsQECWbMSR7cSgDnl5cU51uS5rzo2gOC6qHh2M+wVee6Sx4OSNwGohM1zqygBmHdRcFy1+r3vqnL6/sYAkUXOcw+lisXgG+DV2RV4nyP3JPFu0A3wIuDOCnW0NuYGeHVy6N62g7CNKAEG1Y5h5yYkNq1+lywBmLqkLHDbzgoADEpfvxGwnruaNZUrARhcloZYUxUouQ2w5OyS6RVVgeOYW+8pgAA25bkNvwFqF9WWrIrcY7jWqhtgFLlvyVW3FYA2xFtDCcC8oR/fuf/smsh92cb0AMFdky5ZtYYyCd0Ac65ZYv7fmi8a5iWL4A3w6uTIuCZyF41LAGZcVSe9Ks9tLxyAORcFx3W1JcMGwhbiAAyuionbqgItxAEYXDaW3bqG8rADAWhNvipdsm7v9+GFdAnAKHSeeyBdAnC5bStxVAUC1K4JjttqSwCYE21nhZRSSdc0VQFow8mrXlZ2ee1uJ2fv2AMQWnn6eJI1ee7qkAy6AWqXbP6+bvX78OrAIwFozzV5iBWRW4IEIJQVkbsaaBdRHGBUrklF2M0M4EslXZSVWBO5q6JAiW6AXi7dNODZjUE2rcRRFAhQ6XfpLSeH7lW1JeMhGXMDzIi4EqcjbgMEsK7LaxeyS5YuAZhxbmxc1ytQugRgVhce86k9sDfuiSNwA4wuio6rqgKH5e8CN0DlolrpVdkSY26AWZF3Vji59SxAI64Jjv+t+SL7BgMEom8JwO/OHd+uGXMbcQPM64sCz/1XV61+H19q8wowKH0V98ldnTauxDFTCVC7ZNC9rsvr+NKgG2BwUUTcmC1RHwgwqlbinBnEt61+F7YBJi6Jj5t6BY5txAFIaQzYp8bGVStxaobdAINhgjJex6nhZmJ+EmDGycFx3QzlmC0RugFG13RSXTdDOXTDOrV3OEAr4o25J1UvBt0ALyKOuYdXF3URB4hpXP5+ppW9Ai+pewEIb9iH8sx/dFu2RHUJQO2a+g0dpwC+VvIl+5mtzHOL2ACvcrkicG/OlgAw6puDBKwtGRI4FuIATJTJh5OsrS153E+K0A0wI+KYeygpEbgBapdkkzfu/W5jBYBa4GxJqV4YdgOMrhjPbq8KNOoG6J286Xtn3Uqc+tBEboDRIzwGnKEsVQ9agRtg1LWcOnfkvXHMncfOWACkuKvfJ70CBW6AV2eOulfWltTFJQB0xn588cbc4xFZRAlQ6RLI52YjVua5x53pAahcER3Xrn5/+ghAShdFRf25AX4Qtm9JtekDAIOrGoKsidy5quG2DyVAL1+0wmVjntscJUDlmpC4uSrwqAMBaNmp+Yit/bllvAFmRKwKrFa/C90Agz7RHXnMrVkgQC1fMUe5sp5b3xL4I1zjG5UrGnSvitwmKOE+SirlaSOXlzSo8t/1xlzyiT+0jftQAk3rw0t5NI8r/SdKLqmUPoYXWdFvnPhD29ZxKuvPDS17WhD9rvfnVetLmtTdBM/Nd2/dh/KSZDywl5UP0K7ztcabYbz+3GPLqaJBN9yf63y1SwL36nrucac192Jo2MoL2HW+3hU/q6313O7E0DSX8FECrsRx/4V7eAovuf9fSjnn3K20c8FvckW2ZPMM5WFHApzg6VqebJtShXVX+npXhMd1kbtUiW7FJdCuhYbNj0u7qP3dKu4M5VgD6oxCy4YlNq+XcreFebdCh60C5rnHs2xLSriHpUAjcEe3uVegUwoNW1Hfm5OH620u+GltnaF0RqFpy9NpJV+Ttm3ZJfUba7MlzuJdeYj6Y7pL+c0lnb0jNqtyyefZ2ivQdmZ386gn6H5zap9KLtGd4VKWG7karK1Wldudd/lsrS0xQ3kvJZVUxqLPPA3kYw9QbmOoLZmPzU73Znl8cV50XJktKTOvuIeSUilVwC6PMUT/G27qXX/XC/Z3ad0VV8n2GUorcW7l5U33uHLzJbMunODz/KOVOBuVC253a3dWqKuJuI91owXn/FYe9+bFPzdA2yRsf25x+55WbjbopN/KkBR7/8cC9yZh935PaZyRdkb/HKf8TsbZ55xmn7lysZXZRlfMDWxdQ5ntCf3nOON3kiflx3PBRuOSrYZCyxP/za21JfaEvqGhJXMeXxpq31a1qezzn+jy+pXlxU3H+O/Ef4to8mNWvOSSSz8tlbumvrn6Km4ol9RPVpZuycbkiVrGZK3+J3XqYpe1/bkHTue9jPNRpZ+WKik/Z0Gd9dtYuwd4tuhug/MrONZWBWo5dUvlcYXOX6TO+T2tzcY662tdse3M2jy39PYt5Udfg7mzW3SuuKOyNgvi7K+XX14cb3s9tznnW8nvusPl2Zc0Lq9rROOUbxF4B2FLcW6p5KWVziVf8Y7kaAuRO7vMv3DJdND2PLezei9lITsnct/ScFpLP8PRTVH3f5yLRZTbnH+lbO445Tq+mYWLVGnJPZUuar85rYL2Zn3gPvFHt3rM7Tnqnhb7wgndd1aPt7ttzJzn71wQHFevodSh+w9zQd9RnqyVtW3wD+LuIGz4dU8lLc9RPj445bAkcJfXcQ+kgw6EC5Scy/u67XEptMcseOuS62TrmFsDyJspaeFubG4DPrtiFnD1Spy+Ykjg/kPy5AMwpwrcpw27t/bn5obevtu6hvGSJbCkH+Kc2KVrdd8Sy9/v6NHkc7ZryZjnXttdDv62MxMSKyN3Nll1R92OhKWUbhuU/uyWrA4UVrpiozB9S/60yXD6/dDaSYcl55cFynP/ZdM8iKE1fOWCS2drl1fX952s3R7l4MMANtq8Emdde1+asPZUOuWwwokXyurIbWurv8Z5hm3C5bmNue6pL0PN6bHpe35skfP8BnT64b1L9lpeXVui/dD99C30+waf/Rbwaej7+aj31vEAlsTt8prKULJ4Re0ih8g55W7dV8mpPCYsc+k2pnwUnuRkzA3LIo+5bUp4V6Xrrz/Z0Wr805Scc1gWtuNU0bzitvr++nn8zeRP3zWBBS7zxQ7CLmSATr2eLdyYuzokgRugl+vgeFpq4ovdzBQaANROnwXcvve7QTdAJXBVoMYlAIsCrn7Psy8B/rwL9ldfP0M5rpQ26AYYdaW1Acfc49ZWlkIDvDpzTLu9P7dsCcCoKrw77d/8oirwoCMBaFPY1e9KSwDeOH88u7q2ZFwoJHQDVM4Piht2EC4vLwDoqzYCrn7X5BVg1gWzgHoFAvzoESADrsTJVywTAmhHxJU4YzMsaW6AStwZytIPuosllAC184Pi9r3f5UsAaucHx83ZEnEbYOL8WcAN9dwdaW6A0RUxcfvq9yx4AwyuyEOsrgocJiZLljABuNL6MfeQ5zbiBqicHxTX15YoLQGYdXpzEDsIA/wm7kqc6mZizA0wumA0u37MnUVsgBdVcAzX5TVJdAPMi5vntoYS4FVJJXCe2444AK/GxS4nRsftq98BqLXQtwSA0bhpQcAxdx5fyJcAjM4fc2+oLTFHCTAjdH9ujUsAQtiQ584vLwCosiVnjWs3VAWeXmsO0IJy+rj2mzWUojfA6Pw8939rv3CyKQ4AvfMr7tZXBV6wTAggvDb2oQRgNOzNe2JD1e174uQiXwJQO7uA44vV71lBN0CvbhYYryrQQBvgVb5gy7AvdhBWXQJQKfnsbMnaqsD6GUDgBhidHxPXZkvyMG0qbgPUzp/6+yJbInQD1E5vpPpFbckFe64BxHX+Zo/f7Ilj0A1QOX1rhfWRW7wGmFHVTIer567IlgAM8vnTgNsjt7E3wKzThrWra0tKvY2Z6A0wOH3fmdX9ufMFBwfAjA07CL+8AGDY6vHE4GglDsCvGujyatANMCizL4/1RT23fq8AgwuKAr/JcxtzA4yGJq8Bx9wln79MCCC+YWuFmFWB3X1FsgSgdvpodku2pDy9ACAN49nzJgG3zFAOB2ULYYBBOX0a8Jt6bsUlAJUmdlYw5AaYEa+2JCktAZh1eh5iw5g7z7wC4PSyQLuZAfwo7kqcimwJQO3sqLilnvv0TTIBmnB2VFxfFVjfVMRugNHZZYEbxtzjQpxDjgSAdb4bcwveAIPTt3rcELntigMw5/TguKW2JJ/eyRCAV2YoAX5S8ukzlFuyJed3VQFoQOBsSSmnJ+EBWnB6JvmbHYQPORCAVnVF0+cFxy39uavursbdAIOzMxIbxtzacgO8KuN2Zmf9kxuqAqtFlIbcAJ2qA/ZZofur2hLJEoBK3L4lI0NugEqZfXmgL1bi5GLMDTCo6jdOCo7f9C0RtwFqcbMl5c1rAM61oSpwqC0pxagboFdmXh1Ll1eAH5V88lIcVYEAvzo7OG5ZiVO0LgF4L+Dq96S4BGBWv/r9rOD430n/DsBtnT6q3dArcCw1V1sCUDs5dn/RnzvJcwOMzo+Im3YQHl4YcwP0zo+IW2pLuo/CNsDE2aPuL3oFFskSgBkBZyiTvcwA5py+hnLDmHs8JGNugMFYeXdWSuKLPLcdKQEqeRjZ5pNG3Zvy3P0yIYEboNIPZ88KjpuyJTpOAcwY0twnhe5NM5TdbUXcBpgIu4ZyvJtIlgCMqnnJk8LjVzOUQjfAoJqXjDjm7mg4BVA5fQ7wq74l8iUAo9MbqG6J3FWXV6EbYFDtsH7Kv7eltiSrCgSYc3J0/Gr1u2wJwIU2ZUv6vtyWvwNUzk5IfLMSR7YEYOrc6LhhB2HhGmDeyXmITdkSQ26AGWXoFXiOL/bESWYoASolcN8SiygB5oy7qsfrWyJLArAoYH9ue+IAzApcFThpFmj4DTDqdi84KZf81QylPDfAhdZH7nqcLXQDvDorNq6P3LneOFiiG2AQeE+cbKANMOfs3Qs2rH4f27wK4QCVsa1TvBlKxYAAs04Oj9u6vA6vDjgSgFb1wTHnc8Ljlnrus1fmAzSiTyaHqy0BIIbv+pYU+RKA3jhBGa8qcDymcvoW9QBx5ZcXB9s25havAd47Kx+xaYby9H5YAC2IXM893ktUdgOMTioGHHy5EseYG2Bw9mD2230oDboBejnyDsLDDKXaEoDrfLWGMmUdugFq8ddQ2s0M4EKqAgF+dnL9xldrKAGYGGYBTwmUX3acEsMBRicXTW+I3FW0zpNNKQH+uJM3otyyD+V4Lyky3QCX2VbPbRElwIycTl2L890MpbgNUOsDd7hsSd3lVZYboPaIiictUtw25hawAeaUp4/H+rIqULoEYHD2HOC2yD3Wlhh9A/TG7czi7YlTH5FugQCDEndPnPz2NwCkFDLPncVrgBljbDwldG/ch7I/JhEcYE64XoG5emWGEmBQStw1lANxG6Bych7iy3puACpdbUnE1e9l7B1+0uEBNKELiQFXv5e6bYk5SoBB1QP7BF/XcwMwKKeGbruZAezg1JrpbZG7zLwC4NycxH/f/TWJE4BRNawNtoNwReAGqA2VdwGzJefOngI04uT2qd/OUIrdAINzS0s29eeuWtDKlwBUzt0VZ1uvQIEb4FUZ89unRMeNY+7xpdgNMApczz0QtwEqXaL7pNi4bcw9DrqFboBK4DG3ihKABfmcfWe+q+cGYMZJjVQ35rnHPq+G3wCD0Ctxzi1ZBGjDye34ttaWDCWLxtwAvXxuTNw6Q6m4BODFEBrPyZpsnKHMw0djboDRqY1LvlxDeXJfLIDouvgYecwtWQIwOjkLoVcgwA5OrbzbtpuZeA0w4+R2fN/Vc5ugBKjkc3Yx6323g3Ax+gaonJtJ/rLLKwCVc3cz+zpyS5cADMrLiyNt7M9tDSXAvBMLur8bc6vnBqidm4b4rrZEqgSgUnLf+vqU1lNbO04ZawO8yOOLM6Lkt/tQSnQDjEq/zOWU0GgHYYA9nBkeN2VLyuxLAE4d126K3AbaAPPy5MPBvl2JI4gDjPohd8Q9caq93/c+EICGnRscv91BWOgGGJRzY+LWlTjl1FwOQBPGMu6I2ZKzWxkCtKBUr04YfX+b5wZgkMcV5mfMUW7dh9KYG2DGqbHx69XvIjdA5czQLVsCsIOhfCNer8A6gaMsEKB3auCWLQHYRdiOU3UPWkNugF41qg2Y5x4I3ACDOlzHq+ce89yyJQCVLiiesnXYf9u+/NT1nQDM2boPZb+FsGwJQO3MqLgtcldDbaEboDKsfj/h39o8QylPAvBiyEhErC0pqgEB5pw5rN065u7vKsbeAJVhO7Mzhreba0seB2XkDVA5dzC7MXIL2QAzhjLumHviAPBimJgsZ2yKs7Hj1JjoPmWdEEAjzmw49e0MJQC1U8eyWyP3uNOaITdAZWhccjxjboDflaH3dcRsyUAIBxicu3nB5hnKdOJtBaAhj+gYcsw91pYAMDoxKspzA7Rma8eplxcApHHLsIC1JWoBAeaUsbbk+Ni9tW9JTwQHqOTZlweR5wbYQ98S5Iw2r9+uoQSgUvKJJXffrsQ5pR0WQCvyy4sDfVtbkgy/AUZj5d0JsXFrbcn4ypAbYJDPXGD+7QxlPuO2AtCcgPXcVZfXU7bJBGhMxDH3QINugNqwhvL4Ye3myC1eA7wYo3U+IUx+vQ/l7kcC0LbzwuO3kVvsBqjVo+6jfV3PLXADVPq5vzPmAL+u51ZZAjAjYt+SkdANMDi1I8j3kVu6BGBw6vLE7yM3AKM+dAfMc9sVB+CNUv16rO21JTZ/B5gxjmsPD4+ba0v6IxK44bZc3l8o1avDUxPfr36XNYHGlVReS9hKGodoIvg2gffEKbMvgfbkrpCt++VxRedUSio5paIf6CbVYPb4H9zG1e/l1ObhwJHKMF2V3wcbvfhXG3+ah5Pnhj+qVJfx2+F1Nkpbq4wzlLq8AgdZUx+Wy8JonIlcThx0W4kDf9OqgFzyCXUSd3FGX+7eLzOUQKvK2mtZ3N6gTD4c6YdsiRgOzZqOD3OXz84p5fz4X358ni3Oy3Nv31khnzh/Chxnvk6s1PHHVb5eydUS86N/cNvz3AI3tO+x3mb6+4fcDc5KSZ6st8jVq8BrKIF25WrlzfhrevmM0L3emT+r7TOU/YY9ex8JcKaVl7DQvVruq+JPWHy6fcx93uwpcDVtnVerpgUC1nNLc/9ZbtY3Mslhz5/Zx+O1s75a5L4l9RGJ3X+OBhb3stiDaFg86aRvcFpbp61j7uzh6caWRgrljKbDnOjDuLCf0HLSNzivrZOqQAafhtQenO/k8wOU871Z4Dy3iH1bfZP9klIppaRSUul775eyfrk0jXA6d1bOS5ZsX0NZV+zveiRcqTqr9fX83E3OKb+XklJK+d3wu2jNvdGJwfGH2hLn9D6qC3QSq6eBOxum3Ur5kPkcF+uwzokx8es1lG7Gd7KmU7M2Frfy+Yybkd4ucp6752YM7XofW4aReHGr3uy0n9fXM5TO6K04nX/NGJWfd3mf7DVrgLZBSectf/9+zL3uAZsm1G+0nCazGE/1vM76TTzfq/P0LVCGN4Uz/oXjq+C315Yo6L6lrspg+jGllEsu1UWdi3KD23g+rY/GryUNZzz37wbWqS6Vo39qIje9rmNzdxHnpxb7D28ryGjQquG0873aiYH7h74lTui9PIZX5Sk0l1w1sHDS76SszXc66eudd6F8vxLH+byXhQfjkk4cS3AeY+59nTnmVhXIw8JbLY97j5qXvpEV59KCu42GH9fRF8r3kVvovpfnfQknhny3LPeN9AUQ/S7vOaeccsq5f5GMuDcZZ+8jrsRxKu9p8bzWM5THHwpnyamP1WnYd7Kbms5Fh9cvtFFbYgB2IyUvrHaW5r6nbtsbZ3UfZ25G8UO2xGV8K4sn05m+p9dt33serb6QhweX4398/x3+L3AfAvif4VR/Zdza8+gf4E9jbm5kYZQw9Po0EIMFJ+advt/NzGV8L+r94Ef5vNUuakvovD+x+fOXAGduXyBbwkfjY9YJMy/QvohjbtfuPVU9PZ9PcfU2lFOB987LJX+RLfHIfEv50Uf/sSTjsef70HNfOTesUM5LLP6w97ur+F7K2Jw5l75F99i4ueOsw3unTVF+E7nzaeuEOMvTJu/vnvVsqwBvlXFLkoCR26D7ltbm5Zx0eOfE5e9qS0hJ6wrYQT5vzdovtSXKDG7E/ijws2EEFLm2RJHJjfWtiB6tmuvPuV/DO/msNPcvHac8YN9HlZ/rZlm6GsGSutBtdgPWM0PJSbq9guvfVr952gsemHXWDOVPOyvwx3jMgkWnZUu+mKHsN6+T8PxzBG5YUHX4Ofqfki0B2McYsOPtrFDevAYgpXTCsPaXjlPiNsDovFLp39ZQypcADMrTx8PoFQiwi7h9SyS5AeblctqYe1vkLnW1izE3wKyjQ/embMnkYLRqBpiKmC0pC78D4CFil1cArvVDr0AAKudlIr4cc+dshhJg4ryVOOtnKOu7idlJgBenLXeR5wbYR8RsydM9RGkJQK1E7FtSheqcZLkBpvKwbdTh2xd8VVtiVyuAC32VLbHrO8CrgDOUZfYlAA/n7V6wfcydDbkBXlUt+QKNufP0IwCVfN4M4IZ67mE/eskSgCttyJYMdxODboArbR9zF0NugBkR11DafxJgydDRKdIOwvYxA1g0TAce7Kt6bgCejankYDsIp5SMuAHe6MNjoJU4aksA3suzLw/xTT03AK/G4e3RNXgbInc/aSrhDTDntPBozA2wlz6rfHR3pw1VgVXo1rsEYMZJI9wvqgKLcTfAnD5wH501+WYljrgNMOukOLl9htKaHIA55bQB7vaVOCe2oAVoSK4C97Ej3C2RO08+AFCrN1c/NlBu2Pu9DB/EboAX54XGL/qWCNwAs8rMqyN8M0MJwKs6WkfLlgjgAHNyOWuf3u3ZEjWBAHNKPqtD9/qVOCVbigOwKNxKHOEaYFnAXoEALMpPH4+yOnKPZdxHty8EaNJZNYE6TgHsZpgODDPmHh3evxCgRSV0ntuYG+BFteWMbAlAM+JlS8ZJU+kSgFenxcbtOwgng26AOafFxg37UPbVgKftSw/QmJNi94Y1lGVI4AjdAAuODpJf1JYU2RKAOWcNcL/YzUzgBlh0dFJ5fX/u0xYHATQuTlXgcCSy3ABzIlYFGmwDLMl9mIwzQ3neinyANsXrOJWLMTfAkni7melbAvDJOYPub3oFypoAzDgtqbxhzN2F7GwlDsCsKnAfGie3d5wy4ga41pYur1biACzJLy+O8U3fEqEbYM5ZzbC/maGUMAF4VVIfsY/ervebqkD5EoAZQ3unoxfAfLGzgjE3wJwxXh8cJbd0nLIUB2DBaZmJDWPuYswNsCBX+e1D4+SGMfeYwDnmUAAaNw5wc5A89xixDbkB5pw1rv2iKtCQG2BWwF6BygIBlp2UVP5qJY7ADTDjrCXmX+1mJtEN8GpciXNwmNzUK7AP3cbcAK/G2Hhwp+5NvQI1CwR4rwzxMVKeu2ulIlsCMCOPQ+1j67m374mTklE3wLwhNXHoZOU3kVvcBph10vh2+25mKaUiXQIw46QSvC0zlP0x2UIYYM7QmS/QDGXRcgpgQTXkPnTQ/d+Grz16fx6A1p0zHfjdPpRCOMB1NmVLuo9ZugTg1WRfhSNHuF/1LQHgVa4X4BwZMb9YQwnAvHHv9yh9S4b0tiw3wLw+TIZZiTMy9gaYM3RULYcW432T59ZyCmDOkCM5eMyt4xTAbsY8d5i93weW5AAsOTZZYswNsKdTFlFuWf0OwJJqKU7AbMneRwFwBznubmYKugGWHRwlv8tzG3UDzDknTG5aQzkUdAvcADPi7WY2FAMqCgSYU9K4d9iRvsqWHFxjDtCsR5yMuBLHmBtgScSOUwDMKqdkS6zEAdjLuBVOLkdOUn4z5rabGcCMOkdyaJjcNEN50q7GAK0a9+s90oYxd5l9CcDJNkTuPOZvDLoBZpSxSciRI1xdXgH2E2/1e89uZgAfBJqhPCn5DtCsMyo59OcG2M+wh3D1an/bInd3IAfvsAbQqDo2BluJA8CscaHioTV4X65+ly8BmHPKgsUtM5TVY4DIDTDnlDqOLWPuPHSePeZYAFhDnhtgP+H6loxFLipLAOYN/bmPDJSbIrcsCcCic2qmt425H6E7W/4OMGtciBOmKnDcpcfoG2BON7I9duz91c4KAjfAG2H7lpijBPggzAxlz0aUAPPGHYTDdJzqHNkCC6Bh1cRklI5TAjbAsqGl6pH/yFf13HIlALPyKb0Cv8uWCN0Aiw4tC/xuhlKiG2DWKTutf1kVaNANMGfIloSpLemPw25mAIuOHd5uXf1+ynYPAI0aB7hH/ivbdjMz1AZY58jYbWcFgP0MVYGHFpd8F7mNvQEWlTBrKAcadAPMGluqhhtzm6IEmFHKWBV4YJj8rj+3wA0wbxxqHxcodZwC2NEpcXJbPbdqboB14qx+7zeiNPgGuI7dzAB2dEpOYlvkFrABrrcxW5KnHwGYGsLjgUPdbVWBVY05AK/i9eceKst1eQWYNaYkDqzl+KoqUL4b4I1wK3HG45AtAZhTzthrXVUgwJ7y5MMxtu2s0DPkBphX+g9hxtyG2gCLAq7E6R26qTEAizbWc3cROx+7OSZAq+LVc1crcYy5AV6VM8q57YkDsKM8FgUeOML9Ms9tyA0wp4wvoqzE6RlxA8w6ZcHil1WBNn8HuMyXq98PrTEHaNcZ/Z02Zkv67czUlgAsyUfG7m/XUBpyA8w4paXqdzsrWIkD8MYJO9B8W88NwIKcDhx3b43cj5uIPDfAvDKGycNG3V/uQynPDTAvbrZEPTfArDOC48bakv4eop4bYNa4J06UqsB8wlMAQMOqqsAwfUv6/ehtrQAwaxzgRhlzVwFbdQnAq1OahHzZtyRLmADMOSM2WokDcJBgK3FsrQDwyXFtQv7b+PV945LdDwTgDiLuIAzAkjz7cmffdnkFYMa4D+WBAVPfEoBdVQXdR0XK7/bESYbfAHPqMu7DhrgbsyVlWJFv0A3w6pTYuHElzhC4DbkBFh0YJr+rLSl2MwOYd0Ljkq/7cwMw44xu2BtrSxSXACw6I0p+ufodgA+OS3R/O+YWwQHmPeJkoNXvZ7QMB2hZmXw4hH0oAXZUqr3DDiPPDbCjPOwdduDOYWpLAHZ1wnSgMTfAIQ7MlmzcWcG8JMA6ccbc+eUFAJUzBrjf7olj8A0wJ58wsN2c5+67BRbBG+Aam8fcY7yWMAF4UV5e7O/LNZTiNsCsM6YDt85QaswNsEo5bhPhH7IlALyoguRhk5VW4gDs6Ywo+W2e29Ab4Crf1nMbewPMy5MPR9g8Q3nMYQDcxvFxUp4b4BBx6rmH0H1YsQtA28q41PwoG/tzW4kDsKgMETsftnvY1jx3Pj71DtCwfEJ83NifWzkgwFqHhfBvqwIBmFeePu5v80ocaRKARbIlAI3Kx411t+79bvN3gCVjbUmgPHd++gjAxBgmo3V5tQweYE4+YeHLl7UlAjfAB2FqS3rljN2NARpUjk8qf1vPbcwNMOeM6Lg1covYAEvGjES4bInSEoA3yuzLPX3d5dXwG2BW1ZgvRq/A+jAMuwFelW6KMtLOCuq5AZbk4+PjtzOU5bjFQQC3EKcqsKrjli0BeBGxKrBqPGvMDbDguDC5OVtizA2w4IzQ+G1tSZbnBphTNXkN03GqL3exOw7AonLY+Hbrzgo2VgBYFm9nBQEbYNnxcXL76vdx+TsAV9jecapfRLnzgQCwki6vAPs6Pk5+v/e7UTfAjBM2f/92zJ0NvwHm5HT4dmbf9i2xESXAVb7Oc5cidAO8OqGr0+Y8d1VbInYDvDp+OvCHXoGmKAFmRFyJc8RRALDe9jy30A2w4IS6u687TiXDb4AZZdio97Ag+fUMpbgNMCter8CBzd8B5gxld8eFya/z3EoC4U7mYkz3uXLcBgH3VAfHg3502/tzj2txdj4U4EL1BV3K8Imh/tcFv1qpVr8fNMSV54Y/r+TqaTo9Xdwle8LeKGDHqZE7MNxDyaVUS7ZzTimVx29LSrmUVEop6fFFfHbCje6XMbcbMdzCOEIsYx/Qp9k1V/smR+cmvo/cziTcxLqRtCt+g6Mj99d9S5xGuIUTGtuxu+/7ligUgjtYW3NsrLbaOL49rKBbbQn8aWVd6Ha9b3DCno/fZ0uAG1gcFo6BxzP2FpG7vDqRcAv5+XXuFpD0Vd6PT7riVxvW3xz3Q9ueLZEugXt56Ws3Lfg9uu3dDY1LccLUlozcguEO+uWT45L3abjJr59i2fE/rf82/w1DbriXXH14ua6LriU/CDNDOdkTx8mE5pW8eCVbLP2LMF1e89vfAC0aAve7KOM63+7wUe32PPfY5dWQ+/ZmTrGzfj+fQnOpfmWN4x9TttdzD4eU3Yrvqeuj/9Lt88FZv53yoXiku+ad+dWqlThH3e++r+fmth5rM/qH6DL2tSip2CDlfj6NwarG3awy/kQD1XNXDSFF8bt5lKFO2sKXXMb79fFlqpyvX//+/py+ef7inXHWN2CXV+fyjvT7/Hs+dtkoS3/Iq+MD9xczlHnmFXfhOeoPyi8v5r7AO2O9E35WP/TnXq4C5c7kuu+kfIo0TvZ2R08O/DRD6S58O6t7NTv3f0jOLvatytPHvX1Rz22mGWf/TqZ9Xme2yCnF8o1tjm/Q/UWee1yKs+uREMDyKujJb5z9OyrpZa7D9f6FKkoe9GP7vldgtn3d/eSScu47Mud6Yuo1VDv7t/OoDczV70oy2v7K4YUcm6sCT9inh0t1pb2lq9d/MwJz9u9jJjLn2T3OnPS1Avbnzuam7q3kfq3zsDxjaNvMLc1c0sUZ/0nA3cyqSVOn9o6qpp59Y+ZhQ6v6q7gN9US7Oz42/rAnjvP4N9QN2Yvb9h3Nn8yZGzYrVRvDHfQv/LL6Xcv1e1pqUjFk75z6W+nXtw/nvtRn2Or3rUruMt354zKnL23dzaz0tZ92goZ76GN0vd4m18NGMfsLfVPzKLUl05ZTzukNLTaGU1tyT8W1vK+6RfcRP9kf6rmTm/FNLZzV4Yx75LqPx63atXyIfNBP9ocZypSSC/iWFk5qnyRTZ3AjzuUBjh7ifBG5674l1lHe0NKQ21MWrDGmFY8Jkb+OudWH3c/76Gx9BqwxTEweVlvye+Q2CLub92VDJ2yvB3fQD2gPe0j9orZk5rIVve+kLJ3Qozdpgnvor5SDYvc3Y+7poRw1d8pV8tyQ+pEoGddQnntI0JQxh3zUoPurMffThStw38mwXq7kvsq3axo4DenOOrx39MKHLyN3Si7iuxoXuHfzKyXlkqu+lY8/dNJhybGx+4fIfXQih2usTYQ46/De0CUkTp47pVRf30rF7mXdG81SHPjssL4lX0fuSaNAV/GNrLsNu1nDe8P1cVRrvl/6c0+G3fwphtyw4PBh7e8rcTSruZeh5Wfuz2zO3RZ2OdvMDjY5alS7tT93pRpyu5pvowy7T6Y8zK+UlPO4QsfZhvWOCY871Ja4lO/m06yKOzUsO3zz9z0it13NAEaTtQ+H/At75LkBGB0/92cNJcDODk8lfz/mLqoMAOb00TEftX/BT/tQjs3DAXh2WGzcoypQ4I7oZdb4sHW4wFvRVuLU7fdFhHDqDSNL/wkbz8E5wq5+L9UhCdyhlJJSyrkMuztXWz4L3XCuSPXc5elGInTHMqwCqGL25BPA0Y4d2X415rb0JrQymYIo1cma3acM2Nn4xBssz/20P8ouh8JO8tPL/OYPgWPkamupY8Ljl5F7ejCiQWD1yTFFCWcYV7uE2xOnJh7E8vRWqdPcThUc7/jB7FeR+3l60pg7tLo+0KmCM0Va/T4pVbCtQjzVBOXTTda5gjOU18KufX1ZFdgRCGLqywIf52cs4sxqguAcB0fJH1a/J0/fYdWBe8xuC9xwE79lSwhtKCWpJrqB45XZlzv6JlsyXZJnHBfO83Na6faSvOhw4O85euHyT1WBuQjcEeX8OnVstA0nGrcviDrmJqKSX8bYBt1woslk0+6+7FtSfyCckvLclkXG3XCS8vRxb99E7r7GrIgFQeU06XnTf1aDGTjJ0eNae7/fU3n+3aPOROiGU4wdp475/vLcN1VSGs9PvxbH+YKzHLsU56tsycsLQhpPlMANt/L9Spz80haDMMpjm9C6q6uwDec5uqPyL31LbI0T2EtZoKJAOM/Rgyar32+ofyh6WoFrXwU4S555taevOk6Nu74bdEf0iNmTc5OLcwWnOXyU9NMMpQfwqPJztb0pCThRnlkJt6uvsiXjShziytNkSZ5bnAMc66AthH9ZiWPAHV0VqXNJKdsUB05RSp+dPGiw9NvOCgRWcppuriC5BSfJb17v5pcxd9EHI6yXN0ue+yRwjKMzkz9E7qNT8PygvPxGpgTOM9ZyxdlZYczfiAVR5a68pPtNKqWoL4ETjQsWj/juX0Tu8Tgs7QispGqKpMt5u9PCSQ7OSfywEud11xUiqRuD5a7HqxMGJzm2ePqXviXiQFyvQVpyC850bHunX/pzG3SHVfJroLb6HU4TsePU2K+foKY1gCWVVNRwwokO3sbgizH3GAIM4gJ7GmJLlsCpjt077Isx91CoKBKEVVLJ0yJAhSVwqnj13AdPmvK7nFKpYnWx4BVONZZMHzPB9NPe72JBUCXVC3EedYEXHg78OVVJySHrXn5Z/X7YhvT86GnInZK7LJyr2r87SJ57JBrE9fxmkeeGcx0aH63EAdhbqfqVBBlzl5lXAAzGwH1MA5NfqgIBmHP0APeXbIkADjBrbBISZcw9HJJ+zwBzxprAMP25D14bBNC6cQ3FMXnuX3oFit0Abxxag/fLmPuofXoA7uKYBYvf7IlzdOdZgMYdPKr9acxtxA0w5+Aw+dXq9yHzLnQDvDo6Nn5Vz235O8CyR5jMx+zc/VU9t/XvAAuGTajKMStxfqoKNOQGmHNwmPxphhKAWYdurPDl6ne7vwMsOHiA+92Y2wwlwKJDw+NPe+IYcwPMOjY6qgoE2N+xU5RfjbnHzrOG3QAz8qGrKH/azazqZAhApd+B5pCC7m92M9O5BGDZsANNnGxJ36/koNVBAM3r+zsdMsC1DyXA7g5uhv3V6vds/TvAsqHl1AFx8rvIPRwSAHMOHXV/tYayX4hvfhJg2SFbCP+0hjIf00sFoHVlbO8UJFtiDSXAsnFYG2bMbaQNsGhIkgSq5+5fCOEAsw4Nj8bcADsrB22oMPhpNzN5boB5w4rFI+q5v9tZQboEYFEXJkvKB8TJ32pLDLoBZh3aJeS3/tw7HgjADR2TmPhqB+G+3EWrQIA5Y8A+ZK5StgTgCEcmJ36rChS4AWaNtSUHfPPvsiXdi2MOCeA24uS5h8B9SCcVgBvJYaoCD97tAaB5h9bgfdfldTiUI24mAM0bAvchQfK7yG39O8CCsXj6kG//Za9Ay98B3hunAQ8Z3v6W5zbiBph3ZKD8aTczI26AeYeOcH9cQ2nUDTCjHtfuHyf/++LvSJYALDt2oeJPVYGlyJcAvJokJvaPk/Z+B9hdyYcmJ8xQAuwuV/2dDvBdr8BDDwmgdVUqOU5/7nphp+gN8GoMk/tHye/G3FpOASyq5ijDzVDazwxgVrg1lFX+xhwlwJwj+5Z8sxKnGvwbcgPMKU8fd/Vdr8DqUAy6AV7lI1uqfjXmHtM3JRt1A7yostxRdjMblweJ2wCzxqTy/qUcX+39bhMzgNVi1HOPdxBDboBFhwx09S0B2N9YPB2o49RQ7yJ2A7wa4nWcMXd1D5EvAVhQIvbntvwd4FU5dMXil70C7a0AsOjI/Xq/qwoUuAHWyQdkur+rChxemaAEmHVk8fRX2ZIxgWPMDTDvwDD5W1WgMTfAvL5+I0xVoHQJwLJyZJ/X78bcR3YvBLiBQ0e430Xu8SlAohvgVb2LQYyqwLHJKwBzcj2u3T1ifrknTn9IhtwAs44c4H6Z5672EAZgxjghGGJnhUn/QqEbYMkBuYnf+nOnZNQNMGcc1+4fur/aQXiUZboBlsRZQzkEbANugNN9mS2R3gZYVC2h3D1g/pQtyemgPdYA7iNKbUl3Bym2oQSYU++rsP/49ssurwMjboA55cDtzL7sFShgAyw6cjrwt/7ciksA5pWZV3v5fSUOAK/yy4v9fLeDcB4PySQlwIwxy71/3uSrGcpq8C/hDTAr3j6UAyNugDnh9qGsKxWFboAZ8WpL+jx3liwBWJRLmNXvXYm5ATfAsnJAqvu7yF2v6wRgQZCqwJSMtgGWjX2mwqzEMdQGWDYWl8TY+13jEoBlJecudB8QML/tWzKUmEubALzK/Y4K+YBdDH7d+323AwG4lb6e+4g9cX7MlkibAMwoZYiOBwy6v+xbonEJwKIjq6d/7VsicAPMGdaah8mWjMoB9S4AzRunAwPVllSvDbsBnuUDtnwffBW5y3hAWbNAgDkHjmrtrABwhHB7v6eq2sWQG2DGGK/3D5O/VgUacwO88QiUB2S8v1xDWYZyF2NugDldSiKX/Ye43465h3sJAHMOXIrzdcepx5GUsfkUAJX88mI3X+5mVu2NadgN8OrIIPnrnjgG3ABzjtxh/cuVOHsfBsDtHBe6f5yhTEm6BGDOsBQnzEqcOnAbgAO86ounc9o9sfzrmNuAG2DecXOUP3Z5FbgBZlULcKL05+4PSaYEYFY+sEvIt/XcQjbAKgfsQ/l1tqQ7EhEcYNaQLolTWyJkAyzq0yUHRMuv+3OPqXcxHOC9MKvfJ3Om6ksAXh3YJOTrlTi2VgBYEq1vSZ0ssYYS4GQ/9udO2agbYNZxwfHbGUojbYB19g+X6rkBDlHG9k57R8rv67kfodvYG2BefmyusP8Syq97BdrMDGBZ1VJ15+i9Q69Ao26A90rZfYz7dX9uo26ABcOWOAe0nPo1z101MgRgcOSg9rsxdxWs8xHZd4AbCLYP5bgbvZU4ADMOzUZ8my0RrgEW5Lqee+84/mNtSSpJcQnAjFwtWAxXW2L0DTDvqET3111e+xcCN8C8wxIS3/YKrHZWkCwBWLR3mLT6HeAQ1VKcvb/192NuIRtgQe43e9y/M9/3XV4lSQAWdXFy/+WKX+/93h9Ksfc7wKxHdDwgQfFzVeD+rVQA7iHY6vdq73f5boBF8XYzUxUIMKufoDxgO7NfV78ng26AOXUP7J3j5Pf9ufc8CoAbOmyn9e97BY6PAQDMKE8fdyPPDXCM4wo5fu44ZdQN8EGUviWavAJ8EK+eOx+Wege4g/LyYjff15YI2QALDlxh/m2vwIXfAZCqxnxRakty1eW1yHUDvIpcW1L0ewWYkQ8b1X7fK/C4/oUAN1DyMLDdO1D+3LfEgBtgztBoKucwHacOrHcBuJkgHafqrTHFboD34tRz19OSpigBFuweI//79i9WrcLtZwbwXpzV7/YzA/jkER3L7j1Vv5+hFK8BFpTj1uL8MObe8SgAbicPnfnirKHsj0RpCcCsIUxG6VtSHYnADTDvER/37xHyQ3/uLvWuKBBgyf5B8vs9cY5ajw9wE4ftHfZ9r8Dy8gqAGXHG3OnALdYAbuGoKPn1GkojbYBVIq2hTEcVKgLcyv7b9v4QucvkAwBPjhrZWv0OcJByVJ77+xnKodzFDsIAb5SUQs1QJgXdAIvGpPK+gfLnHYST0A3wxkE7rf/QK7CvLRG4AWbUKxb39XttCQBzhmHt7hUdv+/9DsAHUfbEGe4m+9eYA9zC2HFq50H3D1WB+aDUO8BNHNUs8IeVONZQAizL3a9RsiXZIkqAD7pNceJkSw5sGg5wA9VAO8ze79VBSZgAvMiHLXfZoSpw91lTgHuo+jvt6vc8t7ANMKdKb0fJlhT9uQGWHRUff1+JI3QDzMlDX6e9d1r/fSWOfAnAvHpCcE8/1Jb09k69A9zC2JZ77yKTr8fchtwAn0Trzz2uodw7gcOBnCo41SNOlr0788mW3NzTycnus3CeIWLvnS35fSVOLnbFCaw+N+WABu/Ae3lMTexrh30oxYLA6kY3JacDOt9wd4+7vXfPd47arveHbMlRNxN283qhFeeLlfoH/TFwp5y9fzbqr8C9k8r/ff9Xjbnjm2SysmQJa3Q3/Ml7pR6neRetdtxDipU491WeQ3XJqeirzpKSch9thvxI92JgCLBFP0O587fVn/vWytPZKcnpYsmqZ3q3/9WGAe7eP7MdqgIlvuJ6erOULk/pjDFnZdGxvs5b9H1LosxQHrfZA3uaTIzk9Jhkcsb4gRv/euP+k/FW4hBVSWVyqy8plf0Xc/HHWL/xlShjbisn48slT5oT5MdUtwuPN1a9Ndz6N+k7Tu28evn7bInrP76cnpKSWZabt16u6Vz/Ot7zXfpfKDvPDnw/5h5fiQRhlTQTqF14zMrp5c3RFXb3y3C637riN4hXFXhQtQs76RYtT09QSWO9Ljwbwsz4pulflZxKVle62UHF07+vfnf/DaoL3NN953K1vxI8m9nvNlcfXezbjXnuXf0QuZ3F8Mo0s51TKrnMZlAgjYu1598fuoJ+4ahL7Zc1lBZRBldymaZGDtqeg9v4cEnLkG52VJeQ78fcReAOr+RJKUmZm4Na9X32OyQi+zAFMvyxS361mfzTLvYYczuNYb3MJ20cdZfJXBX3t/wGMVjb7Kgf2S95biOx8HLOeXw6Kt0c5crJklJK/7eHb9B/m5Lqpy5uY1XdgcC92mHjnu/3fk9jEyxnMqznZoGvn3j7N3OXJi95GLtXf7nkDd+LZnRp2Xd57lxkubco+ahB9/crcap6TycyqDL80v9a0uqHpachde5yJyWVx36Wnrnup3woXsuPYiWnfq16weK+PzQ7K9zay/jpUWyyYtBUXcOvF3P9GWf/TsZr+t17xFKcbY7ah9IM5X2VLsHRL6J4XZrz4a+vYQbzXpazJf37yTlf76DQ/fsMpS4GUeVHRmPsOvH47MrVXCvPqkmOm1k+7+WliRmLyuzLHfzen9ulG9NjcPRYNtnnrLuKkHUnbOVpdd++k+X3RqnnTFijSnSHGXMPnMiIxmXMJXejpE0Ng9b2WcjeAHdime1Rdp6h/L3jFGGVp2e1LrG17i20NPqqhg+5eOi6kb6ce/Yt8ijvZ5uhY9e+l8kee7+7ckMquZpu6lu+pi0FueMJLunxt4YqbpVFt/RUB1qGR6qnJysnfb3x5xZjZwWrMKLr9zDJVYlfP2ZaWzeSumWYqftbj4v5aT29Ydht5PrcdsX/3XOawP2leGPug+4l7KXUdT/TQdOG2cePLSxUiN3KmvuwM77FMcXTu+S5LamKagiv+fU5eIX87v1WJoHb6b+P6bnsHtry48GrGzVaM71FOWhk81Oee3gEJ6Ln59vqIamsajZTFgbU0tz3NOnA/Xr2raDc7KDpwF+yJfmYxwB2U4XXMo3da87aIzsudP8xH/q8Ot+bHRInf6nnLi8vCOplhL3miTcvBm5X8E3lp4nKlz9li6Mq8H7Jc/fLqYsCg5jGW+uw8r3/+PsCeCf8ruSxd1T27hHY26nj1Lq8KWd7eU7b9uC2mNWULoEVJlMHu/lp9fuw4KrkZHlVWHnyOqdNwfbTl4rbsEqYGcqXB2YXcTxvSgRW/uWUVoy5nXd4bxhyB1lD+coFHFAefulteDJadUZlRWGNMLUlkiNN2vT+Wfhitfzw0UuVwF5+W0Ppur21FRVDbt+wYNyFYudLZY8Zyo418HfzbuV7Sq+FhsCJfsxzS3L+CaX7X+k3tyxjSaAbNrw1zuPvHCr/2/fbcTdDa+4ud/JU/NntuQPMGaq4917w8lNVYEqp6v2cctHx81aWRtN180EnHd45qL/T75Fb66nbWpUHcdJhyTGLjffIluRjlnfSAGcclhw1DbTL3u99JmftduG0YWkP4e6jMw5LhpnJnaPjrjOUxtx3Ut2Icz83OZ7gXExrwEfjNRIvz21HytsamwVWQVq8hi2WGwB9Z5cZyvGlaxpgdFA35B0i97iFrLgNMHFMU83fZyjrx+ifvxnADeWdB7a/R+5c98MSuwFm7Bscd+nPPdS9SJcA1Lop/nBj7lSGYzLiBpi1b0Zil6pAM5QAs44pLtlxNzNpboBT7BK5Lc0AmHNQdNwjzz1mS0RwgMpB3Zx+jtzj+uiUZUsAJoKOuXMZArakCcDUMePZX2tLno9K8AYYHLTxzK61JQI3QK3aiXJPP0bup4MRuAEmAo65zUgCvHdMp8AfI7cpSYAFQ4zceZj7U+QWuAGWHNRJdecZSgBG4/rEXdfk/JYteXzI/a/2fgeYOGab3h+zJTml/sj27j8L0L5h+4JA2ZIxc5Oz2A0wVcZCjl3D409rKEs+quQF4B4OadCttgSgNVbiABwn4p44+eUFAKNjti3YacytMzfAnEdw3LlmereVOEI3wIsy+bCX7yN3qQfa9jEDmBFtT5w8huus+RTAkoAzlEXgBphRXl7s4pdsyXG9ZwFuYYyNQVa/5zevAehMOoTsZ5/aEoUlADNi7kP5kIVugDnRaktSGsf/siUAc8ohc5S/zVD2rbkNuQHmjP25Y+yskFMqigEBlpRD1in+0p+7HmkL4QAzJrs+7uWHPHe1BY7F7wDn+SFyH7SnMcB9hKwKfByTwA0wL1htSUpJzAZYlA/ZgOaXyD0kurN0CcCs8vRxFz/t/X7UFmsAt3FEccmPu5k9jsXqd4APwuW5xW2AZbsuXPxvl+8iWQIw55iU8k55brEbYM4hUfKnbIksCcCy/PRxF7usxDHkBphz0Pj2t2yJZAnAojFM7jhHuc+Y20ocgA92HOH+uIay9K8AmHPEAPfHGUp5boAlXcTed0+cH+q5S+4H25IlALOGtiVBaktKLod0UgG4j6FXYKCOU2pLAD44YBnlj7UlACwZ4vaeA9yfxtzV6N+gG2DOEZ1L9ulbIm4DzBpHuFGyJWXmFQCjoXY6TMep4ZgEboB5R4RJ2RKAI5XHipcg9dwplTpdYtgNcJLfakuGZZ1G3QDzDlj+/sOYu56ftP4dYMmuy99/zXNnmW6ABUcEyd9qS4ZMtzE3wIxySPX0Tqvf922DBXATeawKjJHnruJ1VtENMCtctuSYmwnAjRyxEufHbImhNsCScVgbJc9djuiBBXAnVVp5Nz9WBY61JYI3wIwjdqD5NXLrXAKwJNwMZSplOCYZb4AZ+YCR7a/9uftZU9kSgHkl7T283WkHYdkSgFlHVHL81HHKQBvggyPi5I9j7v4BQAgHmHdAcclOe+JYRAkwK1i2JKVxglLcBvhgvznKvWpLhG6AOUN03DFO/thxqujPDbBgTJZYQwnQigPqOPaq5xa6AV5V2/RG2VlhPBJxG2BGPiSXbDczgCMdER1/i9ziNcCSErGeG4AFh2yJ82uX1/6FqkCAWUdMB+6z+j0lmROAOUeUTqvnBjhWX9C9XynHr3u/D4Nu6RKAGePwNsjq92MW5APcSZl82MWvM5SW4gAs6fvy7fk9ZUsAWvPrSpx+rC1bArAgUm3JAbv0ANxJ5DWUkiUAc4bMxI7f88cZSkNtgJWi7GY2BG4RHGDeAYHyx93MuiPJBt8As+L25y46TgHMO2C7Xl1eAY50REbiv9/+enn6CMCsPZPKP/ctyf0LwRvgvTj9ubXnBlhU8tjmdTc/rn7Px+zUA3APY+De02957vp4DLoBnh2TSbabGcCx9u9cstPOClncBph1wKD753ruR8guhtwAZ9lrB2GRG2BeuB2EVZQALBtWLIbJcxtrA6wSaA1l9Rjw86EA3NARu/X+uoPwuKux0A3wKj993MOPq9+rtoXSJgDzSkqRVr/vdBQA91UeQ9x42RIA5pWhpepufq3nHvIlQjjAjCOahPzatyRbigOwaP/x7U59SwRugA/2S3T/uJuZETfA6XbrWyJ2A8zbPV2yX98SK3EA5vSBe78o+fPq954O3QDzdi8L3K3jlCE3wLzd4+PPK3GGKUqhG2BJnGyJviUAC8oRdRw/15YcUGMOcCfRVuJUzV0lSwDmVN2w97Jbr0BjboA5Q3SMk+fu5WLQDbBkvzj5a23J8EI9N8CMeopyrzj5c5fX8aXQDTBj//5Ov2dLBGyAJfvvrPB75NYtEGDBARV4djMDONQBO4ft1nEKgFnR6rlTHu4iBt9RKdeEiwXu8ipCBPFUMFqKEwNXi9fldWzzatQdQUkpFcuiIKAdh1E/13PnA9pg8aVpnU/JCn8ghHC7mWnLHUiZvqhX2jpNcJkDHoJ/7s9tNBfG5FyUlErV6MZpgssc0BvE3u83MuZGHpFaawIIoexe0b1Xxymh4XLlKVlSnxNnB64ULc+dhx6BEqlXy9Uj2dP0g8ANl9r9Evx9hlLIDqPKlvQvgOv1Q6n9ouXvVYEqzwLpikq605K7zzgzcLWS0jgF9bv/9vk2ex4SX3vMg+Q+izX8FrjU0C0wys4KuryGUh7PZcNKnOFOD1xo9zC5X+QWHiJ4DtQG3XC9IXDvNub+OVtigjKUp/dFSXu+WYCv5N0D5e9j7mFWjABKfSZKrtdRAleJVs99yD49fC/X742cUj6iZQKwzbDsZa/LcYd9KC3FiaOU5xNhyA1XK/vXcfya57b8PRwnAkKpVr3sNsD9eczdH5PFlCG8zIRIdMPFxsUuZbeugfvluQ9oZMhW+bXTK3C1/sLcL0juVltiaBfDNHRng264XrgurxWju3hyv6gSuFDePc+94xpKY7sA6nrukgy5IYL9a0v22xNHhAihPCW7ixMDl9u9ScjvtSXVEI/r5VTnR7phNxDCbrnLn3cQFhdiKY+Vk/3rIlsCAQxlgTsFzN+zJXn/FA5fe0qO6NANAezfUfXnHYQF7rBKvU8ocJn+Mtyv0Ovn3cz6F9ljeQQvbV3trABX27+ce8eVOOJDAI9tcOrAnRWXwPX2zk3stg+lBR8RvKS1nRWIIO+8j8HvkXv3rTH5Ta7PhRE3BDAt1N3BfqvfCeI5WBt1QxS7TQf+Xs8995Kr5JS7Rq82mYMwus2q9iv1+rm2JB+wJJ+vPUpJpsUlthCGi8Vb/d7bf3NjtiuPm/pwMkop060pgQtFWYmThtkw47oIcr/cvS/8d1bgatXU025bh9lZ4dasfocIurTyfplLK3Hu5mny2rMQBNAPcMtOwXu3bIm4HUJ5TpBYigPXG7cQDlLPXbR5DeXlXWHMDQHsvZ3ZjruZCREhCNUQzzAduNMF+nu2RLIkFicCwtl918efI/f4ECBrAjBn96rA3/eh3OMoAG5t570VdlhDKXYDLOuXNUfJlpihBFgpzJh7t72MAW5q95Kv/fLchtwAs8aVkzsFyt12EE5iN8Cs3asCd+hbUq3I//17AdzQzp35dtiHUr4EYMH+dRx7jrl//04At7RzmPy9tqTa1BiAV7vv+fh7bYmqQIBl/d5he41wdxxzAzCjjCtwdhrq/pznrlfiyHQDzNh7jnKHlTjiNcCicU/vfcbcO3Sc0rgEYNGY546yswIAH+w8IbjDzgp5fAnAjEec3G2l+Z47K8iWACwogfLcACzKM69+sd8MpRE3wLx+4UuYfSirLYQBmLP3dODvkTsbbAMsGhuXBMlzlyJPArAoXp57r3sIwF111YC7rTnfoSpQ4AZY9gjdu3Xo+31nharllLQJwKxHnAyzs0LVtFCnboBZ4aoCd0+9A9xL2XvZy55rKA25AWbkbmpytyC5Y+Q24gaY1W9jtldOeY81lLl/AcCMYcVilKpAM5QAH5R+a4WdouTvVYE2xQH4pM+WBFlDWQRugGXjWDtI3xI7CAN8MkwHBhlzV3cQaW6AOXlsFriLPaoC9XkFWLJ3T9U9egXuvCAf4Hb2zUnsMeYeHgN264MFcCfh9sQpyUocgEV7L3tRzw1wuL7lVJR67pRK7nd7AGDOzvFxlzz3425SrH4HWLJXmNwjW5J2rlQEuJUhYO8VJHeM3OI2wBv7hu4d1lCW5xcAVHavwfvv5+8w3EJySTtNmwLcye77rO+4J06RMAGYs3ePkD2qAmVJAFbIYbq8ajgF8MkjlVwCrcTpCeAAs8owQRlmzG1eEmDR0I8vzgxlfxOR7gaYNY5v9wndu3ackjABeGPPJYu/13OnoVZR3AaYVW37uEek3GU3s2EV5Q7fDOB2SleEl3eaF9yztkTgBpiTu4Uve9Vz7LmGMht0A8zKTx9/s0uvQG1eARZ1s4E7Dbr37M8tbgPMGrdUiJPn3ntbY4B72Tdwq+cGOEVJKdQaSvEaYFnZda35DnviCNwA6+xUPf175M7D+F8IB5hV8q77me3Scap/YS0OwJx+T4U4/bnHA5E4gT+hFHthbbNXX+7eLv25u4/iNtxeefy/JdPb5HHzsF0C5Q5VgWX3bY2By60IzHstCPwT4tVzV+s6nUho3+rRtOt9tSFw7xMk91z97jTCPawK3QZqm+ybmtixV6DF7/CXKCbbZtf73J4zlMA9rAgyWTHZd8JUBZZxzlQMh1t4DS/jerucHnUSWeDeog+PUdZQqueGm5kLLqUP2o/9XfLeBcq3F66eu+jPDbeSS3c195E655xzyrmL29lwe7N+9ftOdfD2xAFeddOPuRtsPz9Ql6S2ZKtdw6SqQODV8t5bHrO323cfA1WBwDvvAvdjglLg3qAMATtOPfe+mxoDV1seVOdH8xJDte/s8XMz5mYtp/cP6cfTb056zu//jE/CZEvGDt3O5W2Vvkdc6v+/OtnO+029XSZZsmfs78TZhzJVRfrW4txV6SuacvX70odv1/DNlDJe1LNy9V5glS447vRT26XL6869VAim5FTy4zTnMhSk5vKo+h3Lx7iPz5e0uL1N6UN3mMid9u6CRSiPAN1F5/qZKpfHp3Z9QxJFf1bflpcUp3yjPS+U/3b5Lg9SJbeUy3Brnp7g0v3itN/a20Djet+mL9cpuwTvXbMlbsH3tPIKdfpv5PMlbci90b4Pp/t2nPr9mxGQK/Tv6aoCFy5p+1B+KUyvQG5vVeh2Jd/KpyG1Ife1dq3ndir/DKf67j7ciEsuiks2GSvgd1n2su8aSitxbq1r/PlYPpe7Au+qeYUr+T4+XcldOT+rDTP9+/R72bUqUNfHuyr1yS1d6B7+UEH3DVWVvqXq8vr4UPaqkPhbgs1QpuFYBO67muw5+BhsVzVh3dowI7A7yiU9tr8p/UP12OziwsNqUOkb5+7yc9tnB+H+UFy8NzV3Xp9aEmVDsFupb9S55JRzKt1J7jLcmrxu1JfrxNlZwRTl3ZW3ibAyLqJ0+m/l06O94pKtdk0qqwrks8d2sbMPVHXTGk9cd/LY3n3hz087kpsoTx9/s8eYe9LL4vdvR0CPFiXv/2zhj2mVeaud7Tno3nVPnJSkuu9p8aT29YHcjIeoPY2Nc8NkS56Ow+m+nZLe99E3O31bxtx7yn1RyT4zu/vUlkxal7hT305+rCJ4d2L7ToJO/L0I3LsqXfnVPpfJHl1en9fJOuE3tLDyQntuWKEf++xSlbNTbYlM97293Y5wrON21mHRkCaJkueWILm/zyfYewCW7HuFHDDmNuq+naXzOTwCSpfAgmE52y4hfKfI/XQoOy3NJ4rFBRn9Q6BzDu/ltOcgZ68x96RrhZ6BN7PUk2ToXWmOEhZUBd07fLd9+pY8lHol9H7flut1SyjfbQOekjMOH+1YhrVn3xLbWd1bGStMqhPdVws697DGPrnkPcfcSdPAm3o8TeWSurrukkt+dNfPZbxhO+mwYAzYO1wqB0Vul/G91P0Ac586qV4lJxw+2nFkq8sraww7mXXvvm5zlJyHElDZEli2Z0pi1zG3KcrbeiRFZiYp+wyKgiL4YM+04mHZEqH7Zh4pkdIF79KlSx6fcLbhgzKswNllkLNv5K4Obs9vy/WqwO3swhdK7quzwkVuyZL7kgyBn+waHQ+aoXSV345TCj/a8SLaecw9PFW70AFqew669x5zl+pXAHp7DmcPq+cWvAFG46r3HaLjrpG7XkEpWwIwY489hHeN3ONCHCNugMq+k3977CDcm4RrRWQAg6qWe4fouO/q9/GluA0wseM6xR2zJTIkAO+UskeCu7PbmPt5J8qdvi3ATUTs8prrw7E7DsDEELf32Px9txnKMt2L3pgboNJHyF2KTHacoXxskKJVM8CrXfd63HkN5WOVkFQJwJNqZ6mf7Re5xxuKBZQAT4bAHawqMKXUTVQK3ADzctlh0L1fntumCgBv1X2dfrbTmLtaGyRwA7zqYuMu63F2itzdoXRbFJqhBJjac4Jy7zWUWaspgDkl71cYuH+eW+AGeDHu/L7D8HbHNZQpJXEbYNYw4t4jL7Fn35KUpLgBlsWZoSz9nu+7fDeA++mKSsoe9dz7RO6+tLxoEggwZ9clL/tWBaY9W4cD3Mie2/TuvfpdphtgRt6xKHDnyG0NJcCs0teUBMqWdIohN8CcMWCHmaEcZk332KYH4Ib6lTiR8tx9cclO3w7gZvrdzPbIluy+97s0N8CcsDOUyagbYNYQuAPluQfG3AAz8suL7+21+t1QG2BZv/z99++00+r3YbcHIRxgzlDPvUO6ZK8ZShOUAIt27FyyWz1399GQG2DOOL79PU7u37cEgBdlzynKXSJ3vejdoBtgRrjakvzmNQAPuXTxMdLq957ADTAn90E7TFVgNUMpWwIwY88KvN06Tj0+ZN0CAZbssXJxn3ruev9J+RKAGWPA/jlM6hUIcIJhgBsrW9IdjUQ3wIsxM7FHjDTmBjjDmFL+fXOF/aoC+zH3bt8Q4EbyjuPa/SL3UF0CwKtq0P3rt9p9JY4xN8CMKqUcKFvyYI8FgFlDvP49Sv7383eYkiwBONpuVYGWvwOsUHbIKu9XFZj3KzIHuJ2xovv3MLlb5FbQDbCoH97+Xs+9W55b4AZYsGPbkv13M5PmBpiRh+WKgfahzE8fAahU5RthVuJIlgAsyTsuf99tT5y+C5alOABzyn4j3N1rSwy6AV7VZdxxVr8XvQIB3qpyJXFqS8pwNxG6AY61d55bugRgzrBz2A4tVfeuCtyzdzjAfVTZkp9D985rKHMx6AaYs2NKeb/akh23NQa4m7JnTnn33cx0eQV4teuodveqQIlugDkRdxAWsAEWhKwtGbIlu31DgBvJY3+nMB2nRkI3wIzfN1QY7B65ZU0AZoy79f7+vfQtATjDmC0J1HHKWBtg0X6D7t06ThVdXgEW7RYfd+s4lWRLAN6r9p2J07fEWBtgQVUV+HOZye713ADMGsJ1nHpuq98jcjuFW9q9tkSsiMRtFMKoguPPI1zZkhuqT4XejRDEngOp/bIlwwuh4kqlPM99OB8Qxl7Re7edFexDGUFJKU8Cd7FLEYSxX5jcb08coTuI6ZC7OB8QxlgW+KP9ewVypVJK3UCy1K0SgCuNl2Kk3cwIoORxNWtKpWRjbohiksf88XvtvoOwQHGpKqv9yJpIc0McAbMlO25Iz0/GW2hJ9RAcuFbIPXFEiAiqvHZJue5xA1xrvDbjjLmHCLHD5ph8LVd57ccL7Qggivz08Xvy3Hczsw7HKYEYqlTmb5elHYTvpVj7Dg34NV+yV39uESKE6WkoOTszEFDJQcbc+Sm7ylVyN9AuKeXyKOcWvCGCeoYyzM4KPcUMVxqX3uSUUk65KOiGIIZ4HWoNZX9Mvxe88K1cynMFt7MBQQzD2jh7v6fhYATuK/VZq9L9WrLl7xDEjmPuHasC91vYyfeeQnXxDARRlHG9S5QZyqSeO4ynZImlURDFeDUGqQrsevinJHRfbBqnhW0IY+xN8fOj8AF5brUl13p5R7iVQhC7VU8f0Z9bpLjUdBmlkwFRlL5o9/dVFvtF7rGf/27fkm/kx7lwGiCY8cL8ueTrgDG31Op1ShrG3Hn4BBBMoB2EbSEcxPMOwk4IBDHuEhunKnAM3MZ51ymPvSfH3wrbEFGcbMnQLkOsuE4efum5j0IU1ZD7x++04wxln3nnQuUxfz28P+yIA2HUO1b9GCn3y3OPByJYXKak/NQbUJ4b4thtNvCAGUpx4jKP+Y9J25KUklMCYTyuyUhrKDsmKK/z+NlPtjDLSeCGMHYK3Hvu/d6/ECeuN3bcLcncAwRRho9hZigNtQMYGkh2v3NSIJJxgjLMmHs8KNHiatMAXncoA64zGWr/dlHu3yvQQC+AXP26Q48EYAf1ToNh1lDqOHW9PI3YOzyTATvarXh6x9Xv/ZEIFler7uZuoxBGKbsNcHWcuptpRbeCbohkvCJ/S5ccsYOwQHGp116BTgiEUHbbh9Iayr9AjT0EMQy6f7sqD8hzy61GI3BDCKX0D8G/FnzJcwOcZa/UhN3MAE6yW075gMgtcAO8KvstezmgV+Du3xHgBnLZLae8f98S02EAc/JuI9sd98TJygIBFlRJkjh9S0RsgLfqUsAfKzn2zHObmgR4q1pB+euuOAfUlgAwI3dJkhyoV2C1n9l+3xPgPsrkww+OGHPLdwPM6rYajFfPDf+/vbvdbl3VFTDMHmNdKpelez3nh5EQH3acAAn1fJ+x1mySpq6bNooiBAB4YTB0z+/nJuMGgK68S9V+q7wGojcAdE2aRblg73fiNgBc2Kq3JCN0A0BHGqDcad0SFiwBgK+gtwQAviQn2xv1lkj5EQDgzGvj+G/sywEAN0UN3nG00j2zWsIC3QBww3CUnDlCycIlAHBhWpBckHNHodINAA2Zto3BzDp3jtfUSwCgFjuXPjMv55ZodW5SbgBoyaxa8szdzPQCQ5QA0JFj42AEX9AVSMYNAB3z+rmZQwkA36El5RhksG7CnjgA8C1HdJR88UPz936PlEsAoEtHAeN21ZLx9QsB4JGmdd6t2PsdANAxLa1dsScOIRwAWmIlCZGxSMkIJQB8RyyKJSORcklXIEk3AHRsWOd2K05NPCgAPMkRHwdD+IKcm4wbAM6kZu59dlagwA0AV2YltvNn4hC/AaBvdAaOmtnPzequAHClaAscMHGtwEm70QPAY224g7CGbHJvAOiQ6uPHpveWUOUGgL7o1nkdOtDUdUtiCEEmbEgPAI82GiWnrluiy7wCAC6M1pQXzKGctkcmADyLFbr3ybkBAJeiTXvZp7dEzeo1B4CHsdLEmBVdgRRLAKBrUphcsm4JoRsAevIONNvs/R5ZuAQALkiOkvvs/T6pggMAz5RHJjcaoTxC9+igKQA8k8xaU3Vub4nYPwCAyrR91v/3f4MH8KhzA8A1W5pv5CBLugLJugGga8pmZktybrJuAOhyee1InFyzDyVJNwC0JgVucm4A+J4pVe5FK04RuAGgJxYfPrYkcjNECQB9MYTxivLEHYSDzX8n5waADpk0DLhihJIdhAGgK+e1Q3Fy4ghlPg9ybgBoyayV+abuQ0nIBoBzMU7qnZ67D6W4DwCAmjQXPrGgt4S4DQB9uhj24KaPS+ZQMkQJABfi4O7vU7sCCdgAcCXltTI4Kji3nzsZezEBgKeLMtTSwex3APialNdGGat0r4jclLkBoMd2641jcXJJzg0A6LB4PZjfrtgTBwDQIW4K5Ybrc1PpBoCeOQt0Uy0BgK+RNDAZx6oUi3pLKJwAQCtKWiRkrHt6arVk1kY9APBIecvHjfq5pXMJAJBYE7eMDVHOzblTxI5MogSAnjm7v6+pllAvAYCe/XpLXNwmcANAx5zekrn93JEhSgA4N6kwsWR9bkYoAeDSPtWSIJZyk3MDQMOty73RilPW8DL1qADwDLF78X1zqyVEbAC4MKmmzM4KAPA9c5Z5XVItEZJvAOjZcO93Nyd/6mEB4FlkrLrMuiUA8Au77UNJuQQA+tLiTkE2Wp87dypSLgGA1hEbJY5FySVzKJmIAwA9OhVnsM49c92SOasXAsBzaS15LEj+N+NUksHFrwDg8eYMAi7qCgQAXBkKl0v2xAmUSwCgY1KMnJxzE7AB4JRo/0YU2aYr0Nq4aS4BgJZrBtxxrUAK3gDQkcLk4HTFyXMop7yaAMBT+UL358F7SbUkDhVwAOD5JA6kuHN7S2gtAYArc6LkmnVLIoVuAGhJ3sdg5DBTc27bQHjiMQHgUWYEyiUrTlHmBoCescVdzaqdFYjdAFDLkXGsNLFk9nsUCiYA0DMleC+Z/c4keAC4tNO6JfpqMqmUAwCP4lpLhkL3zPW58/R3cm4AaM3aopdVXgHgizasc+uZELcBoCuHx4H8e261RKqPAIDCfjm3sC43AFzT0sRIzZsVpwDgm2bEyUXrc1MuAYALI2u8Tl8rUBiiBIBTbuOwbfahDHkqDkk3ALTcAOU2de68cAlJNwB07Ndb4ma/AwBqElxvycBxFvWWUOgGgK7tdlYAALwwYwuaNTsrRIYoAaBrRnBcM0JJtQQA+nRJ1ZFGjsk7K0w9GoAN8TQfk5d32qVakvsTZy1CC2AjEoqpJO1teC33lMTPH7g1I5TUSoAHkigu8EQJQSRE4Rn/Fhet5ePYTZ0bwAsSUyOyhNB9R83cu1P2yEhMkdq2Dht5yVu0Jw6/RuAhbiWFPOMvHeFb6he9gRe82Tk3sRt4lJvv5nnCt1Jc1vBcP5JDOfeaPXH4NQLPcLcM+5hyyfkPcutHlBSPU34tUeJxW+eun55iCNP3xLFLMw8L4FduLq4xtL/LSrdP66RaIOkfkaMTRI5/9LYgIkGCyHFBQpAQg8gx9CgS7f5dn7/crVq3hKwb+Pvq3ofLVohvP+fTkF/vZn/17LyKWoYOH7rbjqtpYNa9MLlh2vRwfPqqtc+KU3l20NyjAvgFbSpJtDNCW02CxKMSEE/j4+ST8R9f3DvYuedaQI7I6bqkc08lZxeOs7Kjpg3TxS1vRfGBx2zNCOVXfo8AViuzzaNs6z4bbUF+Ge8MdF9fBOm7xz1a7vJJFWuXSsqco66zKm2L43DF51thO6yqlsTbDzaAfYkmolUHmxUqiiJCqjtc52115vxeqCj7NGLOmrvZsju3cD+ufqlkv1PkprsEeJacmrY5tZaBrdYQq1qEu+O9EG3RP430WV3GkuUcYT6LrzuMpOojOZLfLpqJQ+QGnuEIz/Es+FZJtxs1zEN/lwcv0uYd4uoS2hzYH1T9wLo5lNRLgD+mmKmtF9PH3vNZqgJFtES5OKJrxnDNKo+N0h32uE7LaVf1lhC3gW11Euhu0I6v30afdlyc3fhU0ebbxOLFTqIrAc0zewfhk3meeBBx//Y+g425NrkykLgWOjkmmkiaa5Lv0HP1jF/993ARCo+fcG7+2B7OP44pQsfg1lNMbzPiq7P9ACOUeJtlbLyz2k9TaNaLxSSTlAUemWK0S+ne/dblzi/7ZFr3N1lfYqrEpB8sFd0/OkH78V1/d9nFbg+WPaZucFYf6LUxcFWdm+f0k4m2xuq1VMykj/83yoddtFtZg0sxxqg3WcC7W9M4m4n4+Wm336KcqHhEyyKMRlsq1dWONVjna/ZCpeOCva5A9xA0Z6CPUCxrHdXfdy4xfP/Pfnbkdk07Uw+MHaT5FvYnHfRPPHcH8Guf4KRprJ2pYlme6+OwNr65+fDZL7ZZufTVcVy8tJkz2gQYXRdLZ17Otf5EeA3i+VUgT9Sxb5dPRr+1i/1uUEAuXi3un+gUq7oCeQI/kX+WNs/XPJGYX37r5jpz9b/BBWkrBmiR43tddNfvobt/E+VfiobJy9bu629SN6y8+oLqFLWc4lJyfTRPxmbvn9svsLMCbnMdXVf45d9XNPiKzj7OBYJNBn1fVj91RnkIWp4phkGKL38j3sYqRn827zKfpI/RxRuV5qjbReraqmrJ7j83PnA3ivDLV/qmuhztKitOO01A0dWjQpM/3/yd1nWe7QPgn8VagbjrdnT5owWTmyet2aQ2G6QRwJjzFn1rcrJaxi/CdP97Wn+E+GtiLy/HvXpjc422uDN8zrhC5MZ9N0POT3/7d4ql1g2TW7nskzle6X1SSfRsykmZM/8se25qzMV55R9Fip/ZmjR0AC89FDyDd8fe77it7O5tooP73NKzqKqTdZrXlETdYJSNUImmyGncT3oZcr6lE5m/FaLbpjV3onlNJteZqY+P1GG4VyUmRv9RRG7cVQ5QaiJaJKTuk1O+X3vFj3zVIUmKMk1u58qLafiOtHfb2b4k2sOZWjDz6KArW1w0DOKfwFqBuEnyakE5evrg+cY0rDL70wTYHcrW8Hez/XI3l/2vU4JyKLY25qvK7g6KWXiuz8G//BCPcYZ9KHGLrlB5EZirl21Xl3BX8+XzD2KJp3ZkWPbpJ5n0p8T9kr1o2CRFK2doxm815aqxmSCNtyzLuQndz+ILw9IN3lJVZH05uqmwFv0KOgqoKbOm0iH4i+mwc3+sD+UQLaFI813stteg81Ybisz4FNUSNKoxwKbefJofWvuFK8haCaOuMzdNdBtpRiT17UauyeSHqUieZzTFkX/jpXXVEvKJ3RSjd+UtJ/Eml1/bS73jt7lx03xyWYX+Al9n6ZRbouuO0/naoWxQmROdgSELqyX8Yf+MLzG3k3zrO6aLuZxcdDfoHUXXljr/tW6UOndW0KgWYoqu46TXJWeDpJfvMoDfmLyzQrZJQfLJ5PhPjo96VQNorkVEkSAhihx3TV+gK+ene+fk8rg9Rj2kBF1qP+bv9HOxey2GEKMO/8UYjx8/hhhiDDHGEEMMIcSoi90Xo4fFcY+vTbcQuLGZdau88tf+mXoOX9S5b5oP27KUfmkfXzn298uTWv0e3lppLmZpn9I83DVCn5z60A9efc/qel71I+qLiP4Qoeim03bB3unRyIGnWLbiVH5WjR0v/Pnn2WmZQkunvoYcrNMi9yWkbVrzeJ72yulRrCzbnQEdrDJw4v23R2fdEh8vCd2UxS383qgp99rrmmYW4FEW5txTsu59xzmbmHASO6xGbB9DHWpzDVlDl8b0Xli1QbSyR+OLe2pfRdGXX2vVZlu63i90etW4En2MJoHGP21ynbsOGiMxxLdj1QeTsUO/fRbug/jPSAhBJByF5FQTThXlGIJ9Iko+iOSgnGusuTqd6hlavLZkNIfL9D3tqqTjFie28AXv+sixKQzHdFsqMmu1Oa9JV95fk+XiqL5KkyvUd84HeKRlOwgfPn1W6Xtk1wpgt8/syep3FVjWm6a8ld1horeGIoUWX2jWY7Z9ckU5KZzd1PhOz/OrKS8XLYGZbktFRAWWmR25q9j9cWugVgDyBbu9N/YUy4v+XXUe8MuTsutVfPy39V9fzuyz4oXfmskH6bZae2fp/A26cIo5gDaAaaOYeQY74RjYwuLIPdDVXb4CdHPsMoznXLwcnvLT3SyPtqFBXbRY0rlaEdlir3UyxCJO273OhgW3VL6K2MhlnhbYX4qOYjKwlfmRu4y5d7dHqVPfIFUALFYusrxZ55oEd9E1y4Xio9iqRTk/zg0bIYdsDfEhBeadQ3Gr2vTbhi/bySn6mFoxiAgN/A0rIncoE8+3YoFN+6sL5r6nWHvhLN7mfuec9docOYvJUQcAi6y6f2FruaoR3KNc9tJLcbNW7cWtt0+MBv6sVZE7x0K97WV52s017g3IxeoFwarIRfQKVpoN4a8E4tA50ao2Xj4e9buR5mEJ7gE9K04TuYG/a0nkDsFHU7spWm3ZdY5oO681clzE29wil1Po5pPb6Xaa+M/320aswp4HR60en0v1oRiOvUasBp5iTeSWKlr53jpxN2kQ8otnSp1Des0A22Z8raa4TW/OXep2Sdzn9HZtS3Qvci7y+lWRAPyDVuXcRdatdeu239nbLw6fqcviZw3ZVUnevb+whkObTKgvW4HyBoBXlldLwlBI/kE0L0rGNvUmx2rtECzvm0cCXVUo5DZDN4OoTJiJxwDetm6V1ylHWTT145iOrfOoQ1oDNETNeKPeLkH0HI7PawOd6KKhx4cY0ldJCHZV0jfxRemQp21H9y8AvOEbOfeAvN34x0dwnSrNDrTlbBrrPa9n8liPocusgyt2hHy9+LqhEweAM8vq3FNCt1vRtHe8dsaJfiyWqk7Ta6xuYYWOvEWVdSRq0fmkm3HmmikA8KH/fn0Cp2KQIkS6tac09Fqbii86S1qz77jrcYSYiyA2b8eqF8fXpLvZf+7bFiflPwDATyysc78T3nR7Kf2qdCVXmCWKBl+RGFPOnIN1iKLFakmV5hC1t+O4Yt9LtAxtLeFXp0qUBrCbdV2BRVf3CZtk4qdNatnCLR3lShpiFZA6pOaJ85Q0ADza0sjtpgdWbXVFQ7OtDOWWkqoPdbYsq95EmAbw71gduUOwVf0k90fXsfmT9QQB4F+1MnIDAFb4fxWfpXdwDJ4rAAAAAElFTkSuQmCC";

        // let count = 0;
        // setInterval(async () => {
        //   if (count < 5) {
        //     let base64Str = base64Str_0;
        //     if (count === 0) {
        //       base64Str = base64Str_0;
        //     }
        //     if (count === 1) {
        //       base64Str = base64Str_1;
        //     }
        //     if (count === 2) {
        //       base64Str = base64Str_2;
        //     }
        //     if (count === 3) {
        //       base64Str = base64Str_3;
        //     }
        //     if (count === 4) {
        //       base64Str = base64Str_4;
        //     }

        //     if (!(this.$store.state.isTask || this.isInitPickUp)) {
        //       await this.resetPgmDatas();
        //       // const dom = document.querySelector("#pgmContainer");
        //       // if (dom) {
        //       //   dom.scrollTo(0, 0);
        //       // }
        //       this.konvaConfig.pgmImage = new Image();
        //       this.pgmData = base64Str;
        //       this.konvaConfig.pgmImage.src = base64Str;
        //       const _this = this;

        //       this.konvaConfig.pgmImage.onload = function () {
        //         _this.konvaConfig.stage.width =
        //           _this.konvaConfig.pgmImage?.width;
        //         _this.konvaConfig.stage.height =
        //           _this.konvaConfig.pgmImage?.height;
        //         _this.cvsW = _this.konvaConfig.pgmImage?.width;
        //         _this.cvsH = _this.konvaConfig.pgmImage?.height;
        //         if (count === 0) {
        //           _this.pixelX = 500;
        //           _this.pixelY = 500;
        //           _this.originX = 0.0;
        //           _this.originY = 0.0;
        //           _this.resolution = 0.019999999552965164;
        //         }
        //         if (count === 1) {
        //           _this.pixelX = 504;
        //           _this.pixelY = 616;
        //           _this.originX = -2.3495583534240723;
        //           _this.originY = -4.269152641296387;
        //           _this.resolution = 0.019999999552965164;
        //         }
        //         if (count === 2) {
        //           _this.pixelX = 1354;
        //           _this.pixelY = 2718;
        //           _this.originX = -2.797055244445801;
        //           _this.originY = -28.09564971923828;
        //           _this.resolution = 0.019999999552965164;
        //         }
        //         if (count === 3) {
        //           _this.pixelX = 1371;
        //           _this.pixelY = 2727;
        //           _this.originX = 2.839669942855835;
        //           _this.originY = -28.207735061645508;
        //           _this.resolution = 0.019999999552965164;
        //         }
        //         if (count === 4) {
        //           _this.pixelX = 1407;
        //           _this.pixelY = 2736;
        //           _this.originX = -3.424409866333008;
        //           _this.originY = -28.303916931152344;
        //           _this.resolution = 0.019999999552965164;
        //         }
        //         // 任务详情和场景在线任务勾选 在实时更新地图时，对应的任务导航点在地图也要实时更新
        //         if (_this.curMethod === "info") {
        //           _this.isDetail = false;
        //           const TaskInfoData = { ..._this.taskInfoRow };
        //           const point = cloneDeep(TaskInfoData?.params?.point);
        //           let polylinePoints = [];
        //           for (let j = 0; j < point?.length; j++) {
        //             const p = cloneDeep(point[j]);
        //             if (
        //               (_this.pixelX || _this.pixelX === 0) &&
        //               (_this.pixelY || _this.pixelY === 0) &&
        //               (_this.originX || _this.originX === 0) &&
        //               (_this.originY || _this.originY === 0) &&
        //               (_this.resolution || _this.resolution === 0)
        //             ) {
        //               const { uvX, uvY } = worldToUv(
        //                 p.location.x,
        //                 p.location.y,
        //                 _this.pixelX,
        //                 _this.pixelY,
        //                 _this.originX,
        //                 _this.originY,
        //                 _this.resolution
        //               );
        //               const layerX = Math.round(_this.pixelX * uvX);
        //               const layerY = Math.round(_this.pixelY * uvY);
        //               p.location.x = uvX;
        //               p.location.y = uvY;
        //               const item = {
        //                 x: layerX,
        //                 y: layerY,
        //                 omega: p.location.omega,
        //                 key: _this.historyMaxnodeNum,
        //               };
        //               _this.konvaConfig.points.push(item);
        //               _this.points.set(_this.historyMaxnodeNum, p);
        //               _this.historyMaxnodeNum += 1;
        //               polylinePoints.push(layerX, layerY);
        //               if (polylinePoints.length >= 4) {
        //                 const newPolyline = [...polylinePoints];
        //                 _this.konvaConfig.polyline.push(newPolyline);
        //               }
        //             }
        //           }

        //           const area = cloneDeep(TaskInfoData?.params?.area) || [];
        //           let infoPointArr = [];

        //           for (let i = 0; i < area.length; i++) {
        //             let obj = {};
        //             if (i % 2 === 0) {
        //               obj.x = area[i];
        //               obj.y = area[i + 1];

        //               if (
        //                 (_this.pixelX || _this.pixelX === 0) &&
        //                 (_this.pixelY || _this.pixelY === 0) &&
        //                 (_this.originX || _this.originX === 0) &&
        //                 (_this.originY || _this.originY === 0) &&
        //                 (_this.resolution || _this.resolution === 0)
        //               ) {
        //                 const { uvX, uvY } = worldToUv(
        //                   obj.x,
        //                   obj.y,
        //                   _this.pixelX,
        //                   _this.pixelY,
        //                   _this.originX,
        //                   _this.originY,
        //                   _this.resolution
        //                 );
        //                 const Lx = uvX * _this.pixelX;
        //                 const Ly = uvY * _this.pixelY;
        //                 _this.konvaConfig.areaPoints.push({
        //                   x: Lx,
        //                   y: Ly,
        //                 });
        //                 infoPointArr.push(Lx, Ly);
        //                 const res = [...infoPointArr];
        //                 _this.konvaConfig.polygon = [res];
        //                 _this.areaPoints = area;
        //               }
        //             }
        //           }
        //         }

        //         const selectedTaskData = cloneDeep(_this.selectionList);
        //         if (selectedTaskData?.length > 0) {
        //           _this.isDetail = true;
        //           for (let i = 0; i < selectedTaskData.length; i++) {
        //             const point =
        //               cloneDeep(selectedTaskData[i]?.params?.point) || [];
        //             const color = cloneDeep(selectedTaskData[i]?.color);
        //             let polylinePoints = [];
        //             for (let j = 0; j < point?.length; j++) {
        //               const p = cloneDeep(point[j]);
        //               if (
        //                 (_this.pixelX || _this.pixelX === 0) &&
        //                 (_this.pixelY || _this.pixelY === 0) &&
        //                 (_this.originX || _this.originX === 0) &&
        //                 (_this.originY || _this.originY === 0) &&
        //                 (_this.resolution || _this.resolution === 0)
        //               ) {
        //                 console.log(
        //                   count,
        //                   p.location.x,
        //                   p.location.y,
        //                   _this.pixelX,
        //                   _this.pixelY,
        //                   _this.originX,
        //                   _this.originY,
        //                   _this.resolution
        //                 );
        //                 const { uvX, uvY } = worldToUv(
        //                   p.location.x,
        //                   p.location.y,
        //                   _this.pixelX,
        //                   _this.pixelY,
        //                   _this.originX,
        //                   _this.originY,
        //                   _this.resolution
        //                 );

        //                 const layerX = Math.round(_this.pixelX * uvX);
        //                 const layerY = Math.round(_this.pixelY * uvY);

        //                 p.location.x = uvX;
        //                 p.location.y = uvY;
        //                 const item = {
        //                   x: layerX,
        //                   y: layerY,
        //                   omega: p.location.omega,
        //                   color,
        //                   key: _this.historyMaxnodeNum,
        //                 };
        //                 _this.konvaConfig.points.push(item);
        //                 _this.points.set(_this.historyMaxnodeNum, p);
        //                 _this.historyMaxnodeNum += 1;
        //                 polylinePoints.push(layerX, layerY);
        //                 if (polylinePoints.length >= 4) {
        //                   _this.konvaConfig.polyline.push({
        //                     color,
        //                     groupLine: polylinePoints,
        //                   });
        //                 }
        //               }
        //             }

        //             const area = selectedTaskData[i]?.params?.area || [];
        //             let infoPointArr = [];

        //             for (let i = 0; i < area.length; i++) {
        //               let obj = {};
        //               if (i % 2 === 0) {
        //                 obj.x = area[i];
        //                 obj.y = area[i + 1];

        //                 if (
        //                   (_this.pixelX || _this.pixelX === 0) &&
        //                   (_this.pixelY || _this.pixelY === 0) &&
        //                   (_this.originX || _this.originX === 0) &&
        //                   (_this.originY || _this.originY === 0) &&
        //                   (_this.resolution || _this.resolution === 0)
        //                 ) {
        //                   const { uvX, uvY } = worldToUv(
        //                     obj.x,
        //                     obj.y,
        //                     _this.pixelX,
        //                     _this.pixelY,
        //                     _this.originX,
        //                     _this.originY,
        //                     _this.resolution
        //                   );
        //                   const Lx = uvX * _this.pixelX;
        //                   const Ly = uvY * _this.pixelY;
        //                   _this.konvaConfig.areaPoints.push({
        //                     x: Lx,
        //                     y: Ly,
        //                     color,
        //                   });
        //                   infoPointArr.push(Lx, Ly);
        //                   if (_this.konvaConfig.areaPoints.length >= 3) {
        //                     _this.konvaConfig.polygon.push({
        //                       color,
        //                       groupPolygon: infoPointArr,
        //                     });
        //                   }
        //                   this.infoAreaPoints = [
        //                     ..._this.konvaConfig.areaPoints,
        //                   ];
        //                   const process = selectedTaskData[i]?.params?.process;
        //                   _this.TaskDetailData = process;
        //                 }
        //               }

        //               if (count === 0) {
        //                 _this.pixelX = 500;
        //                 _this.pixelY = 500;
        //                 _this.originX = 0.0;
        //                 _this.originY = 0.0;
        //                 _this.resolution = 0.019999999552965164;
        //               }
        //             }
        //           }
        //         }
        //         if (count === 4) {
        //           count = -1;
        //         }
        //         count++;
        //       };
        //     }
        //   }
        // }, 5000);
      };
      this.mapWs.onmessage = async (msg) => {
        const msgObj = JSON.parse(msg?.data);
        const {
          map: {
            pixel_x,
            pixel_y,
            origin_x,
            origin_y,
            resolution,
            current_data,
          },
        } = msgObj;
        const base64Str = current_data;
        if (!(this.$store.state.isTask || this.isInitPickUp)) {
          await this.resetPgmDatas();
          // const dom = document.querySelector("#pgmContainer");
          // if (dom) {
          //   dom.scrollTo(0, 0);
          // }
          // window.scrollTo(0, document.documentElement.scrollTop);
          this.konvaConfig.pgmImage = new Image();
          this.pgmData = base64Str;
          this.konvaConfig.pgmImage.src = base64Str;
          const _this = this;
          // 当 pgmImage 加载完毕后触发事件 避免pgmImage已经有值，但宽高为0, 页面显示空白问题
          this.konvaConfig.pgmImage.onload = function () {
            _this.konvaConfig.stage.width = _this.konvaConfig.pgmImage?.width;
            _this.konvaConfig.stage.height = _this.konvaConfig.pgmImage?.height;
            _this.cvsW = pixel_x || _this.konvaConfig.pgmImage?.width;
            _this.cvsH = pixel_y || _this.konvaConfig.pgmImage?.height;
            this.pixelX = pixel_x;
            this.pixelY = pixel_y;
            this.originX = origin_x;
            this.originY = origin_y;
            this.resolution = resolution;
            if (_this.curMethod === "info") {
              _this.isDetail = false;
              const TaskInfoData = { ..._this.taskInfoRow };
              const point = cloneDeep(TaskInfoData?.params?.point);
              let polylinePoints = [];
              for (let j = 0; j < point?.length; j++) {
                const p = cloneDeep(point[j]);
                if (
                  (pixel_x || pixel_x === 0) &&
                  (pixel_y || pixel_y === 0) &&
                  (origin_x || origin_x === 0) &&
                  (origin_y || origin_y === 0) &&
                  (resolution || resolution === 0)
                ) {
                  const { uvX, uvY } = worldToUv(
                    p.location.x,
                    p.location.y,
                    pixel_x,
                    pixel_y,
                    origin_x,
                    origin_y,
                    resolution
                  );
                  const layerX = Math.round(pixel_x * uvX);
                  const layerY = Math.round(pixel_y * uvY);
                  p.location.x = uvX;
                  p.location.y = uvY;
                  const item = {
                    x: layerX,
                    y: layerY,
                    omega: p.location.omega,
                    key: _this.historyMaxnodeNum,
                  };
                  _this.konvaConfig.points.push(item);
                  _this.points.set(_this.historyMaxnodeNum, p);
                  _this.historyMaxnodeNum += 1;
                  polylinePoints.push(layerX, layerY);
                  if (polylinePoints.length >= 4) {
                    const newPolyline = [...polylinePoints];
                    _this.konvaConfig.polyline.push(newPolyline);
                  }
                }
              }

              const area = cloneDeep(TaskInfoData?.params?.area) || [];
              let infoPointArr = [];

              for (let i = 0; i < area.length; i++) {
                let obj = {};
                if (i % 2 === 0) {
                  obj.x = area[i];
                  obj.y = area[i + 1];

                  if (
                    (pixel_x || pixel_x === 0) &&
                    (pixel_y || pixel_y === 0) &&
                    (origin_x || origin_x === 0) &&
                    (origin_y || origin_y === 0) &&
                    (resolution || resolution === 0)
                  ) {
                    const { uvX, uvY } = worldToUv(
                      obj.x,
                      obj.y,
                      pixel_x,
                      _this.pixelYpixel_y,
                      origin_x,
                      origin_y,
                      resolution
                    );
                    const Lx = uvX * pixel_x;
                    const Ly = uvY * pixel_y;
                    _this.konvaConfig.areaPoints.push({
                      x: Lx,
                      y: Ly,
                    });
                    infoPointArr.push(Lx, Ly);
                    const res = [...infoPointArr];
                    _this.konvaConfig.polygon = [res];
                    _this.areaPoints = area;
                  }
                }
              }
            }
            const selectedTaskData = cloneDeep(_this.selectionList);
            if (selectedTaskData?.length > 0) {
              _this.isDetail = true;
              for (let i = 0; i < selectedTaskData.length; i++) {
                const point =
                  cloneDeep(selectedTaskData[i]?.params?.point) || [];
                const color = cloneDeep(selectedTaskData[i]?.color);
                let polylinePoints = [];
                for (let j = 0; j < point?.length; j++) {
                  const p = cloneDeep(point[j]);
                  if (
                    (pixel_x || pixel_x === 0) &&
                    (pixel_y || pixel_y === 0) &&
                    (origin_x || origin_x === 0) &&
                    (origin_y || origin_y === 0) &&
                    (resolution || resolution === 0)
                  ) {
                    const { uvX, uvY } = worldToUv(
                      p.location.x,
                      p.location.y,
                      pixel_x,
                      pixel_y,
                      origin_x,
                      origin_y,
                      resolution
                    );

                    const layerX = Math.round(pixel_x * uvX);
                    const layerY = Math.round(pixel_y * uvY);

                    p.location.x = uvX;
                    p.location.y = uvY;
                    const item = {
                      x: layerX,
                      y: layerY,
                      omega: p.location.omega,
                      color,
                      key: _this.historyMaxnodeNum,
                    };
                    _this.konvaConfig.points.push(item);
                    _this.points.set(_this.historyMaxnodeNum, p);
                    _this.historyMaxnodeNum += 1;
                    polylinePoints.push(layerX, layerY);
                    if (polylinePoints.length >= 4) {
                      _this.konvaConfig.polyline.push({
                        color,
                        groupLine: polylinePoints,
                      });
                    }
                  }
                }

                const area = selectedTaskData[i]?.params?.area || [];
                let infoPointArr = [];
                for (let i = 0; i < area.length; i++) {
                  let obj = {};
                  if (i % 2 === 0) {
                    obj.x = area[i];
                    obj.y = area[i + 1];

                    if (
                      (pixel_x || pixel_x === 0) &&
                      (pixel_y || pixel_y === 0) &&
                      (origin_x || origin_x === 0) &&
                      (origin_y || origin_y === 0) &&
                      (resolution || resolution === 0)
                    ) {
                      const { uvX, uvY } = worldToUv(
                        obj.x,
                        obj.y,
                        pixel_x,
                        pixel_y,
                        origin_x,
                        origin_y,
                        resolution
                      );
                      const Lx = uvX * pixel_x;
                      const Ly = uvY * pixel_y;
                      _this.konvaConfig.areaPoints.push({
                        x: Lx,
                        y: Ly,
                        color,
                      });
                      infoPointArr.push(Lx, Ly);
                      if (_this.konvaConfig.areaPoints.length >= 3) {
                        _this.konvaConfig.polygon.push({
                          color,
                          groupPolygon: infoPointArr,
                        });
                      }
                      this.infoAreaPoints = [..._this.konvaConfig.areaPoints];
                      const process = selectedTaskData[i]?.params?.process;
                      _this.TaskDetailData = process;
                    }
                  }
                }
              }
            }
          };
        }
      };
      this.mapWs.onclose = (event) => {
        if (event.wasClean) {
          console.log(
            `[close] Connection closed cleanly, ----map----, code=${event.code} reason=${event.reason} deviceId=${this.deviceId}`
          );
        } else {
          console.log("[close] Connection died, ----map----");
        }
      };
      this.ws.onerror = (e) => {
        console.log(`${mapWsUrl}----map连接失败---` + e.code);
      };
    },

    closeMapWebsoket() {
      this.mapWs?.close();
      this.mapWs = null;
    },

    clearTimeoutData: function () {
      this.timeId && clearTimeout(this.timeId);
      this.timeId = null;
    },
    initHavedData: function () {
      this.konvaConfig.points = [];
      this.konvaConfig.polyline = [];
      this.$refs.circleTooltipRef.isContent = false;
      this.konvaConfig.polygon = [];
      this.areaPoints = [];
      this.konvaConfig.areaPoints = [];
      this.TaskDetailData = [];
      this.path = [];
      this.curPoint = [];
    },
    onHavedData: function (datas, isDetail, method, optsType) {
      const data = cloneDeep(datas);
      this.method = method;
      this.optsType = optsType;
      const w = this.cvsW;
      const h = this.cvsH;
      this.isDetail = isDetail;
      if (!isDetail) {
        this.isShow = false; // false 展示 CoordinatePickup
      }
      this.initHavedData();
      if (data.length > 0) {
        for (let i = 0; i < data.length; i++) {
          const point = data[i]?.params?.point || [];
          const color = data[i]?.color;
          let polylinePoints = [];
          for (let j = 0; j < point.length; j++) {
            const p = cloneDeep(point[j]);
            let layerX = Math.round(w * Number(p.location.x));
            let layerY = Math.round(h * Number(p.location.y));
            if (this.isSceneName || this.buildMapping === true) {
              if (
                (this.pixelX || this.pixelX === 0) &&
                (this.pixelY || this.pixelY === 0) &&
                (this.originX || this.originX === 0) &&
                (this.originY || this.originY === 0) &&
                (this.resolution || this.resolution === 0)
              ) {
                const { uvX, uvY } = worldToUv(
                  p.location.x,
                  p.location.y,
                  this.pixelX,
                  this.pixelY,
                  this.originX,
                  this.originY,
                  this.resolution
                );
                layerX = Math.round(w * uvX);
                layerY = Math.round(h * uvY);
                p.location.x = uvX;
                p.location.y = uvY;
              }
            }
            const item = {
              x: layerX,
              y: layerY,
              omega: p.location.omega,
              color,
              key: this.historyMaxnodeNum,
            };
            this.konvaConfig.points.push(item);
            this.points.set(this.historyMaxnodeNum, p);
            this.historyMaxnodeNum += 1;
            polylinePoints.push(layerX, layerY);
            if (polylinePoints.length >= 4) {
              if (isDetail) {
                this.konvaConfig.polyline.push({
                  color,
                  groupLine: polylinePoints,
                });
              } else {
                const newPolyline = [...polylinePoints];
                this.konvaConfig.polyline.push(newPolyline);
              }
            }
          }
          const area = data[i]?.params?.area || [];
          let infoPointArr = [];
          for (let i = 0; i < area.length; i++) {
            let obj = {};
            if (i % 2 === 0) {
              obj.x = area[i];
              obj.y = area[i + 1];
              let Lx = area[i] * this.cvsW;
              let Ly = area[i + 1] * this.cvsH;
              if (this.isSceneName || this.buildMapping === true) {
                if (
                  (this.pixelX || this.pixelX === 0) &&
                  (this.pixelY || this.pixelY === 0) &&
                  (this.originX || this.originX === 0) &&
                  (this.originY || this.originY === 0) &&
                  (this.resolution || this.resolution === 0)
                ) {
                  obj.x = area[i];
                  obj.y = area[i + 1];
                  const { uvX, uvY } = worldToUv(
                    obj.x,
                    obj.y,
                    this.pixelX,
                    this.pixelY,
                    this.originX,
                    this.originY,
                    this.resolution
                  );
                  Lx = uvX * this.cvsW;
                  Ly = uvY * this.cvsH;
                }
              }
              this.konvaConfig.areaPoints.push({ x: Lx, y: Ly, color });
              infoPointArr.push(Lx, Ly);
              if (this.konvaConfig.areaPoints.length >= 3) {
                if (optsType === "seleted") {
                  this.konvaConfig.polygon.push({
                    color,
                    groupPolygon: infoPointArr,
                  });
                } else {
                  const res = [...infoPointArr];
                  this.konvaConfig.polygon = [res];
                  this.areaPoints = area;
                }
              }
            }
          }
          this.infoAreaPoints = [...this.konvaConfig.areaPoints];
          const process = data[i]?.params?.process;
          this.TaskDetailData = process;
        }
      } else {
        this.initHavedData();
      }
    },
    wheelForScale: function (e) {
      e.evt.preventDefault();
      this.isAttributeForm = false;
      const scaleBy = 1.01;
      const stage = this.$refs.konvaStage.getStage();
      const oldScale = stage.scaleX();
      const mousePointTo = {
        x: stage.getPointerPosition().x / oldScale - stage.x() / oldScale,
        y: stage.getPointerPosition().y / oldScale - stage.y() / oldScale,
      };
      const newScale =
        e.evt.deltaY > 0 ? oldScale * scaleBy : oldScale / scaleBy;
      stage.scale({ x: newScale, y: newScale });
      this.$nextTick(() => {
        stage.x(
          (-mousePointTo.x + stage.getPointerPosition().x / newScale) * newScale
        );
        stage.y(
          (-mousePointTo.y + stage.getPointerPosition().y / newScale) * newScale
        );
        stage.batchDraw();
        const scale = e.evt.deltaY > 0 ? scaleBy : 1 / scaleBy;
        this.stageScale = newScale;
        this.stagePointerPosition = {
          x: stage.x(),
          y: stage.y(),
        };
        this.triggerPosition = {
          ...this.triggerPosition,
          layerX:
            stage.getPointerPosition().x +
            (-stage.getPointerPosition().x + this.triggerPosition.layerX) *
              scale,
          layerY:
            stage.getPointerPosition().y +
            (-stage.getPointerPosition().y + this.triggerPosition.layerY) *
              scale,
        };
      });
    },
    onStageTouchstart: function (e) {
      const len = e.evt.touches.length;
      const { pageX, pageY } = e.evt.touches[0];
      if (len >= 2) {
        clearTimeout(timeId);
        this.isAttributeForm = false;
      } else {
        timeId = setTimeout(() => {
          if (this.method === "TASK_INVESTIGATE") {
            const { x, y } = this.stagePointerPosition;
            const dom = document.getElementById("pgmContainer");
            const cxL = pageX - dom.offsetLeft + dom.scrollLeft;
            const cyT = pageY - dom.offsetTop + dom.scrollTop - 62;
            const cx0 = cxL - x;
            const cy0 = cyT - y;
            const cx = cx0 / this.stageScale;
            const cy = cy0 / this.stageScale;
            if (e.target.attrs.id || e.target.attrs.id === 0) {
              this.isAttributeForm = true;
              this.artFormTop = cyT;
              this.artFormLeft = cxL;
            } else {
              // 增加点 编辑存在， 将提示先清空
              if (this.optsType === "update" && !isEmpty(this.infoAreaPoints)) {
                this.$message({
                  type: "info",
                  message: "若想更新边界区域, 请先清空边界点！",
                });
                return;
              }
              this.isAttributeForm = false;
              const obj = { x: cx, y: cy };
              this.konvaConfig.areaPoints.push(obj);
              const uvX = (cx / this.cvsW).toFixed(6);
              const uvY = (cy / this.cvsH).toFixed(6);
              this.areaPoints.push(uvX, uvY);
            }
          } else {
            this.triggerPosition = {
              pageX,
              pageY,
            };
            this.isTouchStart = true;
            this.visibleCircleTooltip = true;
            this.initData();
            if (this.isInitPickUp) {
              this.isShow = false;
            }
          }
        }, 50);
      }
    },
    onStageTouchmove: function (e) {
      e.evt.preventDefault();
      const dom = document.getElementById("pgmContainer");
      const stage = this.$refs.konvaStage.getStage();
      const touch1 = e.evt.touches[0];
      const touch2 = e.evt.touches[1];
      if (touch1 && touch2) {
        this.isTouchmoveing = true;
        this.visibleCircleTooltip = false;
        this.konvaConfig.stage.draggable = false; // 缩放时，禁掉拖拽，两者冲突会导致缩放失效
        const p1 = {
          x: touch1.pageX,
          y: touch1.pageY,
        };
        const p2 = {
          x: touch2.pageX,
          y: touch2.pageY,
        };

        if (!lastCenter) {
          lastCenter = getCenter(p1, p2);
          return;
        }

        if (!lastDist) {
          lastDist = getDistance(p1, p2);
        }
        const newCenter = getCenter(p1, p2); // 缩放中心
        const newDist = getDistance(p1, p2); // 两指距离
        const pointTo = {
          x: (newCenter.x - stage.x()) / stage.scaleX(),
          y: (newCenter.y - stage.y()) / stage.scaleX(),
        };
        let circlePointTo = {
          x: 0,
          y: 0,
        };
        if (this.triggerPosition) {
          circlePointTo = {
            x:
              (newCenter.x -
                (this.triggerPosition.pageX -
                  dom.offsetLeft +
                  dom.scrollLeft)) /
              stage.scaleX(),
            y:
              (newCenter.y -
                (this.triggerPosition.pageY - dom.offsetTop + dom.scrollTop)) /
              stage.scaleX(),
          };
        }
        const scale = stage.scaleX() * (newDist / lastDist);
        // 用于子组件的位置更新
        this.stageScale = scale;
        this.stagePointerPosition = {
          x: stage.x(),
          y: stage.y(),
        };
        stage.scale({ x: scale, y: scale });
        const dx = newCenter.x - lastCenter.x;
        const dy = newCenter.y - lastCenter.y;
        const newPos = {
          x: newCenter.x - pointTo.x * scale + dx,
          y: newCenter.y - pointTo.y * scale + dy,
        };

        this.triggerPosition = {
          pageX:
            newCenter.x -
            circlePointTo.x * scale +
            dx +
            (dom.offsetLeft - dom.scrollLeft),
          pageY:
            newCenter.y -
            circlePointTo.y * scale +
            dy +
            (dom.offsetTop - dom.scrollTop),
        };
        stage.position(newPos);
        lastDist = newDist;
        lastCenter = newCenter;
      }
    },
    onStageTouchend: function () {
      lastDist = 0;
      lastCenter = null;
      // this.konvaConfig.stage.draggable = true;
    },

    onStageClick: function (e) {
      const { layerX, layerY, clientX, clientY } = e.evt;
      this.triggerPosition = {
        layerX,
        layerY,
        clientX,
        clientY,
      };

      if (this.method === "TASK_INVESTIGATE") {
        const { x, y } = this.stagePointerPosition;
        const cx = (layerX - (x || 0)) / this.stageScale;
        const cy = (layerY - (y || 0)) / this.stageScale;
        const obj = { x: cx, y: cy };
        if (
          (e.target.attrs.id || e.target.attrs.id === 0) &&
          e.target.attrs?.name !== "area_circle"
        ) {
          // 点击区域弹窗
          this.artFormTop = layerY;
          this.artFormLeft = layerX;
          this.isAttributeForm = true;
        } else {
          if (e.target?.attrs?.name === "area_circle") {
            //点击点准备拖拽areaPoint
          } else {
            // 增加点 编辑存在， 将提示先清空
            if (this.optsType === "update" && !isEmpty(this.infoAreaPoints)) {
              this.$message({
                type: "info",
                message: "若想更新边界区域, 请先清空边界点！",
              });
              return;
            }

            if (this.optsType === "add" && !isEmpty(this.konvaConfig.polygon)) {
              this.$message({
                type: "info",
                message: "区域点已形成，若想更新, 请先清空边界点！",
              });
              return;
            }

            this.isAttributeForm = false;
            const uvX = (
              (layerX - (x || 0)) /
              (this.cvsW * this.stageScale)
            ).toFixed(6);
            const uvY = (
              (layerY - (y || 0)) /
              (this.cvsH * this.stageScale)
            ).toFixed(6);
            this.konvaConfig.areaPoints.push(obj);
            this.areaPoints.push(uvX, uvY);
          }
        }
      } else {
        this.visibleCircleTooltip = true;
        this.initData();
        if (this.isInitPickUp) {
          this.isShow = false;
        }
      }
    },

    initData: function () {
      if (this.$refs.circleTooltipRef) {
        this.$refs.circleTooltipRef.form = {
          omega: 0,
          identifierList: this.identifierList, // 目标物
          metaTaskList: this.metaTaskList, // 动作
          selectPoint: this.selectPoint || {
            location: { omega: 0 },
            process: [],
            station: [],
          }, // 选择点
        };
        this.$refs.circleTooltipRef.directions = {
          cx: 60,
          cy: 60,
          omega: 0,
        };
      }
    },

    resetPoint: function () {
      this.konvaConfig.points = [];
      this.konvaConfig.polyline = [];
      this.points = new Map();
      this.historyMaxnodeNum = 0;
      this.resetAreaPointData();
    },

    deleteCircleTooltipData: function (data) {
      const { directions, triggerPoint, visible } = data;
      const {
        location: { x, y },
      } = triggerPoint;
      const { cx, cy } = directions;
      this.visibleCircleTooltip = visible;
      const obj = getMinPoint(
        this.points,
        { x, y },
        this.threshold / this.stageScale
      );

      const obj1 = getKonvaConfigByObj(this.konvaConfig.points, obj);
      if (!isEmpty(obj)) {
        this.points.delete(obj.key);
        let newPolyline = [];
        this.konvaConfig.points = this.konvaConfig.points.map((i) => {
          if (i.key === obj1.key) {
            return;
          } else {
            return { ...i };
          }
        });
        // 更新 polyline
        newPolyline = this.konvaConfig.polyline.map((arrItem) => {
          const result = [];
          for (var i = 0; i < arrItem.length; i = i + 2) {
            if (obj1.x == arrItem[i] && obj1.y == arrItem[i + 1]) {
              continue;
            } else {
              result.push(arrItem[i]);
              result.push(arrItem[i + 1]);
            }
          }
          return result;
        });
        this.konvaConfig.points = [
          ...new Set(this.konvaConfig.points.filter(Boolean)),
        ];
        this.konvaConfig.polyline = newPolyline;
      }
    },
    saveCircleTooltipData: async function (data) {
      const { directions, triggerPoint, visible } = data;
      const {
        location: { x, y, omega },
      } = triggerPoint;
      const { cx, cy } = directions;
      this.visibleCircleTooltip = visible;
      if (this.isInitPickUp) {
        // 设备初始位置设置-拾取逻辑
        // this.konvaConfig.points = [
        //   {
        //     x: cx,
        //     y: cy,
        //     omega,
        //   },
        // ];
        // let map = new Map();
        // map.set(this.historyMaxnodeNum, triggerPoint);
        // this.points = map;
        // 设备-初始位置拾取逻辑
        if (this.onSaveInitPickup && this.isInitPickUp) {
          await this.onSaveInitPickup({
            x,
            y,
            omega,
            pixelX: this.pixelX,
            pixelY: this.pixelY,
            originX: this.originX,
            originY: this.originY,
            resolution: this.resolution,
          });
          this.isShow = true;
        }
      } else {
        // 导航
        const obj = getMinPoint(
          this.points,
          { x, y },
          this.threshold / this.stageScale
        );
        const obj1 = getKonvaConfigByObj(this.konvaConfig.points, obj);
        let map = new Map();
        if (!isEmpty(obj)) {
          map = this.points.set(this.historyMaxnodeNum, triggerPoint);
          this.konvaConfig.points = this.konvaConfig.points.map((i) => {
            if (i.key === obj1.key) {
              return { ...i, omega };
            } else {
              return { ...i };
            }
          });
        } else {
          map = this.points.set(this.historyMaxnodeNum, triggerPoint);
          this.konvaConfig.points.push({
            x: cx,
            y: cy,
            omega,
            key: this.historyMaxnodeNum,
          });
          this.historyMaxnodeNum += 1;
        }

        this.points = map;
        let pointArr = [];
        const curPoints = [...new Set(this.konvaConfig.points.filter(Boolean))];
        console.log("curPoints", curPoints);
        for (let i = 0; i < curPoints.length; i++) {
          pointArr.splice(
            pointArr.length,
            0,
            Number(curPoints[i].x.toFixed(0)),
            Number(curPoints[i].y.toFixed(0))
          );
        }
        console.log("pointArr", pointArr);
        if (pointArr.length >= 4) {
          this.konvaConfig.polyline.push(pointArr);
        }
        this.konvaConfig.points = curPoints;
      }
    },

    saveCurPoint: function (obj) {
      const { x, y } = obj;
      const triggerPoint = {
        location: { ...obj, stageScale: this.stageScale },
        process: [],
        station: [],
      };
      // 判断当前位置点是都已被添加，若添加则不再更新数据
      let isHaved = false;
      this.points.forEach((val, key) => {
        const location = val?.location;
        if (location.x === obj?.x && location?.y === obj?.y) {
          isHaved = true;
          return;
        }
      });
      if (isHaved === true) {
        // 存在 不在添加
        return;
      } else {
        // 不存在
        let map = new Map();
        map = this.points.set(this.historyMaxnodeNum, triggerPoint);
        const cx = this.cvsW * x;
        const cy = this.cvsH * y;
        const omega = obj?.omega;
        this.konvaConfig.points.push({
          x: cx,
          y: cy,
          omega,
          key: this.historyMaxnodeNum,
        });
        this.historyMaxnodeNum += 1;
        let pointArr = [];
        for (let i = 0; i < this.konvaConfig.points.length; i++) {
          pointArr.splice(
            pointArr.length,
            0,
            this.konvaConfig.points[i].x,
            this.konvaConfig.points[i].y
          );
        }
        if (pointArr.length >= 4) {
          this.konvaConfig.polyline.push(pointArr);
        }
      }
    },

    saveBoundaryPoint: function () {
      const pointArr = [];
      const len = this.konvaConfig.areaPoints.length;
      if (len < 3) {
        this.$message({
          type: "warning",
          message: "至少三个点形成一个区域才可保存哦！",
        });
        return len;
      }
      for (let i = 0; i < len; i++) {
        pointArr.push(
          this.konvaConfig.areaPoints[i].x,
          this.konvaConfig.areaPoints[i].y
        );
      }
      if (pointArr.length >= 6) {
        this.konvaConfig.polygon = [pointArr];
      }
      this.isAttributeForm = false;
    },

    saveCurBoundaryPoint: function (obj) {
      const { x, y } = obj;
      const cx = (this.cvsW * x).toFixed();
      const cy = (this.cvsH * y).toFixed();
      this.konvaConfig.areaPoints.push({ x: cx, y: cy });
      this.areaPoints.push(x, y);
    },

    onArtFormDelete: function () {
      this.isAttributeForm = false;
    },

    onArtFormSave: function (formData) {
      this.isAttributeForm = false;
      this.attributeFormData = formData;
    },

    getAttributeFormData: function () {
      return this.attributeFormData?.process;
    },

    onDragAreaPointStart: function (e) {
      const { id } = e.target?.attrs;
      const arr = id?.split("_");
      const curX = Number(arr[0]);
      const curY = Number(arr[1]);
      // 记录拖拽的点坐标，方便拖拽结束更新点的坐标位
      this.curDragAreaPoint = { curX, curY };
    },

    onDragAreaPointEnd: function (e) {
      const { layerX, layerY, clientX, clientY } = e.evt;
      const { curX, curY } = this.curDragAreaPoint;
      const { x, y } = this.stagePointerPosition;
      const cx = (layerX - (x || 0)) / this.stageScale;
      const cy = (layerY - (y || 0)) / this.stageScale;
      const obj = { x: cx, y: cy };
      const uvX = ((layerX - (x || 0)) / (this.cvsW * this.stageScale)).toFixed(
        6
      );
      const uvY = ((layerY - (y || 0)) / (this.cvsH * this.stageScale)).toFixed(
        6
      );

      let idx = -1;
      for (let i of this.konvaConfig.areaPoints) {
        idx++;
        if (i?.x === curX && i?.y === curY) {
          i.x = cx;
          i.y = cy;
          break;
        }
      }

      // 更新拖拽结束数据
      this.areaPoints?.splice(idx * 2, 2, uvX, uvY);
      const arr = !isEmpty(this.konvaConfig.polygon?.[0])
        ? [...this.konvaConfig.polygon?.[0]]
        : [];
      arr.splice(idx * 2, 2, cx, cy);
      this.konvaConfig.polygon = [arr];
    },

    resetData: function () {
      this.initData();
      this.resetPgmDatas();
      this.resetWsData();
    },

    resetPgmDatas: function () {
      this.initData();
      this.konvaConfig = {
        stage: {
          width: 1000,
          height: 1000,
          // draggable: true,
        },
        group: {
          x: 0,
          y: 0,
        },
        pgmImage: null,
        points: [],
        polyline: [],
        polygon: [],
        areaPoints: [],
        path: [],
        curPoint: [],
        // { x: 100, y: 100, omega: 45 }
        cloudPoints: [],
      };
      // 切换路由 重绘konva
      lastDist = 0;
      lastCenter = null;
      this.pgmData = null;
      if (this.$refs.konvaStage) {
        const stage = this.$refs.konvaStage.getStage();
        stage.scale({ x: 1, y: 1 });
        stage.position({ x: 0, y: 0 });
        stage.batchDraw();
      }
      this.historyMaxnodeNum = 0;
      this.stageScale = 1;
      this.stagePointerPosition = {
        x: 0,
        y: 0,
      };
    },

    // 只情空点，不清空地图和ws 数据
    clearPgmData: function () {
      this.initData();
      this.resetPoint();
    },

    resetWsData: function () {
      this.konvaConfig.curPoint = [];
      this.konvaConfig.cloudPoints = [];
      this.konvaConfig.path = [];
    },
    resetAreaPointData: function () {
      this.konvaConfig.polygon = [];
      this.konvaConfig.areaPoints = [];
      this.areaPoints = [];
      this.isAttributeForm = false;
      this.infoAreaPoints = [];
      this.curDragAreaPoint = null;
    },
  },

  destroyed() {
    this.pgmData = null;
    this.clearTimeoutData();
  },
};
</script>
<style lang="scss" scoped>
.pgm_konva {
  width: 100%;
}
</style>
