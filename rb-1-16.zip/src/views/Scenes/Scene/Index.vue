<template>
  <div class="scene" id="scene">
    <NotFound
      v-if="
        (!mapId && !sceneName?.includes('建图')) ||
        (sceneName?.includes('建图') && !firstDeviceId)
      "
      desc="暂无地图信息"
      :image="require('@/assets/img/empty.svg')"
    />
    <div
      class="scence_CesiumViewer"
      v-if="mapType === 2 && !sceneName?.includes('建图')"
      style="height: calc(100% - 22px)"
    >
      <CesiumViewer
        :mapId="mapId"
        :mapInfo="mapInfo"
        ref="cesiumViewerRef"
        :pageType="pageType"
        :method="method"
        :taskInfoRow="mapInfoPointsData"
        :wsData="wsDeviceDataList"
        isPage="sceneDetail"
      />
    </div>
    <PgmKonvaScene
      ref="pgmKonvaShowRef"
      v-if="mapType === 0 || (sceneName.includes('建图') && firstDeviceId)"
      :mapId="mapId"
      :wsData="wsDeviceDataList"
      :isSceneName="sceneName.includes('建图')"
      :deviceId="firstDeviceId"
      :taskInfoRow="taskInfoRow"
      :curMethod="method"
      :selectionList="selectionList"
    />
    <CustomCollapse v-if="isShowSceneDetail">
      <el-form label-position="top">
        <el-row>
          <el-col :span="5" class="scene_col">
            <el-form-item label="场景信息">
              <p>
                场景名称：
                <span v-if="selectSceneInfo">
                  {{ selectSceneInfo?.name || "-" }}
                </span>
                <span v-else>-</span>
              </p>
              <p>
                地图名称：
                <span v-if="selectSceneInfo">
                  {{ selectSceneInfo?.map?.name || "-" }}
                </span>
                <span v-else>-</span>
              </p>
              <p>
                订阅服务：
                <span v-if="selectSceneInfo">
                  {{ selectSceneInfo?.subscribe?.name || "-" }}
                </span>
                <span v-else>-</span>
              </p>
            </el-form-item>
          </el-col>
          <el-col :span="5" class="scene_col">
            <el-form-item label="已选设备">
              <NotFound
                v-if="selectedDeviceList.length === 0"
                desc="暂无已选设备"
                :image="require('@/assets/img/empty.svg')"
              />
              <ul v-else>
                <li
                  v-for="item in selectedDeviceList"
                  :key="item.id"
                  class="text_mutil_overflow_custum"
                  :style="{ color: item?.color || 'skyblue', fontWeight: 800 }"
                >
                  {{ item.name }}
                </li>
              </ul>
            </el-form-item>
          </el-col>
          <el-col :span="11" class="scene_col list">
            <el-form-item label="在线任务">
              <el-table
                highlight-current-row
                stripe
                :data="onlineTasksList"
                ref="sceneTableRef"
                height="100%"
                v-loading="tableLoading"
                @select="selectChange"
                :header-cell-class-name="headerCellAllClassName"
              >
                <el-table-column
                  prop="name"
                  label="任务名称"
                  :formatter="formatterFun"
                  column-key="name"
                >
                  <template slot-scope="scope">
                    <a
                      :style="ACellStyle(scope.row)"
                      target="_self"
                      rel="noopener noreferrer"
                      @click="onClickTaskInfo(scope.row)"
                      >{{ scope.row.name }}</a
                    >
                  </template>
                </el-table-column>
                <el-table-column
                  prop="status"
                  label="任务状态"
                  column-key="status"
                  :formatter="formatterFun"
                />
                <el-table-column label="操作">
                  <template slot-scope="scope">
                    <el-button
                      @click="onAction(scope.row, 'update')"
                      type="text"
                      size="small"
                      v-if="scope.row.status === 'Create'"
                      >编辑</el-button
                    >
                    <el-button
                      @click="onAction(scope.row, 'Restore')"
                      type="text"
                      size="small"
                      v-if="scope.row.status === 'Pause'"
                      >恢复</el-button
                    >
                    <el-button
                      @click="onAction(scope.row, 'suspend')"
                      type="text"
                      size="small"
                      v-if="
                        scope.row.status === 'Create' ||
                        scope.row.status === 'Running' ||
                        scope.row.status === 'Restore'
                      "
                      >{{
                        scope.row.status === "Running" ||
                        scope.row.status === "Restore"
                          ? "暂停"
                          : "启动"
                      }}</el-button
                    >
                    <el-button
                      @click="onAction(scope.row, 'end')"
                      type="text"
                      size="small"
                      v-if="
                        scope.row.status === 'Running' ||
                        scope.row.status === 'Pause'
                      "
                      >终止</el-button
                    >
                    <el-button
                      @click="onAction(scope.row, 'emergencyStop')"
                      type="text"
                      size="small"
                      class="stop_btn"
                      v-if="
                        scope.row.status === 'Running' ||
                        scope.row.status === 'Action'
                      "
                      >急停</el-button
                    >
                  </template>
                </el-table-column>
                <el-table-column type="selection" width="42" align="center">
                </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
          <el-col :span="3" class="scene_col btn">
            <div class="scene_opts">
              <SelectTask ref="selectTaskRef" :onClickTaskBtn="resetTask" />
              <el-button
                @click="onClickOpts('history')"
                type="primary"
                size="small"
                >历史任务</el-button
              >
              <el-button
                @click="onClickOpts('edit')"
                type="primary"
                size="small"
                >场景编辑</el-button
              >
            </div>
          </el-col>
        </el-row>
      </el-form>
    </CustomCollapse>
    <AddUpdateTask
      :selectSceneInfo="selectSceneInfo"
      ref="addUpdateTaskRef"
      :getOnlineTaskList="getOnlineTaskList"
      :isShowTaskInfo="isShowTaskInfo"
      :getCurTaskPoints="getCurTaskPoints"
      :resetMapData="resetMapData"
      :getCurTaskInfoPoints="getCurTaskInfoPoints"
      :onClickNavPoint="onClickNavPoint"
      :onClearBoundaryPoint="onClearBoundaryPoint"
      :saveBoundaryPoint="saveBoundaryPoint"
      :getAreaPoints="getAreaPoints"
      :updateCurSceneMapObj="updateCurSceneMapObj"
      isCurPage="sceneDetail"
      :isSceneName="sceneName.includes('建图')"
      :getSceneDetail="getSceneDetail"
    />
    <HistoryTask
      ref="historyTaskRef"
      :getOnlineTaskList="getOnlineTaskList"
      :historyTableLoading="historyTableLoading"
      :historyTaskList="historyTaskList"
      :getHistroyTaskList="getHistroyTaskList"
    />
    <UpdateScene
      v-if="isShowUpdateScene"
      :selectSceneInfo="selectSceneInfo"
      :closeUpdateScene="closeUpdateScene"
    />
    <TaskDetail
      v-if="isShowTaskDetail"
      :isShowTaskInfo="isShowTaskInfo"
      :taskCondition="taskCondition"
      :taskInfoRow="taskInfoRow"
      :onTaskEdit="onTaskEdit"
      :onUpdateCancel="onUpdateTaskCancel"
      :onDeleteOnlineTask="onDeleteOnlineTask"
      :getCurTaskInfoPoints="getCurTaskInfoPoints"
      :openDeviceTravelWebsocket="openWebsocket"
      :closeDeviceTravel="closeWebsoket"
    />
  </div>
</template>
<script>
import PgmKonvaScene from "@/views/Scenes/components/PgmKonvaScene/Index.vue";
import CustomCollapse from "@/components/CustomCollapse/Index.vue";
import AddUpdateTask from "@/views/Task/AddUpdateTask/Index.vue";
import NotFound from "@/components/NotFound/Index.vue";
import SelectTask from "@/views/Task/components/SelectTask/Index.vue";
import UpdateScene from "../UpdateScene/Index.vue";
import HistoryTask from "@/views/Task/HistoryTask/Index.vue";
import TaskDetail from "@/views/Task/Detail/Index.vue";
import CesiumViewer from "@/components/CesiumViewer/Index.vue";
import { getOnlineTaskList, executeTask, getHistoryTaskList } from "@/api/task";
import { emergencyStop } from "@/api/cmd";
import { RandomColor } from "@/utils/RandomColor.js";
import { strToObj } from "@/utils/index";
import { isEqual } from "lodash";
import GlobalLoading from "@/components/Loading/Loading.js";
import { getSceneDetail } from "@/api/scene.js";
import { isEmpty, cloneDeep } from "lodash";
import { UvToWorld, worldToUv } from "@/utils/mapWorldUvConversion";

export default {
  data() {
    return {
      selectedDeviceList: [], // 已选设备
      onlineTasksList: [], // 在线任务
      tableLoading: false,
      isShowSceneDetail: true,
      isShowTaskDetail: false,
      taskInfoRow: null,
      mapId: "",
      mapType: "",
      historyTableLoading: false,
      historyTaskList: [],
      selectionList: [], // 在线勾选List
      selectSceneInfo: null,
      sceneId: "",
      sceneName: "",
      mapInfo: null,
      loadLoading: true,
      isShowUpdateScene: false,
      pageType: this.$store.state.curTaskInfo?.optsType,
      method: this.$store.state.curTaskInfo?.method,
      ws: {},
      wsDeviceDataList: [],
      mapInfoPointsData: [],
      firstDeviceId: "",
    };
  },
  components: {
    PgmKonvaScene,
    CustomCollapse,
    AddUpdateTask,
    NotFound,
    SelectTask,
    HistoryTask,
    UpdateScene,
    TaskDetail,
    CesiumViewer,
  },
  async mounted() {
    await this.getSceneDetail();
  },
  watch: {
    $route: async function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        // 场景切换 重置
        this.isShowSceneDetail = true;
        this.isShowTaskDetail = false;
        await this.closeWebsoket();
        this.resetSceneData();
        await this.getSceneDetail();
      }
    },
  },
  methods: {
    getSceneDetail: async function (addUpdateTask) {
      const { sceneId } = this.$route.params;
      if (sceneId) {
        const res = await getSceneDetail({ id: sceneId });
        this.selectedDeviceList = (res?.devices || [])?.map((i, idx) => {
          const color = RandomColor();
          // 设备详情直接进入任务详情，不开启设备下已选设备的device-travel
          if (!this.$route?.query?.taskId) {
            this.openWebsocket(i, color);
          }
          return { ...i, color: color || "skyblue" };
        });

        this.firstDeviceId = this.selectedDeviceList?.[0]?.id;
        if (!addUpdateTask) {
          this.selectSceneInfo = res;
          this.sceneId = res?.id;
          this.sceneName = res?.name;
          this.mapId = res?.map?.id;
          this.mapType = res?.map?.type;
          this.wsDeviceDataList = [];

          this.mapInfo = {
            ...res,
            location: strToObj(res?.map?.location, ["jd", "wd", "gc"]),
            level: strToObj(res?.map?.level, ["min", "max"]),
            zoom: strToObj(res?.map?.zoom, ["min", "max"]),
            rectangle: strToObj(res?.map?.rectangle, [
              "west",
              "east",
              "north",
              "south",
            ]),
          };
          await this.getOnlineTaskList();
          // 从设备详情 进入任务 先渲染完地图，在渲染任务详情（解决因为渲染时机问题导致导航点不能正常渲染问题）
          if (this.$route?.query?.taskId) {
            this.isShowTaskDetail = true;
          }
        }
      }
    },

    closeWebsoket(taskDeviceList) {
      this.wsDeviceDataList = [];
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.konvaConfig.curPoint = [];
        this.$refs.pgmKonvaShowRef.konvaConfig.path = [];
        this.$refs.pgmKonvaShowRef.konvaConfig.cloudPoints = [];
      }

      // 关闭任务详情 下 设备的device-tarvel
      if (!isEmpty(taskDeviceList)) {
        for (let i of taskDeviceList) {
          if (this.ws[i?.sn]) {
            this.ws[i?.sn].close();
            this.ws[i?.sn] = null;
          }
        }
        return;
      }
      // 关闭场景 下 设备的device-tarvel
      if (!isEmpty(this.selectedDeviceList)) {
        for (let i of this.selectedDeviceList) {
          if (this.ws[i?.sn]) {
            this.ws[i?.sn].close();
            this.ws[i?.sn] = null;
          }
        }
      }
    },

    openWebsocket(deviceObj, color, isCurPage) {
      const curPage = isCurPage ? isCurPage : "sceneDetail";
      const deviceId = deviceObj?.id;
      const sn = deviceObj?.sn;
      let socketUrl = `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/device-travel/${deviceId}`;
      this.ws[deviceObj?.sn] = new WebSocket(socketUrl);
      this.ws[deviceObj?.sn].onopen = () => {
        console.log(
          `---WebSocket连接--${curPage}--device-travel--${sn}--${deviceId}成功---`
        );
        /* mock pgm */
        // let xC = 0.0008;
        // let x = 0.219735;
        // let y = 0.344086;
        // if (sn === "11") {
        //   xC = 0.01;
        //   x = 0.619735;
        //   y = 0.444086;
        // }
        // if (sn === "1") {
        //   xC = 0.001;
        //   x = 0.344086;
        //   y = 0.444086;
        // }
        // if (sn === "10") {
        //   xC = 0.01;
        //   x = 0.556425;
        //   y = 0.448541;
        // }
        // setInterval(() => {
        //   x = Number((x + Number(xC.toFixed(6))).toFixed(6));
        //   const obj = {
        //     travel: {
        //       location: [
        //         {
        //           omega: 0,
        //           x,
        //           y,
        //         },
        //       ],
        //     },
        //   };
        //   this.wsDeviceDataList.push({ sn, ...obj, color });
        // }, 1000);
        /* tile mock */
        // const wsData11 = [
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.836269, y: 30.813266 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.836396, y: 30.813278 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.836555, y: 30.81325 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.836705, y: 30.813175 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.836852, y: 30.813111 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.837014, y: 30.81304 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.837292, y: 30.812953 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.837509, y: 30.812953 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.83783, y: 30.813012 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.837945, y: 30.81304 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.838211, y: 30.813064 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.838599, y: 30.813028 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.838841, y: 30.812917 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.839019, y: 30.81285 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.839241, y: 30.812794 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.839435, y: 30.812739 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.839657, y: 30.812652 }],
        //     },
        //   },
        // ];
        // const wsData1 = [
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.836519, y: 30.812232 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.83664, y: 30.81221 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.836776, y: 30.812164 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.836896, y: 30.812138 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.837058, y: 30.812089 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.837168, y: 30.812066 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.837307, y: 30.812044 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.837398, y: 30.812059 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.83759, y: 30.812085 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.837699, y: 30.812251 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.837948, y: 30.812338 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.83808, y: 30.812443 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.838276, y: 30.812587 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.838566, y: 30.812636 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.83877, y: 30.812477 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.839113, y: 30.81247 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.839392, y: 30.812443 }],
        //     },
        //   },
        // ];
        // const wsData10 = [
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.836112, y: 30.81145 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.836467, y: 30.811379 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.836609, y: 30.811318 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.836873, y: 30.811125 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.837264, y: 30.810836 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.837711, y: 30.810912 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.837853, y: 30.810912 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.838183, y: 30.810963 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.838487, y: 30.810958 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.838781, y: 30.810887 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.839111, y: 30.810948 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.839248, y: 30.811065 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.839487, y: 30.811156 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.839685, y: 30.811222 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.839827, y: 30.811227 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.839883, y: 30.811136 }],
        //     },
        //   },
        //   {
        //     travel: {
        //       location: [{ omega: 0, x: 120.84003, y: 30.81108 }],
        //     },
        //   },
        // ];

        // let count = 0;
        // setInterval(() => {
        //   let obj = {};
        //   if (sn === "11") {
        //     obj = wsData11[count];
        //     if (count < wsData11?.length) {
        //       this.wsDeviceDataList.push({ sn, ...obj, color });
        //     }
        //   }
        //   if (sn === "0") {
        //     obj = wsData1[count];
        //     if (count < wsData1?.length) {
        //       this.wsDeviceDataList.push({ sn, ...obj, color });
        //     }
        //   }
        //   if (sn === "10") {
        //     obj = wsData10[count];
        //     if (count < wsData10?.length) {
        //       this.wsDeviceDataList.push({ sn, ...obj, color });
        //     }
        //   }
        //   count++;
        // }, 1000);
      };

      this.ws[deviceObj?.sn].onmessage = (msg) => {
        const msgObj = JSON.parse(msg?.data);
        this.wsDeviceDataList.push({ sn, ...msgObj, color });
      };

      this.ws[deviceObj?.sn].onclose = (event) => {
        if (event.wasClean) {
          console.log(
            `[close] Connection closed cleanly, --${curPage}--device-travel----, code=${event.code} reason=${event.reason} deviceId=${deviceId}`
          );
        } else {
          console.log(
            `[close] Connection died, --${curPage}--device-travel----`
          );
        }
      };
      this.ws.onerror = (e) => {
        console.log(`WebSocket连接失败: --${curPage}--device-travel----e.code`);
      };
    },

    getOnlineTaskList: async function (notClearSelect) {
      try {
        this.tableLoading = true;
        if (!notClearSelect) {
          this.clearTableSelection();
        }

        const scenceId = this.selectSceneInfo?.id;
        if (scenceId) {
          const content = await getOnlineTaskList({
            scenceId,
          });
          // 单纯排序
          const resSort = content.sort((a, b) => {
            return b?.createTime - a?.createTime;
          });
          const dataColors = (resSort || []).map((i) => {
            return { ...i, color: RandomColor() || "skyblue" };
          });
          this.onlineTasksList = dataColors;
          if (notClearSelect) {
            this.showTableSelect();
          }
        }
      } catch (error) {
        this.onlineTasksList = [];
        this.tableLoading = false;
        console.log("error", error);
      } finally {
        this.tableLoading = false;
      }
    },
    formatterFun(row, column) {
      const { columnKey } = column;
      switch (columnKey) {
        default:
          return row[columnKey] || "-";
      }
    },
    clearTableSelection() {
      this.$refs.sceneTableRef?.clearSelection();
      this.selectionList = [];
      this.mapInfoPointsData = [];
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.onHavedData([], true, "", "seleted");
      }
    },
    // 场景下 勾选在线任务之后，去其他页面不清空勾选(除新建、编辑页，两者会实际更新在线任务列表数据，默认清空)
    showTableSelect() {
      this.$nextTick(() => {
        this.selectionList.forEach((row) => {
          this.$refs.sceneTableRef?.toggleRowSelection(
            this.onlineTasksList.find((item) => {
              return row.name === item.name;
            }),
            true
          );
        });
      });
      this.mapInfoPointsData = this.selectionList;
      if (this.$refs.pgmKonvaShowRef) {
        const seletedData = cloneDeep(this.selectionList);
        this.$refs.pgmKonvaShowRef.onHavedData(
          seletedData,
          true,
          "",
          "seleted"
        );
      }
    },
    onAction: async function (row, type) {
      let params = { id: row.id };
      switch (type) {
        case "Restore":
          {
            params = { ...params, status: "Restore" };
            await executeTask(params);
            await this.getOnlineTaskList(true);
          }
          break;
        case "suspend":
          {
            params = { ...params, status: "Running" };
            if (row.status === "Running" || row.status === "Restore") {
              params = { ...params, status: "Pause" };
            }
            await executeTask(params);
            await this.getOnlineTaskList(true);
          }
          break;
        case "end":
          this.$confirm("是否确认终止任务：" + row.name + "?", "终止任务", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning",
          }).then(async () => {
            params = { ...params, status: "Cancel" };
            await executeTask(params);
            const deleteSelected = this.selectionList.map((i) => {
              if (i?.id === row.id) {
                return;
              }
              return i;
            });
            this.selectionList = deleteSelected.filter(Boolean);
            await this.getOnlineTaskList(true);
            this.$message({
              type: "success",
              message: "终止任务成功!",
            });
          });
          break;
        case "emergencyStop": {
          params = {
            deviceId: row.id,
            method: "EmergencyStop",
            params: {
              action: 1,
            },
            cache: "0",
            response: "0",
            expired: 100,
            streamType: 0,
          };
          const len = row.deviceIds?.length;
          if (len > 0) {
            // 急停任务下所有的设备
            for (let i = 0; i < len; i++) {
              params = { ...params, deviceId: row.deviceIds[i] };
              await emergencyStop(params);
            }
          } else {
            await emergencyStop(params);
          }

          await this.getOnlineTaskList(true);
          break;
        }
        default: {
          // 默认走更新update
          this.$store.commit("updateIsTask", {
            isTask: true,
            curTaskInfo: { ...row, optsType: "update" },
          });
          this.clearTableSelection();
          await this.resetTask();
          await this.onTaskEdit(row);
          break;
        }
      }
    },

    onClickOpts: function (type) {
      switch (type) {
        case "history":
          this.$store.commit("updateIsTaskHistory", true);
          this.getHistroyTaskList();
          break;
        default: // 默认走更新edit
          this.isShowUpdateScene = true;
          break;
      }
    },

    closeUpdateScene: function () {
      this.isShowUpdateScene = false;
      this.getSceneDetail();
    },

    getHistroyTaskList: async function () {
      try {
        this.historyTableLoading = true;
        const content = await getHistoryTaskList({
          scenceId: this.selectSceneInfo?.id,
        });

        this.historyTaskList = content;
      } catch (error) {
        this.historyTaskList = [];
        this.historyTableLoading = false;
        console.log("error", error);
      } finally {
        this.historyTableLoading = false;
      }
    },
    selectChange(selection, row) {
      const taskPoints = selection.length > 0 ? selection : [];
      this.selectionList = cloneDeep(taskPoints);
      this.mapInfoPointsData = taskPoints;
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.onHavedData(taskPoints, true, "", "seleted");
      }
    },

    // /设置表格背景颜色
    ACellStyle(row) {
      return `color:  ${row.color || "#ccc"}`;
    },

    headerCellAllClassName({ row, column, rowIndex, columnIndex }) {
      // 保证最后一列
      const len = row.length - 1;
      if (columnIndex === len) {
        return "header_cell_allShow";
      }
    },

    // 任务详情
    onClickTaskInfo: async function (row) {
      this.isShowSceneDetail = false;
      // 关闭场景的已选设备
      await this.closeWebsoket();

      this.isShowTaskDetail = true;
      this.taskInfoRow = row;
      this.clearTableSelection();
      // if (this.$refs.pgmKonvaShowRef) {
      //   this.$refs.pgmKonvaShowRef.onHavedData([row], true);
      // }
    },

    onDeleteOnlineTask: function () {
      this.isShowTaskDetail = false;
      this.isShowSceneDetail = true;
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.onHavedData([{}], true);
      }
      // 任务详情 点击删除/终止按钮， 清空 界面 ws map 导航点
      this.taskInfoRow = null;
      this.curMethod = "";
      this.selectionList = [];
      this.getOnlineTaskList();
    },

    resetTask: function (obj) {
      const addUpdateTaskRefs = this.$refs.addUpdateTaskRef;
      if (addUpdateTaskRefs) {
        addUpdateTaskRefs.isCollapse = true;
        if (addUpdateTaskRefs.$refs && addUpdateTaskRefs.$refs.taskRef) {
          addUpdateTaskRefs.$refs.taskRef.resetFormData(obj);
        }
      }
    },

    // <- goBack
    taskCondition: function () {
      this.isShowSceneDetail = true;
      this.isShowTaskDetail = false;
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.isShow = true;
        this.$refs.pgmKonvaShowRef.resetPoint();
      }
      this.getOnlineTaskList();
      if (this.$refs?.cesiumViewerRef) {
        this.$refs?.cesiumViewerRef?.clearAreaPoints();
      }

      // 退出任务信息，开启场景下 已选设备device-travel
      for (let i = 0; i < this.selectedDeviceList?.length; i++) {
        this.openWebsocket(
          this.selectedDeviceList[i],
          this.selectedDeviceList[i?.color]
        );
      }
    },

    onTaskEdit: function (taskInfo) {
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.resetPoint();
      }

      const curTaskInfoRow = {
        ...taskInfo,
        location: strToObj(taskInfo?.location, ["jd", "wd", "gc"]),
        level: strToObj(taskInfo?.level, ["min", "max"]),
        zoom: strToObj(taskInfo?.zoom, ["min", "max"]),
        rectangle: strToObj(taskInfo?.rectangle, [
          "west",
          "east",
          "north",
          "south",
        ]),
      };

      this.mapInfoPointsData = [curTaskInfoRow];
    },

    isShowTaskInfo: function (isShowTaskDetail) {
      this.isShowTaskDetail = isShowTaskDetail;
    },

    onUpdateTaskCancel: function () {
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.isShow = true;
      }
      this.clearTableSelection();
      this.taskInfoRow = null;
    },

    updateCurSceneMapObj: function (obj) {
      this.$refs?.cesiumViewerRef?.resetViewer();
      this.$refs?.pgmKonvaShowRef?.resetData();
      this.mapId = obj?.id;
      this.mapType = obj?.type;
      this.mapInfo = {
        ...obj,
        location: strToObj(obj?.location, ["jd", "wd", "gc"]),
        level: strToObj(obj?.level, ["min", "max"]),
        zoom: strToObj(obj?.zoom, ["min", "max"]),
        rectangle: strToObj(obj?.rectangle, ["west", "east", "north", "south"]),
      };
    },

    // 拿到taskInfo 的point 给到pgm展示操作
    getCurTaskInfoPoints: function (points, isShow, method, optsType) {
      // method 任务类型
      this.$nextTick(() => {
        if (this.$refs.pgmKonvaShowRef) {
          this.$refs.pgmKonvaShowRef.onHavedData(
            points,
            isShow,
            method,
            optsType
          );
        }
        this.pageType = optsType;
        this.method = method;
        if (method === "info") {
          const infoObj = points?.[0];
          this.taskInfoRow = infoObj;
        }
      });
    },

    getCurTaskPoints: function () {
      // 处理接口传参
      if (this.$refs.pgmKonvaShowRef) {
        const { points, pixelX, pixelY, originX, originY, resolution } =
          this.$refs.pgmKonvaShowRef;
        const paramsPoint = [];
        for (let item of points.values()) {
          if (this.sceneName.includes("建图")) {
            const {
              location: { x, y },
            } = item;

            if (
              (pixelX || pixelX === 0) &&
              (pixelY || pixelY === 0) &&
              (originX || originX === 0) &&
              (originY || originY === 0) &&
              (resolution || resolution === 0)
            ) {
              const { worldX, worldY } = UvToWorld(
                x,
                y,
                pixelX,
                pixelY,
                originX,
                originY,
                resolution
              );

              item.location.x = worldX;
              item.location.y = worldY;
            }

            paramsPoint.push(item);
          } else {
            paramsPoint.push(item);
          }
        }
        return paramsPoint;
      }

      if (this.$refs?.cesiumViewerRef) {
        const { points } = this.$refs?.cesiumViewerRef;
        const paramsPoint = [];
        for (let item of points.values()) {
          paramsPoint.push(item);
        }
        return paramsPoint;
      }
    },

    getAreaPoints: function () {
      // 处理接口传参
      if (this.$refs.pgmKonvaShowRef) {
        const { areaPoints, pixelX, pixelY, originX, originY, resolution } =
          this.$refs.pgmKonvaShowRef;
        const atrFormData = this.$refs.pgmKonvaShowRef?.getAttributeFormData();
        if (this.sceneName.includes("建图")) {
          let arr = [];
          for (let i = 0; i < areaPoints?.length; i++) {
            const { worldX, worldY } = UvToWorld(
              areaPoints[i],
              areaPoints[i + 1],
              pixelX,
              pixelY,
              originX,
              originY,
              resolution
            );
            arr.push(worldX, worldY);
            i++;
          }
          return { areaPoints: arr, process: atrFormData };
        }
        return { areaPoints, process: atrFormData };
      }
      if (this.$refs.cesiumViewerRef) {
        const { areaPoints } = this.$refs.cesiumViewerRef;
        const atrFormData = this.$refs.cesiumViewerRef.cesiumTooltipFormData;
        return { areaPoints, process: atrFormData?.process };
      }
    },

    // 清空point相关数据
    resetMapData: function (cancel) {
      // this.clearTableSelection();
      this.taskInfoRow = null;
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.resetPoint();
        if (cancel) {
          // 取消隐藏tooltip
          this.$refs.pgmKonvaShowRef.isShow = true;
        }
      }
      // 清空瓦片图points
      if (this.$refs.cesiumViewerRef) {
        this.$refs.cesiumViewerRef?.resetViewerData();
        this.$refs?.cesiumViewerRef?.clearAreaPoints();
      }
    },

    // 添加任务
    onClickNavPoint: function (optsType, method) {
      this.pageType = optsType;
      this.method = method;
      this.$refs?.pgmKonvaShowRef?.onHavedData([{}], false);
    },

    onClearBoundaryPoint: function () {
      if (this.$refs.pgmKonvaShowRef) {
        this.$refs.pgmKonvaShowRef.resetAreaPointData();
      }
      if (this.$refs.cesiumViewerRef) {
        this.$refs.cesiumViewerRef.clearAreaPoints();
      }
    },
    saveBoundaryPoint: function () {
      if (this.$refs.pgmKonvaShowRef) {
        return this.$refs.pgmKonvaShowRef.saveBoundaryPoint();
      }
      if (this.$refs.cesiumViewerRef) {
        this.$refs.cesiumViewerRef.addPolygonById();
      }
    },

    resetSceneData: function () {
      this.$store.commit("updateIsTaskHistory", false);
      this.firstDeviceId = "";
      this.$refs?.cesiumViewerRef?.resetViewer();
      this.$refs?.pgmKonvaShowRef?.resetData();
      this.selectSceneInfo = null;
      this.sceneId = "";
      this.sceneName = "";
      this.mapId = "";
      this.mapType = "";
      this.wsDeviceDataList = [];
      this.isShowUpdateScene = false;
      this.selectedDeviceList = [];
      this.firstDeviceId = "";
    },
  },
  beforeDestroy() {
    this.closeWebsoket();
    this.resetSceneData();
  },
};
</script>

<style lang="scss" scoped>
@import "./Index.scss";
</style>
