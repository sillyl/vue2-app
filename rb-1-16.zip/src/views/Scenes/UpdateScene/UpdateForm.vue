<template>
  <el-form ref="form" :model="form" label-width="80px">
    <el-col :span="8">
      <el-form-item label="场景名称">
        <el-input v-model="form.name" disabled></el-input>
      </el-form-item>
      <el-form-item label="订阅服务">
        <el-select v-model="form.subscribeId" placeholder="请选择">
          <el-option
            v-for="item in subscribeList"
            :label="item.name"
            :value="item.id"
            :key="item.id"
          ></el-option>
        </el-select>
      </el-form-item>
    </el-col>
    <el-col :span="8">
      <el-form-item label="视频转发" class="video_label">
        <el-form-item v-for="(i, idx) in videoUrlsAll" :key="i.sn + idx">
          <el-form-item
            class="video_label_item"
            v-for="(item, index) in i.videoUrls"
            :label="i.sn + '(' + i.name + ')-视频' + (index + 1)"
            :title="i.sn + '(' + i.name + ')-视频' + (index + 1)"
            :key="index"
          >
            <el-input
              v-model="form['video' + i.sn + index]"
              @input="onInputChange($event)"
            ></el-input>
          </el-form-item>
        </el-form-item>
      </el-form-item>
    </el-col>
    <el-col :span="3" class="update_scene_opts">
      <slot></slot>
    </el-col>
  </el-form>
</template>

<script>
import { getSceneDetail } from "@/api/scene";
import { getMapMenuList } from "@/api/map.js";
import { getSubscribeList } from "@/api/subscribe.js";
export default {
  name: "UpdateForm",
  props: ["selectSceneInfo"],
  data() {
    return {
      form: {
        name: "",
        subscribeId: "",
        mapId: "",
      },
      subscribeList: [],
      mapList: [],
      sceneInfo: {
        videoUrls: [],
      },
      videoUrlsAll: [],
    };
  },

  mounted() {
    this.getSceneDetailData();
  },

  methods: {
    getSceneDetailData: async function () {
      try {
        const res = await getSceneDetail({
          id: this.selectSceneInfo?.id,
        });
        this.form = {
          name: res?.name,
          mapId: res?.map?.id,
          subscribeId: res?.subscribeId,
        };
        this.videoUrlsAll = res?.devices;
        if (res?.devices?.length > 0) {
          let len = 0;
          for (let j = 0; j < res?.devices?.length; j++) {
            const obj = res?.devices[j];

            for (let k = 0; k < obj?.videoUrls?.length; k++) {
              this.form["video" + obj.sn + k] = obj?.videoUrls[k];
            }
          }
        }
        this.subscribeList = await getSubscribeList();
        this.mapList = await getMapMenuList();
      } catch (error) {
        this.sceneInfo = null;
      }
    },

    onInputChange: function (e, obj) {
      this.$forceUpdate();
    },

    resetFormData: function () {
      this.form = {
        name: "",
        subscribeId: "",
        mapId: "",
      };
    },
  },
};
</script>

<style lang="scss" scoped>
form {
  padding: 8px;
  height: calc(100% - 16px);
  overflow: auto;

  .el-select,
  .el-input-number {
    width: 100%;
  }

  ::v-deep {
    .video_label label:nth-child(1) {
      text-align: left;
      width: 100% !important;
      margin-left: 8px;
    }

    .video_label {
      .el-form-item__content {
        .el-form-item__label {
          text-align: right;
          width: 140px !important;
          margin-left: -2px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          padding: 0 8px 0 0;
        }
      }

      &_item {
        margin: 0 0 20px -80px;
        .el-form-item__content {
          margin-left: 140px !important;
        }
      }
    }
  }

  .update_scene_opts {
    float: right;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: flex-end;
    ::v-deep {
      .el-button {
        margin-bottom: 10px;
      }
    }
  }
}
</style>
