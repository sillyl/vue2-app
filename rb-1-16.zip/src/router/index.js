import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);

const routes = [
  {
    path: "/login",
    alias: "/",
    name: "Login",
    component: () =>
      import(/* webpackChuncName: "Login"*/ "@/views/Login/Index.vue"),
  },
  {
    path: "/jMuxerVideo",
    name: "JMuxerVideo",
    component: () =>
      import(
        /* webpackChuncName: "VideoPlay"*/ "@/components/VideoPlay/JMuxerVideo.vue"
      ),
  },
  {
    path: "/video-split",
    name: "VideoSplit",
    component: () =>
      import(
        /* webpackChunkName: "controlMode" */ "@/components/SplitScreen/Index.vue"
      ),
  },
  {
    path: "/control-mode",
    component: () =>
      import(/* webpackChunkName: "Layout" */ "@/views/Layout/Index.vue"),
    children: [
      // fix ControlMode 在开始登陆时 渲染两边的问题
      // {
      //   path: "/control-mode",
      //   name: "controlMode",
      //   component: () =>
      //     import(
      //       /* webpackChunkName: "controlMode" */ "@/views/ControlMode/Index.vue"
      //     ),
      // },
      {
        path: "/scene",
        name: "scene",
        component: () =>
          import(/* webpackChunkName: "Scenes" */ "@/views/Scenes/Index.vue"),
        children: [
          {
            path: ":sceneId",
            name: "sceneDetail",
            component: () =>
              import(
                /* webpackChunkName: "Scenes" */ "@/views/Scenes/Scene/Index.vue"
              ),
          },
        ],
      },
      {
        path: "/device",
        name: "device",
        component: () =>
          import(/* webpackChunkName: "Devices" */ "@/views/Devices/Index.vue"),
        children: [
          {
            path: ":id",
            name: "deviceId",
            component: () =>
              import(
                /* webpackChunkName: "Devices" */ "@/views/Devices/Device/Index.vue"
              ),
          },
        ],
      },
      {
        path: "/map",
        name: "map",
        component: () =>
          import(/* webpackChunkName: "Maps" */ "@/views/Maps/Index.vue"),
        children: [
          {
            path: ":id",
            name: "mapId",
            component: () =>
              import(
                /* webpackChunkName: "Maps" */ "@/views/Maps/Map/Index.vue"
              ),
          },
        ],
      },
      // {
      //   path: "/subscribe",
      //   name: "subscribe",
      //   component: () =>
      //     import(
      //       /* webpackChunkName: "Subscribe" */ "@/views/Subscribes/Index.vue"
      //     ),
      //   children: [
      //     {
      //       path: ":id",
      //       name: "subscribeId",
      //       component: () =>
      //         import(
      //           /* webpackChunkName: "Maps" */ "@/views/Subscribes/Subscribe/Index.vue"
      //         ),
      //     },
      //   ],
      // },
      // {
      //   path: "/task",
      //   name: "Task",
      //   component: () =>
      //     import(/* webpackChunkName: "Task" */ "@/views/Task/Index.vue"),
      //   children: [
      //     {
      //       path: "add",
      //       name: "addTask",
      //       component: () =>
      //         import(
      //           /* webpackChunkName: "Task" */ "@/views/Task/AddUpdateTask/Index.vue"
      //         ),
      //     },
      //     {
      //       path: "update",
      //       name: "updateTask",
      //       component: () =>
      //         import(
      //           /* webpackChunkName: "Task" */ "@/views/Task/AddUpdateTask/Index.vue"
      //         ),
      //     },
      //     {
      //       path: ":id/detail",
      //       name: "taskDetail",
      //       component: () =>
      //         import(
      //           /* webpackChunkName: "Task" */ "@/views/Task/Detail/Index.vue"
      //         ),
      //     },
      //   ],
      // },
      {
        path: "/notFound",
        name: "NotFound",
        meta: {
          title: "Page not found",
          isLogin: false,
        },
        component: () =>
          import(
            /* webpackChunkName: "NotFound" */ "@/components/NotFound/Index.vue"
          ),
      },
    ],
  },
  {
    path: "/notFound",
    name: "NotFound",
    meta: {
      title: "Page not found",
      isLogin: false,
    },
    component: () =>
      import(
        /* webpackChunkName: "NotFound" */ "@/components/NotFound/Index.vue"
      ),
  },

  // 所有未定义路由，全部重定向到notFound页
  {
    path: "*",
    redirect: "/notFound",
  },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
