import Vue from "vue";
import Vuex from "vuex";
import { localStorageGetItem } from "@/utils/localStorageFun.js";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    isControlMode: false, // 控制模式内容显隐
    isShowNippleVal: localStorageGetItem("nippleVal") || false, // 控制全局摇杆的显隐
    isAddMap: false, //添加地图
    isTask: false, // 是否展示任务
    curTaskInfo: null,
    isCollapse: true, // CustomCollapse 展开收起
    deviceList: [],
    isTaskHistory: false,
    websocketUrl: "ws://" + window.location.host.split(":")[0] + ":8090",
    // websocketUrl: "ws://192.168.8.52:8090",
    curCtrlMode: "", // 当前控制模式 smartCtrCenter:2 , platCtrCenter: 1, jointCtrCenter:3
    curDeviceId: localStorageGetItem("curDeviceId") || "",
    curDeviceInfo: localStorageGetItem("curDeviceInfo") || null,
    curCtrlModes: {},
    curSubscribe: {
      isShow: false,
      optType: "",
    },
  },
  getters: {},
  mutations: {
    updateCurCtrlMode(state, data) {
      state.curCtrlMode = data;
    },
    updateCurCtrlModes(state, data) {
      state.curCtrlModes = data;
    },
    updateisShowNippleVal(state, data) {
      state.isShowNippleVal = data;
    },
    updateIsControlMode(state, isControlMode) {
      state.isControlMode = isControlMode;
    },
    addMap(state, isAddMap) {
      state.isAddMap = isAddMap;
      state.isControlMode = false; // 增加地图时不展示两边的控制模式
    },
    updateIsTask(state, data) {
      state.isTask = data.isTask;
      if (data.curTaskInfo) {
        state.curTaskInfo = data.curTaskInfo || null;
      }
    },
    updateIsCollapse(state, isCollapse) {
      state.isCollapse = isCollapse;
    },

    updateIsTaskHistory(state, data) {
      state.isTaskHistory = data;
    },

    // 设备list
    setDeviceList(state, data) {
      state.deviceList = data;
    },

    updateCurDeviceId(state, data) {
      state.curDeviceId = data;
    },

    saveCurDeviceInfo: function (state, data) {
      state.curDeviceInfo = data;
    },

    updateCurSubscribe: function (state, data) {
      state.curSubscribe = data;
    },
  },
  actions: {},
  modules: {},
});
