export const STATUS_CODE = {
  UNAUTHENTICATED: 401,
  SUCCESS: 0,
  NOTFOUND: 100609, // NOT_FOUND_RESOURCE
};

export const fileTypeList = ["png", "jpg", "pgm"];

export const cmdMethods = ["GET_INFO", "EmergencyStop"];

export const cmdStatus = [
  "PENDING",
  "SUCCESS",
  "FAILED",
  "TIMEOUT",
  "DELIVERED", // 交付
];

export const alertTyleList = [{ 0: "低电量" }, { 1: "故障" }, { 2: "异常" }];

export const alertLevel = ["紧急", "严重", "警告", "一般"];
// 紧急、严重、警告、一般和信息

export const alertModule = ["移动底盘", "机械臂", "NUC"];

export const subscribeOpts = {
  add: "添加订阅",
  edit: "编辑订阅",
  info: "订阅详情",
};
