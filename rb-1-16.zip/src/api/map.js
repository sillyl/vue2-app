import axiosInstance, { axiosWarpInstance } from "@/utils/axiosInstance.js";

export const getMapList = async (data) => {
  const res = await axiosWarpInstance(
    "/cpix/v1.0/configure/map/consumer/list?pageNo=0&pageSize=50&sort=createTime",
    data,
    { type: "get" }
  );
  return res;
};

// menu list
export const getMapMenuList = async (data) => {
  const res = await axiosWarpInstance(
    "/cpix/v1.0/configure/map/consumer/all/list",
    data,
    { type: "get" }
  );
  return res;
};

// 内置地图
export const getBuiltInMapList = async (data) => {
  const res = await axiosWarpInstance(
    `/cpix/v1.0/configure/device/consumer/map/list/${data?.id}`,
    data,
    { type: "get" }
  );
  return res;
};

export const getMapTypeList = async () => {
  const res = await axiosWarpInstance(
    "/cpix/v1.0/configure/map/consumer/type/list",
    {},
    { type: "get" }
  );
  return res;
};

export const uploadMap = async (data) => {
  const res = await axiosWarpInstance(
    "/cpix/v1.0/configure/map/consumer/upload",
    data,
    { type: "post", isFormData: true }
  );
  return res;
};

export const getMapInfo = async (data) => {
  const res = await axiosWarpInstance(
    `/cpix/v1.0/configure/map/consumer/info/${data.id || data.mapId}`,
    data,
    { type: "get", isFormData: true }
  );
  return res;
};

export const viewMap = async (data) => {
  const res = await axiosWarpInstance(
    `/cpix/v1.0/configure/map/consumer/view/${data.id || data.mapId}`,
    {},
    {
      type: "get",
      skipGlobalHandler: true,
    }
  );
  return res;
};

export const deleteMap = async (data) => {
  const res = await axiosWarpInstance(
    `/cpix/v1.0/configure/map/consumer/delete/${data.id || data.mapId}`,
    {},
    {
      type: "delete",
    }
  );
  return res;
};

// 地图下发
export const distributeMap = async (data) => {
  const res = await axiosWarpInstance(
    "/cpix/v1.0/configure/map/consumer/distribute",
    data,
    {
      type: "post",
    }
  );
  return res;
};

// 地图纠偏
export const mapRectify = async (data) => {
  const res = await axiosWarpInstance(
    `/cpix/v1.0/configure/map/consumer/rectify/${data.id}`,
    data,
    {
      type: "get",
    }
  );
  return res;
};
