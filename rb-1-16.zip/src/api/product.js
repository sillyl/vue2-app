import { axiosWarpInstance } from "@/utils/axiosInstance.js";

export const getProductInfo = async (data) => {
  const res = await axiosWarpInstance(
    `/cpix/v1.0/configure/product/common/info/${data.productId}`,
    {},
    { type: "get" }
  );
  return res;
};
