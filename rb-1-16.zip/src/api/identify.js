import { axiosWarpInstance } from "@/utils/axiosInstance.js";

export const getIdentifierList = () => {
  const res = axiosWarpInstance(
    "/cpix/v1.0/configure/identifier/consumer/list",
    {},
    {
      type: "get",
    }
  );
  return res;
};
