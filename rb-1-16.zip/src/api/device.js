import { axiosWarpInstance } from "@/utils/axiosInstance.js";

export const getDeviceList = async (data) => {
  const res = await axiosWarpInstance(
    "/cpix/v1.0/configure/device/consumer/list?productId=1&pageNum=0&pageSize=50",
    data,
    { type: "get" }
  );
  return res;
};

export const getDeviceMenuList = async (data) => {
  const res = await axiosWarpInstance(
    "/cpix/v1.0/configure/device/consumer/menu/list",
    data,
    { type: "get" }
  );
  return res;
};

// 下拉设备
export const getDeviceAllList = async (data) => {
  let url = "/cpix/v1.0/configure/device/consumer/all/list";
  const res = await axiosWarpInstance(url, data, { type: "get" });
  return res;
};

// 设备基本信息
export const getDeviceInfo = async (data) => {
  const res = await axiosWarpInstance(
    `/cpix/v1.0/configure/device/common/info/${data.id}`,
    {},
    { type: "get" }
  );
  return res;
};

export const getDeviceDetail = async (data) => {
  const res = await axiosWarpInstance(
    `/cpix/v1.0/configure/device/common/detail/${data.id}`,
    {},
    { type: "get" }
  );
  // let res;
  // if (Number(data.id) === 1) {
  //   res = {
  //     id: "1",
  //     sn: "0",
  //     mapDeviceId: null,
  //     name: "dev1",
  //     location: "",
  //     ip: "10.88.104.156",
  //     port: 8083,
  //     videoUrls: ["rtsp://10.88.104.103:8554/grasp"],
  //     rosDescUrl: null,
  //     rosBridgeUrl: "ws://192.168.8.102:9090",
  //     createTime: 1678262222501,
  //     groupId: "1",
  //     productId: "1",
  //     userId: "2",
  //     deviceStatus: 0,
  //     curMapId: "8ad8e81c888f87b101888f88ba620002",
  //     curScenceId: null,
  //     curTaskId: "402888b788087d920188087fbc4d0002",
  //     shootNum: null,
  //     scence: null,
  //     task: {
  //       id: "402888b788087d920188087fbc4d0002",
  //       name: "aa20230511T094929Z",
  //       describe: "",
  //       method: "TASK_NAVIGATION",
  //       params: {
  //         point: [
  //           {
  //             process: [],
  //             station: [],
  //             location: {
  //               x: "0.396648",
  //               y: "0.643625",
  //               omega: 0,
  //             },
  //           },
  //           {
  //             process: [],
  //             station: [],
  //             location: {
  //               x: "0.413408",
  //               y: "0.399386",
  //               omega: 0,
  //             },
  //           },
  //         ],
  //       },
  //       createTime: 1683769769037,
  //       location: null,
  //       deviceIds: ["1"],
  //       scenceId: "ff80818187fa66f10187fa6a326f0001",
  //       parentId: null,
  //       userId: "2",
  //       status: "Create",
  //       priority: 1,
  //     },
  //     map: {
  //       id: "8ad8e81c888f87b101888f88ba620002",
  //       no: null,
  //       name: "map042801",
  //       type: 0,
  //       fileType: "pgm",
  //       from: "dev1",
  //       location: null,
  //       zoom: null,
  //       level: null,
  //       rectangle: null,
  //       offsetX: null,
  //       offsetY: null,
  //       createTime: 1686035282530,
  //       userId: "2",
  //     },
  //     product: {
  //       id: "1",
  //       name: "product1",
  //       driverServerName: "cpix-udp-driver-service",
  //       model: "NHY",
  //       encrypt: null,
  //       secret: null,
  //       pml: [],
  //       pmlFlag: {},
  //       createTime: 1678262222499,
  //     },
  //   };
  // }

  // if (Number(data.id) === 2) {
  //   res = {
  //     id: "2",
  //     sn: "0",
  //     mapDeviceId: null,
  //     name: "dev1",
  //     location: "",
  //     ip: "10.88.104.156",
  //     port: 8083,
  //     videoUrls: ["rtsp://10.88.104.103:8554/grasp"],
  //     rosDescUrl: null,
  //     rosBridgeUrl: "ws://192.168.8.102:9090",
  //     createTime: 1678262222501,
  //     groupId: "1",
  //     productId: "1",
  //     userId: "2",
  //     deviceStatus: 0,
  //     curMapId: "8ad8e81c888f87b101888f88ba620002",
  //     curScenceId: "8ad8e8098bad9116018bada13c9b0001",
  //     curTaskId: "402888b788087d920188087fbc4d0002",
  //     shootNum: null,
  //     scence: {
  //       id: "8ad8e8098bad9116018bada13c9b0001",
  //       userId: "2",
  //       name: "nnTile-0",
  //       deviceIds: ["1", "4", "2", "3"],
  //       channels: null,
  //       mapId: "ff8081818778710e0187788e882a0003",
  //       status: "Open",
  //       subscribeId: "1",
  //       videoPushs: null,
  //       timeScope: 1000,
  //       createTime: 1699425107098,
  //       defaultScence: false,
  //       tasks: [
  //         {
  //           id: "8ad8e8098bad9116018bada3801b0003",
  //           name: "侦查nn-0",
  //           describe: null,
  //           method: "TASK_INVESTIGATE",
  //           params: {
  //             area: [],
  //             mappingType: 0,
  //             mapConflation: "complete",
  //             formation: "",
  //             mapName: "map1699425238580",
  //             point: [],
  //             circulate: 1,
  //           },
  //           createTime: 1699425255443,
  //           location: null,
  //           deviceIds: ["1", "2", "3", "4"],
  //           scenceId: "8ad8e8098bad9116018bada13c9b0001",
  //           parentId: null,
  //           userId: "2",
  //           status: "Create",
  //           priority: 2,
  //         },
  //       ],
  //       map: {
  //         id: "ff8081818778710e0187788e882a0003",
  //         no: null,
  //         name: "嘉兴地图",
  //         type: 2,
  //         fileType: "png",
  //         from: "导入",
  //         location: "120.838279:30.811383:600",
  //         zoom: "200:1000",
  //         level: "1:18",
  //         rectangle: "120.808154:30.789338:120.871210:30.825225",
  //         offsetX: null,
  //         offsetY: null,
  //         createTime: 1681354819624,
  //         userId: "2",
  //       },
  //       subscribe: {
  //         id: "1",
  //         name: "subscribe1",
  //         type: "udp",
  //         args: '{"local": {"ip":"127.0.0.1","port": 7766},"remote":[{"ip":"127.0.0.1","port": 7765}]}',
  //         userId: "2",
  //         model: "ZNY2",
  //         encrypt: "",
  //         secret: "",
  //         subscribeServerId: "1",
  //         createTime: 1678262222500,
  //       },
  //       devices: [
  //         {
  //           id: "1",
  //           sn: "0",
  //           mapDeviceId: null,
  //           name: "dev1",
  //           location: "",
  //           ip: "10.88.104.156",
  //           port: 8083,
  //           videoUrls: ["rtsp://10.88.104.103:8554/grasp"],
  //           rosDescUrl: null,
  //           rosBridgeUrl: "ws://192.168.8.102:9090",
  //           createTime: 1678262222501,
  //           groupId: "1",
  //           productId: "1",
  //           userId: "2",
  //           deviceStatus: 0,
  //           curMapId: "8ad8e81c888f87b101888f88ba620002",
  //           curScenceId: "8ad8e8098bad9116018bada13c9b0001",
  //           curTaskId: "8ad8e8098bad9116018bada3801b0003",
  //           shootNum: null,
  //         },
  //         {
  //           id: "4",
  //           sn: "11",
  //           mapDeviceId: null,
  //           name: "仿真2",
  //           location: "",
  //           ip: "127.0.0.1",
  //           port: 8083,
  //           videoUrls: null,
  //           rosDescUrl: null,
  //           rosBridgeUrl: null,
  //           createTime: 1686107653854,
  //           groupId: "1",
  //           productId: "1",
  //           userId: "2",
  //           deviceStatus: 0,
  //           curMapId: null,
  //           curScenceId: "8ad8e8098bad9116018bada13c9b0001",
  //           curTaskId: "8ad8e8098bad9116018bada3801b0003",
  //           shootNum: null,
  //         },
  //         {
  //           id: "2",
  //           sn: "1",
  //           mapDeviceId: null,
  //           name: "dev2",
  //           location: "",
  //           ip: "127.0.0.1",
  //           port: 8083,
  //           videoUrls: [
  //             "rtsp://admin:nanhu@2020@192.168.8.64/h264/ch1/sub/av_stream",
  //           ],
  //           rosDescUrl: null,
  //           rosBridgeUrl: "ws://127.0.0.1:9090",
  //           createTime: 1673848764431,
  //           groupId: "1",
  //           productId: "1",
  //           userId: "2",
  //           deviceStatus: 0,
  //           curMapId: "ff80818187e46b210187e46bfd4e0001",
  //           curScenceId: "8ad8e8098bad9116018bada13c9b0001",
  //           curTaskId: "8ad8e8098bad9116018bada3801b0003",
  //           shootNum: null,
  //         },
  //         {
  //           id: "3",
  //           sn: "10",
  //           mapDeviceId: null,
  //           name: "仿真1",
  //           location: "",
  //           ip: "127.0.0.1",
  //           port: 8083,
  //           videoUrls: null,
  //           rosDescUrl: null,
  //           rosBridgeUrl: null,
  //           createTime: 1686107646314,
  //           groupId: "1",
  //           productId: "1",
  //           userId: "2",
  //           deviceStatus: 0,
  //           curMapId: null,
  //           curScenceId: "8ad8e8098bad9116018bada13c9b0001",
  //           curTaskId: "8ad8e8098bad9116018bada3801b0003",
  //           shootNum: null,
  //         },
  //       ],
  //     },
  //     task: {
  //       id: "8ad8e8098bad9116018bada3801b0003",
  //       name: "侦查nn-0",
  //       describe: null,
  //       method: "TASK_INVESTIGATE",
  //       params: {
  //         area: [],
  //         mappingType: 0,
  //         mapConflation: "complete",
  //         formation: "",
  //         mapName: "map1699425238580",
  //         point: [],
  //         circulate: 1,
  //       },
  //       createTime: 1699425255443,
  //       location: null,
  //       deviceIds: ["1", "2", "3", "4"],
  //       scenceId: "8ad8e8098bad9116018bada13c9b0001",
  //       parentId: null,
  //       userId: "2",
  //       status: "Create",
  //       priority: 2,
  //     },
  //     map: {
  //       id: "ff8081818778710e0187788e882a0003",
  //       no: null,
  //       name: "嘉兴地图",
  //       type: 2,
  //       fileType: "png",
  //       from: "导入",
  //       location: "120.838279:30.811383:600",
  //       zoom: "200:1000",
  //       level: "1:18",
  //       rectangle: "120.808154:30.789338:120.871210:30.825225",
  //       offsetX: null,
  //       offsetY: null,
  //       createTime: 1681354819624,
  //       userId: "2",
  //     },
  //     product: {
  //       id: "1",
  //       name: "product1",
  //       driverServerName: "cpix-udp-driver-service",
  //       model: "NHY",
  //       encrypt: null,
  //       secret: null,
  //       pml: [],
  //       pmlFlag: {},
  //       createTime: 1678262222499,
  //     },
  //   };
  // }
  return res;
};

// 删除设备
export const deleteDevice = async (data) => {
  const res = await axiosWarpInstance(
    `/cpix/v1.0/configure/device/consumer/delete/${data.id}`,
    {},
    { type: "delete" }
  );
  return res;
};

// 启用地图
export const enableMap = async (data) => {
  const res = await axiosWarpInstance(
    "/cpix/v1.0/configure/cmd/consumer/post",
    data,
    { type: "post" }
  );
  return res;
};

// 绑定地图
export const bindMap = async (data) => {
  const res = await axiosWarpInstance(
    "/cpix/v1.0/configure/cmd/consumer/post",
    data,
    { type: "post" }
  );
  return res;
};

// 在线升级
export const onlineUpgrade = async (data) => {
  const res = await axiosWarpInstance(
    "/cpix/v1.0/configure/device/consumer/terminal/handle",
    data,
    { type: "get" }
  );
  return res;
};

// 重启设备
export const rebootDevice = async (data) => {
  const res = await axiosWarpInstance(
    `/cpix/v1.0/configure/device/common/info/${data.id}`,
    {},
    { type: "get" }
  );
  return res;
};

// 设备 告警
export const getAlertList = (data) => {
  const res = axiosWarpInstance(
    "/cpix/v1.0/configure/event/common/list",
    data,
    { type: "get" }
  );
  return res;
};
