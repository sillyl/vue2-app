export const UvToWorld = (
  uvX,
  uvY,
  pixel_x,
  pixel_y,
  origin_x,
  origin_y,
  resolution
) => {
  const mapX = uvX * pixel_x;
  const mapY = uvY * pixel_y;
  const worldX = origin_x + (mapX + 0.5) * resolution;
  const worldY = (pixel_y - mapY) * resolution + origin_y;
  return {
    worldX,
    worldY,
  };
  // return {
  //   worldX: Number(worldX.toFixed(2)),
  //   worldY: Number(worldY.toFixed(2)),
  // };
};

export const worldToUv = (
  worldX,
  worldY,
  pixel_x,
  pixel_y,
  origin_x,
  origin_y,
  resolution
) => {
  const uvX = Math.floor((worldX - origin_x) / resolution + 0.5) / pixel_x;
  const uvY =
    (pixel_y - Math.floor((worldY - origin_y) / resolution)) / pixel_y;
  return { uvX, uvY };
  // return { uvX: Number(uvX.toFixed(6)), uvY: Number(uvY.toFixed(6)) };
};
