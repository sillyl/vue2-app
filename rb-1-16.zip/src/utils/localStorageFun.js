function localStorageSetItem(key, val) {
  localStorage.setItem(key, JSON.stringify(val));
}

function localStorageGetItem(key) {
  const res = localStorage.getItem(key);
  if (res) {
    const data = JSON.parse(res);
    return data;
  }
  return res;
}

export { localStorageSetItem, localStorageGetItem };
