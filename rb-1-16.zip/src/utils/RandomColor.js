let hexStr = "0123456789abcde";
// 将f去掉 防止出现颜色很浅的情况
export function RandomColor() {
  let hexCode = "#";
  for (let i = 0; i < 6; i++) {
    hexCode += hexStr[Math.floor(Math.random() * hexStr.length)];
  }
  return hexCode;
}
