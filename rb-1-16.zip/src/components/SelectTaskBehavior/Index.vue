<template>
  <div class="select_task_behavior">
    <div class="select_task_behavior_txt">行为动作指令</div>
    <div class="select_task_behavior_content">
      <el-select v-model="action" placeholder="请选择动作" size="small">
        <el-option
          v-for="item in metaTaskList"
          :key="item.method"
          :label="item.name"
          :value="item.method"
        >
        </el-option>
      </el-select>
      <!-- 标注任务显示 -->
      <el-select
        v-model="target"
        placeholder="请选择目标物"
        v-if="action === 'TASK_MARK'"
        size="small"
      >
        <el-option
          v-for="item in identifierList"
          :key="item.code"
          :label="item.name"
          :value="item.code"
        ></el-option>
      </el-select>
    </div>
  </div>
</template>

<script>
import { taskBehaviorsDefault, taskBehaviors } from "@/constants";
import { getSceneMetaTaskList } from "@/api/task";
import { getIdentifierList } from "@/api/identify";
export default {
  props: [],
  data() {
    return {
      target: "",
      action: "",
      identifierList: [],
      metaTaskList: [],
    };
  },
  mounted() {
    this.getSceneMetaTaskList();
  },
  methods: {
    getSceneMetaTaskList: async function () {
      this.metaTaskList = await getSceneMetaTaskList({ type: 2 });
      this.action = this.metaTaskList?.[0]?.method;
      this.identifierList = await getIdentifierList();
      // code: 4 表示人
      const person = this.identifierList?.filter((i) => i?.code === "4");
      this.target = person?.length > 0 ? person?.[0].code : "";
    },
  },
};
</script>

<style lang="scss" scoped>
@import "@/assets/css/common.scss";
.select_task_behavior {
  display: flex;
  max-width: 448px;
  margin-top: 8px;

  &_txt {
    line-height: 32px;
    font-size: 16px;
  }
  &_content {
    padding-left: 8px;
    flex: 1;

    .el-select {
      width: 40%;
    }
  }
}
</style>
