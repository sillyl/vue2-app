<template>
  <div class="button_group_content">
    <div
      class="button_group_content_btns"
      v-for="(i, idx) in data.group"
      :key="(i.groupId || i.id) + idx"
    >
      <el-row>
        <el-col :span="i.name ? 9 : 0" v-if="i.name">
          <span class="controls_p_name button_group_content_name"
            >{{ i.name }}
          </span>
        </el-col>
        <el-col
          :span="i.name ? 15 : 24"
          :class="[
            'button_group_content_btn',
            !i.name && 'button_group_content_btn_not_name',
          ]"
        >
          <el-col
            :span="!i.name ? 8 : 12"
            v-for="k in i.packages"
            :key="k.action"
            class="button_group_content_btn_row"
          >
            <el-button type="primary" @click="onBtnClick(i, k)"
              >{{ k.name }}
            </el-button>
          </el-col>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
import { triggerCmd } from "@/components/JsonSchema/triggerCmd";
export default {
  props: ["data"],
  data() {
    return {};
  },

  methods: {
    onBtnClick: async function (data, item) {
      const { type, id } = data;
      const { action } = item;
      await triggerCmd(id, type, action);
    },
  },
};
</script>

<style lang="scss" scoped>
.button_group_content {
  &_name {
    line-height: 40px;
  }

  &_btn {
    .el-button + .el-button {
      margin-left: 0px;
    }

    .el-button {
      margin-right: 10px;
      margin-bottom: 4px;
      padding: 8.9px 12px;
      margin-top: 4px;
    }

    &_not_name {
      padding-left: 8px;
    }

    &_row {
      display: flex;
      justify-content: center;
    }
  }
}
</style>
