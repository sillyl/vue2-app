<template>
  <div class="slider_number_group">
    <div v-for="(i, idx) in data.group" :key="i.id + idx">
      <p v-if="i.name" class="controls_p_name">{{ i.name }}</p>
      <SliderNumber
        :data="i"
        v-for="k in i.packages"
        :key="k.action"
        :item="k"
      />
    </div>
  </div>
</template>

<script>
import SliderNumber from "../SliderNumber/Index.vue";
export default {
  props: ["data"],
  data() {
    return {};
  },

  components: {
    SliderNumber,
  },
};
</script>

<style lang="scss" scoped></style>
