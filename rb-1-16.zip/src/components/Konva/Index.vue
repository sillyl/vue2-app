<template>
  <div style="background: #f6f6f6">
    <div
      id="pgmContainer"
      :style="{ height: tableHeight + 'px' }"
      :max-height="tableHeight"
      style="overflow-y: auto; overflow-x: auto"
    >
      <v-stage
        class="konva-stage"
        ref="konvaStage"
        :config="konvaConfig.stage"
        :scale="konvaConfig.scale"
        @contextmenu="onContextmenu"
        @click="onStageClick"
        @touchstart="onStageTouchstart"
        @touchmove="onStageTouchmove"
        @touchend="onStageTouchend"
        @wheel="wheelForScale($event)"
      >
        <v-layer ref="konvaLayer">
          <v-group :config="konvaConfig.group">
            <v-image
              :config="{
                image: konvaConfig.pgmImage,
              }"
            />
          </v-group>
          <v-group :config="konvaConfig.group">
            <v-circle
              v-for="(item, index) in konvaConfig.curPoint"
              :key="index + 3000"
              :config="{
                x: item.x,
                y: item.y,
                radius: 8,
                fill: '#ffff00',
                stroke: 'black',
                strokeWidth: 3,
              }"
            >
            </v-circle>
            <v-arrow
              v-for="(item, index) in konvaConfig.curPoint"
              :key="index + 2000"
              :config="{
                x: item.x,
                y: item.y,
                points: [
                  0,
                  0,
                  50 * Math.cos((item.omega * Math.PI) / 180),
                  50 * Math.sin((item.omega * Math.PI) / 180),
                ],
                pointerLength: 30,
                pointerWidth: 10,
                fill: '#ffff00',
                stroke: 'black',
                strokeWidth: 3,
              }"
            >
            </v-arrow>
          </v-group>
          <v-group :config="konvaConfig.group">
            <v-line
              v-for="(item, index) in konvaConfig.polyline"
              :key="index + 1000"
              :config="{
                points: item,
                stroke: '#ff0000',
                strokeWidth: 6,
                lineCap: 'round',
                lineJoin: 'round',
              }"
            >
            </v-line>
          </v-group>
          <v-group
            :config="konvaConfig.group"
            @click="onMouseClick"
            @tap="onTouchTap"
            @dragstart="onDragStart"
            @dragmove="onDragMove"
            @dragend="onDragEnd"
          >
            <v-circle
              v-for="(item, index) in konvaConfig.points"
              :key="index"
              :config="{
                id: index,
                x: item.x,
                y: item.y,
                radius: 8,
                fill: '#ff0000',
              }"
              :draggable="true"
            >
            </v-circle>
          </v-group>
          <v-group
            :config="konvaConfig.group"
            @tap="onTouchTap"
            @mousedown="onMouseDownForArrow"
            @touchstart="onTouchStartForArrow"
            @mousemove="onMouseMoveForArrow"
            @touchmove="onTouchMoveForArrow"
            @mouseup="onMouseUpForArrow"
            @touchend="onTouchEndForArrow"
          >
            <v-arrow
              v-for="(item, index) in konvaConfig.points"
              :key="index + 99"
              :config="{
                id: index,
                x: item.x,
                y: item.y,
                points: [
                  0,
                  0,
                  50 * Math.cos((item.omega * Math.PI) / 180),
                  50 * Math.sin((item.omega * Math.PI) / 180),
                ],
                pointerLength: 30,
                pointerWidth: 10,
                fill: '#ffff00',
                stroke: 'black',
                strokeWidth: 3,
              }"
            >
            </v-arrow>
          </v-group>
        </v-layer>
      </v-stage>
      <CircleTooltip
        :visible="visibleCircleTooltip"
        :triggerPosition="triggerPosition"
        :circleNeedData="circleNeedData"
        ref="circleTooltipRef"
        @saveCircleTooltipData="saveCircleTooltipData"
        @deleteCircleTooltipData="deleteCircleTooltipData"
      />
    </div>
  </div>
</template>

<script>
import CircleTooltip from "../CoordinatePickup/Index.vue";
import { MapImage } from "@/utils/maping.js";
import { getCurrentTime } from "@/utils/index.js";
import {
  getMinPoint,
  getCenter,
  getDistance,
  getKonvaConfigByObj,
} from "@/utils/CoordinatePickupFun.js";
import { isEmpty } from "lodash";
let clickNum = 0;
let lastCenter;
let lastDist;
let timeId;
export default {
  name: "investigate",
  components: {
    CircleTooltip,
  },
  data() {
    return {
      visibleCircleTooltip: false,
      triggerPosition: null,
      isTouchmoveing: false,
      threshold: 0.01,
      isTouchStart: false,
      tableHeight: 0,
      dialogVisible: false,
      deviceId: this.$route.query.deviceId,
      taskId: this.$route.query.taskId,
      showModel: "tileMap", // tileMap pgmMap
      pointSelect: false,
      metaTaskList: [],
      identifierList: [],
      mapList: [],
      sceneList: [],
      deviceList: [],
      task: {
        id: "",
        name: "导航任务" + getCurrentTime(),
        describe: "",
        method: "TASK_NAVIGATION",
        params: {
          circulate: 1,
          point: [],
        },
        deviceIds: [],
        location: "",
        sceneId: "",
      },
      scene: {
        id: "",
        name: "",
        deviceIds: [],
        mapId: "",
      },
      points: new Map(),
      selectPoint: { location: { omega: 0 }, process: [], station: [] },
      selectPointId: 0,
      selectArrowId: -1,
      selectArrowX: 0,
      selectArrowY: 0,
      selectPoint2Id: -1,
      selectPoint2X: 0,
      selectPoint2Y: 0,
      konvaConfig: {
        stage: {
          width: 2000,
          height: 2000,
        },
        group: {
          x: 0,
          y: 0,
          scaleX: 1,
          scaleY: 1,
        },
        pgmImage: null,
        points: [],
        polyline: [],
        curPoint: [{ x: 100, y: 100, omega: 45 }],
        scaleDistance: 0,
      },
      selectMoveEntity: null, // 需要移动的导航点
      curLocationEntity: null, // 当前设备的位置
      curLocationPosition: null,
      polylineEntity: null,
      travelUrl: this.$store.getters.websocketUrl + "url",
      konvaScrollStartX: -1,
      konvaScrollStartY: -1,
      navigationPoint: null,
      curClickPointCartesian: null,
      stageScale: 1,
      stagePointerPosition: {
        x: 0,
        y: 0,
      },
      // 插入节点的最大数量（包括已删除的），这是个递增值
      historyMaxnodeNum: 0,
    };
  },
  computed: {
    circleNeedData() {
      return {
        stage: this.konvaConfig.stage,
        points: this.points,
        threshold: this.threshold,
        id: "pgmContainer",
        isTouchStart: this.isTouchStart,
        isTouchmoveing: this.isTouchmoveing,
        form: {
          omega: 0,
          identifierList: this.identifierList, // 目标物
          metaTaskList: this.metaTaskList, // 动作
          selectPoint: this.selectPoint, // 选择点
        },
        stageScale: this.stageScale,
        stagePointerPosition: this.stagePointerPosition,
      };
    },
  },
  methods: {
    // 放大缩小函数
    wheelForScale(e) {
      e.evt.preventDefault();
      const scaleBy = 1.01;
      const stage = this.$refs.konvaStage.getStage();
      const oldScale = stage.scaleX();
      const mousePointTo = {
        x: stage.getPointerPosition().x / oldScale - stage.x() / oldScale,
        y: stage.getPointerPosition().y / oldScale - stage.y() / oldScale,
      };
      const newScale =
        e.evt.deltaY > 0 ? oldScale * scaleBy : oldScale / scaleBy;
      stage.scale({ x: newScale, y: newScale });
      this.$nextTick(() => {
        stage.x(
          (-mousePointTo.x + stage.getPointerPosition().x / newScale) * newScale
        );
        stage.y(
          (-mousePointTo.y + stage.getPointerPosition().y / newScale) * newScale
        );
        stage.batchDraw();
        const scale = e.evt.deltaY > 0 ? scaleBy : 1 / scaleBy;
        this.stageScale = newScale;
        this.stagePointerPosition = {
          x: stage.x(),
          y: stage.y(),
        };
        this.triggerPosition = {
          ...this.triggerPosition,
          layerX:
            stage.getPointerPosition().x +
            (-stage.getPointerPosition().x + this.triggerPosition.layerX) *
              scale,
          layerY:
            stage.getPointerPosition().y +
            (-stage.getPointerPosition().y + this.triggerPosition.layerY) *
              scale,
        };
      });
    },
    deleteCircleTooltipData: function (data) {
      const { directions, triggerPoint, visible } = data;
      const {
        location: { x, y },
      } = triggerPoint;
      const { cx, cy } = directions;
      this.visibleCircleTooltip = visible;
      const obj = getMinPoint(
        this.points,
        { x, y },
        this.threshold / this.stageScale
      );
      // const stageThreshold = this.threshold *  (this.konvaConfig.stage.width * this.stageScale);
      // const obj1 = getMinPoint(this.konvaConfig.points, { x: cx, y: cy }, stageThreshold);
      const obj1 = getKonvaConfigByObj(this.konvaConfig.points, obj);

      if (!isEmpty(obj)) {
        this.points.delete(obj.key);
        let newPolyline = [];
        this.konvaConfig.points = this.konvaConfig.points.map((i) => {
          if (i.key === obj1.key) {
            return;
          } else {
            return { ...i };
          }
        });
        // 更新 polyline
        newPolyline = this.konvaConfig.polyline.map((arrItem) => {
          const result = [];
          for (var i = 0; i < arrItem.length; i = i + 2) {
            if (obj1.x == arrItem[i] && obj1.y == arrItem[i + 1]) {
              continue;
            } else {
              result.push(arrItem[i]);
              result.push(arrItem[i + 1]);
            }
          }
          return result;
        });
        this.konvaConfig.points = [
          ...new Set(this.konvaConfig.points.filter(Boolean)),
        ];
        this.konvaConfig.polyline = newPolyline;
      }
    },
    saveCircleTooltipData: function (data) {
      const { directions, triggerPoint, visible } = data;
      const {
        location: { x, y, omega },
      } = triggerPoint;
      const { cx, cy } = directions;
      this.visibleCircleTooltip = visible;
      const obj = getMinPoint(
        this.points,
        { x, y },
        this.threshold / this.stageScale
      );
      const obj1 = getKonvaConfigByObj(this.konvaConfig.points, obj);
      let map = new Map();
      if (!isEmpty(obj)) {
        map = this.points.set(this.historyMaxnodeNum, triggerPoint);
        this.konvaConfig.points = this.konvaConfig.points.map((i) => {
          if (i.key === obj1.key) {
            return { ...i, omega };
          } else {
            return { ...i };
          }
        });
      } else {
        map = this.points.set(this.historyMaxnodeNum, triggerPoint);
        this.konvaConfig.points.push({
          x: cx,
          y: cy,
          omega,
          key: this.historyMaxnodeNum,
        });
        this.historyMaxnodeNum += 1;
      }

      this.points = map;
      let pointArr = [];
      const curPoints = [...new Set(this.konvaConfig.points.filter(Boolean))];
      for (let i = 0; i < curPoints.length; i++) {
        pointArr.splice(pointArr.length, 0, curPoints[i].x, curPoints[i].y);
      }
      if (pointArr.length >= 4) {
        this.konvaConfig.polyline.push(pointArr);
      }
      this.konvaConfig.points = curPoints;
    },
    onStageClick: function (e) {
      const { layerX, layerY, clientX, clientY } = e.evt;
      this.triggerPosition = {
        layerX,
        layerY,
        clientX,
        clientY,
      };
      this.initData();
    },
    onStageTouchstart: function (e) {
      const len = e.evt.touches.length;
      const { pageX, pageY } = e.evt.touches[0];
      if (len >= 2) {
        clearTimeout(timeId);
      } else {
        timeId = setTimeout(() => {
          this.triggerPosition = {
            pageX,
            pageY,
          };
          this.isTouchStart = true;
          this.initData();
        }, 50);
      }
    },
    onStageTouchmove: function (e) {
      e.evt.preventDefault();
      const dom = document.getElementById("pgmContainer");
      const stage = this.$refs.konvaStage.getStage();
      const touch1 = e.evt.touches[0];
      const touch2 = e.evt.touches[1];
      if (touch1 && touch2) {
        this.isTouchmoveing = true;
        if (stage.isDragging()) {
          stage.stopDrag();
        }
        const p1 = {
          x: touch1.pageX,
          y: touch1.pageY,
        };
        const p2 = {
          x: touch2.pageX,
          y: touch2.pageY,
        };

        if (!lastCenter) {
          lastCenter = getCenter(p1, p2);
          return;
        }

        if (!lastDist) {
          lastDist = getDistance(p1, p2);
        }
        const newCenter = getCenter(p1, p2); // 缩放中心
        const newDist = getDistance(p1, p2); // 两指距离
        const pointTo = {
          x: (newCenter.x - stage.x()) / stage.scaleX(),
          y: (newCenter.y - stage.y()) / stage.scaleX(),
        };
        let circlePointTo = {
          x: 0,
          y: 0,
        };
        if (this.triggerPosition) {
          circlePointTo = {
            x:
              (newCenter.x -
                (this.triggerPosition.pageX -
                  dom.offsetLeft +
                  dom.scrollLeft)) /
              stage.scaleX(),
            y:
              (newCenter.y -
                (this.triggerPosition.pageY - dom.offsetTop + dom.scrollTop)) /
              stage.scaleX(),
          };
        }
        const scale = stage.scaleX() * (newDist / lastDist);
        // 用于子组件的位置更新
        this.stageScale = scale;
        this.stagePointerPosition = {
          x: stage.x(),
          y: stage.y(),
        };
        stage.scale({ x: scale, y: scale });
        const dx = newCenter.x - lastCenter.x;
        const dy = newCenter.y - lastCenter.y;
        const newPos = {
          x: newCenter.x - pointTo.x * scale + dx,
          y: newCenter.y - pointTo.y * scale + dy,
        };

        this.triggerPosition = {
          pageX:
            newCenter.x -
            circlePointTo.x * scale +
            dx +
            (dom.offsetLeft - dom.scrollLeft),
          pageY:
            newCenter.y -
            circlePointTo.y * scale +
            dy +
            (dom.offsetTop - dom.scrollTop),
        };
        stage.position(newPos);
        lastDist = newDist;
        lastCenter = newCenter;
      }
    },
    onStageTouchend: function () {
      lastDist = 0;
      lastCenter = null;
    },
    initData: function () {
      this.visibleCircleTooltip = true;
      this.$refs.circleTooltipRef.form = {
        omega: 0,
        identifierList: this.identifierList, // 目标物
        metaTaskList: this.metaTaskList, // 动作
        selectPoint: this.selectPoint ||
          this.navigationPoint || {
            location: { omega: 0 },
            process: [],
            station: [],
          }, // 选择点
      };
      this.$refs.circleTooltipRef.directions = {
        cx: 60,
        cy: 60,
        omega: 0,
      };
    },
    onContextmenu: function (click) {
      click.evt.preventDefault();
    },
    onMouseClick: function (click) {
      if (click.evt.button == 0) {
        if (!this.pointSelect) {
          // this.hidePgmLayer();
        }
      } else if (click.evt.button == 2) {
        if (!this.pointSelect) {
          if (this.showModel === "pgmMap") {
            let id = click.target.attrs.id;
            if (typeof id == "undefined") {
              // this.hidePgmLayer();
            } else {
              this.selectPoint = {
                location: { omega: 0 },
                process: [],
                station: [],
              };
              this.selectPoint = this.points.get(id);

              this.selectPointId = id;

              let x = click.evt.clientX;
              let y = click.evt.clientY;
            }
          }
        }
      }
    },
    onTouchTap: function (click) {
      if (!this.pointSelect) {
        let id = click.target.attrs.id;
        if (typeof id != "undefined") {
          this.selectPoint = {
            location: { omega: 0 },
            process: [],
            station: [],
          };
          this.selectPoint = this.points.get(id);
          this.selectPointId = id;

          let x = click.evt.changedTouches[0].clientX;
          let y = click.evt.changedTouches[0].clientY;
        } else {
          // this.hidePgmLayer();
        }
      }
    },
    onDragStart: function (click) {
      if (this.showModel === "pgmMap") {
        if (typeof click.target.attrs.id != "undefined") {
          this.selectPoint2Id = click.target.attrs.id;
          if (click.evt.type == "touchmove") {
            this.selectPoint2X = click.evt.touches[0].clientX;
            this.selectPoint2Y = click.evt.touches[0].clientY;
          }
        }
      }
    },
    onDragMove: function (click) {
      if (this.selectPoint2Id != -1) {
        let id = this.selectPoint2Id;
        let layerX = 0;
        let layerY = 0;

        if (click.evt.type == "mousemove") {
          layerX = click.evt.layerX;
          layerY = click.evt.layerY;
        } else {
          let distanceX = click.evt.touches[0].clientX - this.selectPoint2X;
          let distanceY = click.evt.touches[0].clientY - this.selectPoint2Y;
          this.selectPoint2X = click.evt.touches[0].clientX;
          this.selectPoint2Y = click.evt.touches[0].clientY;
          layerX =
            Math.round(
              this.konvaConfig.points[Number(id)].x *
                this.konvaConfig.group.scaleX
            ) + distanceX;
          layerY =
            Math.round(
              this.konvaConfig.points[Number(id)].y *
                this.konvaConfig.group.scaleX
            ) + distanceY;
        }

        this.konvaConfig.points[Number(id)].x = Math.round(
          layerX / (this.konvaConfig.group.scaleX * 1.0)
        );
        this.konvaConfig.points[Number(id)].y = Math.round(
          layerY / (this.konvaConfig.group.scaleY * 1.0)
        );

        let uvX = layerX / (this.konvaConfig.stage.width * 1.0);
        let uvY = layerY / (this.konvaConfig.stage.height * 1.0);

        let curPoint = this.points.get(id);
        curPoint.location.x = uvX.toFixed(6);
        curPoint.location.y = uvY.toFixed(6);
      }
    },
    onDragEnd: function (click) {
      if (this.showModel === "pgmMap") {
        if (this.selectPoint2Id != -1) {
          this.konvaConfig.polyline = [];
          var pointArr = [];
          for (let i = 0; i < this.konvaConfig.points.length; i++) {
            pointArr.push(this.konvaConfig.points[i].x);
            pointArr.push(this.konvaConfig.points[i].y);
          }
          this.konvaConfig.polyline.push(pointArr);

          this.selectPoint2Id = -1;
        }
      }
    },
    onMouseDownForArrow: function (click) {
      if (this.showModel === "pgmMap") {
        if (click.evt.button == 0) {
          if (typeof click.target.attrs.id != "undefined") {
            this.selectArrowId = click.target.attrs.id;
          } else {
            if (this.pointSelect) {
              let uvX = click.evt.layerX / (this.konvaConfig.stage.width * 1.0);
              let uvY =
                click.evt.layerY / (this.konvaConfig.stage.height * 1.0);

              var point = {
                location: { x: uvX.toFixed(6), y: uvY.toFixed(6), omega: 0 },
                process: [],
                station: [],
              };
              this.points.set(this.konvaConfig.points.length, point);
              this.selectArrowId = this.konvaConfig.points.length;

              let item = {
                x: click.evt.layerX,
                y: click.evt.layerY,
                omega: 0,
                key: this.konvaConfig.points.length,
              };
              this.konvaConfig.points.push(item);
            }
          }
        }
      }
    },
    onTouchStartForArrow: function (click) {
      if (this.showModel === "pgmMap") {
        if (typeof click.target.attrs.id != "undefined") {
          this.selectArrowId = click.target.attrs.id;
          this.selectArrowX = click.evt.touches[0].clientX;
          this.selectArrowY = click.evt.touches[0].clientY;
        } else {
          if (this.pointSelect) {
            let layerX =
              click.evt.touches[0].clientX +
              click.evt.layerX -
              this.konvaConfig.group.x;
            let layerY =
              click.evt.touches[0].clientY +
              click.evt.layerY -
              this.konvaConfig.group.y;

            let uvX = layerX / (this.konvaConfig.stage.width * 1.0);
            let uvY = layerY / (this.konvaConfig.stage.height * 1.0);

            layerX = Math.round(layerX / (this.konvaConfig.group.scaleX * 1.0));
            layerY = Math.round(layerY / (this.konvaConfig.group.scaleY * 1.0));

            var point = {
              location: { x: uvX.toFixed(6), y: uvY.toFixed(6), omega: 0 },
              process: [],
              station: [],
            };
            this.points.set(this.konvaConfig.points.length, point);
            this.selectArrowId = this.konvaConfig.points.length;

            let item = {
              x: layerX,
              y: layerY,
              omega: 0,
              key: this.konvaConfig.points.length,
            };
            this.konvaConfig.points.push(item);
          }

          if (click.evt.touches.length >= 2) {
            let p1x = click.evt.touches[0].clientX;
            let p1y = click.evt.touches[0].clientY;
            let p2x = click.evt.touches[1].clientX;
            let p2y = click.evt.touches[1].clientY;

            this.konvaConfig.scaleDistance = Math.sqrt(
              Math.pow(p1x - p2x, 2) + Math.pow(p1y - p2y, 2)
            );

            this.konvaScrollStartX = -1;
            this.konvaScrollStartY = -1;
          } else if (click.evt.touches.length == 1) {
            this.konvaScrollStartX = click.evt.touches[0].clientX;
            this.konvaScrollStartY = click.evt.touches[0].clientY;
          }
        }
      }
      click.evt.preventDefault();
    },
    onMouseMoveForArrow: function (click) {
      if (this.showModel === "pgmMap") {
        if (click.evt.button == 0) {
          if (this.selectArrowId != -1) {
            var tleft =
              click.evt.layerX -
              this.konvaConfig.points[Number(this.selectArrowId)].x;
            var ttop =
              click.evt.layerY -
              this.konvaConfig.points[Number(this.selectArrowId)].y;

            var angle = Math.atan2(ttop - 0, tleft - 0);
            this.konvaConfig.points[Number(this.selectArrowId)].omega =
              angle / (3.14159 / 180);
          }
        }
      }
    },
    onTouchMoveForArrow: function (click) {
      if (this.showModel === "pgmMap") {
        if (this.selectArrowId != -1) {
          let tleft = click.evt.touches[0].clientX - this.selectArrowX;
          let ttop = click.evt.touches[0].clientY - this.selectArrowY;
          var angle = Math.atan2(ttop - 0, tleft - 0);
          this.konvaConfig.points[Number(this.selectArrowId)].omega =
            angle / (3.14159 / 180);

          let curPoint = this.points.get(this.selectArrowId);
          curPoint.location.omega = angle / (3.14159 / 180);
        } else {
          if (click.evt.touches.length >= 2) {
            const stage = this.$refs.konvaStage.getStage();
            const scaleBy = 1.2;
            const pointer = stage.getPointerPosition();
            const layerNode = this.$refs.konvaLayer.getNode();
            let bgx = layerNode.getAttr("x");
            let bgy = layerNode.getAttr("y");
            const mousePointTo = {
              x: (pointer.x - bgx) / this.konvaConfig.group.scaleX,
              y: (pointer.y - bgy) / this.konvaConfig.group.scaleY,
            };
            let p1x = click.evt.touches[0].clientX;
            let p1y = click.evt.touches[0].clientY;
            let p2x = click.evt.touches[1].clientX;
            let p2y = click.evt.touches[1].clientY;
            let scaleDistance = Math.sqrt(
              Math.pow(p1x - p2x, 2) + Math.pow(p1y - p2y, 2)
            );
            if (scaleDistance > this.konvaConfig.scaleDistance) {
              if (
                this.konvaConfig.group.scaleX < 4 &&
                this.konvaConfig.group.scaleY < 4
              ) {
                this.konvaConfig.group.scaleX =
                  this.konvaConfig.group.scaleX * scaleBy;
                this.konvaConfig.group.scaleY =
                  this.konvaConfig.group.scaleY * scaleBy;
                this.konvaConfig.stage.width = Math.round(
                  this.konvaConfig.stage.width * scaleBy
                );
                this.konvaConfig.stage.height = Math.round(
                  this.konvaConfig.stage.height * scaleBy
                );
              }
            } else {
              if (
                this.konvaConfig.group.scaleX > 1 &&
                this.konvaConfig.group.scaleY > 1
              ) {
                this.konvaConfig.group.scaleX =
                  this.konvaConfig.group.scaleX / scaleBy;
                this.konvaConfig.group.scaleY =
                  this.konvaConfig.group.scaleY / scaleBy;
                this.konvaConfig.stage.width = Math.round(
                  this.konvaConfig.stage.width / scaleBy
                );
                this.konvaConfig.stage.height = Math.round(
                  this.konvaConfig.stage.height / scaleBy
                );
              }
            }
            this.konvaConfig.group.x = Math.round(
              pointer.x - mousePointTo.x * this.konvaConfig.group.scaleX
            );
            this.konvaConfig.group.y = Math.round(
              pointer.y - mousePointTo.y * this.konvaConfig.group.scaleY
            );
            this.konvaConfig.scaleDistance = scaleDistance;
          } else if (click.evt.touches.length == 1) {
            if (this.konvaScrollStartX != -1 && this.konvaScrollStartY != -1) {
              let konvaScrollDistanceX =
                this.konvaScrollStartX - click.evt.touches[0].clientX;
              let konvaScrollDistanceY =
                this.konvaScrollStartY - click.evt.touches[0].clientY;
              this.konvaScrollStartX = click.evt.touches[0].clientX;
              this.konvaScrollStartY = click.evt.touches[0].clientY;

              const stage = this.$refs.konvaStage.getStage();
              let scrollRatioX =
                konvaScrollDistanceX /
                (stage.attrs.container.offsetWidth * 1.0);
              let scrollRatioY =
                konvaScrollDistanceY /
                (stage.attrs.container.offsetHeight * 1.0);

              let scrollSegX = Math.round(
                stage.attrs.container.parentElement.scrollLeftMax * scrollRatioX
              );
              let scrollSegY = Math.round(
                stage.attrs.container.parentElement.scrollTopMax * scrollRatioY
              );
              stage.attrs.container.parentElement.scrollLeft += scrollSegX;
              stage.attrs.container.parentElement.scrollTop += scrollSegY;
            }
          }
        }
      }
      click.evt.preventDefault();
    },
    onMouseUpForArrow: function (click) {
      if (this.showModel === "pgmMap") {
        if (click.evt.button == 0) {
          if (this.selectArrowId != -1) {
            var tleft =
              click.evt.layerX -
              this.konvaConfig.points[Number(this.selectArrowId)].x;
            var ttop =
              click.evt.layerY -
              this.konvaConfig.points[Number(this.selectArrowId)].y;

            var angle = Math.atan2(ttop - 0, tleft - 0);
            this.konvaConfig.points[Number(this.selectArrowId)].omega =
              angle / (3.14159 / 180);

            let curPoint = this.points.get(this.selectArrowId);
            curPoint.location.omega = angle / (3.14159 / 180);

            this.selectArrowId = -1;
          }
        }
      }
    },
    onTouchEndForArrow: function (click) {
      if (this.showModel === "pgmMap") {
        if (this.selectArrowId != -1) {
          this.selectArrowId = -1;
          console.log("onTouchEndForArrow");
        }

        this.konvaScrollStartX = -1;
        this.konvaScrollStartY = -1;
      }
      click.evt.preventDefault();
    },
  },
  mounted() {},
  created() {
    this.tableHeight = document.documentElement.clientHeight - 250;
  },
  beforeDestroy() {},
};
</script>

<style lang="scss" scoped>
@import "./Index.scss";
</style>
