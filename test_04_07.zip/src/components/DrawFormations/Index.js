// 多点绘制一字型
export const drawCountLinePoint = function (count) {
  let arr = [{ omega: -90, uvX: 0.218165, uvY: 0.27933 }];
  for (let i = 1; i < count; i++) {
    arr.push({
      omega: -90,
      realDistance: 1 * i,
      angle: 0,
    });
  }
  return arr;
};

// xy->ux====>konavaPoints, points
export const getUvPoints = function (cvsW, cvsH, konavaPoints) {
  let arr = [];
  let arrPoints = [];
  for (let i of konavaPoints) {
    const uvX = (i?.x / cvsW).toFixed(6);
    const uvY = (i?.y / cvsH).toFixed(6);
    arr.push({ x: uvX, y: uvY, omega: i?.omega });
    arrPoints.push({ ...i, uvX, uvY });
  }
  return { uvPoints: arr, points: arrPoints };
};

// uv-》xy====>konavaPoints, points
export const getXYPoints = function (cvsW, cvsH, points) {
  let arr = [];
  let arrPoints = [];
  for (let i of points) {
    const x = Number((i?.uvX * cvsW)?.toFixed(2));
    const y = Number((i?.uvY * cvsH)?.toFixed(2));
    arr.push({ x, y, omega: i?.omega });
    arrPoints.push({ ...i, x, y });
  }
  return { uvPoints: arr, points: arrPoints };
};

// 根据同顶点的实际距离和同位角 求出其他点在画布中像素位置和UV
export const getXYByRealInstance = function (cvsW, cvsH, pixelScale, points) {
  const { uvX, uvY } = points?.[0];
  const startX = uvX * cvsW;
  const startY = uvY * cvsH;
  const len = points?.length;
  const otherPoints = points?.slice(1, len);
  let arr = [{ ...points?.[0], x: uvX, y: uvY }];
  let arrPoints = [{ ...points?.[0], x: startX, y: startY }];
  for (let i of otherPoints) {
    const realDistance = i?.realDistance / pixelScale;
    const angle = i?.angle;
    const x = startX + realDistance * Math.cos((angle / 180) * Math.PI);
    const y = startY + realDistance * Math.sin((angle / 180) * Math.PI);
    const uvX = Number((x / cvsW).toFixed(6));
    const uvY = Number((y / cvsH).toFixed(6));
    arr.push({ x: uvX, y: uvY, omega: i?.omega });
    arrPoints.push({ ...i, x, y });
  }
  return { uvPoints: arr, points: arrPoints };
};

// 绘制等腰三角形
export const drawIsoscelesTriangle = function () {
  return [
    { omega: -90, uvX: 0.407242, uvY: 0.139665 },
    {
      omega: -90,
      realDistance: 3,
      angle: 70,
    },
    {
      omega: -90,
      realDistance: 3,
      angle: 110,
    },
  ];
};

// 绘制方型

export const drawCountSquarePoint = function () {
  return [
    { omega: -90, uvX: 0.072722, uvY: 0.139665 },
    { omega: -90, realDistance: 3, angle: 0 },
    { omega: -90, realDistance: 4.242640687119285, angle: 45 },
    { omega: -90, realDistance: 3, angle: 90 },
  ];
};
