<template>
  <div id="draw_formation" class="draw_formation">
    <v-stage
      ref="stageRef"
      class="draw_formation_stage"
      :config="konvaConfig.stage"
      @click="onStageClick"
      @wheel="wheelForScale($event)"
      @touchmove="onArrowTouchmove($event)"
      @touchend="onStageTouchend"
      @mousemove="onArrowMouseMove"
      @mouseup="onArrowMounseup"
    >
      <v-layer>
        <v-group :config="konvaConfig.group">
          <v-line
            v-for="(item, index) in konvaConfig.polyline"
            :key="`line_${index}`"
            :config="{
              points: item,
              stroke: item.color || '#ff0000',
              strokeWidth: 6,
              lineCap: 'round',
              lineJoin: 'round',
              opacity: 0.5,
              closed: curFormationType === 'line' ? false : true,
            }"
          >
          </v-line>
        </v-group>
        <!-- <v-group
          :config="konvaConfig.group"
          @mousedown="onArrowMounsedown"
          @mousemove="onArrowMouseMove"
          @touchstart="onArrowTouchstart"
          @touchmove="onArrowTouchmove"
        >
          <v-arrow
            v-for="(item, index) in konvaConfig.points"
            :key="`${item.x}_${item.y}_${item.omega}_${index}_arrow`"
            :config="{
              id: `${item.x}_${item.y}_${item.omega}_${index}_arrow`,
              x: item.x,
              y: item.y,
              points: [
                0,
                0,
                40 * Math.cos((item.omega * Math.PI) / 180),
                40 * Math.sin((item.omega * Math.PI) / 180),
              ],
              pointerLength: 30,
              pointerWidth: 15,
              fill: item?.color || '#ff0000',
              stroke: 'black',
              strokeWidth: 2,
            }"
          >
          </v-arrow>
        </v-group>
        <v-group :config="konvaConfig.group">
          <v-text
            v-for="(item, index) in konvaConfig.points"
            :key="`text_${index}`"
            :config="{
              id: index,
              x: item.x + 20,
              y: item.y - 40,
              text: item?.omega?.toFixed(2),
              fontSize: 10,
              fontFamily: 'Calibri',
              fill: 'green',
            }"
          >
          </v-text>
        </v-group> -->
        <v-group :config="konvaConfig.group">
          <v-text
            v-for="(item, index) in konvaConfig.textPointsLoation"
            :key="`text_${index}`"
            :config="{
              id: index,
              x: item.xT,
              y: item.yT,
              text: item?.text,
              fontSize: 10,
              fontFamily: 'Calibri',
              fill: 'green',
            }"
          >
          </v-text>
        </v-group>
        <v-group
          :config="konvaConfig.group"
          @dragstart="onDragCircleStart"
          @dragmove="onDragCircleMove"
          @dragend="onDragCircleEnd"
        >
          <v-circle
            name="circle_point"
            v-for="(item, index) in konvaConfig.points"
            :key="index"
            :config="{
              id: index,
              x: item.x,
              y: item.y,
              radius: 6,
              fill: item?.color || '#ff0000',
              opacity: 0.6,
            }"
            :draggable="true"
          >
          </v-circle>
        </v-group>
      </v-layer>
    </v-stage>
    <el-tooltip
      effect="light"
      content="队形作为模板保存,之后可在快捷队形列表中直接获取！"
      placement="left"
      class="draw_formation_btn"
      v-if="
        formationType === 'custom'
          ? konvaConfig.points?.length === pointCounts
          : isShowSave
      "
    >
      <el-button type="primary" round size="small" @click="saveFormation">
        保存
      </el-button>
    </el-tooltip>
  </div>
</template>

<script>
let lastDist;
let lastCenter;
import { getCenter, getDistance } from "@/utils/CoordinatePickupFun.js";
import { isEqual, isEmpty } from "lodash";
import { drawCountLinePoint, getXYByRealInstance } from "./Index.js";

export default {
  props: [
    "formationType",
    "pointCounts",
    "curPixelScale",
    "curFormationObj",
    "saveFormations",
  ],
  data() {
    return {
      konvaConfig: {
        stage: {
          width: 700,
          height: 200,
        },
        group: {
          x: 0,
          y: 0,
        },
        polyline: [],
        points: [],
        textPointsLoation: [], // 存放位置信息点的坐标
      },
      stageScale: 1,
      points: [],
      stagePointerPosition: {
        x: 0,
        y: 0,
      },
      cvsW: null,
      cvsH: null,
      curMoveArrowId: "", // 鼠标当前移动箭头标识
      curSelectCircleId: "", // 当前选中圆标识
      curFormationType: "",
      isShowSave: false,
    };
  },

  mounted() {
    this.generateStage();
    if (!isEmpty(this.curFormationObj)) {
      this.clearFormations();
      this.computedDefaultFormation(this.curFormationObj);
    }
  },

  watch: {
    curPixelScale: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.getTextPointsLoation(newVal);
      }
    },

    curFormationObj: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.clearFormations();
        this.computedDefaultFormation(newVal);
      }
    },
    formationType: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.curFormationType = "";
        this.isShowSave = false;
      }
    },
  },

  methods: {
    generateStage() {
      // 将画布自适应屏幕空间大小
      const dom = document.querySelector("#draw_formation");
      const { width, height } = dom.getBoundingClientRect();
      this.konvaConfig.stage.width = width;
      this.konvaConfig.stage.height = height;
      this.cvsW = width;
      this.cvsH = height;
    },

    getIsLineFormation: function (points) {
      const len = points?.length;
      if (len > 1) {
        const otherPoints = points?.slice(1, len);
        let angle = otherPoints?.[0]?.angle;
        for (let item of otherPoints) {
          if (item?.angle === angle) {
            this.curFormationType = "line";
          } else {
            this.curFormationType = "";
          }
        }
      }
    },

    // 处理默认定制队形
    computedDefaultFormation: async function (curFormationObj) {
      if (curFormationObj) {
        const { count, points } = curFormationObj;
        if (points?.length > 1) {
          const res = getXYByRealInstance(
            this.cvsW,
            this.cvsH,
            this.curPixelScale,
            points
          );
          this.konvaConfig.points = res?.points;
          this.points = res?.uvPoints;
          this.getIsLineFormation(curFormationObj?.points);
          this.resetDrawPloyline();
        } else {
          // points 不存在时 一字型
          const res = await drawCountLinePoint(this.pointCounts);
          const { uvPoints, points } = getXYByRealInstance(
            this.cvsW,
            this.cvsH,
            this.curPixelScale,
            res
          );
          this.konvaConfig.points = points;
          this.points = uvPoints;
          this.getIsLineFormation(points);
          this.resetDrawPloyline();
        }
      }
    },

    onStageClick: function (e) {
      if (
        this.konvaConfig.points?.length >= this.pointCounts &&
        !this.curMoveArrowId &&
        !this.curSelectCircleId
      ) {
        this.$message({
          type: "info",
          message: "点的数量不允许超过设备数量！",
        });
        return;
      }

      const { layerX, layerY } = e.evt;
      const { x, y } = this.stagePointerPosition;
      const cx = (layerX - (x || 0)) / this.stageScale;
      const cy = (layerY - (y || 0)) / this.stageScale;
      const uvX = ((layerX - (x || 0)) / (this.cvsW * this.stageScale)).toFixed(
        6
      );
      const uvY = ((layerY - (y || 0)) / (this.cvsH * this.stageScale)).toFixed(
        6
      );

      let obj = { x: cx, y: cy, omega: -90, uvX, uvY };
      // 点击圆 不再添加
      // e.target.attrs?.name !== "circle_point";
      if (
        !e.target.attrs?.id &&
        !this.curMoveArrowId &&
        !this.curSelectCircleId &&
        (!this.formationType || this.formationType === "custom")
      ) {
        if (this.konvaConfig.points?.length >= 1) {
          const startPoint = this.konvaConfig.points?.[0];
          const distance = getDistance(startPoint, { x: cx, y: cy });
          let realDistance = (distance * this.curPixelScale)?.toFixed(2);
          realDistance = Number(realDistance);
          const angle =
            Math.atan2(cy - startPoint.y, cx - startPoint.x) / (Math.PI / 180);
          obj = { x: cx, y: cy, omega: -90, uvX, uvY, realDistance, angle };
        }

        this.konvaConfig.points.push(obj);
        this.points.push({ x: uvX, y: uvY, omega: obj?.omega });
        this.resetDrawPloyline();
      }
    },
    wheelForScale: function (e) {
      e.evt.preventDefault();
      const scaleBy = 1.01;
      const stage = this.$refs.stageRef.getStage();
      const oldScale = stage.scaleX();
      const mousePointTo = {
        x: stage.getPointerPosition().x / oldScale - stage.x() / oldScale,
        y: stage.getPointerPosition().y / oldScale - stage.y() / oldScale,
      };
      const newScale =
        e.evt.deltaY > 0 ? oldScale * scaleBy : oldScale / scaleBy;
      stage.scale({ x: newScale, y: newScale });
      this.$nextTick(() => {
        stage.x(
          (-mousePointTo.x + stage.getPointerPosition().x / newScale) * newScale
        );
        stage.y(
          (-mousePointTo.y + stage.getPointerPosition().y / newScale) * newScale
        );
        stage.batchDraw();
        const scale = e.evt.deltaY > 0 ? scaleBy : 1 / scaleBy;
        this.stageScale = newScale;
        this.stagePointerPosition = {
          x: stage.x(),
          y: stage.y(),
        };
      });
    },

    onStageTouchend: function () {
      lastDist = 0;
      lastCenter = null;
    },

    onArrowMounsedown: function (e) {
      // id: x_y_arrow
      if (e.target?.attrs?.id?.includes("arrow")) {
        this.curMoveArrowId = e.target?.attrs?.id;
      }
    },

    onArrowMouseMove: function (e) {
      const { layerX, layerY } = e.evt;
      if (this.curMoveArrowId) {
        const [x, y] = this.curMoveArrowId.split("_");
        const L = layerX - x;
        const T = layerY - y;
        const angle = Math.atan2(T - 0, L - 0);
        const idx = this.konvaConfig.points.findIndex(
          (i) => i.x === Number(x) && i.y === Number(y)
        );
        if (idx > -1) {
          const omega = angle / (Math.PI / 180);
          this.konvaConfig.points[idx].omega = omega;
          this.points[idx].omega = omega;
        }
      }
    },

    onArrowMounseup: function () {
      this.curMoveArrowId = null;
    },

    onArrowTouchstart: function (e) {
      if (e.target?.attrs?.id?.includes("arrow")) {
        this.curMoveArrowId = e.target?.attrs?.id;
      }
    },

    onArrowTouchmove: function (e) {
      const touch1 = e.evt.touches[0];
      const touch2 = e.evt.touches[1];
      if (touch1 && !touch2 && this.curMoveArrowId) {
        const { pageX, pageY } = touch1;
        const dom = document.getElementById("draw_formation");
        const pageDom = document.querySelector(".robot-body");
        const { width, height } = pageDom.getBoundingClientRect();
        const domWH = dom.getBoundingClientRect();
        const H = height - domWH?.height;
        const [X, Y] = this.curMoveArrowId.split("_");
        const cxL = pageX - dom.offsetLeft + dom.scrollLeft;
        const cyT = pageY - dom.offsetTop + dom.scrollTop - H;
        const L = cxL - X;
        const T = cyT - Y;
        const angle = Math.atan2(T - 0, L - 0);
        const idx = this.konvaConfig.points.findIndex(
          (i) => i.x === Number(X) && i.y === Number(Y)
        );
        if (idx > -1) {
          const omega = angle / (Math.PI / 180);
          this.konvaConfig.points[idx].omega = omega;
          this.points[idx].omega = omega;
        }
      }
      if (touch1 && touch2) {
        e.evt.preventDefault();
        const dom = document.getElementById("draw_formation");
        const pageDom = document.querySelector(".robot-body");
        const { height } = pageDom.getBoundingClientRect();
        const domWH = dom.getBoundingClientRect();
        const H = height - domWH?.height;
        const stage = this.$refs.stageRef.getStage();
        this.konvaConfig.stage.draggable = false; // 缩放时，禁掉拖拽，两者冲突会导致缩放失效
        const p1 = {
          x: touch1.pageX - dom.offsetLeft + dom.scrollLeft,
          y: touch1.pageY - dom.offsetTop + dom.scrollTop - H,
        };
        const p2 = {
          x: touch2.pageX - dom.offsetLeft + dom.scrollLeft,
          y: touch2.pageY - dom.offsetTop + dom.scrollTop - H,
        };

        if (!lastCenter) {
          lastCenter = getCenter(p1, p2);
          return;
        }

        if (!lastDist) {
          lastDist = getDistance(p1, p2);
        }
        const newCenter = getCenter(p1, p2); // 缩放中心
        const newDist = getDistance(p1, p2); // 两指距离
        const pointTo = {
          x: (newCenter.x - stage.x()) / stage.scaleX(),
          y: (newCenter.y - stage.y()) / stage.scaleX(),
        };

        const scale = stage.scaleX() * (newDist / lastDist);
        // 用于子组件的位置更新
        this.stageScale = scale;
        this.stagePointerPosition = {
          x: stage.x(),
          y: stage.y(),
        };
        stage.scale({ x: scale, y: scale });
        const dx = newCenter.x - lastCenter.x;
        const dy = newCenter.y - lastCenter.y;
        const newPos = {
          x: newCenter.x - pointTo.x * scale + dx,
          y: newCenter.y - pointTo.y * scale + dy,
        };
        stage.position(newPos);
        lastDist = newDist;
        lastCenter = newCenter;
      }
    },

    onDragCircleStart: function (e) {
      e.cancelBubble = true;
      this.curSelectCircleId = e.target?.attrs?.id;
    },

    onDragCircleMove: function (e) {
      const { layerX, layerY, type } = e.evt;
      const id = Number(this.curSelectCircleId);
      const { x, y } = this.stagePointerPosition;
      let cx = 0;
      let cy = 0;
      let uvX = 0;
      let uvY = 0;
      if (type === "touchmove") {
        const touch1 = e.evt.touches[0];
        const { pageX, pageY } = touch1;
        const dom = document.getElementById("draw_formation");
        const pageDom = document.querySelector(".robot-body");
        const { height } = pageDom.getBoundingClientRect();
        const domWH = dom.getBoundingClientRect();
        const H = height - domWH?.height;
        const cxL = pageX - dom.offsetLeft + dom.scrollLeft;
        const cyT = pageY - dom.offsetTop + dom.scrollTop - H;
        cx = (cxL - (x || 0)) / this.stageScale;
        cy = (cyT - (y || 0)) / this.stageScale;
        uvX = ((cxL - (x || 0)) / (this.cvsW * this.stageScale)).toFixed(6);
        uvY = ((cyT - (y || 0)) / (this.cvsH * this.stageScale)).toFixed(6);
      }
      if (type === "mousemove") {
        cx = (layerX - (x || 0)) / this.stageScale;
        cy = (layerY - (y || 0)) / this.stageScale;
        uvX = ((layerX - (x || 0)) / (this.cvsW * this.stageScale)).toFixed(6);
        uvY = ((layerY - (y || 0)) / (this.cvsH * this.stageScale)).toFixed(6);
        // 更新拖拽结束数据
      }
      if (id > -1) {
        this.konvaConfig.points[id].x = cx;
        this.konvaConfig.points[id].y = cy;
        this.konvaConfig.points[id].uvX = uvX;
        this.konvaConfig.points[id].uvY = uvY;
        this.points[id].x = uvX;
        this.points[id].y = uvY;
        const startPoint = this.konvaConfig.points[0];
        const distance = getDistance(startPoint, { x: cx, y: cy });
        let realDistance = (distance * this.curPixelScale)?.toFixed(2);
        const angle =
          Math.atan2(cy - startPoint.y, cx - startPoint.x) / (Math.PI / 180);
        this.konvaConfig.points[id].realDistance = Number(realDistance);
        this.konvaConfig.points[id].angle = angle;
        this.resetDrawPloyline();
        this.isShowSave = true;
      }
    },

    onDragCircleEnd: function (e) {
      // const { layerX, layerY, type } = e.evt;
      // const id = Number(this.curSelectCircleId);
      // const { x, y } = this.stagePointerPosition;
      // let cx = 0;
      // let cy = 0;
      // let uvX = 0;
      // let uvY = 0;
      // if (type === "touchend") {
      //   const touch1 = e.evt.touches[0];
      //   const { pageX, pageY } = touch1;
      //   const dom = document.getElementById("draw_formation");
      //   const pageDom = document.querySelector(".robot-body");
      //   const { height } = pageDom.getBoundingClientRect();
      //   const domWH = dom.getBoundingClientRect();
      //   const H = height - domWH?.height;
      //   const cxL = pageX - dom.offsetLeft + dom.scrollLeft;
      //   const cyT = pageY - dom.offsetTop + dom.scrollTop - H;
      //   cx = (cxL - (x || 0)) / this.stageScale;
      //   cy = (cyT - (y || 0)) / this.stageScale;
      //   uvX = ((cxL - (x || 0)) / (this.cvsW * this.stageScale)).toFixed(6);
      //   uvY = ((cyT - (y || 0)) / (this.cvsH * this.stageScale)).toFixed(6);
      // }
      // if (type === "mouseup") {
      //   cx = (layerX - (x || 0)) / this.stageScale;
      //   cy = (layerY - (y || 0)) / this.stageScale;
      //   uvX = ((layerX - (x || 0)) / (this.cvsW * this.stageScale)).toFixed(6);
      //   uvY = ((layerY - (y || 0)) / (this.cvsH * this.stageScale)).toFixed(6);
      //   // 更新拖拽结束数据
      // }
      // if (id > -1) {
      //   this.konvaConfig.points[id].x = cx;
      //   this.konvaConfig.points[id].y = cy;
      //   this.konvaConfig.points[id].x = uvX;
      //   this.konvaConfig.points[id].y = uvY;
      //   this.points[id].x = uvX;
      //   this.points[id].y = uvY;
      //   this.resetDrawPloyline();
      // }
      this.curSelectCircleId = null;
    },

    // 绘制线条
    resetDrawPloyline: function () {
      // 画线前先清掉 重绘
      this.konvaConfig.polyline = [];
      const pointArr = [];
      for (let i = 0; i < this.konvaConfig.points.length; i++) {
        pointArr.push(
          this.konvaConfig.points[i].x,
          this.konvaConfig.points[i].y
        );
      }
      if (pointArr.length >= 4) {
        this.konvaConfig.polyline.push(pointArr);
        this.getTextPointsLoation(); // 满足绘制线时，即绘制线条距离文字
      }
    },

    // 计算绘制文字在哪个位置显示
    getTextPointsLoation: function (curPixelScale) {
      const points = this.konvaConfig.points;
      const len = points?.length;
      this.konvaConfig.textPointsLoation = [];
      // if (this.curFormationType === "line") {
      for (let i = 0; i < points.length - 1; i++) {
        const { x, y } = getCenter(points[i], points[i + 1]);
        let distance = getDistance(points[i], points[i + 1]);
        const realDistance = (
          distance * (curPixelScale || this.curPixelScale)
        )?.toFixed(2);
        distance = distance.toFixed(2);
        this.konvaConfig.textPointsLoation.push({
          xT: x - 15,
          yT: y + 10 * i,
          text: realDistance ? `${distance}px/${realDistance}m` : "",
        });
      }
      if (this.curFormationType !== "line" && len > 2) {
        // 有闭合且点两个以上
        const { x, y } = getCenter(points[0], points[len - 1]);
        let distance = getDistance(points[0], points[len - 1]);
        const realDistance = (
          distance * (curPixelScale || this.curPixelScale)
        )?.toFixed(2);
        distance = distance.toFixed(2);
        this.konvaConfig.textPointsLoation.push({
          xT: x - 15,
          yT: y + 10,
          text: realDistance ? `${distance}px/${realDistance}m` : "",
        });
      }
    },

    // 保存为模板
    saveFormation: async function () {
      const points = this.konvaConfig.points;
      if (this.saveFormations) {
        this.saveFormations(points);
      }
    },

    clearFormations: function () {
      this.konvaConfig.polyline = [];
      this.konvaConfig.points = [];
      this.points = [];
      this.konvaConfig.textPointsLoation = [];
    },
  },

  destroyed() {
    this.isShowSave = false;
  },
};
</script>

<style lang="scss">
@import "@/assets/css/common.scss";
.draw_formation {
  height: 100%;
  background-image: linear-gradient(
      to bottom,
      transparent 9px,
      rgb(241, 239, 239) 1px
    ),
    linear-gradient(to right, transparent 9px, rgb(242, 239, 239) 1px);
  background-size: 10px 10px;
  background-repeat: repeat;

  &_stage {
    height: 100%;
  }

  &_btn {
    position: absolute;
    right: 6px;
    top: 6px;
    animation: reFlash 2s infinite;
  }

  @keyframes reFlash {
    0% {
      border-color: #ffffff;
      box-shadow: 0 0 5px #04f725;
    }
    100% {
      border-color: #00ff33;
      box-shadow: 0 0 15px #f75307;
    }
  }
}
</style>
