<template>
  <div class="squared_btns" v-if="data.packages?.length > 0">
    <div
      class="icon_direction"
      v-for="(item, idx) in data.packages"
      :key="item.action + idx"
      @mousedown="onBtnMousedown(item)"
      @mouseup="onBtnMouseup(item)"
      @touchstart="onBtnTouchstart(item)"
      @touchend="onBtnTouchend(item)"
      @contextmenu.prevent
      :style="{
        backgroundColor:
          curClickBtn === `${item?.action}${data?.id}` ? bgColor : 'black',
      }"
    >
      <i
        :class="iconClass[idx]"
        :style="{
          color:
            curClickBtn === `${item?.action}${data?.id}`
              ? iconColor
              : 'darkturquoise',
        }"
        >{{ iconClass[idx] ? "" : "ok" }}</i
      >
    </div>
  </div>
</template>

<script>
import { triggerCmd } from "@/components/JsonSchema/triggerCmd";
export default {
  props: ["data"],
  data() {
    return {
      iconClass: [
        "el-icon-top-left",
        "el-icon-top",
        "el-icon-top-right",
        "el-icon-back",
        "",
        "el-icon-right",
        "el-icon-bottom-left",
        "el-icon-bottom",
        "el-icon-bottom-right",
      ],
      bgColor: "black",
      iconColor: "darkturquoise",
      curClickBtn: null,
    };
  },

  methods: {
    // 长按下发指令
    postEventTypeTriggerCmd: async function (item) {
      const { id, type } = this.data;
      const { action, eventType } = item;
      if (eventType === "press") {
        this.timeId = setInterval(async () => {
          if (action !== 99) {
            await triggerCmd(id, type, action);
          }
        }, 200);
      }
      if ((!eventType || eventType === "click") && action !== 99) {
        await triggerCmd(id, type, action);
      }
    },

    clearSetInterval: async function (item) {
      const { id, type } = this.data;
      const { action, eventType } = item;
      if (eventType === "press" && action !== 99) {
        if (this.timeId) {
          clearInterval(this.timeId);
          this.timeId = null;
        } // 结束后给小车发停止指令
        for (let i = 0; i < 3; i++) {
          await triggerCmd(id, type, action, null, { stop: 0 });
        }
      }
    },

    onBtnMousedown: async function (item) {
      this.pressStyle(true, item?.action, this.data?.id);
      await this.postEventTypeTriggerCmd(item);
    },
    onBtnMouseup: async function (item) {
      this.pressStyle();
      await this.clearSetInterval(item);
    },
    onBtnTouchstart: async function (item) {
      this.pressStyle(true, item?.action, this.data?.id);
      await this.postEventTypeTriggerCmd(item);
    },
    onBtnTouchend: async function (item) {
      this.pressStyle();
      await this.clearSetInterval(item);
    },

    pressStyle: function (isPress, action, id) {
      if (isPress) {
        this.curClickBtn = `${action}${id}`;
        this.bgColor = "#66b1ff";
        this.iconColor = "#fff";
      } else {
        this.curClickBtn = null;
        this.bgColor = "black";
        this.iconColor = "#darkturquoise";
      }
    },
  },

  destroyed() {
    if (this.timeId) {
      clearInterval(this.timeId);
      this.timeId = null;
    }
  },
};
</script>

<style lang="scss" scoped>
.squared_btns {
  width: 130px;
  height: 130px;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
}

.icon_direction {
  width: calc((100% - 8px - 12px) / 3);
  height: calc((100% - 8px - 12px) / 3);
  border: 1px solid #b98716;
  border-radius: 16%;
  display: flex;
  justify-content: center;
  align-items: center;

  i {
    font-size: 25px;
    height: 100%;
    width: 100%;
    text-align: center;
    line-height: 38px;
  }
}
</style>
