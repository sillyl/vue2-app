<template>
  <div class="select_task_behavior">
    <div class="select_task_behavior_txt">行为动作指令</div>
    <div class="select_task_behavior_content">
      <el-select
        v-model="action"
        value-key="method"
        placeholder="请选择动作"
        size="small"
        :class="[isCancel ? 'select_behavior' : 'el-select_default']"
        @change="onChangeSelect"
      >
        <el-option
          v-for="item in metaTaskList"
          :key="item.method"
          :label="item.name"
          :value="item"
        >
        </el-option>
      </el-select>
      <!-- 标注任务显示 -->
      <el-select
        v-model="target"
        placeholder="请选择目标物"
        v-if="action.method === 'TASK_MARK'"
        size="small"
        :class="[isCancel ? 'select_behavior' : 'el-select_default']"
      >
        <el-option
          v-for="item in identifierList"
          :key="item.code"
          :label="item.name"
          :value="item.code"
        ></el-option>
      </el-select>
      <el-button v-if="isCancel" size="small" @click="onClickCancel"
        >取消{{ action.name }}</el-button
      >
    </div>
  </div>
</template>

<script>
import { taskBehaviorsDefault, taskBehaviors } from "@/constants";
import { getSceneMetaTaskList } from "@/api/task";
import { getIdentifierList } from "@/api/identify";
import { enableMap } from "@/api/device";
export default {
  props: ["deviceId"],
  data() {
    return {
      target: "",
      action: "",
      identifierList: [],
      metaTaskList: [],
      isCancel: false,
      cancelTask: [],
    };
  },
  mounted() {
    this.getSceneMetaTaskList();
  },
  methods: {
    getSceneMetaTaskList: async function () {
      this.metaTaskList = await getSceneMetaTaskList({ type: 2 });
      this.action = this.metaTaskList?.[0];
      this.identifierList = await getIdentifierList();
      // code: 4 表示人
      const person = this.identifierList?.filter((i) => i?.code === "4");
      this.target = person?.length > 0 ? person?.[0].code : "";
    },

    onChangeSelect: function () {
      // controlAction === 1开启还未终止
      const arr = this.cancelTask.filter(
        (i) => i.method === this.action.method && i.controlAction === 1
      );
      if (arr?.length > 0) {
        this.isCancel = true;
      } else {
        this.isCancel = false;
      }
    },
    onClickCancel: async function () {
      // controlAction: 3 取消（终止）
      const params = {
        deviceId: this.deviceId,
        method: this.action.method,
        params: {
          controlAction: 3,
        },
        cache: "0",
        response: "1",
        expired: 100,
        streamType: 0,
      };
      await enableMap(params);
      this.isCancel = false;
      const res = this.cancelTask.map((i) => {
        if (i.method === this.action.method) {
          return { ...i, controlAction: 3 };
        }
        return { ...i };
      });
      this.cancelTask = res;
    },
  },

  destroyed() {
    this.target = "";
    this.action = "";
    this.identifierList = [];
    this.metaTaskList = [];
    this.isCancel = false;
    this.cancelTask = [];
  },
};
</script>

<style lang="scss" scoped>
@import "@/assets/css/common.scss";
.select_task_behavior {
  display: flex;
  max-width: 448px;
  margin-top: 8px;

  &_txt {
    line-height: 32px;
    font-size: 16px;
  }
  &_content {
    padding-left: 8px;
    flex: 1;

    .el-select_default {
      width: 40%;
    }

    .select_behavior {
      width: 35%;
    }

    .el-button {
      padding: 9px 6px;
    }
  }
}
</style>
