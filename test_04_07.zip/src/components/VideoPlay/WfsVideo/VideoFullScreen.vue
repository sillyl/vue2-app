<template>
  <div class="video_player_wfs_content" :id="'video_player_wfs_content_' + id">
    <video
      :id="id"
      muted
      autoplay
      crossOrigin="anonymous"
      @dblclick="ondbClickVideo($event, id)"
    >
      <!-- @loadedmetadata="onLoadedMetaData(id)" -->
      你的浏览器不支持 video 标签
    </video>
    <i
      v-if="isShowFull"
      :class="[isFullScreen ? 'icon-shrink' : 'icon-enlarge']"
      @click="onIsFull()"
    />
    <el-dialog
      title="是否确认标记?"
      :visible.sync="dialogVisible"
      width="25%"
      :modal-append-to-body="false"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <span slot="footer" class="dialog-footer">
        <el-button @click="onCancel">取 消</el-button>
        <el-button type="primary" @click="onSysOk">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { isEmpty } from "lodash";
import { tasksMethods } from "@/views/Task/constants.js";
import dayjs from "dayjs";
import { localStorageGetItem } from "@/utils/localStorageFun.js";
import { addTask } from "@/api/task.js";
export default {
  // id格式 video+deviceId+index
  props: [
    "id",
    "isFullScreen",
    "onIsFullScreen",
    "isFull",
    "curBehavior",
    "getCurBehaviorData",
  ],
  data() {
    return {
      isShowFull: this.isFull || true,
      dialogVisible: false,
      taskMarkParams: {},
    };
  },

  methods: {
    onIsFull: function () {
      if (this.onIsFullScreen) {
        this.onIsFullScreen();
      }
    },

    ondbClickVideo: async function (e, id) {
      const { offsetX, offsetY } = e;
      const dom = document.getElementById(id);
      const { width, height } = dom.getBoundingClientRect();
      const u = offsetX / width;
      const v = offsetY / height;
      const idx = id?.indexOf("-") || 6;
      const deviceId = id.slice(5, idx);

      let curBehaviorData = {};
      // controlAction: 1 执行
      let params = {
        params: { uv: { u, v }, controlAction: 1 },
      };

      if (this.getCurBehaviorData) {
        curBehaviorData = this.getCurBehaviorData();
        const defaultScenceItem = localStorageGetItem("defaultScenceItem");
        if (!isEmpty(curBehaviorData)) {
          const { action, target, scenceId, deviceIds } = curBehaviorData;
          switch (action) {
            case "TASK_GRAB": {
              // 抓取
              params = {
                ...params,
                name:
                  tasksMethods[action] +
                  dayjs(new Date().getTime()).format("YYYYMMDDHHmmss"),
                method: action,
                scenceId: scenceId || defaultScenceItem?.id,
                deviceIds: [deviceId],
              };
              await this.addChildTask(params, "抓取");
              break;
            }
            case "TASK_STRIKE": {
              // 打击
              params = {
                ...params,
                name:
                  tasksMethods[action] +
                  dayjs(new Date().getTime()).format("YYYYMMDDHHmmss"),
                method: action,
                scenceId: scenceId || defaultScenceItem?.id,
                deviceIds: [deviceId],
              };
              await this.addChildTask(params, "打击");
              break;
            }
            case "TASK_FOLLOW": {
              // 跟随
              params = {
                ...params,
                name:
                  tasksMethods[action] +
                  dayjs(new Date().getTime()).format("YYYYMMDDHHmmss"),
                method: action,
                scenceId: scenceId || defaultScenceItem?.id,
                deviceIds: [deviceId],
              };
              await this.addChildTask(params, "跟随");
              break;
            }
            case "TASK_TRACKING": {
              // 锁定
              params = {
                ...params,
                name:
                  tasksMethods[action] +
                  dayjs(new Date().getTime()).format("YYYYMMDDHHmmss"),
                method: action,
                scenceId: scenceId || defaultScenceItem?.id,
                deviceIds: [deviceId],
              };
              await this.addChildTask(params, "锁定");
              break;
            }
            case "TASK_MARK": {
              // 标注
              this.dialogVisible = true;
              this.taskMarkParams = params = {
                name:
                  tasksMethods[action] +
                  dayjs(new Date().getTime()).format("YYYYMMDDHHmmss"),
                method: action,
                scenceId: scenceId || defaultScenceItem?.id,
                params: {
                  ...params?.params,
                  targetCode: target,
                },
                deviceIds: [deviceId],
              };
              break;
            }
          }
        }
      }
    },

    addChildTask: async function (params, name) {
      const { method } = params;
      if (method) {
        try {
          await addTask(params);
          this.$message({
            type: "success",
            message: `${name}成功!`,
          });
        } catch (error) {
          throw error;
        }
      }
    },

    onCancel: function () {
      this.dialogVisible = false;
    },
    async onSysOk() {
      this.dialogVisible = false;
      await this.addChildTask(this.taskMarkParams, "标记");
    },
  },
};
</script>
<style lang="scss" scoped>
.video_player_wfs_content {
  background: rgb(54, 54, 54);
  height: calc(100% - 32px);
  video {
    width: 100%;
    height: 100%;
    object-fit: fill;
  }
  i {
    bottom: 10px;
    position: absolute;
    right: 8px;
    color: #ccc;
    font-size: 20px;
  }
  ::v-deep {
    .el-dialog__title {
      line-height: 14px;
      font-size: 16px;
    }
    .el-dialog__body {
      padding: 10px 20px;
    }
  }

  .dialog-footer {
    .el-button {
      padding: 8px 8px;
      font-size: 12px;
    }
  }
}
</style>
