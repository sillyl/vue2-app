<template>
  <canvas
    :width="canvasW"
    :height="canvasH"
    :id="ctxId"
    @touchstart.stop.prevent="onCvsTouchStart"
    @touchend="onCvsTouchEnd"
    @mousedown="onCvsmousedown"
    @mouseup="onCvsmouseup"
    @contextmenu.prevent
  ></canvas>
</template>
<script>
/*
  当且仅当三个按钮时，即arr 长度为3时，默认设定扇形三个，中心点击不做任何处理
  目前内置支持扇形2-5个，加中心最多六个按钮
*/

import { getFθ } from "@/utils/CoordinatePickupFun";
import { triggerCmd } from "@/components/JsonSchema/triggerCmd";
export default {
  props: [
    "id",
    "num",
    "canvasWidth",
    "canvasHeight",
    "isCore",
    "centerR",
    "arr",
    "bgColor",
    "clickBgColor",
    "fontColor",
    "data",
  ],
  data() {
    return {
      ctxId: this.id || "ctx",
      ctx: null,
      nums: this.arr?.length - 1 || 5,
      canvasW: this.canvasWidth || 140,
      canvasH: this.canvasHeight || 140,
      roundRadius: this.centerR || 50, // 中心圆半径
      arrs: [],
      childData: null, // 统一暴露子组件数据 给父组件点击计算使用
      bgCor: this.bgColor || "#E0FFFF",
      clickBgCor: this.clickBgColor || "#409EFF",
      fontCor: this.fontColor || "#000000",
      timeId: null,
      curBtnObj: {},
      radθ: 0,
      θ: 0,
      coreX: null,
      coreY: null,
      radiusM: null,
      start: null,
      end: null,
      curNum: 0,
      rad: null,
    };
  },
  mounted() {
    this.onDraw();
  },
  methods: {
    onDraw: async function () {
      const canvas = document.querySelector(`#${this.ctxId}`);
      this.ctx = canvas.getContext("2d");
      this.curNum =
        this.arr?.length === 3 || this.arr?.length === 4
          ? this.nums + 1
          : this.nums; //圆弧的份数
      //一个圆弧对应的弧度
      this.rad = (Math.PI * 2) / this.curNum;
      this.radθ = this.rad * (180 / Math.PI); // 角度
      this.coreX = this.canvasW / 2; // 圆心坐标
      this.coreY = this.canvasH / 2;
      this.radiusM = this.canvasW / 2.1; // 扇形（大圆）半径
      this.roundRadius = this.coreX / 2.5; // 小圆半径
      this.θ = 360 / this.curNum / 2; // 需要旋转多少角度
      const radDiff = (Math.PI / 180) * this.θ;
      this.start = radDiff - this.rad * 2;
      this.end = this.rad + radDiff - this.rad * 2;
      this.ctx.translate(this.coreX, this.coreY); // 将中心调整到圆心
      let txtPostion = (this.coreX + this.roundRadius) / 2;
      await this.updateArrs(txtPostion, this.roundRadius);
      this.paintP();
      if (!this.isCore) {
        // 不传默认展示
        this.paintCircle();
      }
    },
    updateArrs: function (txtPostion) {
      let locations = [
        // 默认四个扇形
        { x: 0, y: -txtPostion }, // 0
        { x: txtPostion, y: 0 }, // 1
        { x: 0, y: txtPostion }, // 2
        { x: -txtPostion, y: 0 }, // 3
      ];

      if (this.arr?.length === 3) {
        locations = [
          { x: -txtPostion / 1.6, y: -txtPostion / 1.3 }, // 1
          { x: txtPostion / 1.01, y: 0 }, // 2
          { x: -txtPostion / 1.6, y: txtPostion / 1.3 }, // 0
        ];
      }
      if (this.nums === 5) {
        locations = [
          { x: 8, y: -(txtPostion / 1.2) }, // 3
          { x: txtPostion / 1.1, y: 0 }, // 4
          { x: 8, y: txtPostion / 1.2 }, // 0
          { x: -txtPostion / 1.2, y: txtPostion / 1.8 }, // 1
          { x: -txtPostion / 1.2, y: -(txtPostion / 2) }, // 2
        ];
      }
      this.arrs = (this.arr || [])?.map((i, idx) => {
        return { ...i, ...locations[idx] };
      });
    },
    paintP: function (index) {
      for (let i = 0; i < this.curNum; i++) {
        const text = this.arrs?.[i]?.name;
        const x = this.arrs?.[i]?.x;
        const y = this.arrs?.[i]?.y;
        this.ctx.save();
        this.ctx.beginPath();
        this.ctx.moveTo(0, 0);
        this.ctx.arc(0, 0, this.radiusM, this.start, this.end);
        this.ctx.closePath();
        this.ctx.fillStyle = this.bgCor; // 填充整体背景颜色
        this.ctx.stroke();
        this.ctx.fill();
        this.ctx.closePath();
        this.ctx.beginPath();
        this.ctx.textAlign = "center";
        this.ctx.textBaseline = "middle";
        this.ctx.font = "12px scans-serif";
        this.ctx.fillStyle = this.fontCor; // 字体颜色
        this.ctx.fillText(text, x, y);
        this.ctx.restore();
        this.start = this.end;
        this.end = this.end + this.rad;
      }
      if (index === 0 || index) {
        this.paintCircle();
      }
    },
    paintCircle: function () {
      this.ctx.beginPath();
      this.ctx.arc(0, 0, this.roundRadius, 0, Math.PI * 2, true);
      this.ctx.fillStyle = this.bgCor;
      this.ctx.stroke();
      this.ctx.fill();
      this.ctx.closePath();
      this.ctx.beginPath();
      this.ctx.font = "12px scans-serif";
      this.ctx.textAlign = "center";
      this.ctx.textBaseline = "middle";
      this.ctx.fillStyle = this.fontCor; // 字体颜色
      if (
        this.arr?.length &&
        !(this.arr?.length === 3 || this?.arr?.length == 4)
      ) {
        this.ctx.fillText(this.arrs[this.arrs.length - 1]?.name, 0, 0);
      }
      this.ctx.restore();
    },

    redrawPaintP: function (index) {
      for (let i = 0; i < this.curNum; i++) {
        const text = this.arrs?.[i]?.name;
        const x = this.arrs?.[i]?.x;
        const y = this.arrs?.[i]?.y;
        this.ctx.save();
        this.ctx.beginPath();
        this.ctx.moveTo(0, 0);
        this.ctx.arc(0, 0, this.radiusM, this.start, this.end);
        this.ctx.closePath();
        if (index === i) {
          this.ctx.fillStyle = this.clickBgCor;
        } else {
          this.ctx.fillStyle = this.bgCor;
        }
        this.ctx.stroke();
        this.ctx.fill();
        this.ctx.closePath(); // 上一个形成闭合，否则影响下一个开始
        this.ctx.beginPath();
        this.ctx.textAlign = "center";
        this.ctx.textBaseline = "middle";
        this.ctx.font = "12px scans-serif";
        this.ctx.fillStyle = this.fontCor; // 字体颜色
        this.ctx.fillText(text, x, y);
        this.ctx.restore();
        this.start = this.end;
        this.end = this.end + this.rad;
      }
      this.paintCircle(); // 保证中心圆是是最后一个绘制（重要必须！！！）
    },

    redrawPaintCircle: function () {
      this.ctx.save();
      this.ctx.beginPath();
      this.ctx.arc(0, 0, this.roundRadius, 0, Math.PI * 2, true);
      this.ctx.stroke();
      this.ctx.fillStyle = this.clickBgCor;
      this.ctx.fill();
      this.ctx.closePath();
      this.ctx.beginPath();
      this.ctx.font = "12px scans-serif";
      this.ctx.textAlign = "center";
      this.ctx.textBaseline = "middle";
      this.ctx.fillStyle = this.fontCor; // 字体颜色
      if (this?.arr?.length !== 3 || this?.arr?.length !== 4) {
        this.ctx.fillText(this.arrs[this.arrs.length - 1]?.name, 0, 0);
      }
      this.ctx.restore();
    },

    postTriggerCmd: async function (id, type, action, index) {
      if (action !== 99) {
        try {
          this.redrawPaintP(index);
          await triggerCmd(id, type, action);
        } catch (error) {
          throw error;
        } finally {
          this.paintP(index);
        }
      }
    },

    // 长按下发指令
    postContinueTriggerCmd: async function (id, type, action, index) {
      this.timeId = setInterval(async () => {
        if (action !== 99) {
          try {
            if (this.timeId) {
              this.redrawPaintP(index);
            }
            await triggerCmd(id, type, action);
          } catch (error) {
            this.paintP(index);
            throw error;
          }
        }
      }, 200);
    },

    onCvsmousedown: async function (e) {
      const canvas = document.querySelector(`#${this.ctxId}`);
      const x = e.layerX - canvas.offsetLeft; //获取点击后x的坐标
      const y = e.layerY - canvas.offsetTop; //获取点击后y的坐标
      this.partCvsEvent(x, y);
    },

    onCvsmouseup: async function () {
      const { eventType, id, type, action, index } = this.curBtnObj;
      if (eventType === "press" && action !== 99) {
        if (this.timeId) {
          clearInterval(this.timeId);
          this.timeId = null;
          this.paintP(index);
        } // 结束后给小车发停止指令
        for (let i = 0; i < 3; i++) {
          await triggerCmd(id, type, action, null, { stop: 0 });
        }
      }
    },

    onCvsTouchStart: async function (e) {
      const canvas = document.querySelector(`#${this.ctxId}`);
      const touch = e.touches[0];
      const { top, left } = canvas.getBoundingClientRect();
      const x = touch.pageX - left; //获取点击后x的坐标
      const y = touch.pageY - top; //获取点击后y的坐标
      this.partCvsEvent(x, y);
    },
    onCvsTouchEnd: async function () {
      const { eventType, id, type, action, index } = this.curBtnObj;
      if (eventType === "press" && action !== 99) {
        if (this.timeId) {
          clearInterval(this.timeId);
          this.timeId = null;
          this.paintP(index);
        } // 结束后给小车发停止指令
        for (let i = 0; i < 3; i++) {
          await triggerCmd(id, type, action, null, { stop: 0 });
        }
      }
    },

    partCvsEvent: async function (x, y) {
      const angleA = getFθ({ x: this.coreX, y: this.coreY }, { x, y }); // 点击位置在坐标系中的角度
      let angle = this.θ + this.radθ * 1;
      const curR =
        Math.pow(x - this.coreX, 2) + Math.pow(y - this.coreY, 2) <
        Math.pow(this.roundRadius, 2);
      const { type, id, eventType } = this.data;
      if (curR) {
        const obj = this.arr?.[this.arr?.length - 1];
        if (!(this.arr?.length === 3 || this?.arr?.length == 4)) {
          try {
            this.paintP();
            this.redrawPaintCircle();
            console.log("在中心圆中", obj);
            this.curBtnObj = {
              eventType,
              id,
              type,
              action: obj?.action,
            };
            await this.postCmdApi(eventType, id, type, obj?.action);
          } catch (error) {
            throw error;
          } finally {
            this.paintCircle();
          }
        }
        return;
      }
      const curClickPointR =
        Math.pow(x - this.coreX, 2) + Math.pow(y - this.coreY, 2) <
        Math.pow(this.radiusM, 2); // 确保点击在大圆内触发事件
      if (curClickPointR) {
        const arrData = this.arr;
        if (this.nums === 1) {
          console.log("在外圆中", arrData[0]);
          this.curBtnObj = {
            eventType,
            id,
            type,
            action: arrData[0]?.action,
            index: 0,
          };
          await this.postCmdApi(eventType, id, type, arrData[0]?.action, 0);
        }

        if (this.nums === 2) {
          console.log("在外圆中", arrData[0]);
          this.curBtnObj = {
            eventType,
            id,
            type,
            action: arrData[0]?.action,
            index: 0,
          };
          await this.postCmdApi(eventType, id, type, arrData[0]?.action, 0);
        }

        if (this.arr?.length === 3) {
          if (-angle < angleA && angleA <= -angle + this.radθ) {
            console.log("在扇形0内", arrData[0]);
            this.curBtnObj = {
              eventType,
              id,
              type,
              action: arrData[0]?.action,
              index: 0,
            };
            await this.postCmdApi(eventType, id, type, arrData[0]?.action, 0);
            return;
          }
          if (-angle + this.radθ < angleA && angleA < this.θ) {
            console.log("在扇形1内", arrData[1]);
            this.curBtnObj = {
              eventType,
              id,
              type,
              action: arrData[1]?.action,
              index: 1,
            };
            await this.postCmdApi(eventType, id, type, arrData[1]?.action, 1);
            return;
          }

          if (this.θ < angleA && angleA < angle) {
            console.log("在扇形2内", arrData[2]);
            this.curBtnObj = {
              eventType,
              id,
              type,
              action: arrData[2]?.action,
              index: 2,
            };
            await this.postCmdApi(eventType, id, type, arrData[2]?.action, 2);
            return;
          }
        }

        if (this.arr?.length === 4 || this.nums === 4) {
          if (-angle < angleA && angleA < -this.θ) {
            this.curBtnObj = {
              eventType,
              id,
              type,
              action: arrData[0]?.action,
              index: 0,
            };
            await this.postCmdApi(eventType, id, type, arrData[0]?.action, 0);
            return;
          }
          if (-this.θ < angleA && angleA < this.θ) {
            console.log("在扇形1内", arrData[1]);
            this.curBtnObj = {
              eventType,
              id,
              type,
              action: arrData[1]?.action,
              index: 1,
            };
            await this.postCmdApi(eventType, id, type, arrData[1]?.action, 1);
            return;
          }
          if (this.θ < angleA && angleA < angle) {
            console.log("在扇形2内4", angleA, arrData[2]);
            this.curBtnObj = {
              eventType,
              id,
              type,
              action: arrData[2]?.action,
              index: 2,
            };
            await this.postCmdApi(eventType, id, type, arrData[2]?.action, 2);
            return;
          }
          if (
            (angle < angleA && angleA <= 180) ||
            (-180 < angleA && angleA < -angle)
          ) {
            console.log("在扇形3内", arrData[3]);
            this.curBtnObj = {
              eventType,
              id,
              type,
              action: arrData[3]?.action,
              index: 3,
            };
            await this.postCmdApi(eventType, id, type, arrData[3]?.action, 3);
            return;
          }
        }

        if (this.nums === 5) {
          if (-180 + this.radθ < angleA && angleA < -180 + this.radθ * 2) {
            console.log("在扇形0内", arrData[0]);
            this.curBtnObj = {
              eventType,
              id,
              type,
              action: arrData[0]?.action,
              index: 0,
            };
            await this.postCmdApi(eventType, id, type, arrData[0]?.action, 0);
            return;
          }

          if (-angle + this.radθ < angleA && angleA < this.θ) {
            console.log("在扇形1内", arrData[1]);
            this.curBtnObj = {
              eventType,
              id,
              type,
              action: arrData[1]?.action,
              index: 1,
            };
            await this.postCmdApi(eventType, id, type, arrData[1]?.action, 1);
            return;
          }

          if (this.θ < angleA && angleA < angle) {
            console.log("在扇形2内5", arrData[2]);
            this.curBtnObj = {
              eventType,
              id,
              type,
              action: arrData[2]?.action,
              index: 2,
            };
            await this.postCmdApi(eventType, id, type, arrData[2]?.action, 2);
            return;
          }

          if (angle < angleA && angleA <= angle + this.radθ) {
            console.log("在扇形3内5", arrData[3]);
            this.curBtnObj = {
              eventType,
              id,
              type,
              action: arrData[3]?.action,
              index: 3,
            };
            await this.postCmdApi(eventType, id, type, arrData[3]?.action, 3);
            return;
          }

          if (-180 < angleA && angleA <= -180 + this.radθ) {
            console.log("在扇形4内", arrData[4]);
            this.curBtnObj = {
              eventType,
              id,
              type,
              action: arrData[4]?.action,
              index: 4,
            };
            await this.postCmdApi(eventType, id, type, arrData[4]?.action, 4);
            return;
          }
        }
      }
    },

    postCmdApi: async function (eventType, id, type, action, index) {
      if (eventType === "press") {
        await this.postContinueTriggerCmd(id, type, action, index);
      }
      if (!eventType || eventType === "click") {
        await this.postTriggerCmd(id, type, action, index);
      }
    },
  },

  destroyed() {
    if (this.timeId) {
      clearInterval(this.timeId);
      this.timeId = null;
    }
  },
};
</script>
<style lang="scss" scoped></style>
