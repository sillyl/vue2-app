<template>
  <div class="button_group_content">
    <div
      class="button_group_content_btns"
      v-for="(i, idx) in data.group"
      :key="(i.groupId || i.id) + idx"
    >
      <el-row>
        <el-col :span="i.name ? 9 : 0" v-if="i.name">
          <span class="controls_p_name button_group_content_name"
            >{{ i.name }}
          </span>
        </el-col>
        <el-col
          :span="i.name ? 15 : 24"
          :class="[
            'button_group_content_btn',
            !i.name && 'button_group_content_btn_not_name',
          ]"
        >
          <el-col
            :span="!i.name ? 8 : 12"
            v-for="k in i.packages"
            :key="k.action"
            class="button_group_content_btn_row"
          >
            <el-button
              type="primary"
              @mousedown.native.prevent="onBtnMousedown(i, k)"
              @mouseup.native.prevent="onBtnMouseup(i, k)"
              @touchstart.native.prevent="onBtnTouchstart(i, k)"
              @touchend.native.prevent="onBtnTouchend(i, k)"
              >{{ k.name }}
            </el-button>
          </el-col>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
import { triggerCmd } from "@/components/JsonSchema/triggerCmd";
export default {
  props: ["data"],
  data() {
    return {
      timeId: null,
    };
  },

  methods: {
    // 长按下发指令
    postEventTypeTriggerCmd: async function (data, item) {
      const { type, id } = data;
      const { action, eventType } = item;
      if (eventType === "press") {
        this.timeId = setInterval(async () => {
          if (action !== 99) {
            await triggerCmd(id, type, action);
          }
        }, 200);
      }
      if ((!eventType || eventType === "click") && action !== 99) {
        await triggerCmd(id, type, action);
      }
    },

    clearSetInterval: async function (data, item) {
      const { type, id } = data;
      const { action, eventType } = item;
      if (eventType === "press" && action !== 99) {
        if (this.timeId) {
          clearInterval(this.timeId);
          this.timeId = null;
        } // 结束后给小车发停止指令
        for (let i = 0; i < 3; i++) {
          await triggerCmd(id, type, action, null, { stop: 0 });
        }
      }
    },

    onBtnMousedown: async function (data, item) {
      await this.postEventTypeTriggerCmd(data, item);
    },
    onBtnMouseup: async function (data, item) {
      await this.clearSetInterval(data, item);
    },
    onBtnTouchstart: async function (data, item) {
      await this.postEventTypeTriggerCmd(data, item);
    },
    onBtnTouchend: async function (data, item) {
      await this.clearSetInterval(data, item);
    },
  },

  destroyed() {
    if (this.timeId) {
      clearInterval(this.timeId);
      this.timeId = null;
    }
  },
};
</script>

<style lang="scss" scoped>
.button_group_content {
  &_name {
    line-height: 40px;
  }

  &_btn {
    .el-button + .el-button {
      margin-left: 0px;
    }

    .el-button {
      margin-right: 10px;
      margin-bottom: 4px;
      padding: 8.9px 12px;
      margin-top: 4px;
    }

    &_not_name {
      padding-left: 8px;
    }

    &_row {
      display: flex;
      justify-content: center;
    }
  }
}
</style>
