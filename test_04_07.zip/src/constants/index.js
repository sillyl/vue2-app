export const STATUS_CODE = {
  UNAUTHENTICATED: 401,
  SUCCESS: 0,
  NOTFOUND: 100609, // NOT_FOUND_RESOURCE
};

export const fileTypeList = ["png", "jpg", "pgm"];

export const cmdMethods = ["GET_INFO", "EmergencyStop"];

export const cmdStatus = [
  "PENDING",
  "SUCCESS",
  "FAILED",
  "TIMEOUT",
  "DELIVERED", // 交付
];

export const alertTyleList = [{ 0: "低电量" }, { 1: "故障" }, { 2: "异常" }];

export const alertLevel = ["紧急", "严重", "警告", "一般"];
// 紧急、严重、警告、一般和信息

export const alertModule = ["移动底盘", "机械臂", "NUC"];

export const subscribeOpts = {
  add: "添加订阅",
  edit: "编辑订阅",
  info: "订阅详情",
};

// 告警类型
export const alarmType = {
  0: "通知",
  1: "告警",
  2: "错误",
};

// 告警类型筛选下拉
export const alarmTypeFilters = [
  { text: "通知", value: "0" },
  { text: "告警", value: "1" },
  { text: "错误", value: "2" },
];

// 告警类型 tag
export const alarmTypeTag = {
  0: "info",
  1: "warning",
  2: "danger",
};

// 告警状态
export const alarmStatus = {
  0: "未处理",
  1: "忽略",
  2: "已处理",
};

export const alarmStatusColor = {
  0: "#66CDAA",
  1: "#D3D3D3",
  2: "#00BFFF",
};

export const alarmStatusFilters = [
  { text: "未处理", value: 0 },
  { text: "忽略", value: 1 },
  { text: "已处理", value: 2 },
];

//  消息类型
export const eventType = {
  0: "机器人状态（含工作状态、定位状态、位置信息）",
  1: "节点状态",
  2: "传感器状态",
  3: "任务事件(task_main_report)",
  4: "告警事件",
  5: "注册消息",
  6: "心跳消息 ",
  7: "机器人通用应答",
  8: "摆臂当前角度",
  9: "指令事件(cmd_main_report)",
  10: "查询数据库响应消息",
};

export const directionCtrl = {
  up: 1,
  down: 2,
  left: 3,
  right: 4,
};
