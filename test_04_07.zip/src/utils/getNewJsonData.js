// 1. 处理数据filter出groupId相同的组；2.各个组件所需数据结构; 3.通过小组件反计算 左右展示的组件数量
import { isEmpty } from "lodash";
export const getNewJsonData = (data) => {
  let arr = [];
  // groupId 仅作为分组类型， id 标识，不做分组
  for (let i of data) {
    if (i?.groupId) {
      const filterArr = arr.filter((k) => i?.groupId === k?.groupId);
      if (isEmpty(filterArr)) {
        arr.push({
          groupId: i?.groupId,
          groupName: i?.groupName,
          group: [{ ...i }],
        });
      } else {
        const index = arr.findIndex((k) => i?.groupId === k?.groupId);
        arr[index]?.group.push(i);
      }
    }
    if (!i?.groupId && i?.id) {
      arr.push({
        id: i?.id,
        groupName: i?.groupName,
        group: [{ ...i }],
      });
    }
    if (i?.split) {
      arr.push({ ...i });
    }
  }
  return [...arr]; // 适合前端渲染的元数据
};
