export const donwloadFile = (response, fileName) => {
  const fileReader = new FileReader();
  let name = fileName;
  if (response.headers["content-disposition"]) {
    name = decodeURI(
      response.headers["content-disposition"]
        .split(";")[1]
        .split("filename=")[1]
    );
  }

  fileReader.onload = () => {
    const blob = new Blob([response.data], {
      type: response?.data?.type,
    });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", name ?? fileName);
    document.body.appendChild(link);
    link.click();
    URL.revokeObjectURL(link.href);
    document.body.removeChild(link);
  };
  fileReader.readAsText(response.data);
};
