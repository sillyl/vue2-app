import { axiosWarpInstance } from "@/utils/axiosInstance.js";

export const getSenceMenuList = async () => {
  const res = await axiosWarpInstance(
    "/cpix/v1.0/configure/scence/consumer/menu/list",
    {},
    { type: "GET" }
  );
  return res;
};

export const getSceneDetail = async (data) => {
  const res = axiosWarpInstance(
    `/cpix/v1.0/configure/scence/common/detail/${data.id}`,
    {},
    {
      type: "GET",
    }
  );
  return res;
};

export const getSenceList = async (data) => {
  let url = `/cpix/v1.0/configure/scence/consumer/list?status=All`;
  if (data) {
    const { status } = data;
    if (status === "Open" || status == "Close") {
      url = `/cpix/v1.0/configure/scence/consumer/list?status=${status}`;
    }
  }
  const res = await axiosWarpInstance(url, data, { type: "GET" });
  return res;
};

// 场景信息？ 原交互在任务详情调取。。。。
export const getSceneInfo = async (data) => {
  const res = axiosWarpInstance(
    `/cpix/v1.0/configure/scence/common/info/${data.id}`,
    {},
    {
      type: "GET",
    }
  );
  return res;
};

// 编辑场景 拿的场景信息接口.......
export const getSceneDeviceInfo = async (data) => {
  const res = axiosWarpInstance(
    `/cpix/v1.0/configure/device/common/info/${data.id}`,
    {},
    {
      type: "GET",
    }
  );
  return res;
};

// 更新scene
export const updateScene = async (data) => {
  const res = axiosWarpInstance(
    "/cpix/v1.0/configure/scence/consumer/update",
    data,
    { type: "post" }
  );
  return res;
};
