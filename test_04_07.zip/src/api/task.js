import { axiosWarpInstance } from "@/utils/axiosInstance.js";

export const getSceneMetaTaskList = (data) => {
  let url = "/cpix/v1.0/configure/scencemetatask/common/all/list";
  if (data && data.type && data.type !== -1) {
    url = `/cpix/v1.0/configure/scencemetatask/common/all/list?type=${data.type}`;
  }
  const res = axiosWarpInstance(url, {}, { type: "get" });
  return res;
};

// 任务信息
export const getTaskInfo = async (data) => {
  const res = await axiosWarpInstance(
    `/cpix/v1.0/configure/scencetask/consumer/info/${data.id}`,
    {},
    { type: "get" }
  );
  return res;
};

// 场景下任务信息
export const getTaskDetail = async (data) => {
  const res = await axiosWarpInstance(
    `/cpix/v1.0/configure/scencetask/consumer/detail/${data.id}`,
    {},
    { type: "get" }
  );
  return res;
};

// 在线任务 list
export const getOnlineTaskList = (data) => {
  const res = axiosWarpInstance(
    `/cpix/v1.0/configure/scencetask/common/online/list`,
    data,
    { type: "get" }
  );
  return res;
};

// 历史任务
export const getHistoryTaskList = (data) => {
  const res = axiosWarpInstance(
    `/cpix/v1.0/configure/scencetask/common/history/list`,
    data,
    { type: "get" }
  );
  return res;
};

// 启动or暂停or终止（cancel）
export const executeTask = async (data) => {
  const res = await axiosWarpInstance(
    "/cpix/v1.0/configure/scencetask/consumer/execute",
    data,
    { type: "post" }
  );
  return res;
};

// 创建
export const addTask = async (data) => {
  const res = await axiosWarpInstance(
    "cpix/v1.0/configure/scencetask/consumer/add",
    data,
    {
      type: "post",
    }
  );
  return res;
};

// 更新
export const updataTask = async (data) => {
  const res = await axiosWarpInstance(
    "/cpix/v1.0/configure/scencetask/consumer/update",
    data,
    {
      type: "post",
    }
  );
  return res;
};

// 克隆
export const cloneTask = async (data) => {
  const res = await axiosWarpInstance(
    "/cpix/v1.0/configure/scencetask/consumer/clone",
    data,
    {
      type: "get",
    }
  );
  return res;
};

// 删除
export const deleteTask = async (data) => {
  const res = await axiosWarpInstance(
    `/cpix/v1.0/configure/scencetask/consumer/delete/${data.id}`,
    {},
    {
      type: "delete",
    }
  );
  return res;
};

// 路径安全检查
export const pathSecurityCheck = (data) => {
  const res = axiosWarpInstance(
    "/cpix/v1.0/configure/scencetask/common/path/check",
    data,
    {
      type: "get",
    }
  );
  return res;
};

// 获取自定义队形
export const getFormationList = () => {
  // type: -1 全查询，不带接口报错
  const res = axiosWarpInstance(
    "/cpix/v1.0/configure/team/consumer/list",
    { type: -1 },
    { type: "get" }
  );
  return res;
};

// 编队 保存自定义队形
export const saveFormation = (data) => {
  const res = axiosWarpInstance(
    "/cpix/v1.0/configure/team/consumer/add",
    data,
    {
      type: "post",
    }
  );
  return res;
};
