<template>
  <el-form :inline="true" :model="formInline">
    <el-form-item label="指令方法" prop="method" class="cmd_form_item">
      <el-select v-model="formInline.method" placeholder="请选择" clearable>
        <el-option
          v-for="item in cmdMethods"
          :key="item"
          :label="item"
          :value="item"
        ></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="指令状态" prop="status" class="cmd_form_item">
      <el-select v-model="formInline.status" placeholder="请选择" clearable>
        <el-option
          v-for="item in cmdStatus"
          :key="item"
          :label="item"
          :value="item"
        ></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="时间区间" class="cmd_form_item_time">
      <el-date-picker
        v-model="formInline.selectTime"
        type="datetimerange"
        range-separator="至"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        style="width: 100%"
      >
      </el-date-picker>
    </el-form-item>
    <el-form-item label="指令ID" prop="id" class="cmd_form_item">
      <el-input
        v-model="formInline.id"
        placeholder="请输入"
        clearable
      ></el-input>
    </el-form-item>
    <el-button type="primary" @click="onSubmit">查询</el-button>
  </el-form>
</template>

<script>
import { cmdMethods, cmdStatus } from "@/constants";
export default {
  props: ["onSearchFun"],
  data() {
    return {
      formInline: {
        id: "",
        method: "",
        status: "",
        selectTime: [
          new Date() - 7 * 24 * 60 * 60 * 1000,
          new Date().getTime(),
        ], // 默认前一周时间, 统一ms级别时间戳
      },
      cmdMethods,
      cmdStatus,
    };
  },
  methods: {
    onSubmit() {
      if (this.onSearchFun) {
        this.onSearchFun();
      }
    },
  },
};
</script>

<style lang="scss" scoped></style>
