<template>
  <div class="robot-body">
    <HeaderMenu ref="headerMenuRef" />
    <Content :getNewMenuMapList="getNewMenuMapList" />
  </div>
</template>
<script>
import HeaderMenu from "./HeaderMenu/Index.vue";
import Content from "./Content/Index.vue";
export default {
  components: {
    HeaderMenu,
    Content,
  },
  mounted() {
    document.addEventListener("keydown", this.listenEsc);
    document.addEventListener("fullscreenchange", (event) => {
      if (document.fullscreenElement) {
        this.$store.commit("updateSysFull", false);
      } else {
        this.$store.commit("updateSysFull", true);
        // if (this.$refs.headerMenuRef) {
        //   this.$refs.headerMenuRef.closeSysDialog();
        // }
      }
    });
  },
  methods: {
    getNewMenuMapList: function () {
      this.$refs.headerMenuRef?.getMapList();
    },

    listenEsc(e) {
      if (e.keyCode == 27) {
        this.$store.commit("updateSysFull", true);
      }
    },
  },
  destroyed() {
    document.removeEventListener("keydown", this.listenEsc);
  },
};
</script>

<style lang="scss" scoped>
.robot-body {
  height: 100%;
}
</style>
