<template>
  <div class="robot_header_alarm">
    <el-badge
      title="告警"
      :is-dot="curAlarmData?.length > 0 ? true : false"
      class="item"
      type="warning"
      @click.native="dialogTableVisible = true"
    >
      <i class="icon-alarm"></i>
    </el-badge>
    <el-dialog
      title="事件告警"
      :visible.sync="dialogTableVisible"
      width="70%"
      :modal-append-to-body="false"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :before-close="handleClose"
    >
      <div class="robot_header_alarm_device" v-if="deviceList?.length > 0">
        <el-select
          v-model="deviceItem"
          placeholder="选择设备"
          value-key="id"
          @change="onChangeSelect"
        >
          <el-option
            v-for="item in deviceList"
            :key="item.id"
            :label="item.name"
            :value="item"
          />
        </el-select>
        <a
          target="_self"
          rel="noopener noreferrer"
          :class="[!deviceItem?.id && 'a_disabled']"
          @click="onClickAlarmHistory"
        >
          设备告警历史
        </a>
      </div>
      <!-- <div class="robot_header_alarm_curAlarm">当前告警事件列表</div> -->
      <div class="alarm_content_table">
        <el-table
          highlight-current-row
          border
          :data="curAlarmData"
          height="calc(100% - 32px)"
          ref="alarmTableRef"
        >
          <el-table-column
            prop="deviceName"
            label="设备名称"
            :formatter="formatterFun"
            column-key="deviceName"
          />
          <el-table-column
            prop="node_name"
            label="节点名称"
            :formatter="formatterFun"
            column-key="node_name"
          />
          <el-table-column
            prop="event_type"
            label="告警类型"
            column-key="event_type"
            :filters="alarmTypeFilters"
            :filter-method="filterHandler"
          >
            <template slot-scope="scope" v-if="scope.row.event_type">
              <el-tag :type="alarmTypeTag[scope.row.event_type]">{{
                alarmType[scope.row.event_type]
              }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="value" label="告警内容" column-key="value">
            <template slot-scope="scope" v-if="scope.row.value">
              <div v-html="scope.row.value"></div>
            </template>
          </el-table-column>
          <el-table-column
            prop="time"
            label="告警时间"
            :formatter="formatterFun"
            column-key="time"
          />
        </el-table>
        <!-- <el-pagination
          style="text-align: right; margin-top: 5px"
          @size-change="onSizeChange"
          @current-change="onCurrentChange"
          :current-page="pageInfo.pageNo"
          :page-sizes="[10, 20, 50, 100]"
          :page-size="pageInfo.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="pageInfo.totalNum"
        >
        </el-pagination> -->
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { alarmType, alarmTypeTag, alarmTypeFilters } from "@/constants";
import dayjs from "dayjs";
import { AnsiUp } from "ansi_up";
import { isEqual } from "lodash";

export default {
  props: ["deviceList", "curDeviceInfo"],
  data() {
    return {
      alarmWs: null,
      curAlarmData: [],
      // allData: [],
      dialogTableVisible: false,
      pageInfo: {
        pageNo: 1,
        pageSize: 20,
        totalNum: 0,
        totalPage: 0,
      },
      ansi_up: new AnsiUp(),
      deviceItem: this.curDeviceInfo?.basicInfo || null,
      alarmType,
      alarmTypeTag,
      alarmTypeFilters,
    };
  },

  computed: {
    // curAlarmList() {
    //   const start = (this.pageInfo.pageNo - 1) * this.pageInfo.pageSize;
    //   const end = start + this.pageInfo.pageSize;
    //   return this.allData.slice(start, end);
    // },
  },

  mounted() {
    this.openAlarmWebsocket();
  },

  watch: {
    curDeviceInfo: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.deviceItem = newVal?.basicInfo || null;
      }
    },
  },

  methods: {
    openAlarmWebsocket: function () {
      this.alarmWs = new WebSocket(
        `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/alarm/all`
      );
      this.alarmWs.onopen = () => {
        console.log(`---ws连接alarm/all成功---`);
        // const data = [
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779585508,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //     deviceName: this.deviceList?.find((j) => j.sn === "0")?.name,
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779586020,
        //     value: "Wrong type! ",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779585508,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     event_type: "1",
        //     node_name: "robot_communication",
        //     time: 1706779586020,
        //     value: "Wrong type! ",
        //   },
        //   {
        //     event_type: "0",
        //     node_name: "robot_communication",
        //     time: 1706779585508,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779586020,
        //     value: "Wrong type! ",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779585508,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779586020,
        //     value: "Wrong type! ",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779585508,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779586020,
        //     value: "Wrong type! ",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779585508,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779586020,
        //     value: "Wrong type! ",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779585508,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779586020,
        //     value: "Wrong type! ",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779585508,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     event_type: "2",
        //     node_name: "robot_communication",
        //     time: 1706779586020,
        //     value: "Wrong type! ",
        //   },
        // ];
        // this.curAlarmData = data?.map((i) => {
        //   return { ...i, value: this.ansi_up.ansi_to_html(i?.value) };
        // });
        // this.pageInfo.totalNum = this.allData?.length;
        // this.onCurrentChange(this.pageInfo.pageNo);
      };
      this.alarmWs.onmessage = (msg) => {
        const curData = JSON.parse(msg?.alarm);
        this.curAlarmData = curData.map((i) => {
          return {
            ...i,
            deviceName:
              this.deviceList?.find((j) => j.sn === i?.robotId)?.name ?? null,
            value: this.ansi_up.ansi_to_html(i?.value),
          };
        });
      };
      this.alarmWs.onclose = (event) => {
        if (event.wasClean) {
          console.log(
            `[close] Connection closed cleanly, ----/alarm/all----, code=${event.code} reason=${event.reason}`
          );
        } else {
          console.log("[close] Connection died, ---/alarm/all----");
        }
      };
      this.alarmWs.onerror = (e) => {
        console.log("WebSocket连接失败: /alarm/all, code:" + e.code);
      };
    },
    closeAlarmWebsocket: function () {
      if (this.alarmWs) {
        this.alarmWs.close();
        this.alarmWs = null;
      }
    },

    formatterFun(row, column) {
      const { columnKey } = column;
      switch (columnKey) {
        case "time": {
          return row[columnKey]
            ? dayjs(row[columnKey]).format("YYYY-MM-DD HH:mm:ss")
            : "-";
        }
        default:
          return row[columnKey] || "-";
      }
    },
    onCurrentChange: function (page) {
      this.pageInfo.pageNo = page;
    },
    onSizeChange: function (size) {
      this.pageInfo.pageSize = size;
    },

    onChangeSelect: function (item) {
      this.deviceItem = item;
    },

    onClickAlarmHistory: function () {
      this.$store.commit("updateDeviceActiveName", "alert");
      this.$router.push(`/device/${this.deviceItem?.id}`);
      this.dialogTableVisible = false;
    },

    filterHandler: function (value, row, column) {
      const property = column["property"];
      return row[property] === value;
    },

    clearFilter() {
      this.$refs.alarmTableRef.clearFilter();
    },

    handleClose: function () {
      this.clearFilter();
      this.dialogTableVisible = false;
    },
  },

  destroyed() {
    this.closeAlarmWebsocket();
  },
};
</script>

<style lang="scss">
$prefixCls: "robot_header_alarm";

.#{$prefixCls} {
  margin: 0px 20px;
  color: #fff;
  display: inline-block;
  i {
    font-size: 16px;
  }

  .el-dialog {
    height: 70%;
    .el-dialog__body {
      height: calc(100% - 74px);
      padding: 10px 20px;
    }
  }

  .alarm_content_table {
    padding-top: 32px;
    height: calc(100% - 76px);
  }

  &_device {
    a {
      margin-left: 10px;
    }
  }

  &_curAlarm {
    padding: 8px 0;
    font-size: 15px;
    font-weight: 500;
  }
}
</style>
