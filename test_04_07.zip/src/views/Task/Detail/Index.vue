<template>
  <div class="task_detail">
    <!-- <PgmKonva ref="pgmKonvaRef" /> -->
    <CustomCollapse>
      <PageNavigator :itemProps="itemProps" :customGoBack="customGoBack">
        <el-row>
          <el-col :span="6" class="task_col">
            <p>当前场景：{{ taskInfo?.scence?.name || "-" }}</p>
            <p>当前任务：{{ taskInfo?.name || "-" }}</p>
            <p>
              任务控制：
              <el-button
                @click="onClick('Restore', taskInfo.status)"
                type="primary"
                v-if="
                  taskInfo.status === 'Pause' ||
                  (taskInfo?.method === 'TASK_TEAM' &&
                    taskInfo.status === 'Processing')
                "
                >恢复</el-button
              >
              <el-button
                type="primary"
                @click="onClick('start', taskInfo.status)"
                v-if="
                  taskInfo.status === 'Create' ||
                  taskInfo.status === 'Running' ||
                  taskInfo.status === 'Restore' ||
                  (taskInfo?.method === 'TASK_TEAM' &&
                    taskInfo.status === 'Processing')
                "
              >
                {{
                  taskInfo.status === "Running" || taskInfo.status === "Restore"
                    ? "暂停"
                    : "启动"
                }}
              </el-button>
              <el-button
                @click="onClick('end')"
                type="danger"
                :disabled="
                  !(
                    taskInfo.status === 'Running' ||
                    taskInfo.status === 'Pause' ||
                    taskInfo.status === 'Restore' ||
                    (taskInfo?.method === 'TASK_TEAM' &&
                      taskInfo.status === 'Processing')
                  )
                "
                >终止</el-button
              >
            </p>
            <p>任务状态：{{ taskInfo?.status || "-" }}</p>
            <p>
              导航类型：{{
                taskTypeList?.find((i) => i.id === taskInfo?.params?.type)
                  ?.name ?? "-"
              }}
            </p>
          </el-col>
          <el-col :span="8" class="task_col task_col_opts">
            <p>
              已选设备
              <!-- :key="item.key"
                  :label="item.label"
                  :value="item.key" -->
              <el-select v-model="deviceId" placeholder="请选择" size="small">
                <el-option
                  v-for="item in deviceList"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id"
                ></el-option>
              </el-select>
              <a
                target="_self"
                rel="noopener noreferrer"
                @click="onClickDevCtrl"
                :class="[
                  (!deviceList || deviceList.length <= 0) && 'a_disabled',
                ]"
              >
                设备控制
              </a>
            </p>
            <p class="task_detail_video">
              视频
              <el-checkbox-group
                v-model="checkList"
                @change="onChangeVideoCheckBox"
                :max="3"
              >
                <el-checkbox
                  v-for="(item, key) in videoCheckBox"
                  :key="key"
                  :label="key"
                  :title="item"
                  >{{ item }}</el-checkbox
                >
              </el-checkbox-group>
            </p>
          </el-col>
          <el-col :span="6" class="task_col">
            <p>
              任务操作：
              <el-button type="primary" @click="onClick('securityCheck')"
                >路径检测
              </el-button>
              <el-button type="primary" @click="onClick('update')">
                <!-- :disabled="taskInfo.status !== 'Create'" -->
                编辑
              </el-button>
              <el-button
                type="danger"
                @click="onClick('delete')"
                :disabled="
                  taskInfo?.status !== 'Create' &&
                  taskInfo?.status !== 'Cancel' &&
                  taskInfo?.status !== 'Success' &&
                  taskInfo?.status !== 'Failed'
                "
                >删除</el-button
              >
            </p>
            <SelectTaskBehavior
              ref="selectTaskBehaviorRef"
              :deviceId="deviceId"
            />
          </el-col>
          <el-col
            :span="3"
            class="task_detail_stopBtn"
            v-if="
              taskInfo?.status === 'Running' || taskInfo?.status === 'Action'
            "
          >
            <StopButton
              :data="taskInfo"
              title="急停"
              :getTaskDetail="getTaskInfo"
            />
          </el-col>
        </el-row>
      </PageNavigator>
    </CustomCollapse>
    <WfsVideo
      v-for="(item, idx) in checkList"
      :key="item + idx"
      :videoCheckBox="videoCheckBox"
      :videoCheckBoxIndex="videoCheckBoxIndex"
      :id="item"
      @closedVideoId="getClosedVideoId"
      :curTop="checkList.indexOf(item) * 202 + 'px'"
      parentId="scene"
      :getCurBehaviorData="getCurBehaviorData"
    />
  </div>
</template>
<script>
import CustomCollapse from "@/components/CustomCollapse/Index.vue";
import StopButton from "@/components/StopButton/Index.vue";
import PageNavigator from "@/components/PageNavigator/Index.vue";
import WfsVideo from "@/components/VideoPlay/WfsVideo/Index.vue";
import SelectTaskBehavior from "@/components/SelectTaskBehavior/Index.vue";
import { Message } from "element-ui";
import { getDeviceAllList } from "@/api/device";
import {
  getTaskInfo,
  executeTask,
  deleteTask,
  getTaskDetail,
  pathSecurityCheck,
} from "@/api/task";
import { localStorageSetItem } from "@/utils/localStorageFun.js";
import { RandomColor } from "@/utils/RandomColor.js";
import { taskTypeList } from "../constants";

export default {
  props: [
    "taskCondition",
    "taskInfoRow",
    "onTaskEdit",
    "onDeleteOnlineTask",
    "getCurTaskInfoPoints",
    "isShowTaskInfo",
    "openDeviceTravelWebsocket",
    "closeDeviceTravel",
    "openDevicePlanWebsocket",
  ],
  data() {
    return {
      deviceId: "",
      deviceList: [],
      checkList: [],
      videoCheckBox: {},
      videoCheckBoxIndex: {},
      itemProps: [{ title: "任务信息" }],
      taskInfo: {
        scenceId: "",
        name: "",
        status: "",
      },
      taskEventWs: null,
      taskDeviceList: [],
      taskTimeId: null,
      taskTypeList,
    };
  },
  components: {
    CustomCollapse,
    StopButton,
    PageNavigator,
    WfsVideo,
    SelectTaskBehavior,
  },

  async mounted() {
    await this.getTaskInfo();
    await this.getDeviceList();
    this.openTaskEventWebsoket();
  },

  methods: {
    onClick: async function (type, status) {
      let params = {
        id: this.taskInfo.id,
      };
      switch (type) {
        case "start":
          {
            params = { ...params, status: "Running" };
            if (status === "Running" || status === "Restore") {
              params = { ...params, status: "Pause" };
            }
            if (this.taskInfo?.method === "TASK_TEAM") {
              params = { ...params, status: "Action" };
            }
            await executeTask(params);
            await this.getTaskInfo();
          }
          break;
        case "Restore":
          {
            params = { ...params, status: "Restore" };
            await executeTask(params);
            await this.getTaskInfo();
          }
          break;
        case "end":
          this.$confirm(
            "是否确认终止任务：" + this.taskInfo.name + "?",
            "终止任务",
            {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              type: "warning",
            }
          ).then(async () => {
            params = { ...params, status: "Cancel" };
            await executeTask(params);
            await this.getTaskInfo();
            if (this.onDeleteOnlineTask) {
              await this.onDeleteOnlineTask();
            }
            this.$message({
              type: "success",
              message: "任务终止成功!",
            });
          });

          break;
        case "update":
          this.isShowTaskInfo(false);
          this.$store.commit("updateIsTask", {
            isTask: true,
            curTaskInfo: {
              ...this.taskInfo,
              optsType: "update",
              page: "taskInfo",
            },
          });
          if (this.onTaskEdit) {
            await this.onTaskEdit(this.taskInfo);
          }
          break;
        case "securityCheck": {
          params = { taskId: this.taskInfo.id };
          await pathSecurityCheck(params);
          break;
        }
        default: // 删除
          this.$confirm(
            "是否确认删除任务：" + this.taskInfo.name + "?",
            "删除任务",
            {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              type: "warning",
            }
          ).then(async () => {
            await deleteTask({ id: this.taskInfo.id });
            if (this.onDeleteOnlineTask) {
              await this.onDeleteOnlineTask();
            }
            // 从设备详情 点击进入任务连接，进入设备详情，点击删除任务更新路由,
            // 注意：不重新刷新页面, 提高用户体验
            if (this.$route?.query?.taskId) {
              history.replaceState(null, "", `${this.$route?.path}`);
            }
            this.$message({
              message: "删除成功",
              type: "success",
            });
          });
          break;
      }
    },
    getTaskInfo: async function (taskTimeId) {
      try {
        const params = this.taskInfoRow;
        const taskId =
          params?.id ||
          this.$route?.query?.taskId ||
          this.$store.state?.curTaskInfo?.id;
        if (taskId) {
          this.taskInfo = await getTaskDetail({
            id: taskId,
          });
        }

        // if (this.taskInfo?.status !== "Create") {
        //   await this.continueUpdateTask();
        // }

        if (!taskTimeId) {
          // 该任务下设备点信息
          this.taskDeviceList = (this.taskInfo?.devices || [])?.map(
            (i, idx) => {
              const color = RandomColor();
              this.openDeviceTravelWebsocket(i, color, "taskDetail");
              this.openDevicePlanWebsocket(i, color, "taskDetail");
              return { ...i, color: color || "skyblue" };
            }
          );

          this.onTaskEdit(this.taskInfo);
          const videoRes = this.taskInfo?.devices;
          if (this.getCurTaskInfoPoints) {
            this.getCurTaskInfoPoints([this.taskInfo], true, "info");
          }
          if (videoRes && videoRes?.length > 0) {
            let len = 0;
            for (let j = 0; j < videoRes?.length; j++) {
              const obj = videoRes[j];
              for (let k = 0; k < obj?.videoUrls?.length; k++) {
                this.videoCheckBoxIndex[`video${obj.id}-${k}`] = len;
                this.videoCheckBox[`video${obj.id}-${k}`] =
                  obj?.sn + "(" + obj?.name + ")" + "-视频" + (k + 1);
                len += 1;
              }
            }
          }
        }
      } catch (error) {
        this.taskInfo = {
          scenceId: "",
          name: "",
          status: "",
        };
        throw error;
      }
    },
    getDeviceList: async function () {
      try {
        // const res = await getDeviceAllList({
        //   scenceId: this.taskInfo?.scenceId,
        // });
        // this.deviceList = res;
        // this.deviceId = res?.[0]?.key || "";

        /* 此处修改为任务下的已选设备，不在拉取场景下的设备 */
        this.deviceList = this.taskInfo?.devices;
        this.deviceId = this.taskInfo?.devices?.[0]?.id || "";
        // 处理视频展示逻辑 任务下的所有设备
      } catch {
        this.deviceList = [];
      }
    },

    onClickDevCtrl: function () {
      if (this.deviceId) {
        this.$router.push(`/device/${this.deviceId}`);
      } else {
        Message.warning("要先选择一个设备哦！");
      }
    },

    customGoBack: function () {
      this.closeDeviceTravel(this.taskDeviceList);
      // 关闭任务下 设备的 device-travel
      if (this.$route?.query?.taskId) {
        history.pushState(null, "", `${this.$route?.path}`);
      }
      this.clearTaskSetTimeout();
      this.taskCondition();
    },

    onChangeVideoCheckBox: function () {
      localStorageSetItem("videoCheckList", this.checkList);
    },

    getClosedVideoId: function (data) {
      const res = this.checkList.filter((i) => i !== data);
      this.checkList = res;
      localStorageSetItem("videoCheckList", res);
    },

    getCurBehaviorData: function () {
      const { action, target } = this.$refs.selectTaskBehaviorRef;
      if (this.$refs.selectTaskBehaviorRef) {
        if (
          action?.method === "TASK_FOLLOW" ||
          action?.method === "TASK_TRACKING" ||
          action?.method === "TASK_GRAB" ||
          action?.method === "TASK_STRIKE"
        ) {
          this.$refs.selectTaskBehaviorRef.isCancel = true;
          const cancelTask = this.$refs.selectTaskBehaviorRef.cancelTask;
          const idx = cancelTask.findIndex((i) => i.method === action?.method);
          if (idx !== -1) {
            cancelTask.splice(idx, 1, { ...action, controlAction: 1 });
          } else {
            cancelTask.push({
              ...action,
              controlAction: 1,
            });
          }
        } else {
          this.$refs.selectTaskBehaviorRef.isCancel = false;
        }
      }
      return {
        action: action?.method,
        target,
        scenceId: this.taskInfo?.scenceId,
        deviceIds: this.taskInfo?.deviceIds || [],
      };
    },

    openTaskEventWebsoket: async function () {
      const curTaskId = this.taskInfo?.id;
      if (curTaskId) {
        const taskEventUrl = `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/task-event/${curTaskId}`;
        this.taskEventWs = new WebSocket(taskEventUrl);
        this.taskEventWs.onopen = () => {
          console.log(`------task-event 连接成功-----当前任务Id:${curTaskId}`);
        };

        this.taskEventWs.onmessage = (msg) => {
          const data = JSON.parse(msg?.data);
          const eventObj = data?.event;
          // 0 通知型事件 1交互性事件，目前和后端敲定的交互逻辑
          if (eventObj?.type === 0) {
            if (eventObj?.eventType === 0) {
              if (eventObj?.status) {
                // 状态： 编队任务添加
                this.$message({
                  type: "success",
                  message: `当前任务状态：${eventObj?.status}`,
                });
                return;
              } else {
                // 任务（中的一个步骤）完成事件
                this.$message({
                  type: "success",
                  message: "当前任务完成！",
                });
                return;
              }
            }
            if (eventObj?.eventType === 1) {
              // 目标识别事件
              if (eventObj?.value === 0) {
                // 识别到目标
                this.$message({
                  type: "success",
                  message: `成功识别到目标物：${eventObj?.target}`,
                });
                return;
              }
              if (eventObj?.value === 1) {
                // 未识别到目标
                this.$message({
                  type: "warning",
                  message: "未识别到目标",
                });
                return;
              }
              return;
            }
          }
        };

        this.taskEventWs.onclose = (event) => {
          if (event.wasClean) {
            console.log(
              `[close] Connection closed cleanly,------task-event-----, code=${event.code} reason=${event.reason}`
            );
          } else {
            console.log(`[close] Connection died ------task-event-----`);
          }
        };
      }
    },

    closeTaskEventWebsoket: function () {
      if (this.taskEventWs) {
        this.taskEventWs.close();
        this.taskEventWs = null;
      }
    },

    continueUpdateTask: function () {
      this.taskTimeId = setTimeout(async () => {
        await this.getTaskInfo(true);
        this.continueUpdateTask();
      }, 3000);
    },

    clearTaskSetTimeout: function () {
      if (this.taskTimeId) {
        clearTimeout(this.taskTimeId);
        this.taskTimeId = null;
      }
    },
  },

  destroyed() {
    this.closeTaskEventWebsoket();
    this.clearTaskSetTimeout();
  },
};
</script>

<style lang="scss" scoped>
@import "@/assets/css/common.scss";
$prefixCls: "task_detail";
.#{$prefixCls} {
  font-size: 16px;
  p {
    padding: 4px;
  }
  .el-row {
    height: 100%;

    .task_col {
      p {
        word-break: break-all;
      }
    }
  }

  .el-select {
    margin: 0 6px;
    width: calc(100% - 152px);
  }

  &_video {
    position: relative;
    .el-checkbox-group {
      display: flex;
      flex-direction: column;
      flex-wrap: nowrap;
      position: absolute;
      top: -3px;
      left: 48px;
      width: calc(100% - 52px);

      .el-checkbox {
        color: inherit;
      }

      ::v-deep {
        .el-checkbox__input {
          top: -14px;
        }
        .el-checkbox__label {
          font-size: 16px;
          line-height: 40px;
          width: calc(100% - 25px);
          display: inline-block;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .el-checkbox__inner {
          z-index: inherit;
        }
      }
    }
  }

  &_stopBtn {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100%;
  }
}
</style>
