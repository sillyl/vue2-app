<template>
  <div class="cluster_formation">
    <el-steps :active="stepActive" simple finish-status="success">
      <el-step title="设备选择" icon="el-icon-edit"> </el-step>
      <el-step title="队形选择" icon="el-icon-edit"> </el-step>
      <!-- <el-step title="指定地点列队" icon="el-icon-location-information">
      </el-step> -->
      <el-step title="编队行走" icon="el-icon-position"></el-step>
    </el-steps>
    <div class="cluster_formation_step1" v-if="stepActive === 0">
      <div class="cluster_formation_step1_content">
        <TaskForm
          ref="taskRef"
          :optsType="$store.state.curTaskInfo.optsType"
          :updateCurSceneMapObj="updateCurSceneMapObj"
          :deviceCurScenceId="deviceCurScenceId"
          :selectSceneInfo="selectSceneInfo"
          :isCurPage="isCurPage"
          :taskFormData="taskFormData"
          :getCurTaskInfoPoints="getCurTaskInfoPoints"
        />
      </div>
      <div class="cluster_formation_step1_btns">
        <el-button @click="onStepNext('selectedDevices')" type="primary">
          下一步
        </el-button>
      </div>
    </div>
    <div class="cluster_formation_step0" v-if="stepActive === 1">
      <div class="cluster_formation_step0_content">
        <el-row>
          <el-col :span="8" class="col_left">
            <el-form
              ref="formStep0Ref"
              :rules="rules"
              :model="form"
              label-width="100px"
            >
              <el-form-item label="快捷队形" prop="formation">
                <el-select
                  v-model="form.formation"
                  placeholder="请选择"
                  :disabled="formationType === 'custom'"
                  :loading="quickFormationLoading"
                  @change="onChangeFormation"
                  @visible-change="visibleFormationChange"
                  value-key="label"
                >
                  <el-option-group
                    v-for="group in curFormationList"
                    :key="group.label"
                    :label="group.label"
                  >
                    <el-option
                      v-for="item in group.options"
                      :key="item.label"
                      :label="item.label"
                      :value="item"
                    ></el-option>
                  </el-option-group>
                </el-select>
              </el-form-item>
              <el-form-item label="自定义队形" prop="customFormation">
                <el-switch
                  v-model="form.customFormation"
                  @change="onChangeSwith"
                />
                <span class="konva_opts_btns">
                  <el-button
                    type="primary"
                    size="small"
                    :disabled="!form.customFormation"
                    @click="onOptsClick()"
                  >
                    清空
                  </el-button>
                </span>
              </el-form-item>
              <el-form-item prop="pixelScale">
                <span slot="label">
                  像素比例
                  <el-tooltip
                    class="spaced_tooltip"
                    content="1像素等于xx米"
                    placement="top-start"
                    effect="light"
                  >
                    <i class="el-icon-question"></i>
                  </el-tooltip>
                </span>
                <el-input-number
                  v-model="form.pixelScale"
                  controls-position="right"
                  :min="0.000001"
                />
              </el-form-item>
            </el-form>
            <div class="cluster_formation_step0_btns">
              <el-button
                @click="onStepBack('selectedFormation')"
                type="primary"
                size="small"
              >
                上一步
              </el-button>
              <el-button
                @click="onStepNext('selectedFormation')"
                type="primary"
                size="small"
              >
                下一步
              </el-button>
            </div>
          </el-col>
          <el-col :span="16" class="col_right">
            <DrawFormations
              ref="drawFormationsRefs"
              :formationType="formationType"
              :pointCounts="pointCounts"
              :curPixelScale="curPixelScale"
              :curFormationObj="curFormationObj"
              :saveFormations="saveFormations"
            />
          </el-col>
        </el-row>
      </div>
    </div>
    <div class="cluster_formation_step2" v-if="stepActive === 2">
      <div class="cluster_formation_step2_content">
        <div v-if="!initFormationStatus">
          设置初始点位列队：
          <el-button type="primary" @click="onInitLocation">
            选点列队
          </el-button>
          <!-- <el-button type="primary" @click="onLineUp"> 列队 </el-button> -->
        </div>
        <div v-if="initFormationStatus">
          <TaskForm
            :optsType="$store.state.curTaskInfo.optsType"
            ref="taskFormationRef"
            :curClusterStep="3"
            :onClickNavPoint="onClickNavPoint"
            :resetMapData="resetMapData"
            pickUpBtnLabel="设置编队行走点位"
            pickUpBtnTxt="拾取"
            clearBtnTxt="清空"
            :getCurTaskInfoPoints="getCurTaskInfoPoints"
          />
        </div>
      </div>
      <div class="cluster_formation_step2_btns">
        <el-tooltip
          class="spaced_tooltip"
          :content="
            initFormationStatus
              ? '编队初始点位列队成功，不允许更新编队信息'
              : ''
          "
          :disabled="initFormationStatus ? false : true"
          placement="top-start"
          effect="light"
        >
          <el-button
            @click="onStepBack('nav')"
            type="primary"
            :disabled="initFormationStatus"
          >
            上一步
          </el-button>
        </el-tooltip>
        <el-tooltip
          :content="!initFormationStatus ? '请先选点列队' : ''"
          :disabled="!initFormationStatus ? false : true"
          placement="top-start"
          effect="light"
        >
          <el-button
            @click="onStepFinished"
            type="primary"
            :disabled="!initFormationStatus ? true : false"
          >
            完成
          </el-button>
        </el-tooltip>
      </div>
    </div>
  </div>
</template>

<script>
import TaskForm from "../components/TaskForm/Index.vue";
import DrawFormations from "@/components/DrawFormations/Index.vue";
import { updataTask, getFormationList, saveFormation } from "@/api/task";
import { isEqual } from "lodash";

export default {
  props: [
    "resetMapData",
    "updateCurSceneMapObj",
    "deviceCurScenceId",
    "selectSceneInfo",
    "isCurPage",
    "onInitPickup",
    "onClickNavPoint",
    "getCurTaskPoints",
    "onClickTaskInfo",
    "getCurTaskInfoPoints",
  ],
  data() {
    return {
      stepActive: 0,
      form: {
        formation: null,
        pixelScale: 0.02,
        customFormation: false,
      },
      rules: {
        pixelScale: [
          {
            required: true,
            trigger: ["blur", "change"],
          },
        ],
      },
      formationList: [],
      curFormationList: [],
      formationType: "default", // 默认固定的快捷队形， custom: 自定义
      taskFormData: null,
      pointCounts: 0, // 根据设备控制画布点的数量
      curFormationObj: null,
      ws: null,
      initFormationStatus: false,
      curPointsParams: null,
      drawFormationParams: null,
      quickFormationLoading: false,
    };
  },

  components: { TaskForm, DrawFormations },

  computed: {
    curPixelScale: function () {
      return this.form.pixelScale;
    },
  },

  async mounted() {
    this.getFormationList();
    if (
      this.$store.state.curTaskInfo?.optsType === "update" &&
      this.$store.state.curTaskInfo?.status === "Processing"
    ) {
      this.stepActive = 2; // 列队成功，编辑直接根据任务状态跳转到第三步编队行走，不允许点击上一步更新队形
      this.initFormationStatus = true;
    }
  },

  methods: {
    // 列队ws 上报初始位置列队状态  成功在显示导航相关操作
    onWsFormationStatus: function () {
      const curTaskId = this.$store.state.curFormationTaskId;
      const socketUrl = `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/task-event/${curTaskId}`;
      this.ws = new WebSocket(socketUrl);
      this.ws.onopen = () => {
        console.log(`---WebSocket连接${socketUrl}成功---`);
      };

      this.ws.onmessage = (msg) => {
        const eventObj = JSON.parse(msg?.event);
        // 0 通知型事件 1交互性事件，目前和后端敲定的交互逻辑
        if (eventObj?.type === 0) {
          if (eventObj?.eventType === 0) {
            if (eventObj?.status) {
              // 状态： 编队任务添加
              if (eventObj?.status === "Processing") {
                this.initFormationStatus = true;
              } else {
                this.initFormationStatus = false;
              }
              this.$message({
                type: "success",
                message: `当前任务状态：${eventObj?.status}`,
              });
              return;
            } else {
              // 任务（中的一个步骤）完成事件
              this.$message({
                type: "success",
                message: "当前任务完成！",
              });
              return;
            }
          }
        }
      };
      this.ws.onclose = (event) => {
        if (event.wasClean) {
          console.log(
            `[close] Connection closed cleanly, --------, code=${event.code} reason=${event.reason}`
          );
        } else {
          console.log("[close] Connection died, -------");
        }
      };

      this.ws.onerror = (e) => {
        console.log("WebSocket连接失败: " + socketUrl + "code:" + e.code);
      };
    },

    getFormationList: async function () {
      const res = await getFormationList();
      this.formationList = res;
      const len = this.pointCounts;
      const curF = this.formationList?.filter(
        (i) => i.count === len || i.count === -1
      );
      this.curFormationList = this.getGroupFormation(curF);
    },

    getGroupFormation(formationList) {
      const arr1 = formationList?.filter((i) => i.templateType === 0);
      const arr2 = formationList?.filter((i) => i.templateType === 1);
      const arr = [];
      if (arr1?.length > 0) {
        arr.push({
          label: "内部模板",
          options: arr1,
        });
      }
      if (arr2?.length > 0) {
        arr.push({
          label: "自定义模板",
          options: arr2.sort((a, b) => {
            return b.createTime - a.createTime;
          }),
        });
      }
      return arr;
    },

    onStepNext: function (curStep) {
      if (curStep === "selectedFormation") {
        const points = this.$refs.drawFormationsRefs.konvaConfig.points;
        if (points?.length <= 0) {
          this.$message({
            type: "warning",
            message: "请绘制队形",
          });
          return;
        }
        if (points?.length < this.pointCounts) {
          this.$message({
            type: "info",
            message: "队形和设备数量不匹配（队形点数少于设备数量）",
          });
          return;
        }
        this.stepActive += 1;
        this.computedPointsParams(points);
        // 为导航任务上一步 自定义队形数据存储
        const curPoints = this.$refs.drawFormationsRefs.konvaConfig.points;
        this.curFormationObj = {
          ...this.curFormationObj,
          points: curPoints,
          count: curPoints?.length,
        };
        this.saveFormations(curPoints, true);
      }
      if (curStep === "selectedDevices") {
        // 校验必填参数
        const taskRef = this.$refs.taskRef;
        taskRef.$refs.form.validate((valid) => {
          if (valid) {
            const { deviceIds } = taskRef.form;
            this.taskFormData = {
              form: taskRef.form,
              teamLeaderList: taskRef.teamLeaderList,
            };
            if (taskRef?.isDeviceIdsDecline) {
              // 更新设备数量 数量减少 重置选择的队形
              this.form.formation = null;
              this.curFormationObj = null;
            }
            // 根据选择设备数量 过滤队形列表，并统计点的数量
            const len = deviceIds?.length;
            this.pointCounts = len;
            this.stepActive += 1;
            this.getstep0Params();
          } else {
            return false;
          }
        });
      }
    },

    getstep0Params: function () {
      if (this.$store.state.curTaskInfo.optsType === "update") {
        if (
          this.$store.state.formationDetailData &&
          this.$store.state.formationDetailData?.params
        ) {
          const {
            drawParams: { drawFormationParams, formationType, curPixelScale },
          } = this.$store.state.formationDetailData?.params;
          this.form = {
            formation: drawFormationParams,
            pixelScale: curPixelScale,
            customFormation: formationType === "custom" ? true : false,
          };
          this.formationType = formationType;
          this.curFormationObj = drawFormationParams;
        }
      }
    },

    computedPointsParams: function (points) {
      this.curPointsParams = points;
    },

    onStepBack: function (curStep) {
      if (curStep === "nav") {
        if (this.onInitPickup) {
          this.onInitPickup();
        }
      }
      this.stepActive -= 1;
    },

    saveFormations: async function (points, isSave) {
      const { omega, uvX, uvY } = points?.[0];
      const len = points?.length;
      const otherPoints = points.slice(1, len);

      let pointsParams = [{ omega, uvX: Number(uvX), uvY: Number(uvY) }];
      otherPoints.map((i) => {
        const { angle, omega, realDistance } = i;
        pointsParams.push({ angle, omega, realDistance });
      });
      const customFormation = this.curFormationList?.[1]?.options;
      const lastedObj = customFormation?.[0];
      const labelNum = lastedObj?.label?.slice(2);
      const labelIdx = labelNum ? Number(labelNum) + 1 : 1;
      const params = {
        count: pointsParams?.length,
        label: !isSave
          ? `模板${labelIdx}`
          : this.curFormationObj?.label
          ? this.curFormationObj?.label
          : `模板${labelNum}`,
        templateType: 1,
        points: pointsParams,
      };
      if (!isSave) {
        await saveFormation(params);
        // 更新队形列表
        await this.getFormationList();
        this.$message({
          type: "success",
          message: "该模板保存成功",
        });
      } else {
        this.drawFormationParams = params;
      }
    },

    onStepFinished: async function () {
      if (this.getCurTaskPoints) {
        const id =
          this.$store.state.curFormationTaskId ||
          this.$store.state.formationDetailData?.id;

        if (!id) {
          this.$message({
            type: "warning",
            message: "请先选点列队！",
          });
          return;
        }
        const res = this.getCurTaskPoints();
        const { drawParams, leaderId } =
          this.$store.state.step0Params?.params ||
          this.$store.state.formationDetailData?.params;
        const drawData = this.drawFormationParams;
        // 如果快捷队形 被修改了，将被列为自定义模板,为了编辑时不被匹配，将label置为""
        const idx = this.formationList?.findIndex(
          (i) => i.label === drawData?.label
        );
        const res2 = this.formationList[idx]?.points;
        const res3 = !isEqual(res2, drawData?.points);
        // 更新任务
        const params = {
          id,
          params: {
            step: 1,
            point: res || this.$store.state.formationDetailData?.params?.points,
            drawParams: {
              curPixelScale: drawParams?.curPixelScale,
              drawFormationParams: res3 ? { ...drawData, label: "" } : drawData,
              formationType: res3 ? "custom" : drawParams?.formationType,
            },
            leaderId,
          },
        };
        await updataTask(params);
        // 创建完任务直接进入任务详情页
        if (this.onClickTaskInfo) {
          this.onClickTaskInfo({ id });
        }
        this.$store.commit("updateIsTask", {
          isTask: false,
        });
      }
    },
    onChangeSwith: function (e) {
      if (e) {
        // 开启自定义队列 清空快捷队列数据
        this.formationType = "custom";
        this.form.formation = null;
        this.curFormationObj = null;
      } else {
        // 关闭自定义队列 恢复快捷队列的 默认队列
        this.formationType = "default";
      }
      this.clearFormations();
    },

    clearFormations: function () {
      this.$refs?.drawFormationsRefs?.clearFormations();
    },

    onChangeFormation: function () {
      // 根据选择快捷队形绘制 默认队形
      this.curFormationObj = this.form.formation;
    },

    visibleFormationChange: async function (visible) {
      if (visible) {
        try {
          this.quickFormationLoading = true;
          await this.getFormationList();
        } finally {
          this.quickFormationLoading = false;
        }
      } else {
        this.quickFormationLoading = false;
      }
    },

    onInitLocation: function () {
      this.onInitPickup(true);
    },

    onOptsClick: function () {
      this.clearFormations();
    },

    onCloseWs: function () {
      if (this.ws) {
        this.ws.close();
        this.ws = null;
      }
    },

    destroyed() {
      this.onCloseWs();
      this.$store.commit("setCurFormationStep0Params", null);
      this.quickFormationLoading = false;
    },
  },
};
</script>

<style lang="scss" scoped>
@import "./Index.scss";
</style>
