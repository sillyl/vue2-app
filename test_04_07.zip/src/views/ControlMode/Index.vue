<template>
  <div
    class="control_mode_content_plat"
    id="control_mode_content_plat"
    v-if="
      $store.state.isControlMode &&
      $store.state.curCtrlMode &&
      $store.state.curCtrlMode !== 0 &&
      $store.state.curDeviceId
    "
  >
    <PlatLeft ref="platLeftRef" />
    <div class="center">
      <div
        v-if="$store.state.curDeviceId"
        class="control_mode_content_deviceInfo"
      >
        <el-alert
          v-if="poseFront && poseFront !== 0"
          :title="`前摆臂角度：${poseFront}`"
          type="success"
          center
          :closable="false"
        >
        </el-alert>
        <el-alert
          v-if="poseBack && poseBack !== 0"
          :title="`后摆臂角度：${poseBack}`"
          type="success"
          center
          :closable="false"
        >
        </el-alert>
        <el-alert
          :title="`当前设备：${$store.state.curDeviceInfo?.basicInfo?.name}`"
          type="success"
          center
          :closable="false"
        >
        </el-alert>
      </div>
    </div>
    <PlatRight ref="platRightRef" />
  </div>
</template>
<script>
import PlatLeft from "./Plat/PlatLeft.vue";
import PlatRight from "./Plat/PlatRight.vue";
import { videoCheckBoxIndex } from "@/constants";
import { localStorageGetItem } from "@/utils/localStorageFun.js";
import { isEmpty } from "lodash";

export default {
  data() {
    return {
      poseWs: null,
      poseBack: null,
      poseFront: null,
      eventWs: null,
    };
  },
  async mounted() {
    await this.openPoseWebsoket();
    await this.openEventWebsoket();
  },

  components: {
    PlatLeft,
    PlatRight,
  },

  methods: {
    // 1. 处理数据filter出groupId相同的组；2.各个组件所需数据结构; 3.通过小组件反计算 左右展示的组件数量
    getNewJsonData: async function (data) {
      let arr = [];
      // groupId 仅作为分组类型， id 标识，不做分组
      for (let i of data) {
        if (i?.groupId) {
          const filterArr = arr.filter((k) => i?.groupId === k?.groupId);
          if (isEmpty(filterArr)) {
            arr.push({
              groupId: i?.groupId,
              groupName: i?.groupName,
              group: [{ ...i }],
            });
          } else {
            const index = arr.findIndex((k) => i?.groupId === k?.groupId);
            arr[index]?.group.push(i);
          }
        }
        if (!i?.groupId && i?.id) {
          arr.push({
            id: i?.id,
            groupName: i?.groupName,
            group: [{ ...i }],
          });
        }
        if (i?.split) {
          arr.push({ ...i });
        }
      }
      return [...arr]; // 适合前端渲染的元数据
    },

    // device-pose
    openPoseWebsoket: async function () {
      await this.closePoseWebsoket();
      const curDeviceId =
        localStorageGetItem("curDeviceId") || this.$store.state.curDeviceId;
      const poseUrl = `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/device-pose/${curDeviceId}`;
      this.poseWs = new WebSocket(poseUrl);
      this.poseWs.onopen = () => {
        console.log("------device-pose 连接成功-----");
      };

      this.poseWs.onmessage = (msg) => {
        const msgObj = JSON.parse(msg?.data);
        const pose = msgObj?.pose;
        const pendulumArm = pose?.pendulumArm;
        this.poseBack = pendulumArm?.back;
        this.poseFront = pendulumArm?.front;
      };

      this.poseWs.onclose = (event) => {
        if (event.wasClean) {
          console.log(
            `[close] Connection closed cleanly, ----device-pose----, code=${event.code} reason=${event.reason}`
          );
        } else {
          console.log("[close] Connection died, ----device-pose----");
        }
      };
    },

    closePoseWebsoket: function () {
      if (this.poseWs) {
        this.poseWs.close();
        this.poseWs = null;
      }
    },

    // device-event
    openEventWebsoket: async function () {
      await this.closeEventWebsoket();
      const curDeviceId =
        localStorageGetItem("curDeviceId") || this.$store.state.curDeviceId;
      const poseUrl = `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/device-event/${curDeviceId}`;
      this.eventWs = new WebSocket(poseUrl);
      this.eventWs.onopen = () => {
        console.log("------device-event 连接成功-----");
      };

      this.eventWs.onmessage = (msg) => {
        const msgObj = JSON.parse(msg?.data);
        const eventObj = msgObj?.event;

        if (!isEmpty(eventObj)) {
          this.$message({
            message: JSON.stringify(eventObj),
            type: "success",
          });
        }
      };

      this.eventWs.onclose = (event) => {
        if (event.wasClean) {
          console.log(
            `[close] Connection closed cleanly, ----device-event----, code=${event.code} reason=${event.reason}`
          );
        } else {
          console.log("[close] Connection died, ----device-event----");
        }
      };
    },

    closeEventWebsoket: function () {
      if (this.eventWs) {
        this.eventWs.close();
        this.eventWs = null;
      }
    },
  },
};
</script>

<style lang="scss" scoped>
@import "./Index.scss";
</style>
