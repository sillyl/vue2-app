import Vue from "vue";
import Vuex from "vuex";
import { localStorageGetItem } from "@/utils/localStorageFun.js";
import { getNewJsonData } from "@/utils/getNewJsonData";
Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    isControlMode: false, // 控制模式内容显隐
    isShowNippleVal: localStorageGetItem("nippleVal") || false, // 控制全局摇杆的显隐
    isAddMap: false, //添加地图
    isTask: false, // 是否展示任务
    curTaskInfo: null,
    isCollapse: true, // CustomCollapse 展开收起
    deviceList: [],
    isTaskHistory: false,
    // websocketUrl: "ws://" + window.location.host.split(":")[0] + ":8090",
    websocketUrl: "ws://192.168.8.52:8090",
    curCtrlMode: "", // 当前控制模式 smartCtrCenter:2 , platCtrCenter: 1, jointCtrCenter:3
    curDeviceId: localStorageGetItem("curDeviceId") || "",
    curDeviceInfo: localStorageGetItem("curDeviceInfo") || null,
    curCtrlModes: localStorageGetItem("curCtrlModes") || null,
    curSubscribe: {
      isShow: false,
      optType: "",
    },
    sysFull: false,
    curFunctions: localStorageGetItem("curFunctions") || [],
    curJsonLeftData: [],
    curJsonRightData: [],
    videoUrls: localStorageGetItem("curDeviceInfo")?.videoCheckBox || [],
    videoCheckBox: localStorageGetItem("curDeviceInfo")?.videoCheckBox || null,
    videoCheckBoxIndex:
      localStorageGetItem("curDeviceInfo")?.videoCheckBoxIndex || null,
    basicInfo: localStorageGetItem("curDeviceInfo")?.basicInfo || null,
    deviceActiveName: "",
    curFormationTaskId: "",
    step0Params: null,
    formationDetailData: null,
  },
  getters: {},
  mutations: {
    updateCurCtrlMode(state, data) {
      state.curCtrlMode = data;
      const curPageData = state.curFunctions?.filter((i) => i?.pageId === data);
      const rightData = curPageData?.filter((i) => i.layout === "right");
      const leftData = curPageData?.filter((i) => i.layout === "left");
      state.jsonRightData = getNewJsonData(rightData || []);
      state.jsonLeftData = getNewJsonData(leftData || []);
    },
    updateCurCtrlModes(state, data) {
      state.curCtrlModes = data;
    },
    updateisShowNippleVal(state, data) {
      state.isShowNippleVal = data;
    },
    updateIsControlMode(state, isControlMode) {
      state.isControlMode = isControlMode;
    },
    addMap(state, isAddMap) {
      state.isAddMap = isAddMap;
      state.isControlMode = false; // 增加地图时不展示两边的控制模式
    },
    updateIsTask(state, data) {
      state.isTask = data.isTask;
      if (data.curTaskInfo) {
        state.curTaskInfo = data.curTaskInfo || null;
      }
    },
    updateIsCollapse(state, isCollapse) {
      state.isCollapse = isCollapse;
    },

    updateIsTaskHistory(state, data) {
      state.isTaskHistory = data;
    },

    // 设备list
    setDeviceList(state, data) {
      state.deviceList = data;
    },

    updateCurDeviceId(state, data) {
      state.curDeviceId = data;
    },

    saveCurDeviceInfo: function (state, data) {
      state.curDeviceInfo = data;
      state.videoUrls = data?.videoUrls;
      state.videoCheckBox = data?.videoCheckBox;
      state.videoCheckBoxIndex = data?.videoCheckBoxIndex;
      state.basicInfo = data?.basicInfo;
    },

    updateCurSubscribe: function (state, data) {
      state.curSubscribe = data;
    },

    updateSysFull: function (state, data) {
      state.sysFull = data;
    },

    updateCurFunctions: function (state, data) {
      state.curFunctions = data;
    },

    updateDeviceActiveName: function (state, data) {
      state.deviceActiveName = data;
    },

    setCurFormationTaskId: function (state, data) {
      state.curFormationTaskId = data;
    },

    setCurFormationStep0Params: function (state, data) {
      state.step0Params = data;
    },

    setFormationDetailData: function (state, data) {
      state.formationDetailData = data;
    },
  },
  actions: {},
  modules: {},
});
