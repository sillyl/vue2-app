export function stepLineSegment(x1, y1, x2, y2) {
  if (Math.abs(x1 - x2) >= 0.000005 || Math.abs(y1 - y2) >= 0.000005) {
    return true;
  } else {
    return false;
  }
}

export function stepPgmLineSegment(x1, y1, x2, y2) {
  if (Math.abs(x1 - x2) >= 0.01 || Math.abs(y1 - y2) >= 0.01) {
    return true;
  } else {
    return false;
  }
}
