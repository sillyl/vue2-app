import { isEmpty, isPlainObject } from "lodash";

export function getCurrentTime() {
  var time = new Date();
  time.setHours(time.getHours() + 8);
  time = time.toISOString();
  time = time.replaceAll("-", "");
  time = time.replaceAll(":", "");
  time = time.replaceAll("T", "");
  return time.substr(0, 14);
}

//{"a": 1, "b":2} -> "1:2"
export const ObjFormatString = (obj) => {
  if (!isEmpty(obj)) {
    const arr = Object.values(obj);
    const arrNew = arr.filter(Boolean);
    if (arrNew.length !== arr.length) {
      return;
    }
    const str = Object.values(obj).join(":");
    return str;
  }
  return;
};

export const updateObjFormat = (obj) => {
  let newObj = {};
  for (let key in obj) {
    if (isPlainObject(obj[key])) {
      if (ObjFormatString(obj[key])) {
        newObj[key] = ObjFormatString(obj[key]);
      } else {
        delete newObj[key];
      }
    } else {
      newObj[key] = obj[key];
    }
  }
  return newObj;
};

//"1:2:3" -> {"x1":1, "x2":2, "x3":3}
export const strToObj = (str, arr) => {
  const arrNew = (str || "").split(":");
  let obj = {};
  arr.forEach((i) => {
    obj[i] = "-"; // 值不存在就展示-
  });
  if (arr.length === arrNew.length) {
    arr.forEach((i, index) => {
      obj[i] = arrNew[index];
    });
  }
  return obj;
};

// 颜色转换 #b0df0b 》rgba
export function hexToRgba(hex, a) {
  let r = parseInt(hex.slice(1, 3), 16);
  let g = parseInt(hex.slice(3, 5), 16);
  let b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r || 255}, ${g || 0}, ${b || 0}, ${a || 1})`;
}
