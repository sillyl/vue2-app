import { localStorageGetItem } from "@/utils/localStorageFun.js";
import { emergencyStop } from "@/api/cmd";

export const triggerCmd = async function (id, type, action, value, otherVal) {
  const deviceId = localStorageGetItem("curDeviceId");
  const params = {
    deviceId,
    method: type,
    params: value
      ? { id, action, ...value, ...otherVal }
      : { id, action, ...otherVal },
    cache: "0",
    response: "0",
    expired: 100,
    streamType: 0,
    ctrMode: true,
  };
  if (deviceId) {
    await emergencyStop(params);
  }
};
