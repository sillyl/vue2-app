<template>
  <div class="jsonSchema_content" :id="jsonSchemaId" :key="jsonSchemaId">
    <div v-for="(item, idx) in jsonData" :key="item + idx">
      <el-alert
        v-if="item.groupName"
        :title="item.groupName"
        type="success"
        center
        :closable="false"
      />
      <SliderNumberGroup :data="getSliderNumberGroup(item)" />
      <ButtonGroup :data="getButonGroup(item)" />
      <NippleGroup :data="getNippleGroup(item)" />
      <!-- <ButtonOptionsGroup :data="getButtonOptionsGroup(item)" /> -->
      <CheckBoxCustom
        v-if="
          item?.group?.filter((i) => i.type === 5 && i.id === 941)?.length > 0
        "
        :data="getCheckBoxCustom(item)"
        :videoUrls="videoUrls"
        :videoCheckBox="videoCheckBox"
        :videoCheckBoxIndex="videoCheckBoxIndex"
        :basicInfo="basicInfo"
      />
      <SquaredBtnsGroup :data="getSquaredBtnsGroup(item)" />
      <div
        v-if="item.split"
        class="split_H"
        :style="{ height: (item.split || 0) + 'px' }"
      />
    </div>
  </div>
</template>

<script>
import SliderNumberGroup from "./SliderNumberGroup.vue";
import ButtonGroup from "./ButtonGroup.vue";
import NippleGroup from "./NippleGroup.vue";
// import ButtonOptionsGroup from "./ButtonOptionsGroup.vue";
import CheckBoxCustom from "../CheckBoxCustum/Index.vue";
import SquaredBtnsGroup from "./SquaredBtnsGroup.vue";

export default {
  props: [
    "jsonData",
    "jsonSchemaId",
    "videoUrls",
    "basicInfo",
    "videoCheckBox",
    "videoCheckBoxIndex",
  ],
  data() {
    return {};
  },
  components: {
    SliderNumberGroup,
    ButtonGroup,
    NippleGroup,
    // ButtonOptionsGroup,
    CheckBoxCustom,
    SquaredBtnsGroup,
  },

  methods: {
    getSliderNumberGroup: function (item) {
      const group = item?.group;
      // 得到本组 渲染SliderNumberGroup 的数据
      const data = group?.map((i) => {
        let idStart = String(i?.id).substr(0, 2);
        if (
          idStart === "92" &&
          (i?.type === 1 || i?.type === 2 || i?.type === 3)
        ) {
          return { ...i };
        }
      });
      return { ...item, group: data?.filter(Boolean) };
    },

    getButonGroup: function (item) {
      const group = item?.group;
      const data = group?.map((i) => {
        let idStart = String(i?.id).substr(0, 2);
        if (
          idStart === "30" &&
          (i?.type === 4 || i?.type === 2 || i?.type === 3)
        ) {
          return { ...i };
        }
        if (idStart === "11" && (i?.type === 2 || i?.type === 3)) {
          return { ...i };
        }
        if (idStart === "10" && i?.type === 4) {
          return { ...i };
        }
        if (
          (idStart === "31" ||
            idStart === "32" ||
            idStart === "33" ||
            idStart === "34" ||
            idStart === "35" ||
            idStart === "36" ||
            idStart === "37" ||
            idStart === "38" ||
            idStart === "39" ||
            idStart === "90" ||
            idStart === "91" ||
            idStart === "93" ||
            idStart === "96" ||
            idStart === "97") &&
          i?.type === 2
        ) {
          return { ...i };
        }
        if (idStart === "95") {
          return { ...i };
        }
      });
      return { ...item, group: data?.filter(Boolean) };
    },

    getButtonOptionsGroup: function (item) {
      const group = item?.group;
      const data = group?.map((i) => {
        let idStart = String(i?.id).substr(0, 2);
        if (idStart === "10" && i?.type === 1) {
          return { ...i };
        }
      });
      return { ...item, group: data?.filter(Boolean) };
    },

    getNippleGroup: function (item) {
      const group = item?.group;
      const data = group?.map((i) => {
        let idStart = String(i?.id).substr(0, 2);
        if (idStart === "10" && i?.type === 1) {
          const { lockX, lockY, desc } = this.getDirection(i?.packages);
          return { ...i, lockX, lockY, desc };
        }
      });
      const res = data?.filter(Boolean);
      if (res?.length > 0) {
        return { ...item, group: data?.filter(Boolean) };
      }
      return null;
    },

    // 以当前的数据结构 兼容渲染 摇杆组件，以后最好单独给该组件设定数据结构
    getDirection: function (packages) {
      // 1: 前进， 2： 后退， 3： 左转， 4 右转
      let obj = { lockX: false, lockY: false };
      const filterAction = packages
        ?.filter((i) => i.action !== 99)
        ?.sort((a, b) => a.action - b.action);
      if (filterAction?.length === 2) {
        if (
          filterAction.filter((i) => i.action === 1 || i.action === 2)
            ?.length === 2
        ) {
          obj = {
            lockX: false,
            lockY: true,
            desc: `${filterAction[0]?.name}/${filterAction[1]?.name}`,
          };
        }
        if (
          filterAction.filter((i) => i.action === 3 || i.action === 4)
            ?.length === 2
        ) {
          obj = {
            lockX: true,
            lockY: false,
            desc: `${filterAction[0]?.name}/${filterAction[1]?.name}`,
          };
        }
      }
      return obj;
    },

    getCheckBoxCustom: function (item) {
      const group = item?.group;
      const data = group?.map((i) => {
        // 处理展示的视频列表，同时把action 作为ws 参数（重要）
        let videoArr = [];
        for (let k of i.packages) {
          if (k?.action) {
            const url = this.videoUrls[k.action - 1];
            if (url) {
              videoArr.push({ action: k.action, url });
            }
          }
        }
        const newVideoArr = [...videoArr?.filter(Boolean)];
        let idStart = String(i?.id).substr(0, 2);
        if (idStart === "94" && i?.type === 5) {
          return { ...i, videoUrls: newVideoArr };
        }
      });
      return { ...item, group: data?.filter(Boolean) };
    },

    getSquaredBtnsGroup: function (item) {
      const group = item?.group;
      const data = group?.map((i) => {
        let idStart = String(i?.id).substr(0, 2);
        if (idStart === "21" && i?.type === 2) {
          return { ...i };
        }
      });
      return { ...item, group: data?.filter(Boolean) };
    },
  },

  destroyed() {},
};
</script>

<style lang="scss" scoped>
.jsonSchema_content {
  ::v-deep {
    .el-alert {
      margin-bottom: 6px;
      border-radius: 0px;
    }
  }
}
</style>
