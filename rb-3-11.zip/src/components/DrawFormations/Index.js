// 多点绘制一字型
export const drawCountLinePoint = function (count) {
  let arr = [];
  for (let i = 0; i < count; i++) {
    arr.push({
      x: 150 + 50 * i,
      y: 100,
      omega: -90,
    });
  }
  return arr;
};

export const getUvPoints = function (cvsW, cvsH, konavaPoints) {
  let arr = [];
  let arrPoints = [];
  for (let i of konavaPoints) {
    const uvX = (i?.x / cvsW).toFixed(6);
    const uvY = (i?.y / cvsH).toFixed(6);
    arr.push({ x: uvX, y: uvY, omega: i?.omega });
    arrPoints.push({ ...i, uvX, uvY });
  }
  return { uvPoints: arr, points: arrPoints };
};

// 绘制等腰三角形
export const drawIsoscelesTriangle = function () {
  return [
    { x: 280, y: 50, omega: -90 },
    { x: 225, y: 189.55, omega: -90 },
    { x: 335, y: 189.55, omega: -90 },
  ];
};

// 绘制方型

export const drawCountSquarePoint = function () {
  return [
    { x: 50, y: 50, omega: -90 },
    { x: 200, y: 50, omega: -90 },
    { x: 200, y: 200, omega: -90 },
    { x: 50, y: 200, omega: -90 },
  ];
};
