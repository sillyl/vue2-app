<template>
  <div id="draw_formation" class="draw_formation">
    <v-stage
      ref="stageRef"
      class="draw_formation_stage"
      :config="konvaConfig.stage"
      @click="onStageClick"
      @wheel="wheelForScale($event)"
      @touchmove="onArrowTouchmove($event)"
      @touchend="onStageTouchend"
      @mousemove="onArrowMouseMove"
      @mouseup="onArrowMounseup"
    >
      <v-layer>
        <v-group :config="konvaConfig.group">
          <v-line
            v-for="(item, index) in konvaConfig.polyline"
            :key="`line_${index}`"
            :config="{
              points: item,
              stroke: item.color || '#ff0000',
              strokeWidth: 6,
              lineCap: 'round',
              lineJoin: 'round',
              opacity: 0.5,
              closed: curFormationType === 'line' ? false : true,
            }"
          >
          </v-line>
        </v-group>
        <v-group
          :config="konvaConfig.group"
          @mousedown="onArrowMounsedown"
          @mousemove="onArrowMouseMove"
          @touchstart="onArrowTouchstart"
          @touchmove="onArrowTouchmove"
        >
          <v-arrow
            v-for="(item, index) in konvaConfig.points"
            :key="`${item.x}_${item.y}_${item.omega}_${index}_arrow`"
            :config="{
              id: `${item.x}_${item.y}_${item.omega}_${index}_arrow`,
              x: item.x,
              y: item.y,
              points: [
                0,
                0,
                40 * Math.cos((item.omega * Math.PI) / 180),
                40 * Math.sin((item.omega * Math.PI) / 180),
              ],
              pointerLength: 30,
              pointerWidth: 15,
              fill: item?.color || '#ff0000',
              stroke: 'black',
              strokeWidth: 2,
            }"
          >
          </v-arrow>
        </v-group>
        <v-group :config="konvaConfig.group">
          <v-text
            v-for="(item, index) in konvaConfig.points"
            :key="`text_${index}`"
            :config="{
              id: index,
              x: item.x + 20,
              y: item.y - 40,
              text: item?.omega?.toFixed(2),
              fontSize: 10,
              fontFamily: 'Calibri',
              fill: 'green',
            }"
          >
          </v-text>
        </v-group>
        <v-group :config="konvaConfig.group">
          <v-text
            v-for="(item, index) in konvaConfig.textPointsLoation"
            :key="`text_${index}`"
            :config="{
              id: index,
              x: item.xT,
              y: item.yT,
              text: item?.text,
              fontSize: 10,
              fontFamily: 'Calibri',
              fill: 'green',
            }"
          >
          </v-text>
        </v-group>
        <v-group
          :config="konvaConfig.group"
          @dragstart="onDragCircleStart"
          @dragmove="onDragCircleMove"
          @dragend="onDragCircleEnd"
        >
          <v-circle
            name="circle_point"
            v-for="(item, index) in konvaConfig.points"
            :key="index"
            :config="{
              id: index,
              x: item.x,
              y: item.y,
              radius: 6,
              fill: item?.color || '#ff0000',
              opacity: 0.6,
            }"
            :draggable="isSave ? false : true"
          >
          </v-circle>
        </v-group>
      </v-layer>
    </v-stage>
  </div>
</template>

<script>
let lastDist;
let lastCenter;
import { getCenter, getDistance } from "@/utils/CoordinatePickupFun.js";
import { isEqual } from "lodash";
// import { formationTypeObj } from "@/views/Task/constants";
import {
  drawCountLinePoint,
  getUvPoints,
  drawIsoscelesTriangle,
  drawCountSquarePoint,
} from "./Index.js";

export default {
  props: [
    "formationType",
    "pointCounts",
    "curSpaced",
    "curFormationType",
    "drawFormationsData",
  ],
  data() {
    return {
      konvaConfig: {
        stage: {
          width: 700,
          height: 200,
        },
        group: {
          x: 0,
          y: 0,
        },
        polyline: [],
        points: [],
        textPointsLoation: [], // 存放位置信息点的坐标
      },
      stageScale: 1,
      points: [],
      stagePointerPosition: {
        x: 0,
        y: 0,
      },
      cvsW: null,
      cvsH: null,
      curMoveArrowId: "", // 鼠标当前移动箭头标识
      curSelectCircleId: "", // 当前选中圆标识
      isSave: false, // 标识是否点击保存
    };
  },

  mounted() {
    this.generateStage();
    this.computedDefaultFormation();
  },

  watch: {
    curSpaced: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.getTextPointsLoation(newVal);
      }
    },

    curFormationType: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.clearFormations();
        this.computedDefaultFormation(newVal);
      }
    },
  },

  methods: {
    generateStage() {
      // 将画布自适应屏幕空间大小
      const dom = document.querySelector("#draw_formation");
      const { width, height } = dom.getBoundingClientRect();
      this.konvaConfig.stage.width = width;
      this.konvaConfig.stage.height = height;
      this.cvsW = width;
      this.cvsH = height;
    },

    // 处理默认定制队形
    computedDefaultFormation: async function (curFormationType) {
      switch (this.curFormationType || curFormationType) {
        case "line": {
          const res = await drawCountLinePoint(this.pointCounts);
          const { uvPoints, points } = getUvPoints(this.cvsW, this.cvsH, res);
          this.konvaConfig.points = points;
          this.points = uvPoints;
          this.resetDrawPloyline();
          break;
        }
        case "isoscelesTriangle": {
          const res = drawIsoscelesTriangle();
          const { uvPoints, points } = getUvPoints(this.cvsW, this.cvsH, res);
          this.konvaConfig.points = points;
          this.points = uvPoints;
          this.resetDrawPloyline();
          break;
        }
        case "square": {
          const res = drawCountSquarePoint();
          const { uvPoints, points } = getUvPoints(this.cvsW, this.cvsH, res);
          this.konvaConfig.points = points;
          this.points = uvPoints;
          this.resetDrawPloyline();
          break;
        }
        case "saveDrawCustom": {
          const res = this.drawFormationsData;
          const { uvPoints, points } = getUvPoints(this.cvsW, this.cvsH, res);
          this.konvaConfig.points = points;
          this.points = uvPoints;
          this.resetDrawPloyline();
          break;
        }
        default:
          break;
      }
    },

    onStageClick: function (e) {
      if (
        this.konvaConfig.points?.length >= this.pointCounts &&
        !this.curMoveArrowId &&
        !this.curSelectCircleId
      ) {
        this.$message({
          type: "info",
          message: "点的数量不允许超过设备数量！",
        });
        return;
      }
      if (this.isSave === true) return;
      const { layerX, layerY } = e.evt;
      const { x, y } = this.stagePointerPosition;
      const cx = (layerX - (x || 0)) / this.stageScale;
      const cy = (layerY - (y || 0)) / this.stageScale;
      const uvX = ((layerX - (x || 0)) / (this.cvsW * this.stageScale)).toFixed(
        6
      );
      const uvY = ((layerY - (y || 0)) / (this.cvsH * this.stageScale)).toFixed(
        6
      );
      const obj = { x: cx, y: cy, omega: -90, uvX, uvY };
      // 点击圆 不再添加
      // e.target.attrs?.name !== "circle_point";
      if (
        !e.target.attrs?.id &&
        !this.curMoveArrowId &&
        !this.curSelectCircleId &&
        (!this.formationType || this.formationType === "custom")
      ) {
        this.konvaConfig.points.push(obj);
        this.points.push({ x: uvX, y: uvY, omega: obj?.omega });
        this.resetDrawPloyline();
      }
    },
    wheelForScale: function (e) {
      if (this.isSave === true) return;
      e.evt.preventDefault();
      const scaleBy = 1.01;
      const stage = this.$refs.stageRef.getStage();
      const oldScale = stage.scaleX();
      const mousePointTo = {
        x: stage.getPointerPosition().x / oldScale - stage.x() / oldScale,
        y: stage.getPointerPosition().y / oldScale - stage.y() / oldScale,
      };
      const newScale =
        e.evt.deltaY > 0 ? oldScale * scaleBy : oldScale / scaleBy;
      stage.scale({ x: newScale, y: newScale });
      this.$nextTick(() => {
        stage.x(
          (-mousePointTo.x + stage.getPointerPosition().x / newScale) * newScale
        );
        stage.y(
          (-mousePointTo.y + stage.getPointerPosition().y / newScale) * newScale
        );
        stage.batchDraw();
        const scale = e.evt.deltaY > 0 ? scaleBy : 1 / scaleBy;
        this.stageScale = newScale;
        this.stagePointerPosition = {
          x: stage.x(),
          y: stage.y(),
        };
      });
    },

    onStageTouchend: function () {
      if (this.isSave === true) return;
      lastDist = 0;
      lastCenter = null;
    },

    onArrowMounsedown: function (e) {
      if (this.isSave === true) return;
      // id: x_y_arrow
      if (e.target?.attrs?.id?.includes("arrow")) {
        this.curMoveArrowId = e.target?.attrs?.id;
      }
    },

    onArrowMouseMove: function (e) {
      if (this.isSave === true) return;
      const { layerX, layerY } = e.evt;
      if (this.curMoveArrowId) {
        const [x, y] = this.curMoveArrowId.split("_");
        const L = layerX - x;
        const T = layerY - y;
        const angle = Math.atan2(T - 0, L - 0);
        const idx = this.konvaConfig.points.findIndex(
          (i) => i.x === Number(x) && i.y === Number(y)
        );
        if (idx > -1) {
          const omega = angle / (Math.PI / 180);
          this.konvaConfig.points[idx].omega = omega;
          this.points[idx].omega = omega;
        }
      }
    },

    onArrowMounseup: function () {
      if (this.isSave === true) return;
      this.curMoveArrowId = null;
    },

    onArrowTouchstart: function (e) {
      if (this.isSave === true) return;
      if (e.target?.attrs?.id?.includes("arrow")) {
        this.curMoveArrowId = e.target?.attrs?.id;
      }
    },

    onArrowTouchmove: function (e) {
      if (this.isSave === true) return;
      const touch1 = e.evt.touches[0];
      const touch2 = e.evt.touches[1];
      if (touch1 && !touch2 && this.curMoveArrowId) {
        const { pageX, pageY } = touch1;
        const dom = document.getElementById("draw_formation");
        const pageDom = document.querySelector(".robot-body");
        const { width, height } = pageDom.getBoundingClientRect();
        const domWH = dom.getBoundingClientRect();
        const H = height - domWH?.height;
        const [X, Y] = this.curMoveArrowId.split("_");
        const cxL = pageX - dom.offsetLeft + dom.scrollLeft;
        const cyT = pageY - dom.offsetTop + dom.scrollTop - H;
        const L = cxL - X;
        const T = cyT - Y;
        const angle = Math.atan2(T - 0, L - 0);
        const idx = this.konvaConfig.points.findIndex(
          (i) => i.x === Number(X) && i.y === Number(Y)
        );
        if (idx > -1) {
          const omega = angle / (Math.PI / 180);
          this.konvaConfig.points[idx].omega = omega;
          this.points[idx].omega = omega;
        }
      }
      if (touch1 && touch2) {
        e.evt.preventDefault();
        const dom = document.getElementById("draw_formation");
        const pageDom = document.querySelector(".robot-body");
        const { height } = pageDom.getBoundingClientRect();
        const domWH = dom.getBoundingClientRect();
        const H = height - domWH?.height;
        const stage = this.$refs.stageRef.getStage();
        this.konvaConfig.stage.draggable = false; // 缩放时，禁掉拖拽，两者冲突会导致缩放失效
        const p1 = {
          x: touch1.pageX - dom.offsetLeft + dom.scrollLeft,
          y: touch1.pageY - dom.offsetTop + dom.scrollTop - H,
        };
        const p2 = {
          x: touch2.pageX - dom.offsetLeft + dom.scrollLeft,
          y: touch2.pageY - dom.offsetTop + dom.scrollTop - H,
        };

        if (!lastCenter) {
          lastCenter = getCenter(p1, p2);
          return;
        }

        if (!lastDist) {
          lastDist = getDistance(p1, p2);
        }
        const newCenter = getCenter(p1, p2); // 缩放中心
        const newDist = getDistance(p1, p2); // 两指距离
        const pointTo = {
          x: (newCenter.x - stage.x()) / stage.scaleX(),
          y: (newCenter.y - stage.y()) / stage.scaleX(),
        };

        const scale = stage.scaleX() * (newDist / lastDist);
        // 用于子组件的位置更新
        this.stageScale = scale;
        this.stagePointerPosition = {
          x: stage.x(),
          y: stage.y(),
        };
        stage.scale({ x: scale, y: scale });
        const dx = newCenter.x - lastCenter.x;
        const dy = newCenter.y - lastCenter.y;
        const newPos = {
          x: newCenter.x - pointTo.x * scale + dx,
          y: newCenter.y - pointTo.y * scale + dy,
        };
        stage.position(newPos);
        lastDist = newDist;
        lastCenter = newCenter;
      }
    },

    onDragCircleStart: function (e) {
      if (this.isSave === true) return;
      e.cancelBubble = true;
      this.curSelectCircleId = e.target?.attrs?.id;
    },

    onDragCircleMove: function (e) {
      if (this.isSave === true) return;
      const { layerX, layerY, type } = e.evt;
      const id = Number(this.curSelectCircleId);
      const { x, y } = this.stagePointerPosition;
      let cx = 0;
      let cy = 0;
      let uvX = 0;
      let uvY = 0;
      if (type === "touchmove") {
        const touch1 = e.evt.touches[0];
        const { pageX, pageY } = touch1;
        const dom = document.getElementById("draw_formation");
        const pageDom = document.querySelector(".robot-body");
        const { height } = pageDom.getBoundingClientRect();
        const domWH = dom.getBoundingClientRect();
        const H = height - domWH?.height;
        const cxL = pageX - dom.offsetLeft + dom.scrollLeft;
        const cyT = pageY - dom.offsetTop + dom.scrollTop - H;
        cx = (cxL - (x || 0)) / this.stageScale;
        cy = (cyT - (y || 0)) / this.stageScale;
        uvX = ((cxL - (x || 0)) / (this.cvsW * this.stageScale)).toFixed(6);
        uvY = ((cyT - (y || 0)) / (this.cvsH * this.stageScale)).toFixed(6);
      }
      if (type === "mousemove") {
        cx = (layerX - (x || 0)) / this.stageScale;
        cy = (layerY - (y || 0)) / this.stageScale;
        uvX = ((layerX - (x || 0)) / (this.cvsW * this.stageScale)).toFixed(6);
        uvY = ((layerY - (y || 0)) / (this.cvsH * this.stageScale)).toFixed(6);
        // 更新拖拽结束数据
      }
      if (id > -1) {
        this.konvaConfig.points[id].x = cx;
        this.konvaConfig.points[id].y = cy;
        this.konvaConfig.points[id].uvX = uvX;
        this.konvaConfig.points[id].uvY = uvY;
        this.points[id].x = uvX;
        this.points[id].y = uvY;
        this.resetDrawPloyline();
      }
    },

    onDragCircleEnd: function (e) {
      if (this.isSave === true) return;
      // const { layerX, layerY, type } = e.evt;
      // const id = Number(this.curSelectCircleId);
      // const { x, y } = this.stagePointerPosition;
      // let cx = 0;
      // let cy = 0;
      // let uvX = 0;
      // let uvY = 0;
      // if (type === "touchend") {
      //   const touch1 = e.evt.touches[0];
      //   const { pageX, pageY } = touch1;
      //   const dom = document.getElementById("draw_formation");
      //   const pageDom = document.querySelector(".robot-body");
      //   const { height } = pageDom.getBoundingClientRect();
      //   const domWH = dom.getBoundingClientRect();
      //   const H = height - domWH?.height;
      //   const cxL = pageX - dom.offsetLeft + dom.scrollLeft;
      //   const cyT = pageY - dom.offsetTop + dom.scrollTop - H;
      //   cx = (cxL - (x || 0)) / this.stageScale;
      //   cy = (cyT - (y || 0)) / this.stageScale;
      //   uvX = ((cxL - (x || 0)) / (this.cvsW * this.stageScale)).toFixed(6);
      //   uvY = ((cyT - (y || 0)) / (this.cvsH * this.stageScale)).toFixed(6);
      // }
      // if (type === "mouseup") {
      //   cx = (layerX - (x || 0)) / this.stageScale;
      //   cy = (layerY - (y || 0)) / this.stageScale;
      //   uvX = ((layerX - (x || 0)) / (this.cvsW * this.stageScale)).toFixed(6);
      //   uvY = ((layerY - (y || 0)) / (this.cvsH * this.stageScale)).toFixed(6);
      //   // 更新拖拽结束数据
      // }
      // if (id > -1) {
      //   this.konvaConfig.points[id].x = cx;
      //   this.konvaConfig.points[id].y = cy;
      //   this.konvaConfig.points[id].x = uvX;
      //   this.konvaConfig.points[id].y = uvY;
      //   this.points[id].x = uvX;
      //   this.points[id].y = uvY;
      //   this.resetDrawPloyline();
      // }
      this.curSelectCircleId = null;
    },

    // 绘制线条
    resetDrawPloyline: function () {
      // 画线前先清掉 重绘
      this.konvaConfig.polyline = [];
      const pointArr = [];
      for (let i = 0; i < this.konvaConfig.points.length; i++) {
        pointArr.push(
          this.konvaConfig.points[i].x,
          this.konvaConfig.points[i].y
        );
      }
      if (pointArr.length >= 4) {
        this.konvaConfig.polyline.push(pointArr);
        this.getTextPointsLoation(); // 满足绘制线时，即绘制线条距离文字
      }
    },

    // 计算绘制文字在哪个位置显示
    getTextPointsLoation: function (curSpaced) {
      const points = this.konvaConfig.points;
      const len = points?.length;
      this.konvaConfig.textPointsLoation = [];
      // if (this.curFormationType === "line") {
      for (let i = 0; i < points.length - 1; i++) {
        const { x, y } = getCenter(points[i], points[i + 1]);
        let instance = getDistance(points[i], points[i + 1]);
        const realInstance = (
          instance * (curSpaced || this.curSpaced)
        )?.toFixed(2);
        instance = instance.toFixed(2);
        this.konvaConfig.textPointsLoation.push({
          xT: x - 15,
          yT: y + 10 * i,
          text: realInstance ? `${instance}px/${realInstance}m` : "",
        });
      }
      if (this.curFormationType !== "line" && len > 2) {
        // 有闭合且点两个以上
        const { x, y } = getCenter(points[0], points[len - 1]);
        let instance = getDistance(points[0], points[len - 1]);
        const realInstance = (
          instance * (curSpaced || this.curSpaced)
        )?.toFixed(2);
        instance = instance.toFixed(2);
        this.konvaConfig.textPointsLoation.push({
          xT: x - 15,
          yT: y + 10,
          text: realInstance ? `${instance}px/${realInstance}m` : "",
        });
      }
      // } else {
      // for (let i = 0; i < points.length; i++) {
      //   for (let j = 0; j < points.length; j++) {
      //     if (i === j) {
      //       continue;
      //     } else {
      //       const { x, y } = getCenter(points[i], points[j]);
      //       const instance = getDistance(points[i], points[j]);
      //       const spaced = (
      //         instance * (curSpaced || this.curSpaced)
      //       )?.toFixed(2);
      //       this.konvaConfig.textPointsLoation.push({
      //         x,
      //         y,
      //         text: spaced ? `${spaced}m` : "",
      //       });
      //     }
      //   }
      // }
      // }
    },

    // 保存按钮 用于点之间的闭合连线
    saveFormations: function () {
      this.$message({
        type: "warning",
        message: "连线后将不可操作画板, 如若更新请点击 取消连线 按钮！",
      });
      if (!this.isSave) {
        const pointArr = [];
        for (let i = 0; i < this.konvaConfig.points.length; i++) {
          pointArr.splice(
            pointArr.length,
            0,
            this.konvaConfig.points[i].x,
            this.konvaConfig.points[i].y
          );
        }
        if (pointArr.length >= 4) {
          this.konvaConfig.polyline.push(pointArr);
        }
      }
      this.isSave = true;
    },

    cancelSaveFormations: function () {
      this.isSave = false;
      this.konvaConfig.polyline = [];
    },

    clearFormations: function () {
      this.isSave = false;
      this.konvaConfig.polyline = [];
      this.konvaConfig.points = [];
      this.points = [];
      this.konvaConfig.textPointsLoation = [];
    },
  },

  destroyed() {
    //
  },
};
</script>

<style lang="scss">
@import "@/assets/css/common.scss";
.draw_formation {
  height: 100%;
  background-image: linear-gradient(
      to bottom,
      transparent 9px,
      rgb(241, 239, 239) 1px
    ),
    linear-gradient(to right, transparent 9px, rgb(242, 239, 239) 1px);
  background-size: 10px 10px;
  background-repeat: repeat;

  &_stage {
    height: 100%;
  }
}
</style>
