<template>
  <div class="stop_btn" @click="onClick">
    <div class="stop_btn_inner">
      {{ txt || (data?.deviceStatus === 0 ? "急 停" : "恢 复") }}
    </div>
  </div>
</template>

<script>
import { emergencyStop } from "@/api/cmd.js";

export default {
  name: "StopButton",
  props: ["clickFun", "data", "title", "getDeviceBasicInfo", "getTaskDetail"],
  data() {
    return {
      operatorCmd: {
        deviceId: this.data && this.data.id,
        method: "EmergencyStop",
        params: {
          action: this.data && this.data.deviceStatus === 0 ? 1 : 0 || 1,
        },
        cache: "0",
        response: "0",
        expired: 100,
        streamType: 0,
      },
      txt: this.title,
    };
  },
  methods: {
    onClick: async function () {
      if (this.clickFun) {
        this.clickFun();
        return;
      }
      let params = this.operatorCmd;
      this.operatorCmd.params.action =
        this.data && this.data?.deviceStatus
          ? this.data && this.data?.deviceStatus === 0
            ? 1
            : 0
          : 1;
      params = this.operatorCmd;

      const len = this.data?.deviceIds?.length;
      if (len > 0) {
        // 急停任务下所有的设备
        for (let i = 0; i < len; i++) {
          params = { ...params, deviceId: this.data.deviceIds[i] };
          await emergencyStop(params);
        }
      } else {
        await emergencyStop(params);
      }
      // getDeviceBasicInfo 设备-情景控制操作急停之后更新info获取自信的deviceStatus
      if (this.getDeviceBasicInfo) {
        this.getDeviceBasicInfo(true);
      }

      if (this.getTaskDetail) {
        this.getTaskDetail();
      }
    },
  },
};
</script>

<style lang="scss" scoped>
@import "@/assets/css/common.scss";
.stop_btn {
  position: relative;
  width: 80px;
  height: 80px;
  background-color: red;
  border-radius: 50%;
  border: 5px solid #dcdfe6;
  animation: stopBtnBorderFlash 2s infinite;

  @keyframes stopBtnBorderFlash {
    0% {
      border-color: #ffffff;
      box-shadow: 0 0 5px #ffffff;
    }
    50% {
      border-color: #ff0000;
      box-shadow: 0 0 10px #ff0000;
    }
    100% {
      border-color: #ffffff;
      box-shadow: 0 0 5px #ffffff;
    }
  }

  &_inner {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 100%;
    text-align: center;
  }
}
</style>
