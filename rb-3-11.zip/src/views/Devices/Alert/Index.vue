<template>
  <div class="alert_content">
    <Operations
      ref="optsRef"
      :onSearch="onSearch"
      :onSearchReset="onSearchReset"
    />
    <div class="alert_content_table">
      <el-table
        highlight-current-row
        stripe
        :data="alertDataList"
        ref="alertTableRef"
        height="100%"
        v-loading="alertLoading"
      >
        <el-table-column
          prop="nodeName"
          label="节点名称"
          :formatter="formatterFun"
          column-key="nodeName"
        />
        <el-table-column
          prop="level"
          label="告警等级"
          column-key="level"
          :filters="alarmTypeFilters"
          :filter-method="filterHandler"
        >
          <template slot-scope="scope" v-if="scope.row.level">
            <el-tag :type="alarmTypeTag[scope.row.level]">{{
              alarmType[scope.row.level] ?? "-"
            }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column
          prop="status"
          label="状态"
          :formatter="formatterFun"
          column-key="status"
          :filters="alarmStatusFilters"
          :filter-method="filterStatusMethod"
        >
          <template slot-scope="scope" v-if="scope.row.status">
            <span :style="{ color: alarmStatusColor[scope.row.status] }"
              >{{ alarmStatus[scope.row.status] ?? "-" }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="value" label="告警内容" column-key="value">
          <template slot-scope="scope" v-if="scope.row.value">
            <div v-html="scope.row.value"></div>
          </template>
        </el-table-column>
        <!-- <el-table-column
          prop="result"
          label="处理结果"
          :formatter="formatterFun"
          column-key="result"
        /> -->
        <el-table-column
          prop="alarmTime"
          label="告警时间"
          :formatter="formatterFun"
          column-key="alarmTime"
          sortable
        />
        <el-table-column
          prop="createTime"
          label="创建时间"
          :formatter="formatterFun"
          column-key="createTime"
          sortable
        />
        <el-table-column fixed="right" label="操作" width="100">
          <template slot-scope="scope">
            <el-button
              v-if="scope.row.status === '0'"
              @click="onIngoreClick(scope.row, 'ingore')"
              type="text"
              size="small"
              >忽略</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import Operations from "./Operations.vue";
import { getAlertList } from "@/api/device";
import {
  alarmType,
  alarmTypeTag,
  alarmTypeFilters,
  alarmStatus,
  alarmStatusColor,
  alarmStatusFilters,
} from "@/constants";
import dayjs from "dayjs";
import { AnsiUp } from "ansi_up";

export default {
  props: ["deviceId"],
  data() {
    return {
      alarmType,
      alarmTypeTag,
      alarmTypeFilters,
      alarmStatus,
      alarmStatusColor,
      alarmStatusFilters,
      alertDataList: [],
      ansi_up: new AnsiUp(),
      alertLoading: false,
    };
  },
  watch: {},
  components: {
    Operations,
  },

  async mounted() {
    await this.getAlertListData();
  },

  methods: {
    getAlertListData: async function (startTime, endTime) {
      try {
        this.alertLoading = true;
        const res = await getAlertList({
          deviceId: this.deviceId,
          startTime:
            startTime || new Date().getTime() - 6 * 24 * 60 * 60 * 1000,
          endTime: endTime || new Date().getTime(),
        });

        // const res = [
        //   {
        //     status: "0",
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779585508,
        //     createTime: 1706779585852,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //   },
        //   {
        //     status: "0",
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     status: "0",
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779586020,
        //     value: "Wrong type! ",
        //   },
        //   {
        //     status: "0",
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779585508,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //   },
        //   {
        //     status: "1",
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     status: "1",
        //     level: "1",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779586020,
        //     value: "Wrong type! ",
        //   },
        //   {
        //     status: "1",
        //     level: "0",
        //     nodeName: "robot_communication",
        //     alarmTime: 1708994945283,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //   },
        //   {
        //     status: "2",
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     status: "2",
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779586020,
        //     value: "Wrong type! ",
        //   },
        //   {
        //     status: "2",
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779585508,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //   },
        //   {
        //     status: "2",
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     status: "0",
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1708994925281,
        //     value: "Wrong type! ",
        //   },
        //   {
        //     status: "0",
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779585508,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //   },
        //   {
        //     status: "0",
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     status: "0",
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779586020,
        //     value: "Wrong type! ",
        //   },
        //   {
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1708994925281,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //   },
        //   {
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779586020,
        //     value: "Wrong type! ",
        //   },
        //   {
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1708994918283,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //   },
        //   {
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779586020,
        //     value: "Wrong type! ",
        //   },
        //   {
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779585508,
        //     value:
        //       "There is no key \u001B[1;33midentity\u001B[0m in json data!",
        //   },
        //   {
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1706779585852,
        //     value: "There is no key \u001B[1;33mtype\u001B[0m in json data!",
        //   },
        //   {
        //     level: "2",
        //     nodeName: "robot_communication",
        //     alarmTime: 1708994883271,
        //     value: "Wrong type! ",
        //   },
        // ];

        this.alertDataList = res.map((i) => {
          return {
            ...i,
            value: this.ansi_up.ansi_to_html(i?.value),
          };
        });
        this.alertLoading = false;
      } catch (error) {
        console.log("api error", error);
      } finally {
        this.alertLoading = false;
      }
    },

    formatterFun(row, column) {
      const { columnKey } = column;
      switch (columnKey) {
        case "alarmTime": {
          return row[columnKey]
            ? dayjs(row[columnKey]).format("YYYY-MM-DD HH:mm:ss")
            : "-";
        }
        case "createTime": {
          return row[columnKey]
            ? dayjs(row[columnKey]).format("YYYY-MM-DD HH:mm:ss")
            : "-";
        }
        default:
          return row[columnKey] || "-";
      }
    },

    filterHandler: function (value, row, column) {
      const property = column["property"];
      return row[property] === value;
    },

    filterStatusMethod: function (value, row, column) {
      const property = column["property"];
      return row[property] === value;
    },

    clearFilter() {
      this.$refs.alertTableRef.clearFilter();
    },

    onSearch: function (time) {
      this.getAlertListData(time?.[0]?.startTime, time?.[1]?.endTime);
    },

    onSearchReset: function () {
      this.alertDataList = this.alertData;
      this.clearFilter();
      if (this.$refs.optsRef) {
        this.$refs.optsRef.formInline.selectTime = [];
      }
    },

    onIngoreClick: function (row, type) {
      console.log("row, type", row, type);
    },
  },

  destroyed() {
    this.alertData = [];
    this.alertDataList = [];
    this.alertLoading = false;
  },
};
</script>

<style lang="scss" scoped>
@import "./Index.scss";
</style>
