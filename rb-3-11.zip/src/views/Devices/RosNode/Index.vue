<template>
  <div class="ros_node_table" v-if="rosNodeData.length > 0">
    <div class="ros_node_table_opts">
      <el-tooltip
        class="item"
        content="点击设置节点存在勾选节点为启用节点，不勾选则是关闭节点！"
        placement="top-start"
        effect="light"
      >
        <i class="el-icon-question"></i>
      </el-tooltip>
      <el-button type="primary" @click="onSaveBtnClick">设置节点</el-button>
    </div>
    <el-table
      highlight-current-row
      stripe
      :data="rosNodeData"
      ref="rosNodeTableRef"
      height="calc(100% - 58px)"
      v-loading="tableLoading"
      :cell-style="cellStyle"
      :header-cell-style="cellHeaderStyle"
      @selection-change="selectChange"
      size="small"
    >
      <el-table-column
        prop="name"
        label="节点名称"
        :formatter="formatterFun"
        column-key="name"
      />
      <el-table-column
        prop="type"
        label="节点类型"
        column-key="type"
        :formatter="formatterFun"
      />
      <el-table-column type="selection" width="42" align="center">
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import { getRosNode, enableNode } from "@/api/node";
import { rosNodeStatus } from "../constants/index.js";
export default {
  props: ["deviceId"],
  data() {
    return {
      rosNodeData: [],
      tableLoading: false,
      selectionList: [],
    };
  },

  mounted() {
    this.getTableData();
  },

  methods: {
    getTableData: async function () {
      try {
        this.tableLoading = true;
        if (this.deviceId) {
          this.rosNodeData = await getRosNode({ deviceId: this.deviceId });
        }
      } finally {
        this.tableLoading = false;
      }
    },

    formatterFun(row, column) {
      const { columnKey } = column;
      switch (columnKey) {
        case "type":
          return rosNodeStatus[row[columnKey]] || "-";
        default:
          return row[columnKey] || "-";
      }
    },

    selectChange(selection, row) {
      this.selectionList = selection;
    },

    cellStyle: function () {
      return "background-color: #2e4552; color: #000";
    },

    cellHeaderStyle: function () {
      return "background-color: rgb(100 169 209); color: #000";
    },

    onSaveBtnClick: async function () {
      // if (this.selectionList?.length === 0) {
      //   this.$message({
      //     type: "warning",
      //     message: "请先勾选需要启用的节点!",
      //   });
      //   return;
      // }
      const names = this.selectionList.map((i) => i.name);
      await enableNode({
        id: this.deviceId,
        nodeNames: names,
      });
    },
  },
};
</script>

<style lang="scss" scoped>
@import "@/assets/css/common.scss";
.ros_node_table {
  height: calc(100% - 240px);

  &_opts {
    float: right;
    padding: 9px 0px;

    i {
      color: aliceblue;
      font-size: 24px;
      margin-right: 8px;
    }
  }

  .el-table {
    background-color: $bg-color;
    border-top: 1px solid #fff;
  }
}
</style>
