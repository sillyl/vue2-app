export const basicInfoObj = {
  id: "设备ID",
  name: "设备名称",
  sn: "设备号",
  productName: "所属产品",
  curSceneName: "当前场景",
  curTaskName: "当前任务",
  curMapName: "当前地图",
  location: "安装地址",
  videoUrls: "视频地址",
  createTime: "注册时间",
};

export const deviceStatus = {
  true: "Running", // 启动
  false: "Pause", // 暂停
  2: "Complete", // 取消
  3: "Cancel", // 终止
};

// 设备在线诊断状态
export const onlineNodeStatus = {
  0: "正常",
  1: "异常",
};

export const rosNodeStatus = {
  0: "软件节点",
  1: "硬件节点",
};
