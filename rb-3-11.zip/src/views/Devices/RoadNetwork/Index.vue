<template>
  <div class="road_network">
    <PgmKonva
      ref="pgmKonvaRoadRef"
      :wsData="wsData"
      :mapId="mapId"
      :wsPlanGlobalPaths="wsPlanGlobalPaths"
      :wsPlanPartPaths="wsPlanPartPaths"
      :wsPlanSitePaths="wsPlanSitePaths"
      :isExpendedDesc="true"
      :isArrow="isArrow"
    />
    <CustomCollapse>
      <el-row class="road_network_collapase">
        <el-col :span="9">
          <p>
            地图列表：
            <el-select
              v-model="mapId"
              placeholder="请选择"
              @change="onChangeMap"
            >
              <el-option
                v-for="item in mapList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select>
          </p>
        </el-col>
        <el-col :span="9" class="road_network_set_points">
          <div class="road_network_btns">
            采点设置：<el-button type="primary" @click="onClickArrowPoints"
              >拾取站点</el-button
            >
            <el-button type="primary" @click="onClearArrowPoint"
              >清空站点</el-button
            >
          </div>
          <div class="road_network_curBtn">
            <el-button type="primary" @click="onCurPointClick"
              >当前位置点添加为站点</el-button
            >
          </div>
        </el-col>
        <el-col :span="6">
          <el-button
            type="primary"
            class="road_network_SavaSetting"
            @click="onSavaSetting"
          >
            保存路网设置
          </el-button>
        </el-col>
      </el-row>
    </CustomCollapse>
  </div>
</template>

<script>
import PgmKonva from "@/views/Scenes/components/PgmKonvaScene/Index.vue";
import CustomCollapse from "@/components/CustomCollapse/Index.vue";
import { getMapMenuList } from "@/api/map.js";

export default {
  props: [
    "deviceId",
    "wsData",
    "wsPlanGlobalPaths",
    "wsPlanPartPaths",
    "wsPlanSitePaths",
    "curPoint",
  ],
  data() {
    return { curMapId: "", mapList: [], mapId: "", isArrow: false };
  },
  components: {
    PgmKonva,
    CustomCollapse,
  },

  async mounted() {
    await this.getMapList();
  },

  methods: {
    getMapList: async function () {
      try {
        const res = await getMapMenuList();
        // 瓦片图
        this.mapList = res?.filter((i) => i?.type === 0);
        const len = this.mapList?.length;
        this.mapId = len > 0 ? this.mapList[len - 1]?.id : "";
      } catch (error) {
        this.mapList = [];
      }
    },

    onChangeMap: function () {
      if (this.$refs?.pgmKonvaRoadRef) {
        this.$refs.pgmKonvaRoadRef.resetPoint();
      }
      this.isArrow = false;
    },

    onClickArrowPoints: function () {
      this.isArrow = true;
    },

    onClearArrowPoint: function () {
      if (this.$refs.pgmKonvaRoadRef) {
        this.$refs.pgmKonvaRoadRef.resetArrowPointData();
      }
    },

    onCurPointClick: function () {
      if (this.isEmpty(this.curPoint)) {
        this.$message({
          type: "warning",
          message: "当前点为空！",
        });
        return;
      } else {
        this.$refs?.pgmKonvaRoadRef?.saveCurArrowPoint(this.curPoint);
      }
    },

    onSavaSetting: function () {
      console.log("...........", this.$refs?.pgmKonvaRoadRef.arrowPoints);
    },
  },
};
</script>

<style lang="scss">
@import "./Index.scss";
</style>
