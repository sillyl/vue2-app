<template>
  <div
    class="pgm_konva"
    id="pgmContainer"
    :style="{
      height: $store.state.isCollapse ? '100%' : 'calc(100% - 22px)',
    }"
  >
    <div class="float_div" v-if="pgmData && !isExpendedDesc">
      <div class="icon_isExpended" @click="onClickExpended">
        <span>
          <i class="el-icon-s-unfold" v-if="isExpended" />
          <i class="el-icon-s-fold" v-else />
        </span>
      </div>
      <div v-if="isExpended" class="float_div_content">
        <span class="float_div_title">实时上报数据</span>
        <ul @click="onClickLiItem">
          <li data-key="global" key="global">—• —• 全局规划路径</li>
          <li data-key="part" key="part">— —▶ 局部规划路径</li>
          <li data-key="real" key="real">——•▶ 实际行驶路径</li>
          <li data-key="real" key="site">•••••••• 站点集合</li>
        </ul>
      </div>
    </div>
    <v-stage
      class="konva-stage"
      ref="konvaStage"
      :config="konvaConfig.stage"
      @click="onStageClick"
      @wheel="wheelForScale($event)"
      @touchstart="onStageTouchstart"
      @touchmove="onStageTouchmove($event)"
      @touchend="onStageTouchend"
      v-if="pgmData"
    >
      <!--  @dragstart="onDragstart"
      @dragmove="onDragmove"
      @dragend="onDragend" -->
      <v-layer ref="konvaLayer">
        <v-group :config="konvaConfig.group">
          <v-image
            :config="{
              image: konvaConfig.pgmImage,
            }"
          />
        </v-group>
        <!-- 点云? -->
        <v-group :config="konvaConfig.group">
          <v-circle
            v-for="(item, index) in konvaConfig.cloudPoints"
            :key="index + 4000"
            :config="{
              x: item.x,
              y: item.y,
              radius: 4,
              fill: '#0000ff',
            }"
          >
          </v-circle>
        </v-group>
        <!-- 区域点交互 -->
        <v-group :config="konvaConfig.group">
          <v-line
            v-for="(item, index) in konvaConfig.polygon"
            :key="index"
            :config="{
              id: index,
              points: optsType === 'seleted' ? item.groupPolygon : item,
              stroke: item.color || '#ff0000',
              strokeWidth: 6,
              lineCap: 'round',
              lineJoin: 'round',
              fill: item.color || '#ff0000',
              opacity: 0.5,
              closed: true,
            }"
          >
          </v-line>
        </v-group>
        <v-group :config="konvaConfig.group">
          <v-circle
            name="area_circle"
            v-for="(item, index) in konvaConfig.areaPoints"
            :key="index"
            :config="{
              id: index,
              x: item.x,
              y: item.y,
              radius: 8,
              fill: item.color || '#ff0000',
            }"
            :draggable="
              optsType === 'add' || optsType === 'update' ? true : false
            "
            @dragstart="onDragAreaPointStart"
            @dragmove="onDragAreaPointMove"
          >
          </v-circle>
        </v-group>
        <!-- 导航点交互 -->
        <v-group :config="konvaConfig.group">
          <v-line
            v-for="(item, index) in konvaConfig.polyline"
            :key="index + 1000"
            :config="{
              points: isDetail ? item.groupLine : item,
              stroke: item.color || '#ff0000',
              strokeWidth: 6,
              lineCap: 'round',
              lineJoin: 'round',
              opacity: 0.5,
            }"
          >
          </v-line>
        </v-group>
        <v-group :config="konvaConfig.group">
          <v-circle
            v-for="(item, index) in konvaConfig.points"
            :key="index"
            :config="{
              id: index,
              x: item.x,
              y: item.y,
              radius: 8,
              fill: item?.color || '#ff0000',
            }"
          >
          </v-circle>
        </v-group>
        <v-group :config="konvaConfig.group">
          <v-arrow
            v-for="(item, index) in konvaConfig.points"
            :key="index + 99"
            :config="{
              id: index,
              x: item.x,
              y: item.y,
              points: [
                0,
                0,
                50 * Math.cos((item.omega * Math.PI) / 180),
                50 * Math.sin((item.omega * Math.PI) / 180),
              ],
              pointerLength: 30,
              pointerWidth: 10,
              fill: item?.color || '#ff0000',
              stroke: 'black',
              strokeWidth: 3,
            }"
          >
          </v-arrow>
        </v-group>
        <!-- 路网 箭头 点 -->
        <v-group :config="konvaConfig.group">
          <v-line
            name="arrow_line"
            v-for="(item, index) in konvaConfig.arrowPolylinePoints"
            :key="item + index"
            :config="{
              points: item,
              stroke: item.color || '#ff0000',
              strokeWidth: 2,
              lineCap: 'round',
              lineJoin: 'round',
              opacity: 0.8,
            }"
          >
          </v-line>
          <v-arrow
            v-for="(item, index) in konvaConfig.arrowPoints"
            :key="item + index"
            :config="{
              x: item.x,
              y: item.y,
              visible: item?.angle ? true : false,
              points: [
                0,
                0,
                10 * Math.cos(((item?.angle ?? 10) * Math.PI) / 180),
                10 * Math.sin(((item?.angle ?? 10) * Math.PI) / 180),
              ],
              pointerLength: 10,
              pointerWidth: 5,
              fill: '#ffff00',
              stroke: '#ff0000',
              strokeWidth: 3,
            }"
          >
          </v-arrow>
          <v-circle
            name="arrow_circle"
            v-for="(item, index) in konvaConfig.arrowPoints"
            :key="index"
            :config="{
              id: index,
              x: item.x,
              y: item.y,
              radius: 8,
              fill: item.color || '#FF7F00',
              opacity: 0.5,
            }"
            :draggable="true"
            @click="onSelectPoint(item)"
            @dragstart="onDragAreaPointStart"
            @dragmove="onDragAreaPointMove"
          >
          </v-circle>
        </v-group>
      </v-layer>
      <!-- websoket 实时路线数据(小车实际行驶路径) -->
      <v-layer ref="layerRealPathRef">
        <v-group :config="konvaConfig.group">
          <v-line
            v-for="(item, index) in konvaConfig.path"
            :key="index"
            :config="{
              points: sn ? item.groupLine : item,
              stroke: item?.color || '#ffff00',
              strokeWidth: 6,
              lineCap: 'round',
              lineJoin: 'round',
            }"
          >
          </v-line>
        </v-group>
        <v-group :config="konvaConfig.group">
          <v-circle
            v-for="(item, index) in konvaConfig.curPoint"
            :key="index + 3000"
            :config="{
              x: item.x,
              y: item.y,
              radius: 8,
              fill: item?.color || '#ffff00',
              stroke: 'black',
              strokeWidth: 3,
            }"
          >
          </v-circle>
          <v-arrow
            v-for="(item, index) in konvaConfig.curPoint"
            :key="index + 2000"
            :config="{
              x: item.x,
              y: item.y,
              points: [
                0,
                0,
                50 * Math.cos((item.omega * Math.PI) / 180),
                50 * Math.sin((item.omega * Math.PI) / 180),
              ],
              pointerLength: 30,
              pointerWidth: 10,
              fill: item?.color || '#ffff00',
              stroke: 'black',
              strokeWidth: 3,
            }"
          >
          </v-arrow>
        </v-group>
      </v-layer>
      <!-- wesoket device-plan 全局规划路径（并非所有，而是两个点之间lj） -->
      <v-layer ref="layerGlobalPathRef">
        <v-group :config="konvaConfig.group">
          <v-line
            v-for="(item, index) in konvaConfig.planGlobalPath"
            :key="index"
            :config="{
              points: planGlobalSn ? item.groupLine : item,
              stroke: item?.color || '#228B22',
              strokeWidth: 3,
              lineJoin: 'round',
              dash: [5, 5, 0.01, 15],
              lineCap: 'round',
              tension: 0.5,
            }"
          >
          </v-line>
        </v-group>
      </v-layer>
      <!-- wesoket device-plan 局部规划路径 -->
      <v-layer ref="layerPartPathRef">
        <v-group :config="konvaConfig.group">
          <v-line
            v-for="(item, index) in konvaConfig.planPartPath"
            :key="index"
            :config="{
              points: planPartSn ? item.groupLine : item,
              stroke: item?.color || '#7FFF00',
              strokeWidth: 2,
              lineJoin: 'round',
              dash: [8, 8],
              lineCap: 'round',
              tension: 0.8,
            }"
          >
          </v-line>
        </v-group>
        <v-arrow
          v-for="(item, index) in konvaConfig.curPlanPartPoint"
          :key="item + index"
          :config="{
            x: item.x,
            y: item.y,
            points: [
              0,
              0,
              12 * Math.cos((item.omega * Math.PI) / 180),
              12 * Math.sin((item.omega * Math.PI) / 180),
            ],
            pointerLength: 10,
            pointerWidth: 10,
            fill: item?.color || '#7FFF00',
            stroke: 'black',
            strokeWidth: 1,
          }"
        >
        </v-arrow>
      </v-layer>
      <!-- wesoket device-plan 站点集合 -->
      <v-layer ref="layerSitePathRef">
        <v-group :config="konvaConfig.group">
          <v-line
            v-for="(item, index) in konvaConfig.planSitePath"
            :key="index"
            :config="{
              points: planSitelSn ? item.groupLine : item,
              stroke: item?.color || '#00FF7F',
              strokeWidth: 3,
              lineJoin: 'round',
              dash: [0.01, 4],
              lineCap: 'round',
              tension: 0.5,
            }"
          >
          </v-line>
        </v-group>
      </v-layer>
    </v-stage>
    <NotFound
      v-if="!pgmData"
      desc="暂无地图信息"
      :image="require('@/assets/img/empty.svg')"
    />
    <CoordinatePickup
      :isShow="isShow"
      :visible="visibleCircleTooltip"
      :triggerPosition="triggerPosition"
      :circleNeedData="circleNeedData"
      ref="circleTooltipRef"
      @saveCircleTooltipData="saveCircleTooltipData"
      @deleteCircleTooltipData="deleteCircleTooltipData"
      :isInitPickUp="isInitPickUp"
      :onSaveInitPickup="onSaveInitPickup"
    />
    <AttributeForm
      v-if="isAttributeForm"
      :artFormTop="artFormTop"
      :artFormLeft="artFormLeft"
      :identifierList="identifierList"
      :metaTaskList="metaTaskList"
      :onArtFormDelete="onArtFormDelete"
      :onArtFormSave="onArtFormSave"
      :TaskDetailData="TaskDetailData"
    />
  </div>
</template>
<script>
let timeId;
let lastDist;
let lastCenter;
import CoordinatePickup from "@/components/CoordinatePickup/Index.vue";
import AttributeForm from "../AttributeForm/Index.vue";
import GlobalLoading from "@/components/Loading/Loading.js";
import {
  getMinPoint,
  getKonvaConfigByObj,
  getCenter,
  getDistance,
} from "@/utils/CoordinatePickupFun.js";
import { isEqual, isEmpty, cloneDeep } from "lodash";
import { viewMap } from "@/api/map";
import { MapImage } from "@/utils/mapImg.js";
import { getIdentifierList } from "@/api/identify";
import { getSceneMetaTaskList } from "@/api/task";
import NotFound from "@/components/NotFound/Index.vue";
import { stepPgmLineSegment } from "@/utils/geoposition.js";
import { worldToUv, yaw2Omega } from "@/utils/mapWorldUvConversion";

export default {
  props: [
    "mapId",
    "wsData",
    "isInitPickUp",
    "onSaveInitPickup",
    "isSceneName",
    "deviceId",
    "buildMapping",
    "taskInfoRow",
    "curMethod",
    "selectionList",
    "wsPlanGlobalPaths",
    "wsPlanPartPaths",
    "wsPlanSitePaths",
    "isExpendedDesc", // 不传 默认展示描述说明
    "isArrow", // 用来标识路网
  ],
  data() {
    return {
      pgmData: null,
      konvaConfig: {
        stage: {
          width: 1000,
          height: 1000,
          // draggable: true,
        },
        group: {
          x: 0,
          y: 0,
        },
        pgmImage: null,
        points: [],
        polyline: [],
        polygon: [],
        areaPoints: [],
        arrowPoints: [], // 网格站点
        arrowPolylinePoints: [], // 存放点的箭头连线
        path: [],
        curPoint: [],
        curPlanPartPoint: [],
        cloudPoints: [],
        planGlobalPath: [],
        planPartPath: [],
        planSitePath: [],
      },
      arrowSelectedPoints: [], // 存储所有选择的点
      arrowDrawPoints: [], // 处理绘制箭头的数据
      visibleCircleTooltip: false,
      triggerPosition: {
        layerX: 0,
        layerY: 0,
        clientX: 0,
        clientY: 0,
        pageX: 0,
        pageY: 0,
      },
      threshold: 0.01,
      isTouchStart: false,
      isTouchmoveing: false,
      metaTaskList: [],
      identifierList: [],
      selectPoint: { location: { omega: 0 }, process: [], station: [] },
      stagePointerPosition: {
        x: 0,
        y: 0,
      },
      stageScale: 1,
      // 插入节点的最大数量（包括已删除的），这是个递增值
      historyMaxnodeNum: 0,
      points: new Map(),
      areaPoints: [],
      arrowPoints: [], // 网格站点 uv
      isDraging: false,
      startDragData: null,
      diffLayerX: 0,
      diffLayerY: 0,
      diffClientX: 0,
      diffClientY: 0,
      diffPageX: 0,
      diffPageY: 0,
      cvsW: null,
      cvsH: null,
      isDetail: false,
      isShow: true,
      method: "",
      optsType: "",
      isAttributeForm: false,
      artFormTop: 0,
      artFormLeft: 0,
      infoAreaPoints: [],
      attributeFormData: [],
      curDragAreaPoint: null,
      curDragArrowPoint: null,
      sn: false,
      planGlobalSn: false,
      planPartSn: false,
      planSitelSn: false,
      timeId: null,
      mapWs: null,
      curPath: [], //用于存储device 详情页 device-pose path数据
      curGlobalPath: [],
      curPartPath: [],
      curSitePath: [],
      pixelX: null, // x方向像素大小
      pixelY: null, // y方向像素大小
      originX: null, // 原点坐标x
      originY: null, // 原点左边y
      resolution: null, // 分辨率
      curMethoded: this.curMethod,
      isExpended: true, // 默认展开
    };
  },
  computed: {
    circleNeedData() {
      return {
        stage: {
          width: this.cvsW,
          height: this.cvsH,
        },
        points: this.points,
        threshold: this.threshold,
        id: "pgmContainer",
        isTouchStart: this.isTouchStart,
        isTouchmoveing: this.isTouchmoveing,
        form: {
          omega: 0,
          identifierList: this.identifierList, // 目标物
          metaTaskList: this.metaTaskList, // 动作
          selectPoint: this.selectPoint, // 选择点
        },
        stagePointerPosition: this.stagePointerPosition,
        stageScale: this.stageScale,
        isDraging: this.isDraging,
        diffLayerX: this.diffLayerX,
        diffLayerY: this.diffLayerY,
        diffClientX: this.diffClientX,
        diffClientY: this.diffClientY,
        diffPageX: this.diffPageX,
        diffPageY: this.diffPageY,
      };
    },
  },
  components: {
    CoordinatePickup,
    NotFound,
    AttributeForm,
  },
  async mounted() {
    await this.getCircleData();
    this.replaceWsData(this.wsData);
  },
  watch: {
    mapId: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.getCircleData();
      }
    },
    $route: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.getCircleData();
      }
    },
    wsData: function (newVal, oldVal) {
      this.replaceWsData(newVal);
    },
    buildMapping: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.getCircleData();
      }
    },
    isSceneName: function (newVal, oldVal) {
      if (!isEqual(newVal, oldVal)) {
        this.getCircleData();
      }
    },
    wsPlanGlobalPaths: function (newVal) {
      this.replacePlanGlobalWsData(newVal);
    },
    wsPlanPartPaths: function (newVal) {
      this.replacePlanPartWsData(newVal);
    },
    wsPlanSitePaths: function (newVal) {
      this.replacePlanSiteWsData(newVal);
    },
  },
  methods: {
    // 处理ws plan 全局规划路径（只展示路径）
    replacePlanGlobalWsData: function (data) {
      this.konvaConfig.planGlobalPath = [];
      this.curGlobalPath = [];
      const arr = cloneDeep(data);
      for (let i = 0; i < arr.length; i++) {
        const obj = arr[i];
        const { area_route_info, sn, color } = obj;
        let pointArr = [];
        const location = cloneDeep(area_route_info);
        if (!isEmpty(location) && this.cvsW && this.cvsH) {
          for (let j = 0; j < location?.length; j++) {
            let lct = cloneDeep(location[j]);
            const { curX, curY } = this.getCuXY(lct.x, lct.y);
            const len = this.konvaConfig.planGlobalPath?.length;
            let lastX = 0;
            let lastY = 0;
            if (len > 2) {
              if (sn) {
                const lastGroupLine =
                  this.konvaConfig.planGlobalPath?.[len - 1]?.groupLine;
                lastX = lastGroupLine?.[0];
                lastY = lastGroupLine?.[1];
              } else {
                lastX = this.konvaConfig.planGlobalPath?.[len - 2];
                lastY = this.konvaConfig.planGlobalPath?.[len - 1];
              }
            }

            if (stepPgmLineSegment(lastX, lastY, curX, curY)) {
              pointArr.push(curX, curY);
            }
          }
          if (sn) {
            // 组
            const idx = this.konvaConfig.planGlobalPath.findIndex(
              (j) => j.sn === sn
            );
            if (idx === -1) {
              this.konvaConfig.planGlobalPath.push({
                sn,
                color,
                groupLine: pointArr,
              });
            } else {
              this.konvaConfig.planGlobalPath[idx] = {
                sn,
                color,
                groupLine:
                  this.konvaConfig.planGlobalPath[idx]?.groupLine.concat(
                    pointArr
                  ),
              };
              this.planGlobalSn = true;
            }
          } else {
            // 单个设备数据
            this.planGlobalSn = false;
            if (pointArr?.length > 0) {
              this.curGlobalPath = this.curGlobalPath.concat(pointArr);
              this.konvaConfig.planGlobalPath = [this.curGlobalPath];
            }
          }
        }
      }
    },
    // 处理 ws plan 局部规划路径（会给个箭头）
    replacePlanPartWsData: function (data) {
      this.konvaConfig.planPartPath = [];
      this.konvaConfig.curPlanPartPoint = [];
      this.curPartPath = [];
      const arr = cloneDeep(data);
      (arr || []).forEach((obj) => {
        const { area_route_info, sn, color } = obj;
        let pointArr = [];
        const location = cloneDeep(area_route_info);
        let item = {};
        if (!isEmpty(location) && this.cvsW && this.cvsH) {
          for (let j = 0; j < location?.length; j++) {
            let lct = cloneDeep(location[j]);
            const { curX, curY } = this.getCuXY(lct.x, lct.y);
            const len = this.konvaConfig.planPartPath?.length;
            let lastX = 0;
            let lastY = 0;
            if (len > 2) {
              if (sn) {
                const lastGroupLine =
                  this.konvaConfig.planPartPath?.[len - 1]?.groupLine;
                lastX = lastGroupLine?.[0];
                lastY = lastGroupLine?.[1];
              } else {
                lastX = this.konvaConfig.planPartPath?.[len - 2];
                lastY = this.konvaConfig.planPartPath?.[len - 1];
              }
            }

            if (stepPgmLineSegment(lastX, lastY, curX, curY)) {
              pointArr.push(curX, curY);
            }
            item = {
              x: curX,
              y: curY,
              omega:
                this.isSceneName || this.buildMapping === true
                  ? yaw2Omega(lct.yaw)
                  : lct.omega,
              color,
            };
          }
          if (sn) {
            // 组
            const idx = this.konvaConfig.planPartPath.findIndex(
              (j) => j.sn === sn
            );
            if (idx === -1) {
              this.konvaConfig.planPartPath.push({
                sn,
                color,
                groupLine: pointArr,
              });
            } else {
              this.konvaConfig.planPartPath[idx] = {
                sn,
                color,
                groupLine:
                  this.konvaConfig.planPartPath[idx]?.groupLine.concat(
                    pointArr
                  ),
              };
              this.planPartSn = true;
            }

            const index = this.konvaConfig.curPlanPartPoint.findIndex(
              (i) => i.sn === sn
            );
            if (index === -1) {
              this.konvaConfig.curPlanPartPoint.push({
                sn,
                ...item,
              });
            } else {
              this.konvaConfig.curPlanPartPoint[index] = {
                sn,
                ...item,
              };
            }
          } else {
            // 单个设备数据
            this.planPartSn = false;
            if (pointArr?.length > 0) {
              this.curPartPath = this.curPartPath.concat(pointArr);
              this.konvaConfig.planPartPath = [this.curPartPath];
            }
            this.konvaConfig.curPlanPartPoint = [item];
          }
        }
      });
    },
    replacePlanSiteWsData: function (data) {
      this.konvaConfig.planSitePath = [];
      this.curSitePath = [];
      const arr = cloneDeep(data);
      (arr || []).forEach((obj) => {
        const { area_route_info, sn, color } = obj;
        let pointArr = [];
        const location = cloneDeep(area_route_info);
        if (!isEmpty(location) && this.cvsW && this.cvsH) {
          for (let j = 0; j < location?.length; j++) {
            let lct = cloneDeep(location[j]);
            const { curX, curY } = this.getCuXY(lct.x, lct.y);
            const len = this.konvaConfig.planSitePath?.length;
            let lastX = 0;
            let lastY = 0;
            if (len > 2) {
              if (sn) {
                const lastGroupLine =
                  this.konvaConfig.planSitePath?.[len - 1]?.groupLine;
                lastX = lastGroupLine?.[0];
                lastY = lastGroupLine?.[1];
              } else {
                lastX = this.konvaConfig.planSitePath?.[len - 2];
                lastY = this.konvaConfig.planSitePath?.[len - 1];
              }
            }

            if (stepPgmLineSegment(lastX, lastY, curX, curY)) {
              pointArr.push(curX, curY);
            }
          }
          if (sn) {
            // 组
            const idx = this.konvaConfig.planSitePath.findIndex(
              (j) => j.sn === sn
            );
            if (idx === -1) {
              this.konvaConfig.planSitePath.push({
                sn,
                color,
                groupLine: pointArr,
              });
            } else {
              this.konvaConfig.planSitePath[idx] = {
                sn,
                color,
                groupLine:
                  this.konvaConfig.planSitePath[idx]?.groupLine.concat(
                    pointArr
                  ),
              };
              this.planSiteSn = true;
            }
          } else {
            // 单个设备数据
            this.planSiteSn = false;
            if (pointArr?.length > 0) {
              this.curSitePath = this.curSitePath.concat(pointArr);
              this.konvaConfig.planSitePath = [this.curSitePath];
            }
          }
        }
      });
    },
    replaceWsData(arr) {
      this.resetWsData();
      for (let k = 0; k <= arr?.length; k++) {
        const data = arr[k];
        const travel = data?.travel;
        const cloud = data?.cloud;
        const color = data?.color;
        const sn = data?.sn;
        let pointArr = [];
        let item = {};
        if (!isEmpty(travel) && this.cvsW && this.cvsH) {
          const { location } = travel;
          for (let i = 0; i < location?.length; i++) {
            let lct = location[i];
            const { curX, curY } = this.getCuXY(lct.x, lct.y);
            const len = this.konvaConfig.path?.length;
            let lastX = 0;
            let lastY = 0;
            if (len > 2) {
              if (sn) {
                const lastGroupLine =
                  this.konvaConfig.path?.[len - 1]?.groupLine;
                lastX = lastGroupLine?.[0];
                lastY = lastGroupLine?.[1];
              } else {
                lastX = this.konvaConfig.path?.[len - 2];
                lastY = this.konvaConfig.path?.[len - 1];
              }
            }

            if (stepPgmLineSegment(lastX, lastY, curX, curY)) {
              pointArr.push(curX, curY);
            }
            item = {
              x: curX,
              y: curY,
              omega:
                this.isSceneName || this.buildMapping === true
                  ? yaw2Omega(lct.yaw)
                  : lct.omega,
              color,
            };
          }
          if (sn) {
            // 组
            const idx = this.konvaConfig.path.findIndex((j) => j.sn === sn);
            if (idx === -1) {
              this.konvaConfig.path.push({
                sn,
                color,
                groupLine: pointArr,
              });
            } else {
              this.konvaConfig.path[idx] = {
                sn,
                color,
                groupLine:
                  this.konvaConfig.path[idx]?.groupLine.concat(pointArr),
              };
              this.sn = true;
            }
            const index = this.konvaConfig.curPoint.findIndex(
              (i) => i.sn === sn
            );
            if (index === -1) {
              this.konvaConfig.curPoint.push({
                sn,
                ...item,
              });
            } else {
              this.konvaConfig.curPoint[index] = {
                sn,
                ...item,
              };
            }
          } else {
            // 单个设备数据
            this.sn = false;
            if (pointArr?.length > 0) {
              this.curPath = this.curPath.concat(pointArr);
              this.konvaConfig.path = [this.curPath];
            }
            this.konvaConfig.curPoint = [item];
          }
        }

        if (!isEmpty(cloud)) {
          for (var i = 0; i < cloud?.location.length; i++) {
            const lct = cloud?.location[i];
            const curX = Math.round(this.cvsW * Math.abs(lct.x));
            const curY = Math.round(this.cvsH * Math.abs(lct.y));
            const item = { x: curX, y: curY };
            this.konvaConfig.cloudPoints.push(item);
          }
        }
      }
    },
    onDragstart: function (el) {
      this.isDraging = true;
      const { layerX, layerY, clientX, clientY, pageX, pageY } = el.evt;
      this.startDragData = {
        xL: layerX,
        yL: layerY,
        xC: clientX,
        yC: clientY,
        xP: pageX,
        yP: pageY,
      };
    },
    onDragmove: function () {
      this.visibleCircleTooltip = false;
    },
    onDragend: function (e) {
      const { xL, yL, xC, yC, xP, yP } = this.startDragData;
      const { layerX, layerY, clientX, clientY, pageX, pageY } = e.evt;
      this.diffLayerX = layerX + this.diffLayerX - xL;
      this.diffLayerY = layerY + this.diffLayerY - yL;
      this.diffClientX = clientX + this.diffClientX - xC;
      this.diffClientY = clientY + this.diffClientY - yC;
      this.diffPageX = pageX + this.diffPageX - xP;
      this.diffPageY = pageY + this.diffPageX - yP;
    },
    getCircleData: async function () {
      try {
        // GlobalLoading.loadingShow();
        // if (this.timeId) {
        //   await this.clearTimeoutData();
        // }
        if (this.mapWs && !this.$store.state.isTask) {
          this.closeMapWebsoket();
        }
        await this.viewMap();
        await this.getCircleNeedDataList();
      } catch (error) {
        // GlobalLoading.loadingClose();
      } finally {
        // GlobalLoading.loadingClose();
      }
    },
    getCircleNeedDataList: async function () {
      this.identifierList = await getIdentifierList();
      this.metaTaskList = await getSceneMetaTaskList({ type: 2 });
    },
    viewMap: async function () {
      if (this.isSceneName || this.buildMapping === true) {
        await this.wsMapWs();
      } else {
        if (this.mapId) {
          await this.resetData();
          try {
            const pgmImageData = await viewMap({
              id: this.mapId,
            });
            this.pgmData = pgmImageData;
            if (pgmImageData) {
              let img = new MapImage(pgmImageData);
              let canvasImg = img.getInitMap("canvas");
              const dom = document.querySelector(".konva-stage");
              // this.konvaConfig.stage.width = dom.clientWidth;
              // this.konvaConfig.stage.height = dom.clientHeight;
              this.konvaConfig.stage.width = canvasImg.width;
              this.konvaConfig.stage.height = canvasImg.height;
              this.cvsW = canvasImg.width;
              this.cvsH = canvasImg.height;
              this.konvaConfig.pgmImage = new Image();
              this.konvaConfig.pgmImage.src = canvasImg.toDataURL();
            }
          } catch (error) {
            console.log("map error----", error);
          }
        }
      }
    },

    wsMapWs: function () {
      const mapWsUrl = `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/device-map/${this.deviceId}`;
      this.mapWs = new WebSocket(mapWsUrl);
      this.mapWs.onopen = () => {
        console.log(`${mapWsUrl}----连接成功---`);
      };
      this.mapWs.onmessage = async (msg) => {
        const msgObj = JSON.parse(msg?.data);
        const {
          map: {
            pixel_x,
            pixel_y,
            origin_x,
            origin_y,
            resolution,
            current_data,
          },
        } = msgObj;
        const base64Str = current_data;
        if (!(this.$store.state.isTask || this.isInitPickUp)) {
          await this.resetPgmDatas();
          // const dom = document.querySelector("#pgmContainer");
          // if (dom) {
          //   dom.scrollTo(0, 0);
          // }
          // window.scrollTo(0, document.documentElement.scrollTop);
          this.konvaConfig.pgmImage = new Image();
          this.pgmData = base64Str;
          this.konvaConfig.pgmImage.src = base64Str;
          const _this = this;
          // 当 pgmImage 加载完毕后触发事件 避免pgmImage已经有值，但宽高为0, 页面显示空白问题
          this.konvaConfig.pgmImage.onload = function () {
            _this.konvaConfig.stage.width = _this.konvaConfig.pgmImage?.width;
            _this.konvaConfig.stage.height = _this.konvaConfig.pgmImage?.height;
            _this.cvsW = pixel_x || _this.konvaConfig.pgmImage?.width;
            _this.cvsH = pixel_y || _this.konvaConfig.pgmImage?.height;
            _this.pixelX = pixel_x;
            _this.pixelY = pixel_y;
            _this.originX = origin_x;
            _this.originY = origin_y;
            _this.resolution = resolution;
            if (_this.curMethod === "info") {
              _this.isDetail = false;
              const TaskInfoData = { ..._this.taskInfoRow };
              const point = cloneDeep(TaskInfoData?.params?.point);
              let polylinePoints = [];
              for (let j = 0; j < point?.length; j++) {
                const p = cloneDeep(point[j]);
                if (
                  (pixel_x || pixel_x === 0) &&
                  (pixel_y || pixel_y === 0) &&
                  (origin_x || origin_x === 0) &&
                  (origin_y || origin_y === 0) &&
                  (resolution || resolution === 0)
                ) {
                  const { uvX, uvY } = worldToUv(
                    p.location.x,
                    p.location.y,
                    pixel_x,
                    pixel_y,
                    origin_x,
                    origin_y,
                    resolution
                  );
                  const layerX = Math.round(pixel_x * uvX);
                  const layerY = Math.round(pixel_y * uvY);
                  p.location.x = uvX;
                  p.location.y = uvY;
                  const item = {
                    x: layerX,
                    y: layerY,
                    omega: p.location.omega,
                    key: _this.historyMaxnodeNum,
                  };
                  _this.konvaConfig.points.push(item);
                  _this.points.set(_this.historyMaxnodeNum, p);
                  _this.historyMaxnodeNum += 1;
                  polylinePoints.push(layerX, layerY);
                  if (polylinePoints.length >= 4) {
                    const newPolyline = [...polylinePoints];
                    _this.konvaConfig.polyline.push(newPolyline);
                  }
                }
              }

              const area = cloneDeep(TaskInfoData?.params?.area) || [];
              let infoPointArr = [];

              for (let i = 0; i < area.length; i++) {
                let obj = {};
                if (i % 2 === 0) {
                  obj.x = area[i];
                  obj.y = area[i + 1];

                  if (
                    (pixel_x || pixel_x === 0) &&
                    (pixel_y || pixel_y === 0) &&
                    (origin_x || origin_x === 0) &&
                    (origin_y || origin_y === 0) &&
                    (resolution || resolution === 0)
                  ) {
                    const { uvX, uvY } = worldToUv(
                      obj.x,
                      obj.y,
                      pixel_x,
                      _this.pixelYpixel_y,
                      origin_x,
                      origin_y,
                      resolution
                    );
                    const Lx = uvX * pixel_x;
                    const Ly = uvY * pixel_y;
                    _this.konvaConfig.areaPoints.push({
                      x: Lx,
                      y: Ly,
                    });
                    infoPointArr.push(Lx, Ly);
                    const res = [...infoPointArr];
                    _this.konvaConfig.polygon = [res];
                    _this.areaPoints = area;
                  }
                }
              }
            }
            const selectedTaskData = cloneDeep(_this.selectionList);
            if (selectedTaskData?.length > 0) {
              _this.isDetail = true;
              for (let i = 0; i < selectedTaskData.length; i++) {
                const point =
                  cloneDeep(selectedTaskData[i]?.params?.point) || [];
                const color = cloneDeep(selectedTaskData[i]?.color);
                let polylinePoints = [];
                for (let j = 0; j < point?.length; j++) {
                  const p = cloneDeep(point[j]);
                  if (
                    (pixel_x || pixel_x === 0) &&
                    (pixel_y || pixel_y === 0) &&
                    (origin_x || origin_x === 0) &&
                    (origin_y || origin_y === 0) &&
                    (resolution || resolution === 0)
                  ) {
                    const { uvX, uvY } = worldToUv(
                      p.location.x,
                      p.location.y,
                      pixel_x,
                      pixel_y,
                      origin_x,
                      origin_y,
                      resolution
                    );

                    const layerX = Math.round(pixel_x * uvX);
                    const layerY = Math.round(pixel_y * uvY);

                    p.location.x = uvX;
                    p.location.y = uvY;
                    const item = {
                      x: layerX,
                      y: layerY,
                      omega: p.location.omega,
                      color,
                      key: _this.historyMaxnodeNum,
                    };
                    _this.konvaConfig.points.push(item);
                    _this.points.set(_this.historyMaxnodeNum, p);
                    _this.historyMaxnodeNum += 1;
                    polylinePoints.push(layerX, layerY);
                    if (polylinePoints.length >= 4) {
                      _this.konvaConfig.polyline.push({
                        color,
                        groupLine: polylinePoints,
                      });
                    }
                  }
                }

                const area = selectedTaskData[i]?.params?.area || [];
                let infoPointArr = [];
                for (let i = 0; i < area.length; i++) {
                  let obj = {};
                  if (i % 2 === 0) {
                    obj.x = area[i];
                    obj.y = area[i + 1];

                    if (
                      (pixel_x || pixel_x === 0) &&
                      (pixel_y || pixel_y === 0) &&
                      (origin_x || origin_x === 0) &&
                      (origin_y || origin_y === 0) &&
                      (resolution || resolution === 0)
                    ) {
                      const { uvX, uvY } = worldToUv(
                        obj.x,
                        obj.y,
                        pixel_x,
                        pixel_y,
                        origin_x,
                        origin_y,
                        resolution
                      );
                      const Lx = uvX * pixel_x;
                      const Ly = uvY * pixel_y;
                      _this.konvaConfig.areaPoints.push({
                        x: Lx,
                        y: Ly,
                        color,
                      });
                      infoPointArr.push(Lx, Ly);
                      if (_this.konvaConfig.areaPoints.length >= 3) {
                        _this.konvaConfig.polygon.push({
                          color,
                          groupPolygon: infoPointArr,
                        });
                      }
                      this.infoAreaPoints = [..._this.konvaConfig.areaPoints];
                      const process = selectedTaskData[i]?.params?.process;
                      _this.TaskDetailData = process;
                    }
                  }
                }
              }
            }
          };
        }
      };
      this.mapWs.onclose = (event) => {
        if (event.wasClean) {
          console.log(
            `[close] Connection closed cleanly, ----map----, code=${event.code} reason=${event.reason} deviceId=${this.deviceId}`
          );
        } else {
          console.log("[close] Connection died, ----map----");
        }
      };
      this.ws.onerror = (e) => {
        console.log(`${mapWsUrl}----map连接失败---` + e.code);
      };
    },

    closeMapWebsoket() {
      this.mapWs?.close();
      this.mapWs = null;
    },

    clearTimeoutData: function () {
      this.timeId && clearTimeout(this.timeId);
      this.timeId = null;
    },
    initHavedData: function () {
      this.konvaConfig.points = [];
      this.konvaConfig.polyline = [];
      this.$refs.circleTooltipRef.isContent = false;
      this.konvaConfig.polygon = [];
      this.areaPoints = [];
      this.konvaConfig.areaPoints = [];
      this.TaskDetailData = [];
      this.path = [];
      this.curPoint = [];
    },
    onHavedData: function (datas, isDetail, method, optsType) {
      const data = cloneDeep(datas);
      this.method = method;
      this.optsType = optsType;
      const w = this.cvsW;
      const h = this.cvsH;
      this.isDetail = isDetail;
      if (!isDetail) {
        this.isShow = false; // false 展示 CoordinatePickup
      }
      this.initHavedData();
      if (data.length > 0) {
        for (let i = 0; i < data.length; i++) {
          const point = data[i]?.params?.point || [];
          const color = data[i]?.color;
          let polylinePoints = [];
          for (let j = 0; j < point.length; j++) {
            const p = cloneDeep(point[j]);
            let layerX = Math.round(w * Number(p.location.x));
            let layerY = Math.round(h * Number(p.location.y));
            if (this.isSceneName || this.buildMapping === true) {
              if (
                (this.pixelX || this.pixelX === 0) &&
                (this.pixelY || this.pixelY === 0) &&
                (this.originX || this.originX === 0) &&
                (this.originY || this.originY === 0) &&
                (this.resolution || this.resolution === 0)
              ) {
                const { uvX, uvY } = worldToUv(
                  p.location.x,
                  p.location.y,
                  this.pixelX,
                  this.pixelY,
                  this.originX,
                  this.originY,
                  this.resolution
                );
                layerX = Math.round(w * uvX);
                layerY = Math.round(h * uvY);
                p.location.x = uvX;
                p.location.y = uvY;
              }
            }
            const item = {
              x: layerX,
              y: layerY,
              omega: p.location.omega,
              color,
              key: this.historyMaxnodeNum,
            };
            this.konvaConfig.points.push(item);
            this.points.set(this.historyMaxnodeNum, p);
            this.historyMaxnodeNum += 1;
            polylinePoints.push(layerX, layerY);
            if (polylinePoints.length >= 4) {
              if (isDetail) {
                this.konvaConfig.polyline.push({
                  color,
                  groupLine: polylinePoints,
                });
              } else {
                const newPolyline = [...polylinePoints];
                this.konvaConfig.polyline.push(newPolyline);
              }
            }
          }
          const area = data[i]?.params?.area || [];
          let infoPointArr = [];
          for (let i = 0; i < area.length; i++) {
            let obj = {};
            if (i % 2 === 0) {
              obj.x = area[i];
              obj.y = area[i + 1];
              let Lx = area[i] * this.cvsW;
              let Ly = area[i + 1] * this.cvsH;
              if (this.isSceneName || this.buildMapping === true) {
                if (
                  (this.pixelX || this.pixelX === 0) &&
                  (this.pixelY || this.pixelY === 0) &&
                  (this.originX || this.originX === 0) &&
                  (this.originY || this.originY === 0) &&
                  (this.resolution || this.resolution === 0)
                ) {
                  obj.x = area[i];
                  obj.y = area[i + 1];
                  const { uvX, uvY } = worldToUv(
                    obj.x,
                    obj.y,
                    this.pixelX,
                    this.pixelY,
                    this.originX,
                    this.originY,
                    this.resolution
                  );
                  Lx = uvX * this.cvsW;
                  Ly = uvY * this.cvsH;
                }
              }
              this.konvaConfig.areaPoints.push({ x: Lx, y: Ly, color });
              infoPointArr.push(Lx, Ly);
              if (this.konvaConfig.areaPoints.length >= 3) {
                if (optsType === "seleted") {
                  this.konvaConfig.polygon.push({
                    color,
                    groupPolygon: infoPointArr,
                  });
                } else {
                  const res = [...infoPointArr];
                  this.konvaConfig.polygon = [res];
                  this.areaPoints = area;
                }
              }
            }
          }
          this.infoAreaPoints = [...this.konvaConfig.areaPoints];
          const process = data[i]?.params?.process;
          this.TaskDetailData = process;
        }
      } else {
        this.initHavedData();
      }
    },
    wheelForScale: function (e) {
      e.evt.preventDefault();
      this.isAttributeForm = false;
      const scaleBy = 1.01;
      const stage = this.$refs.konvaStage.getStage();
      const oldScale = stage.scaleX();
      const mousePointTo = {
        x: stage.getPointerPosition().x / oldScale - stage.x() / oldScale,
        y: stage.getPointerPosition().y / oldScale - stage.y() / oldScale,
      };
      const newScale =
        e.evt.deltaY > 0 ? oldScale * scaleBy : oldScale / scaleBy;
      stage.scale({ x: newScale, y: newScale });
      this.$nextTick(() => {
        stage.x(
          (-mousePointTo.x + stage.getPointerPosition().x / newScale) * newScale
        );
        stage.y(
          (-mousePointTo.y + stage.getPointerPosition().y / newScale) * newScale
        );
        stage.batchDraw();
        const scale = e.evt.deltaY > 0 ? scaleBy : 1 / scaleBy;
        this.stageScale = newScale;
        this.stagePointerPosition = {
          x: stage.x(),
          y: stage.y(),
        };
        this.triggerPosition = {
          ...this.triggerPosition,
          layerX:
            stage.getPointerPosition().x +
            (-stage.getPointerPosition().x + this.triggerPosition.layerX) *
              scale,
          layerY:
            stage.getPointerPosition().y +
            (-stage.getPointerPosition().y + this.triggerPosition.layerY) *
              scale,
        };
      });
    },
    onStageTouchstart: function (e) {
      const len = e.evt.touches.length;
      const { pageX, pageY } = e.evt.touches[0];
      if (len >= 2) {
        clearTimeout(timeId);
        this.isAttributeForm = false;
      } else {
        timeId = setTimeout(() => {
          if (this.method === "TASK_INVESTIGATE") {
            const { x, y } = this.stagePointerPosition;
            const dom = document.getElementById("pgmContainer");
            const cxL = pageX - dom.offsetLeft + dom.scrollLeft;
            let cyT = pageY - dom.offsetTop + dom.scrollTop - 62;
            if (this.isInitPickUp || this.$route?.name === "deviceId") {
              //相对视口 在设备展示的地图需要-header：62 以及tab：40 高度
              cyT = pageY - dom.offsetTop + dom.scrollTop - 62 - 40;
            }
            const cx0 = cxL - x;
            const cy0 = cyT - y;
            const cx = cx0 / this.stageScale;
            const cy = cy0 / this.stageScale;
            if (e.target.attrs.id || e.target.attrs.id === 0) {
              this.isAttributeForm = true;
              this.artFormTop = cyT;
              this.artFormLeft = cxL;
            } else {
              // 增加点 编辑存在， 将提示先清空
              if (this.optsType === "update" && !isEmpty(this.infoAreaPoints)) {
                this.$message({
                  type: "info",
                  message: "若想更新边界区域, 请先清空边界点！",
                });
                return;
              }
              this.isAttributeForm = false;
              const obj = { x: cx, y: cy };
              this.konvaConfig.areaPoints.push(obj);
              const uvX = (cx / this.cvsW).toFixed(6);
              const uvY = (cy / this.cvsH).toFixed(6);
              this.areaPoints.push(uvX, uvY);
            }
          } else {
            this.triggerPosition = {
              pageX,
              pageY,
            };
            this.isTouchStart = true;
            this.visibleCircleTooltip = true;
            this.initData();
            if (this.isInitPickUp) {
              this.isShow = false;
            }
          }
        }, 50);
      }
    },
    onStageTouchmove: function (e) {
      e.evt.preventDefault();
      const dom = document.getElementById("pgmContainer");
      const stage = this.$refs.konvaStage.getStage();
      const touch1 = e.evt.touches[0];
      const touch2 = e.evt.touches[1];
      if (touch1 && touch2) {
        this.isTouchmoveing = true;
        this.visibleCircleTooltip = false;
        this.konvaConfig.stage.draggable = false; // 缩放时，禁掉拖拽，两者冲突会导致缩放失效
        const p1 = {
          x: touch1.pageX,
          y: touch1.pageY,
        };
        const p2 = {
          x: touch2.pageX,
          y: touch2.pageY,
        };

        if (!lastCenter) {
          lastCenter = getCenter(p1, p2);
          return;
        }

        if (!lastDist) {
          lastDist = getDistance(p1, p2);
        }
        const newCenter = getCenter(p1, p2); // 缩放中心
        const newDist = getDistance(p1, p2); // 两指距离
        const pointTo = {
          x: (newCenter.x - stage.x()) / stage.scaleX(),
          y: (newCenter.y - stage.y()) / stage.scaleX(),
        };
        let circlePointTo = {
          x: 0,
          y: 0,
        };
        if (this.triggerPosition) {
          circlePointTo = {
            x:
              (newCenter.x -
                (this.triggerPosition.pageX -
                  dom.offsetLeft +
                  dom.scrollLeft)) /
              stage.scaleX(),
            y:
              (newCenter.y -
                (this.triggerPosition.pageY - dom.offsetTop + dom.scrollTop)) /
              stage.scaleX(),
          };
        }
        const scale = stage.scaleX() * (newDist / lastDist);
        // 用于子组件的位置更新
        this.stageScale = scale;
        this.stagePointerPosition = {
          x: stage.x(),
          y: stage.y(),
        };
        stage.scale({ x: scale, y: scale });
        const dx = newCenter.x - lastCenter.x;
        const dy = newCenter.y - lastCenter.y;
        const newPos = {
          x: newCenter.x - pointTo.x * scale + dx,
          y: newCenter.y - pointTo.y * scale + dy,
        };

        this.triggerPosition = {
          pageX:
            newCenter.x -
            circlePointTo.x * scale +
            dx +
            (dom.offsetLeft - dom.scrollLeft),
          pageY:
            newCenter.y -
            circlePointTo.y * scale +
            dy +
            (dom.offsetTop - dom.scrollTop),
        };
        stage.position(newPos);
        lastDist = newDist;
        lastCenter = newCenter;
      }
    },
    onStageTouchend: function () {
      lastDist = 0;
      lastCenter = null;
      // this.konvaConfig.stage.draggable = true;
    },

    onStageClick: function (e) {
      const { layerX, layerY, clientX, clientY } = e.evt;
      this.triggerPosition = {
        layerX,
        layerY,
        clientX,
        clientY,
      };

      if (!this.isArrow) {
        if (this.method === "TASK_INVESTIGATE") {
          const { x, y } = this.stagePointerPosition;
          const cx = (layerX - (x || 0)) / this.stageScale;
          const cy = (layerY - (y || 0)) / this.stageScale;
          const obj = { x: cx, y: cy };
          if (
            (e.target.attrs.id || e.target.attrs.id === 0) &&
            e.target.attrs?.name !== "area_circle"
          ) {
            // 点击区域弹窗
            this.artFormTop = layerY;
            this.artFormLeft = layerX;
            this.isAttributeForm = true;
          } else {
            if (e.target?.attrs?.name === "area_circle") {
              //点击点准备拖拽areaPoint
            } else {
              // 增加点 编辑存在， 将提示先清空
              if (this.optsType === "update" && !isEmpty(this.infoAreaPoints)) {
                this.$message({
                  type: "info",
                  message: "若想更新边界区域, 请先清空边界点！",
                });
                return;
              }

              if (
                this.optsType === "add" &&
                !isEmpty(this.konvaConfig.polygon)
              ) {
                this.$message({
                  type: "info",
                  message: "区域点已形成，若想更新, 请先清空边界点！",
                });
                return;
              }

              this.isAttributeForm = false;
              const uvX = (
                (layerX - (x || 0)) /
                (this.cvsW * this.stageScale)
              ).toFixed(6);
              const uvY = (
                (layerY - (y || 0)) /
                (this.cvsH * this.stageScale)
              ).toFixed(6);
              this.konvaConfig.areaPoints.push(obj);
              this.areaPoints.push(uvX, uvY);
            }
          }
        } else {
          this.visibleCircleTooltip = true;
          this.initData();
          if (this.isInitPickUp) {
            this.isShow = false;
          }
        }
      } else {
        // 路网
        const { x, y } = this.stagePointerPosition;
        const cx = (layerX - (x || 0)) / this.stageScale;
        const cy = (layerY - (y || 0)) / this.stageScale;
        const obj = { x: cx, y: cy };
        this.isAttributeForm = false;
        this.visibleCircleTooltip = false;
        const uvX = (
          (layerX - (x || 0)) /
          (this.cvsW * this.stageScale)
        ).toFixed(6);
        const uvY = (
          (layerY - (y || 0)) /
          (this.cvsH * this.stageScale)
        ).toFixed(6);
        // 条件为了限制重复圆和连线后点击的是圆上的线（只有圆存在id）
        if (e.target?.attrs?.name !== "arrow_circle") {
          this.konvaConfig.arrowPoints.push(obj);
          this.arrowPoints.push(uvX, uvY);
        }
      }
    },

    initData: function () {
      if (this.$refs.circleTooltipRef) {
        this.$refs.circleTooltipRef.form = {
          omega: 0,
          identifierList: this.identifierList, // 目标物
          metaTaskList: this.metaTaskList, // 动作
          selectPoint: this.selectPoint || {
            location: { omega: 0 },
            process: [],
            station: [],
          }, // 选择点
        };
        this.$refs.circleTooltipRef.directions = {
          cx: 60,
          cy: 60,
          omega: 0,
        };
      }
    },

    resetPoint: function () {
      this.konvaConfig.points = [];
      this.konvaConfig.polyline = [];
      this.points = new Map();
      this.historyMaxnodeNum = 0;
      this.resetAreaPointData();
      this.resetArrowPointData();
    },

    deleteCircleTooltipData: function (data) {
      const { directions, triggerPoint, visible } = data;
      const {
        location: { x, y },
      } = triggerPoint;
      const { cx, cy } = directions;
      this.visibleCircleTooltip = visible;
      const obj = getMinPoint(
        this.points,
        { x, y },
        this.threshold / this.stageScale
      );

      const obj1 = getKonvaConfigByObj(this.konvaConfig.points, obj);
      if (!isEmpty(obj)) {
        this.points.delete(obj.key);
        let newPolyline = [];
        this.konvaConfig.points = this.konvaConfig.points.map((i) => {
          if (i.key === obj1.key) {
            return;
          } else {
            return { ...i };
          }
        });
        // 更新 polyline
        newPolyline = this.konvaConfig.polyline.map((arrItem) => {
          const result = [];
          for (var i = 0; i < arrItem.length; i = i + 2) {
            if (obj1.x == arrItem[i] && obj1.y == arrItem[i + 1]) {
              continue;
            } else {
              result.push(arrItem[i]);
              result.push(arrItem[i + 1]);
            }
          }
          return result;
        });
        this.konvaConfig.points = [
          ...new Set(this.konvaConfig.points.filter(Boolean)),
        ];
        this.konvaConfig.polyline = newPolyline;
      }
    },
    saveCircleTooltipData: async function (data) {
      const { directions, triggerPoint, visible } = data;
      this.konvaConfig.polyline = [];
      const {
        location: { x, y, omega },
      } = triggerPoint;
      const { cx, cy } = directions;
      this.visibleCircleTooltip = visible;
      if (this.isInitPickUp) {
        // 设备初始位置设置-拾取逻辑
        // this.konvaConfig.points = [
        //   {
        //     x: cx,
        //     y: cy,
        //     omega,
        //   },
        // ];
        // let map = new Map();
        // map.set(this.historyMaxnodeNum, triggerPoint);
        // this.points = map;
        // 设备-初始位置拾取逻辑
        if (this.onSaveInitPickup) {
          await this.onSaveInitPickup({
            x,
            y,
            omega,
            pixelX: this.pixelX,
            pixelY: this.pixelY,
            originX: this.originX,
            originY: this.originY,
            resolution: this.resolution,
          });
          this.isShow = true;
        }
      } else {
        // 导航
        const obj = getMinPoint(
          this.points,
          { x, y },
          this.threshold / this.stageScale
        );
        const obj1 = getKonvaConfigByObj(this.konvaConfig.points, obj);
        let map = new Map();
        if (!isEmpty(obj)) {
          map = this.points.set(this.historyMaxnodeNum, triggerPoint);
          this.konvaConfig.points = this.konvaConfig.points.map((i) => {
            if (i.key === obj1.key) {
              return { ...i, omega };
            } else {
              return { ...i };
            }
          });
        } else {
          map = this.points.set(this.historyMaxnodeNum, triggerPoint);
          this.konvaConfig.points.push({
            x: cx,
            y: cy,
            omega,
            key: this.historyMaxnodeNum,
          });
          this.historyMaxnodeNum += 1;
        }

        this.points = map;
        let pointArr = [];
        const curPoints = [...new Set(this.konvaConfig.points.filter(Boolean))];
        for (let i = 0; i < curPoints.length; i++) {
          pointArr.splice(
            pointArr.length,
            0,
            Number(curPoints[i].x.toFixed(0)),
            Number(curPoints[i].y.toFixed(0))
          );
        }
        if (pointArr.length >= 4) {
          this.konvaConfig.polyline.push(pointArr);
        }
        this.konvaConfig.points = curPoints;
      }
    },

    saveCurPoint: function (obj) {
      const { x, y } = obj;
      const triggerPoint = {
        location: { ...obj, stageScale: this.stageScale },
        process: [],
        station: [],
      };
      // 判断当前位置点是都已被添加，若添加则不再更新数据
      let isHaved = false;
      this.points.forEach((val, key) => {
        const location = val?.location;
        if (location.x === obj?.x && location?.y === obj?.y) {
          isHaved = true;
          return;
        }
      });
      if (isHaved === true) {
        // 存在 不在添加
        return;
      } else {
        // 不存在
        let map = new Map();
        map = this.points.set(this.historyMaxnodeNum, triggerPoint);
        const cx = this.cvsW * x;
        const cy = this.cvsH * y;
        const omega = obj?.omega;
        this.konvaConfig.points.push({
          x: cx,
          y: cy,
          omega,
          key: this.historyMaxnodeNum,
        });
        this.historyMaxnodeNum += 1;
        let pointArr = [];
        for (let i = 0; i < this.konvaConfig.points.length; i++) {
          pointArr.splice(
            pointArr.length,
            0,
            this.konvaConfig.points[i].x,
            this.konvaConfig.points[i].y
          );
        }
        if (pointArr.length >= 4) {
          this.konvaConfig.polyline.push(pointArr);
        }
      }
    },

    saveBoundaryPoint: function () {
      const pointArr = [];
      const len = this.konvaConfig.areaPoints.length;
      if (len < 3) {
        this.$message({
          type: "warning",
          message: "至少三个点形成一个区域才可保存哦！",
        });
        return len;
      }
      // 每次绘制清空 在重绘
      this.konvaConfig.polygon = [];
      for (let i = 0; i < len; i++) {
        pointArr.push(
          this.konvaConfig.areaPoints[i].x,
          this.konvaConfig.areaPoints[i].y
        );
      }
      if (pointArr.length >= 6) {
        this.konvaConfig.polygon = [pointArr];
      }
      this.isAttributeForm = false;
    },

    saveCurBoundaryPoint: function (obj) {
      const { x, y } = obj;
      const cx = (this.cvsW * x).toFixed();
      const cy = (this.cvsH * y).toFixed();
      this.konvaConfig.areaPoints.push({ x: cx, y: cy });
      this.areaPoints.push(x, y);
    },

    saveCurArrowPoint: function (obj) {
      const { x, y } = obj;
      const cx = (this.cvsW * x).toFixed();
      const cy = (this.cvsH * y).toFixed();
      // angle 用于绘制 见连线的箭头指向
      this.konvaConfig.arrowPoints.push({ x: cx, y: cy, angle: 0 });
      this.arrowPoints.push(x, y);
    },

    onArtFormDelete: function () {
      this.isAttributeForm = false;
    },

    onArtFormSave: function (formData) {
      this.isAttributeForm = false;
      this.attributeFormData = formData;
    },

    getAttributeFormData: function () {
      return this.attributeFormData?.process;
    },

    onDragAreaPointStart: function (e) {
      const { id } = e.target?.attrs;
      e.cancelBubble = true;
      // 记录拖拽的点坐标，方便拖拽结束更新点的坐标位
      this.curDragAreaPoint = id;
    },

    onDragAreaPointMove: function (e) {
      this.isAttributeForm = false;
      const { layerX, layerY, type } = e.evt;
      const idx = this.curDragAreaPoint;
      const { x, y } = this.stagePointerPosition;
      let cx = 0;
      let cy = 0;
      let uvX = 0;
      let uvY = 0;
      if (type === "touchmove") {
        const touch1 = e.evt.touches[0];
        const { pageX, pageY } = touch1;
        const dom = document.getElementById("pgmContainer");
        const cxL = pageX - dom.offsetLeft + dom.scrollLeft;
        let cyT = pageY - dom.offsetTop + dom.scrollTop - 62;
        if (this.isInitPickUp || this.$route?.name === "deviceId") {
          //相对视口 在设备展示的地图需要-header：62 以及tab：40 高度
          cyT = pageY - dom.offsetTop + dom.scrollTop - 62 - 40;
        }
        cx = (cxL - (x || 0)) / this.stageScale;
        cy = (cyT - (y || 0)) / this.stageScale;
        uvX = ((cxL - (x || 0)) / (this.cvsW * this.stageScale)).toFixed(6);
        uvY = ((cyT - (y || 0)) / (this.cvsH * this.stageScale)).toFixed(6);
      }

      if (type === "mousemove") {
        cx = (layerX - (x || 0)) / this.stageScale;
        cy = (layerY - (y || 0)) / this.stageScale;

        uvX = ((layerX - (x || 0)) / (this.cvsW * this.stageScale)).toFixed(6);
        uvY = ((layerY - (y || 0)) / (this.cvsH * this.stageScale)).toFixed(6);
      }

      // 更新拖拽结束数据
      this.areaPoints?.splice(idx * 2, 2, uvX, uvY);
      const arr = !isEmpty(this.konvaConfig.polygon?.[0])
        ? [...this.konvaConfig.polygon?.[0]]
        : [];
      arr.splice(idx * 2, 2, cx, cy);
      this.konvaConfig.polygon = [arr];
    },

    // 选择那两个点之间 箭头连接
    onSelectPoint: function (item) {
      const { x, y } = item;

      /* 通过选择的点 连线 计算箭头的角度 */
      // this.arrowDrawPoints
      const res = this.arrowSelectedPoints;

      // console.log(
      //   "arrowPoints",
      //   res,
      //   this.arrowSelectedPoints,
      //   this.konvaConfig.arrowPoints
      // );

      // 每次连线时 先将前一次的线条清空，避免重复渲染
      this.konvaConfig.arrowPolylinePoints = [];
      // 将点的点全部存储
      this.arrowSelectedPoints.push(x, y);
      if (this.arrowSelectedPoints?.length >= 4) {
        this.konvaConfig.arrowPolylinePoints.push([
          ...this.arrowSelectedPoints,
        ]);
      }
    },

    onDragArrowPointStart: function (e) {
      const { id } = e.target?.attrs;
      const arr = id?.split("_");
      const curX = Number(arr[0]);
      const curY = Number(arr[1]);
      // 记录拖拽的点坐标，方便拖拽结束更新点的坐标位
      this.curDragArrowPoint = { curX, curY };
    },

    onDragArrowPointEnd: function (e) {
      const { layerX, layerY, clientX, clientY } = e.evt;
      const { curX, curY } = this.curDragArrowPoint;
      const { x, y } = this.stagePointerPosition;
      const cx = (layerX - (x || 0)) / this.stageScale;
      const cy = (layerY - (y || 0)) / this.stageScale;
      const obj = { x: cx, y: cy };
      const uvX = ((layerX - (x || 0)) / (this.cvsW * this.stageScale)).toFixed(
        6
      );
      const uvY = ((layerY - (y || 0)) / (this.cvsH * this.stageScale)).toFixed(
        6
      );

      let idx = -1;
      for (let i of this.konvaConfig.arrowPoints) {
        idx++;
        if (i?.x === curX && i?.y === curY) {
          i.x = cx;
          i.y = cy;
          break;
        }
      }

      // 更新拖拽结束数据
      this.arrowPoints?.splice(idx * 2, 2, uvX, uvY);
    },

    computeArrowPoints: function (start, end) {
      const dx = end.x - start.x;
      const dy = end.y - start.y;
      const angle = Math.atan2(dy, dx);
      const arrowLength = 20;
      const arrowPointX = end.x - arrowLength * Math.cos(angle);
      const arrowPointY = end.y - arrowLength * Math.sin(angle);
      return [end.x, end.y, arrowPointX, arrowPointY];
    },

    getCuXY: function (x, y) {
      let curX = Math.round(this.cvsW * Math.abs(x));
      let curY = Math.round(this.cvsH * Math.abs(y));
      if (this.isSceneName || this.buildMapping === true) {
        if (
          (this.pixelX || this.pixelX === 0) &&
          (this.pixelY || this.pixelY === 0) &&
          (this.originX || this.originX === 0) &&
          (this.originY || this.originY === 0) &&
          (this.resolution || this.resolution === 0)
        ) {
          const { uvX, uvY } = worldToUv(
            x,
            y,
            this.pixelX,
            this.pixelY,
            this.originX,
            this.originY,
            this.resolution
          );
          curX = Math.round(this.cvsW * Math.abs(uvX));
          curY = Math.round(this.cvsH * Math.abs(uvY));
        }
      }
      return { curX, curY };
    },

    resetData: function () {
      this.initData();
      this.resetPgmDatas();
      this.resetWsData();
    },

    resetPgmDatas: function () {
      this.initData();
      this.konvaConfig = {
        stage: {
          width: 1000,
          height: 1000,
          // draggable: true,
        },
        group: {
          x: 0,
          y: 0,
        },
        pgmImage: null,
        points: [],
        polyline: [],
        polygon: [],
        areaPoints: [],
        arrowPoints: [],
        arrowPolylinePoints: [],
        path: [],
        curPoint: [],
        planGlobalPath: [],
        planPartPath: [],
        planSitePath: [],
        curPlanPartPoint: [],
        // { x: 100, y: 100, omega: 45 }
        cloudPoints: [],
      };
      // 切换路由 重绘konva
      lastDist = 0;
      lastCenter = null;
      this.pgmData = null;
      if (this.$refs.konvaStage) {
        const stage = this.$refs.konvaStage.getStage();
        stage.scale({ x: 1, y: 1 });
        stage.position({ x: 0, y: 0 });
        stage.batchDraw();
      }
      this.historyMaxnodeNum = 0;
      this.stageScale = 1;
      this.stagePointerPosition = {
        x: 0,
        y: 0,
      };
      this.sn = false;
      this.planGlobalSn = false;
      this.planPartSn = false;
      this.planSitelSn = false;
      this.curGlobalPath = [];
      this.curPartPath = [];
      this.curSitePath = [];
      this.arrowSelectedPoints = [];
    },

    clearPgmWsPlanData: function () {
      this.planGlobalPath = [];
      this.planPartPath = [];
      this.planSitePath = [];
      this.curPlanPartPoint = [];
    },

    // 只情空点，不清空地图和ws 数据
    clearPgmData: function () {
      this.initData();
      this.resetPoint();
    },

    resetWsData: function () {
      this.konvaConfig.curPoint = [];
      this.konvaConfig.cloudPoints = [];
      this.konvaConfig.path = [];
    },

    resetAreaPointData: function () {
      this.konvaConfig.polygon = [];
      this.konvaConfig.areaPoints = [];
      this.areaPoints = [];
      this.isAttributeForm = false;
      this.infoAreaPoints = [];
      this.curDragAreaPoint = null;
    },

    resetArrowPointData: function () {
      this.arrowPoints = [];
      this.konvaConfig.arrowPoints = [];
      this.curDragArrowPoint = null;
    },

    onClickExpended: function () {
      this.isExpended = !this.isExpended;
    },

    onClickLiItem: function (e) {
      if (e?.target?.nodeName.toLowerCase() === "li") {
        if (e?.target?.dataset) {
          const { key } = e?.target?.dataset;
          switch (key) {
            case "global":
              if (this.$refs.layerGlobalPathRef) {
                this.$refs.layerGlobalPathRef.getNode().moveToTop();
                this.$refs.layerGlobalPathRef.getStage().draw();
              }

              break;
            case "part":
              if (this.$refs.layerPartPathRef) {
                this.$refs.layerPartPathRef.getNode().moveToTop();
                this.$refs.layerPartPathRef.getStage().draw();
              }
              break;
            case "site":
              if (this.$refs.layerSitePathRef) {
                this.$refs.layerSitePathRef.getNode().moveToTop();
                this.$refs.layerSitePathRef.getStage().draw();
              }
              break;
            default: // real
              if (this.$refs.layerRealPathRef) {
                this.$refs.layerRealPathRef.getNode().moveToTop();
                this.$refs.layerRealPathRef.getStage().draw();
              }
              break;
          }
        }
      }
    },
  },

  destroyed() {
    this.pgmData = null;
    this.clearTimeoutData();
  },
};
</script>
<style lang="scss" scoped>
.pgm_konva {
  width: 100%;
  .float_div {
    position: fixed;
    right: 0px;
    z-index: 1;
    display: flex;
    align-items: center;

    .icon_isExpended {
      line-height: 128px;
      display: inline-block;
      background: linear-gradient(45deg, skyblue, 60%, #f49ef5, transparent);
      i {
        font-size: 18px;
      }
    }

    &_title {
      font-size: 14px;
      font-weight: 600;
      color: deepskyblue;
    }

    &_content {
      font-size: 13px;
      padding: 6px;
      border: 1px solid skyblue;
      background-color: rgba(230, 230, 250, 0.2);
      li {
        line-height: 24px;
      }
      li:active {
        background-color: aliceblue;
      }
    }
  }
}
</style>
