<template>
  <el-dropdown trigger="click">
    <span class="el-dropdown-link">
      {{ user }}
      <i class="el-icon-caret-bottom"></i>
    </span>
    <el-dropdown-menu slot="dropdown">
      <el-dropdown-item icon="el-icon-user"
        >用户名：{{ user || "-" }}</el-dropdown-item
      >
      <div @click="onClickLogout">
        <el-dropdown-item><i class="icon-exit" />登出</el-dropdown-item>
      </div>
    </el-dropdown-menu>
  </el-dropdown>
</template>
<script>
import { getUserInfo, logout } from "@/api/login.js";
export default {
  data() {
    return {
      user: "",
    };
  },
  created() {
    this.getUserInfo();
  },
  methods: {
    getUserInfo: async function () {
      try {
        const res = await getUserInfo();
        this.user = res.user;
      } catch (error) {
        this.user = "";
      }
    },
    onClickLogout: async function () {
      await logout();
      this.$router.push("/login");
    },
  },
};
</script>
<style lang="scss" scoped>
.el-dropdown-link {
  color: #fff;
  font-size: 16px;
}
</style>
