<template>
  <div class="plat_ctrl_mode left">
    <JsonSchema
      :jsonData="$store.state.jsonLeftData"
      jsonSchemaId="left"
      :videoUrls="$store.state.videoUrls"
      :videoCheckBox="$store.state.videoCheckBox"
      :videoCheckBoxIndex="$store.state.videoCheckBoxIndex"
      :basicInfo="$store.state.basicInfo"
    />
  </div>
</template>

<script>
import JsonSchema from "@/components/JsonSchema/Index.vue";

export default {
  props: [
    "curCheckList",
    "jsonData",
    "videoUrls",
    "basicInfo",
    "videoCheckBox",
    "videoCheckBoxIndex",
  ],
  data() {
    return {};
  },
  components: {
    JsonSchema,
  },
  mounted() {},
  methods: {},
};
</script>
<style lang="scss" scoped>
@import "./Index.scss";
</style>
