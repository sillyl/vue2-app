<template>
  <div class="cluster_formation">
    <el-steps :active="stepActive" simple finish-status="success">
      <el-step title="设备选择" icon="el-icon-edit"> </el-step>
      <el-step title="队形选择" icon="el-icon-edit"> </el-step>
      <!-- <el-step title="指定地点列队" icon="el-icon-location-information">
      </el-step> -->
      <el-step title="导航任务" icon="el-icon-position"></el-step>
    </el-steps>
    <div class="cluster_formation_step1" v-if="stepActive === 0">
      <div class="cluster_formation_step1_content">
        <TaskForm
          ref="taskRef"
          :optsType="$store.state.curTaskInfo.optsType"
          :updateCurSceneMapObj="updateCurSceneMapObj"
          :deviceCurScenceId="deviceCurScenceId"
          :selectSceneInfo="selectSceneInfo"
          :isCurPage="isCurPage"
          :taskFormData="taskFormData"
        />
      </div>
      <div class="cluster_formation_step1_btns">
        <el-button @click="onStepNext('selectedDevices')" type="primary">
          下一步
        </el-button>
      </div>
    </div>
    <div class="cluster_formation_step0" v-if="stepActive === 1">
      <div class="cluster_formation_step0_content">
        <el-row>
          <el-col :span="8" class="col_left">
            <el-form
              ref="formStep0Ref"
              :rules="rules"
              :model="form"
              label-width="100px"
            >
              <el-form-item label="快捷队形" prop="formation">
                <el-select
                  v-model="form.formation"
                  placeholder="请选择"
                  :disabled="formationType === 'custom'"
                  @change="onChangeFormation"
                >
                  <el-option
                    v-for="item in curFormationList"
                    :key="item.type"
                    :label="item.name"
                    :value="item.type"
                  ></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="自定义队形" prop="customFormation">
                <el-switch
                  v-model="form.customFormation"
                  @change="onChangeSwith"
                />
                <span class="konva_opts_btns">
                  <el-button
                    type="primary"
                    size="small"
                    :disabled="!form.customFormation"
                    @click="onOptsClick('clear')"
                  >
                    清空
                  </el-button>
                  <!-- <el-button
                    type="primary"
                    size="small"
                    :disabled="!form.customFormation"
                    @click="onOptsClick('cancelSave')"
                  >
                    取消连线
                  </el-button>
                  <el-button
                    type="primary"
                    size="small"
                    :disabled="!form.customFormation"
                    @click="onOptsClick('save')"
                  >
                    连线
                  </el-button> -->
                </span>
              </el-form-item>
              <el-form-item prop="spaced">
                <span slot="label">
                  像素比例
                  <el-tooltip
                    class="spaced_tooltip"
                    content="1像素等于xx米"
                    placement="top-start"
                    effect="light"
                  >
                    <i class="el-icon-question"></i>
                  </el-tooltip>
                </span>
                <el-input-number
                  v-model="form.spaced"
                  controls-position="right"
                  :min="0.000001"
                />
              </el-form-item>
            </el-form>
            <div class="cluster_formation_step0_btns">
              <el-button
                @click="onStepBack('selectedFormation')"
                type="primary"
                size="small"
              >
                上一步
              </el-button>
              <el-button
                @click="onStepNext('selectedFormation')"
                type="primary"
                size="small"
              >
                下一步
              </el-button>
            </div>
          </el-col>
          <el-col :span="16" class="col_right">
            <DrawFormations
              ref="drawFormationsRefs"
              :formationType="formationType"
              :pointCounts="pointCounts"
              :curSpaced="curSpaced"
              :curFormationType="curFormationType"
              :drawFormationsData="drawFormationsData"
            />
          </el-col>
        </el-row>
      </div>
    </div>
    <div class="cluster_formation_step2" v-if="stepActive === 2">
      <div class="cluster_formation_step2_content">
        <div>
          设置初始点位列队：
          <el-button type="primary" @click="onInitLocation"> 选点 </el-button>
        </div>
        <div v-if="initFormationStatus">
          <TaskForm
            ref="taskFormationRef"
            :curClusterStep="3"
            :onClickNavPoint="onClickNavPoint"
            :resetMapData="resetMapData"
          />
        </div>
      </div>
      <div class="cluster_formation_step2_btns">
        <el-tooltip
          class="spaced_tooltip"
          :content="
            initFormationStatus
              ? '编队初始点位列队成功，不允许更新编队信息'
              : ''
          "
          placement="top-start"
          effect="light"
        >
          <el-button
            @click="onStepBack('nav')"
            type="primary"
            :disabled="initFormationStatus"
          >
            上一步
          </el-button>
        </el-tooltip>
        <el-button @click="onStepFinished" type="primary"> 完成 </el-button>
      </div>
    </div>
  </div>
</template>

<script>
import TaskForm from "../components/TaskForm/Index.vue";
import DrawFormations from "@/components/DrawFormations/Index.vue";
import { formationList } from "../constants";
import { isEmpty } from "lodash";
import { getDistance } from "@/utils/CoordinatePickupFun.js";

export default {
  props: [
    "resetMapData",
    "updateCurSceneMapObj",
    "deviceCurScenceId",
    "selectSceneInfo",
    "isCurPage",
    "onInitPickup",
    "onClickNavPoint",
    "getCurTaskPoints",
  ],
  data() {
    return {
      stepActive: 0,
      form: {
        formation: "",
        spaced: 0.02,
        customFormation: false,
      },
      rules: {
        spaced: [
          {
            required: true,
            trigger: ["blur", "change"],
          },
        ],
      },
      curFormationList: formationList,
      formationType: "default", // 默认固定的快捷队形， custom: 自定义
      taskFormData: null,
      pointCounts: 0, // 根据设备控制画布点的数量
      curFormationType: "",
      drawFormationsData: null, // 用于存储绘制的队形数据
      ws: null,
      initFormationStatus: false,
    };
  },

  components: { TaskForm, DrawFormations },

  computed: {
    curSpaced: function () {
      return this.form.spaced;
    },
  },

  mounted() {
    this.onWsFormationStatus();
  },

  methods: {
    // 列队ws 上报初始位置列队状态  成功在显示导航相关操作
    onWsFormationStatus: function () {
      const socketUrl = `${this.$store.state.websocketUrl}/cpix/v1.0/websocket/terminal/handle`;
      this.ws = new WebSocket(socketUrl);
      this.ws.onopen = () => {
        console.log(`---WebSocket连接${socketUrl}成功---`);
        this.initFormationStatus = true;
      };

      this.ws.onmessage = (msg) => {
        const msgObj = JSON.parse(msg?.data);
        this.initFormationStatus = msgObj?.status;
      };

      this.ws.onclose = (event) => {
        if (event.wasClean) {
          console.log(
            `[close] Connection closed cleanly, --------, code=${event.code} reason=${event.reason}`
          );
        } else {
          console.log("[close] Connection died, -------");
        }
      };

      this.ws.onerror = (e) => {
        console.log("WebSocket连接失败: " + socketUrl + "code:" + e.code);
      };
    },

    onStepNext: function (curStep) {
      if (curStep === "selectedFormation") {
        const points = this.$refs.drawFormationsRefs.konvaConfig.points;
        if (points?.length <= 0) {
          this.$message({
            type: "warning",
            message: "请绘制队形",
          });
          return;
        }
        this.stepActive += 1;
        this.computedPointsParams(points);
        // 为导航任务上一步 自定义队形数据存储
        if (this.formationType === "custom") {
          this.drawFormationsData =
            this.$refs.drawFormationsRefs.konvaConfig.points;
        }
      }
      if (curStep === "selectedDevices") {
        // 校验必填参数
        const taskRef = this.$refs.taskRef;
        taskRef.$refs.form.validate((valid) => {
          if (valid) {
            const { name, scenceId, deviceIds, teamLeader } = taskRef.form;
            console.log("taskRef.form", taskRef.form);
            this.taskFormData = {
              form: taskRef.form,
              teamLeaderList: taskRef.teamLeaderList,
            };

            if (
              this.formationType === "custom" &&
              !isEmpty(this.drawFormationsData)
            ) {
              this.curFormationType = "saveDrawCustom";
            }
            if (taskRef?.isDeviceIdsDecline) {
              // 更新设备数量 数量减少 重置选择的队形
              this.form.formation = "";
              this.curFormationType = "";
            }
            // 根据选择设备数量 过滤队形列表，并统计点的数量
            const len = deviceIds?.length;
            this.pointCounts = len;
            this.curFormationList = formationList?.filter(
              (i) => i.count === len || i.count === -1
            );
            this.stepActive += 1;
          } else {
            return false;
          }
        });
      }
    },

    computedPointsParams: function (points) {
      const len = points?.length;
      let pointsPrams = [{ ...points[0] }];
      const forLen =
        this.curFormationType !== "line" ? points.length - 1 : points.length;
      for (let i = 1; i < forLen; i++) {
        let instance = getDistance(points[0], points[i]);
        const realInstance = (instance * this.curSpaced)?.toFixed(2);
        instance = instance.toFixed(2);
        const angle =
          Math.atan2(points[i].y - points[0].y, points[i].x - points[0].x) /
          (Math.PI / 180);
        pointsPrams.push({
          ...points[i],
          realInstance,
          angle,
        });
      }
      if (this.curFormationType !== "line" && len > 2) {
        // 有闭合且点两个以上
        let instance = getDistance(points[0], points[len - 1]);
        const realInstance = (instance * this.curSpaced)?.toFixed(2);
        instance = instance.toFixed(2);
        const angle =
          Math.atan2(
            points[len - 1].y - points[0].y,
            points[len - 1].x - points[0].x
          ) /
          (Math.PI / 180);
        pointsPrams.push({
          ...points[len - 1],
          realInstance,
          angle,
        });
      }

      console.log("pointsPrams", pointsPrams);
    },

    onStepBack: function (curStep) {
      if (curStep === "selectedFormation") {
        this.drawFormationsData =
          this.$refs.drawFormationsRefs.konvaConfig.points;
      }
      if (curStep === "nav") {
        if (
          this.formationType === "custom" &&
          !isEmpty(this.drawFormationsData)
        ) {
          this.curFormationType = "saveDrawCustom";
        }
        if (this.onInitPickup) {
          this.onInitPickup();
        }
      }
      this.stepActive -= 1;
    },

    onStepFinished: function () {
      if (this.getCurTaskPoints) {
        const res = this.getCurTaskPoints();
        console.log("res", res);
      }
    },
    onChangeSwith: function (e) {
      if (e) {
        // 开启自定义队列 清空快捷队列数据
        this.formationType = "custom";
        this.form.formation = "";
        this.curFormationType = "";
      } else {
        // 关闭自定义队列 恢复快捷队列的 默认队列
        this.formationType = "default";
      }
      this.clearFormations();
    },

    onOptsClick: function (type) {
      switch (type) {
        case "clear": // 清空
          this.clearFormations();
          break;
        case "cancelSave": // 取消保存
          this.$refs?.drawFormationsRefs?.cancelSaveFormations();
          break;
        default: // 保存
          this.$refs?.drawFormationsRefs?.saveFormations();
          break;
      }
    },

    clearFormations: function () {
      this.$refs?.drawFormationsRefs?.clearFormations();
    },

    onChangeFormation: function () {
      // 根据选择快捷队形绘制 默认队形
      this.curFormationType = this.form.formation;
    },

    onInitLocation: function () {
      this.onInitPickup(true);
    },

    onCloseWs: function () {
      if (this.ws) {
        this.ws.close();
        this.ws = null;
      }
    },

    destroyed() {
      this.onCloseWs();
    },
  },
};
</script>

<style lang="scss" scoped>
@import "./Index.scss";
</style>
