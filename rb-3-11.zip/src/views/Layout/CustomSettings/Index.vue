<template>
  <span>
    <i class="el-icon-setting" @click="onClickSettings"></i>
    <el-dialog
      title="系统设置"
      :visible.sync="dialogVisible"
      width="200"
      :modal-append-to-body="false"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="sys_content">
        <el-alert
          title="点击确定保存系统设置！！！"
          type="warning"
          :closable="false"
        >
        </el-alert>
        <p>场景列表过滤条件</p>
        <el-radio-group v-model="isSceneFilter">
          <el-radio label="Open">Open</el-radio>
          <el-radio label="Close">Close</el-radio>
        </el-radio-group>
        <p>
          摇杆显示 : <el-switch :value="nippleVal" @change="onChangeNipple" />
        </p>
        <!-- <p>
          全屏：
          <el-switch v-model="sysFull"> </el-switch>
        </p> -->
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="onCancel">取 消</el-button>
        <el-button type="primary" @click="onSysOk">确 定</el-button>
      </span>
    </el-dialog>
  </span>
</template>
<script>
import {
  localStorageSetItem,
  localStorageGetItem,
} from "@/utils/localStorageFun.js";
export default {
  props: [],
  data() {
    return {
      dialogVisible: false,
      isSceneFilter: "Open",
      nippleVal: false,
      // sysFull: false,
    };
  },
  mounted() {
    this.isSceneFilter = localStorageGetItem("isSceneFilter") || "Open";
    this.nippleVal = localStorageGetItem("nippleVal") || false;
  },

  methods: {
    onClickSettings: function () {
      this.dialogVisible = true;
      // 监听esc 按键 控制系统设置全屏 开关
      // if (this.$store.state.sysFull) {
      //   this.sysFull = false;
      // }
    },
    onCancel: function () {
      this.dialogVisible = false;
      this.isSceneFilter = localStorageGetItem("isSceneFilter") || "Open";
      this.nippleVal = localStorageGetItem("nippleVal") || false;
    },
    onSysOk() {
      localStorageSetItem("isSceneFilter", this.isSceneFilter);
      localStorageSetItem("nippleVal", this.nippleVal);
      this.$store.commit("updateisShowNippleVal", this.nippleVal);
      this.dialogVisible = false;
      // this.changeSysFull();
    },
    onChangeNipple: function (e) {
      this.nippleVal = e;
    },
    // changeSysFull: function () {
    //   if (this.sysFull) {
    //     this.fullscreenFunc();
    //     this.$store.commit("updateSysFull", false);
    //   } else {
    //     this.$fullscreen.exit();
    //     this.$store.commit("updateSysFull", true);
    //   }
    // },

    // fullscreenFunc: function () {
    //   // let dom = document.querySelector("#app");
    //   const dom = document.documentElement;
    //   if (dom) {
    //     this.$fullscreen.enter(dom, {
    //       wrap: false,
    //       callback: (f) => {
    //         this.fullscreenFlag = f;
    //       },
    //     });
    //   }
    // },
  },

  destroyed() {
    this.sysFull = false;
  },
};
</script>
<style lang="scss" scoped>
.el-icon-setting {
  color: aliceblue;
  margin: 0 20px;
  font-size: 16px;
}
.sys_content {
  p {
    margin: 16px 0 12px 0;
  }

  .el-alert {
    margin-bottom: 8px;
  }
}
::v-deep {
  .el-dialog__body {
    padding: 5px 20px;
  }
}
</style>
