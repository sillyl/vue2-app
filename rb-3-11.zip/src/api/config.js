import { axiosWarpInstance } from "@/utils/axiosInstance.js";

export const getConfigJsonSchema = async (data) => {
  const res = await axiosWarpInstance(
    `/cpix/v1.0/configure/device/common/scada/${data?.id}`,
    {},
    { type: "get" }
  );
  // const res = {
  //   page: [
  //     {
  //       id: 1,
  //       name: "底盘控制",
  //     },
  //     {
  //       id: 2,
  //       name: "机械臂智能模式",
  //     },
  //     {
  //       id: 3,
  //       name: "机械臂控制模式",
  //     },
  //   ],
  //   function: [
  //     {
  //       split: 10,
  //       pageId: 1,
  //       layout: "left",
  //     },
  //     {
  //       id: 911,
  //       name: "底盘灯",
  //       enable: true,
  //       type: 2,
  //       pageId: 1,
  //       layout: "left",
  //       packages: [
  //         {
  //           name: "开灯",
  //           action: 8,
  //         },
  //         {
  //           name: "关灯",
  //           action: 9,
  //         },
  //       ],
  //     },
  //     {
  //       id: 921,
  //       name: "底盘速度",
  //       enable: true,
  //       type: 1,
  //       pageId: 1,
  //       layout: "left",
  //       packages: [
  //         {
  //           name: "",
  //           action: 9,
  //           unit: [
  //             {
  //               name: "低档",
  //               value: 1,
  //             },
  //             {
  //               name: "高档",
  //               value: 2,
  //             },
  //           ],
  //         },
  //       ],
  //     },
  //     {
  //       id: 101,
  //       name: "智能底盘",
  //       enable: true,
  //       type: 4,
  //       pageId: 1,
  //       layout: "left",
  //       packages: [
  //         {
  //           name: "自主上楼",
  //           action: 1,
  //         },
  //         {
  //           name: "自主下楼",
  //           action: 2,
  //         },
  //         {
  //           name: "自主越障",
  //           action: 3,
  //         },
  //         {
  //           name: "自主越沟",
  //           action: 4,
  //         },
  //       ],
  //     },
  //     {
  //       id: 111,
  //       name: "摆臂姿态",
  //       enable: true,
  //       type: 3,
  //       pageId: 1,
  //       layout: "left",
  //       packages: [
  //         {
  //           name: "上楼",
  //           action: 14,
  //         },
  //         {
  //           name: "下楼",
  //           action: 15,
  //         },
  //         {
  //           name: "收起",
  //           action: 16,
  //         },
  //         {
  //           name: "平位",
  //           action: 17,
  //         },
  //       ],
  //     },
  //     {
  //       split: 10,
  //       pageId: 1,
  //       layout: "left",
  //     },
  //     {
  //       id: 112,
  //       name: "前摆臂",
  //       enable: true,
  //       type: 2,
  //       pageId: 1,
  //       layout: "left",
  //       groupId: 1,
  //       groupName: "摆臂控制",
  //       packages: [
  //         {
  //           name: "上摆",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "下摆",
  //           action: 4,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 113,
  //       name: "后摆臂",
  //       enable: true,
  //       type: 2,
  //       pageId: 1,
  //       layout: "left",
  //       groupId: 1,
  //       groupName: "摆臂控制",
  //       packages: [
  //         {
  //           name: "上摆",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "下摆",
  //           action: 4,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 111,
  //       name: "整体",
  //       enable: true,
  //       type: 2,
  //       pageId: 1,
  //       layout: "left",
  //       groupId: 1,
  //       groupName: "摆臂控制",
  //       packages: [
  //         {
  //           name: "上摆",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "下摆",
  //           action: 4,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       split: 10,
  //       pageId: 1,
  //       layout: "left",
  //     },
  //     {
  //       id: 101,
  //       name: "方向控制",
  //       enable: true,
  //       type: 1,
  //       pageId: 1,
  //       layout: "left",
  //       eventType: "press",
  //       packages: [
  //         {
  //           name: "",
  //           action: 99,
  //         },
  //         {
  //           name: "右转",
  //           action: 4,
  //         },
  //         {
  //           name: "",
  //           action: 99,
  //         },
  //         {
  //           name: "左转",
  //           action: 3,
  //         },
  //       ],
  //     },
  //     {
  //       id: 941,
  //       enable: true,
  //       type: 5,
  //       pageId: 1,
  //       layout: "right",
  //       groupId: 2,
  //       groupName: "云台视频控制",
  //       packages: [
  //         {
  //           name: "云台视频",
  //           action: 1,
  //         },
  //       ],
  //     },
  //     {
  //       id: 211,
  //       name: "云台控制",
  //       enable: true,
  //       type: 2,
  //       pageId: 1,
  //       layout: "right",
  //       groupId: 2,
  //       groupName: "云台视频控制",
  //       packages: [
  //         {
  //           name: "",
  //           action: 10,
  //           eventType: "press",
  //         },
  //         {
  //           name: "",
  //           action: 11,
  //           eventType: "press",
  //         },
  //         {
  //           name: "",
  //           action: 12,
  //           eventType: "press",
  //         },
  //         {
  //           name: "",
  //           action: 13,
  //           eventType: "press",
  //         },
  //         {
  //           name: "",
  //           action: 14,
  //           eventType: "press",
  //         },
  //         {
  //           name: "",
  //           action: 15,
  //           eventType: "press",
  //         },
  //         {
  //           name: "",
  //           action: 16,
  //           eventType: "press",
  //         },
  //         {
  //           name: "",
  //           action: 17,
  //           eventType: "press",
  //         },
  //         {
  //           name: "",
  //           action: 18,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 941,
  //       enable: true,
  //       type: 5,
  //       pageId: 1,
  //       layout: "right",
  //       groupId: 3,
  //       groupName: "底盘视频控制",
  //       packages: [
  //         {
  //           name: "底盘视频",
  //           action: 2,
  //         },
  //       ],
  //     },
  //     {
  //       id: 951,
  //       name: "视频模式",
  //       enable: true,
  //       type: 3,
  //       pageId: 1,
  //       layout: "right",
  //       groupId: 3,
  //       groupName: "底盘视频控制",
  //       packages: [
  //         {
  //           name: "分屏切换",
  //           action: 14,
  //         },
  //         {
  //           name: "单屏切换",
  //           action: 15,
  //         },
  //         {
  //           name: "Head切换",
  //           action: 16,
  //         },
  //         {
  //           name: "Car切换",
  //           action: 17,
  //         },
  //       ],
  //     },
  //     {
  //       id: 101,
  //       name: "方向控制",
  //       enable: true,
  //       type: 1,
  //       pageId: 1,
  //       layout: "right",
  //       eventType: "press",
  //       packages: [
  //         {
  //           name: "前进",
  //           action: 1,
  //         },
  //         {
  //           name: "",
  //           action: 99,
  //         },
  //         {
  //           name: "后退",
  //           action: 2,
  //         },
  //         {
  //           name: "",
  //           action: 99,
  //         },
  //       ],
  //     },
  //     {
  //       split: 220,
  //       pageId: 2,
  //       layout: "left",
  //     },
  //     {
  //       id: 301,
  //       name: "智能左臂",
  //       enable: true,
  //       type: 4,
  //       pageId: 2,
  //       layout: "left",
  //       packages: [
  //         {
  //           name: "自主抓取",
  //           action: 1,
  //         },
  //         {
  //           name: "自主开门",
  //           action: 2,
  //         },
  //       ],
  //     },
  //     {
  //       split: 10,
  //       pageId: 2,
  //       layout: "left",
  //     },
  //     {
  //       id: 301,
  //       name: "左臂姿态",
  //       enable: true,
  //       type: 3,
  //       pageId: 2,
  //       layout: "left",
  //       packages: [
  //         {
  //           name: "零状态",
  //           action: 14,
  //         },
  //         {
  //           name: "归位",
  //           action: 15,
  //         },
  //         {
  //           name: "平抓",
  //           action: 16,
  //         },
  //         {
  //           name: "下抓",
  //           action: 17,
  //         },
  //       ],
  //     },
  //     {
  //       split: 10,
  //       pageId: 2,
  //       layout: "left",
  //     },
  //     {
  //       id: 301,
  //       name: "姿态运动",
  //       enable: true,
  //       type: 3,
  //       pageId: 2,
  //       layout: "left",
  //       groupId: 5,
  //       groupName: "左臂姿态控制",
  //       packages: [
  //         {
  //           name: "前移",
  //           action: 1,
  //           eventType: "press",
  //         },
  //         {
  //           name: "后移",
  //           action: 2,
  //           eventType: "press",
  //         },
  //         {
  //           name: "左移",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "右移",
  //           action: 4,
  //           eventType: "press",
  //         },
  //         {
  //           name: "上移",
  //           action: 5,
  //           eventType: "press",
  //         },
  //         {
  //           name: "下移",
  //           action: 6,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 391,
  //       name: "夹爪控制",
  //       enable: true,
  //       type: 2,
  //       pageId: 2,
  //       layout: "left",
  //       groupId: 5,
  //       groupName: "左臂姿态控制",
  //       packages: [
  //         {
  //           name: "张开",
  //           action: 5,
  //           eventType: "press",
  //         },
  //         {
  //           name: "合拢",
  //           action: 6,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 941,
  //       enable: true,
  //       type: 5,
  //       pageId: 2,
  //       layout: "right",
  //       groupId: 4,
  //       groupName: "底盘视频控制",
  //       packages: [
  //         {
  //           name: "底盘视频",
  //           action: 2,
  //         },
  //       ],
  //     },
  //     {
  //       id: 951,
  //       name: "视频模式",
  //       enable: true,
  //       type: 3,
  //       pageId: 2,
  //       layout: "right",
  //       groupId: 4,
  //       groupName: "底盘视频控制",
  //       packages: [
  //         {
  //           name: "分屏切换",
  //           action: 14,
  //         },
  //         {
  //           name: "单屏切换",
  //           action: 15,
  //         },
  //         {
  //           name: "Head切换",
  //           action: 16,
  //         },
  //         {
  //           name: "Car切换",
  //           action: 17,
  //         },
  //       ],
  //     },
  //     {
  //       split: 10,
  //       pageId: 2,
  //       layout: "right",
  //     },
  //     {
  //       id: 302,
  //       name: "智能右臂",
  //       enable: true,
  //       type: 4,
  //       pageId: 2,
  //       layout: "right",
  //       packages: [
  //         {
  //           name: "自主抓取",
  //           action: 1,
  //         },
  //         {
  //           name: "自主开门",
  //           action: 2,
  //         },
  //       ],
  //     },
  //     {
  //       split: 10,
  //       pageId: 2,
  //       layout: "right",
  //     },
  //     {
  //       id: 302,
  //       name: "右臂姿态",
  //       enable: true,
  //       type: 3,
  //       pageId: 2,
  //       layout: "right",
  //       packages: [
  //         {
  //           name: "零状态",
  //           action: 14,
  //         },
  //         {
  //           name: "归位",
  //           action: 15,
  //         },
  //         {
  //           name: "平抓",
  //           action: 16,
  //         },
  //         {
  //           name: "下抓",
  //           action: 17,
  //         },
  //       ],
  //     },
  //     {
  //       split: 10,
  //       pageId: 2,
  //       layout: "right",
  //     },
  //     {
  //       id: 302,
  //       name: "姿态运动",
  //       enable: true,
  //       type: 3,
  //       pageId: 2,
  //       layout: "right",
  //       groupId: 5,
  //       groupName: "右臂姿态控制",
  //       packages: [
  //         {
  //           name: "前移",
  //           action: 1,
  //           eventType: "press",
  //         },
  //         {
  //           name: "后移",
  //           action: 2,
  //           eventType: "press",
  //         },
  //         {
  //           name: "左移",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "右移",
  //           action: 4,
  //           eventType: "press",
  //         },
  //         {
  //           name: "上移",
  //           action: 5,
  //           eventType: "press",
  //         },
  //         {
  //           name: "下移",
  //           action: 6,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 392,
  //       name: "夹爪控制",
  //       enable: true,
  //       type: 2,
  //       pageId: 2,
  //       layout: "right",
  //       groupId: 5,
  //       groupName: "右臂姿态控制",
  //       packages: [
  //         {
  //           name: "张开",
  //           action: 5,
  //           eventType: "press",
  //         },
  //         {
  //           name: "合拢",
  //           action: 6,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       split: 210,
  //       pageId: 3,
  //       layout: "left",
  //     },
  //     {
  //       id: 311,
  //       name: "大臂旋转",
  //       enable: true,
  //       type: 2,
  //       pageId: 3,
  //       layout: "left",
  //       groupId: 6,
  //       groupName: "左臂关节控制",
  //       packages: [
  //         {
  //           name: "正旋",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "逆旋",
  //           action: 4,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 321,
  //       name: "大臂俯仰",
  //       enable: true,
  //       type: 2,
  //       pageId: 3,
  //       layout: "left",
  //       groupId: 6,
  //       groupName: "左臂关节控制",
  //       packages: [
  //         {
  //           name: "前进",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "后退",
  //           action: 4,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 331,
  //       name: "小臂旋转",
  //       enable: true,
  //       type: 2,
  //       pageId: 3,
  //       layout: "left",
  //       groupId: 6,
  //       groupName: "左臂关节控制",
  //       packages: [
  //         {
  //           name: "正旋",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "逆旋",
  //           action: 4,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 341,
  //       name: "小臂俯仰",
  //       enable: true,
  //       type: 2,
  //       pageId: 3,
  //       layout: "left",
  //       groupId: 6,
  //       groupName: "左臂关节控制",
  //       packages: [
  //         {
  //           name: "前进",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "后退",
  //           action: 4,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 351,
  //       name: "手腕旋转",
  //       enable: true,
  //       type: 2,
  //       pageId: 3,
  //       layout: "left",
  //       groupId: 6,
  //       groupName: "左臂关节控制",
  //       packages: [
  //         {
  //           name: "正旋",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "逆旋",
  //           action: 4,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 361,
  //       name: "手腕俯仰",
  //       enable: true,
  //       type: 2,
  //       pageId: 3,
  //       layout: "left",
  //       groupId: 6,
  //       groupName: "左臂关节控制",
  //       packages: [
  //         {
  //           name: "前进",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "后退",
  //           action: 4,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 391,
  //       name: "夹爪控制",
  //       enable: true,
  //       type: 2,
  //       pageId: 3,
  //       layout: "left",
  //       groupId: 6,
  //       groupName: "左臂关节控制",
  //       packages: [
  //         {
  //           name: "张开",
  //           action: 5,
  //           eventType: "press",
  //         },
  //         {
  //           name: "合拢",
  //           action: 6,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 941,
  //       enable: true,
  //       type: 5,
  //       pageId: 3,
  //       layout: "right",
  //       groupId: 7,
  //       groupName: "底盘视频控制",
  //       packages: [
  //         {
  //           name: "底盘视频",
  //           action: 2,
  //         },
  //       ],
  //     },
  //     {
  //       id: 951,
  //       name: "视频模式",
  //       enable: true,
  //       type: 3,
  //       pageId: 3,
  //       layout: "right",
  //       groupId: 7,
  //       groupName: "底盘视频控制",
  //       packages: [
  //         {
  //           name: "分屏切换",
  //           action: 14,
  //         },
  //         {
  //           name: "单屏切换",
  //           action: 15,
  //         },
  //         {
  //           name: "Head切换",
  //           action: 16,
  //         },
  //         {
  //           name: "Car切换",
  //           action: 17,
  //         },
  //       ],
  //     },
  //     {
  //       split: 10,
  //       pageId: 3,
  //       layout: "right",
  //     },
  //     {
  //       id: 312,
  //       name: "大臂旋转",
  //       enable: true,
  //       type: 2,
  //       pageId: 3,
  //       layout: "right",
  //       groupId: 8,
  //       groupName: "右臂关节控制",
  //       packages: [
  //         {
  //           name: "正旋",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "逆旋",
  //           action: 4,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 322,
  //       name: "大臂俯仰",
  //       enable: true,
  //       type: 2,
  //       pageId: 3,
  //       layout: "right",
  //       groupId: 8,
  //       groupName: "右臂关节控制",
  //       packages: [
  //         {
  //           name: "前进",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "后退",
  //           action: 4,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 332,
  //       name: "小臂旋转",
  //       enable: true,
  //       type: 2,
  //       pageId: 3,
  //       layout: "right",
  //       groupId: 8,
  //       groupName: "右臂关节控制",
  //       packages: [
  //         {
  //           name: "正旋",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "逆旋",
  //           action: 4,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 342,
  //       name: "小臂俯仰",
  //       enable: true,
  //       type: 2,
  //       pageId: 3,
  //       layout: "right",
  //       groupId: 8,
  //       groupName: "右臂关节控制",
  //       packages: [
  //         {
  //           name: "前进",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "后退",
  //           action: 4,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 352,
  //       name: "手腕旋转",
  //       enable: true,
  //       type: 2,
  //       pageId: 3,
  //       layout: "right",
  //       groupId: 8,
  //       groupName: "右臂关节控制",
  //       packages: [
  //         {
  //           name: "正旋",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "逆旋",
  //           action: 4,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 362,
  //       name: "手腕俯仰",
  //       enable: true,
  //       type: 2,
  //       pageId: 3,
  //       layout: "right",
  //       groupId: 8,
  //       groupName: "右臂关节控制",
  //       packages: [
  //         {
  //           name: "前进",
  //           action: 3,
  //           eventType: "press",
  //         },
  //         {
  //           name: "后退",
  //           action: 4,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //     {
  //       id: 391,
  //       name: "夹爪控制",
  //       enable: true,
  //       type: 2,
  //       pageId: 3,
  //       layout: "right",
  //       groupId: 8,
  //       groupName: "右臂关节控制",
  //       packages: [
  //         {
  //           name: "张开",
  //           action: 5,
  //           eventType: "press",
  //         },
  //         {
  //           name: "合拢",
  //           action: 6,
  //           eventType: "press",
  //         },
  //       ],
  //     },
  //   ],
  // };
  return res;
};
