import { axiosWarpInstance } from "@/utils/axiosInstance.js";

// 获取设备支持的ros 节点
export const getRosNode = (data) => {
  const res = axiosWarpInstance(
    `/cpix/v1.0/configure/device/consumer/rosNode/list`,
    data,
    {
      type: "get",
    }
  );
  return res;
};

// 启用节点
export const enableNode = (data) => {
  const res = axiosWarpInstance(
    `/cpix/v1.0/configure/device/consumer/rosNode/setting/${data.id}`,
    data.nodeNames,
    {
      type: "post",
    }
  );

  return res;
};

// 重启节点
export const restartNode = (data) => {
  const res = axiosWarpInstance(
    `/cpix/v1.0/configure/device/consumer/rosNode/restart/${data.id}`,
    data.name,
    {
      type: "post",
    }
  );

  return res;
};
