import { axiosWarpInstance } from "@/utils/axiosInstance.js";

// 获取本账号订阅列表
export const getSubscribeList = (data) => {
  const res = axiosWarpInstance(
    "/cpix/v1.0/configure/subscribe/consumer/list",
    {},
    {
      type: "get",
    }
  );
  return res;
};

// 获取订阅服务列表
export const getSubscribeServerList = (data) => {
  const res = axiosWarpInstance(
    "/cpix/v1.0/configure/subscribeserver/common/list",
    {},
    {
      type: "get",
    }
  );
  return res;
};

export const addSubscribe = (data) => {
  const res = axiosWarpInstance(
    "/cpix/v1.0/configure/subscribe/consumer/add",
    data,
    {
      type: "post",
    }
  );
  return res;
};

export const updateSubscribe = (data) => {
  const res = axiosWarpInstance(
    "/cpix/v1.0/configure/subscribe/consumer/update",
    data,
    {
      type: "post",
    }
  );
  return res;
};

export const deleteSubscribe = (data) => {
  const res = axiosWarpInstance(
    `/cpix/v1.0/configure/subscribe/consumer/delete/${data.id}`,
    data,
    {
      type: "delete",
    }
  );
  return res;
};
